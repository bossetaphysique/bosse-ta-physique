# Bosse ta Physique

Application de coaching pour la terminale spécialité physique-chimie.

## Démarrer

```bash
npm install
npm run dev
```

## Vérifier avant de déployer

```bash
npm run verifier
```

Cette commande enchaîne les deux filets de sécurité. **Ne déployez pas si l'un
des deux signale une erreur.**

### `npm run test` — le moteur de planification

Environ 900 invariants sur le calcul du planning : durée des séances, niveau des
exercices, sujets de synthèse, restitutions, quotas, rattrapage. Instantané.

### `npm run parcours` — l'application entière

Pilote l'interface comme le ferait un élève, sur cinq parcours complets : un
chapitre sur une semaine et demie, deux chapitres menés de front, des soirées
sautées puis rattrapées, une modification des réglages, l'espace coach.

À chaque écran traversé, trois contrôles automatiques :

- aucun texte fautif affiché — `undefined`, `NaN`, `[object Object]` ;
- aucun bouton sans action ;
- la navigation répond toujours.

Compte environ deux minutes. C'est ce filet qui attrape les défauts d'interface
que les tests du moteur ne peuvent pas voir.

## Où est quoi

| Chemin | Contenu |
|---|---|
| `src/App.jsx` | toute l'interface, élève et coach |
| `src/lib/planning.js` | le moteur : ce qui décide du programme de chaque soir |
| `src/lib/planning.test.js` | les invariants du moteur |
| `src/data/banques.js` | les 703 questions flash, 22 chapitres |
| `scripts/parcours.mjs` | le banc d'essai de l'application |
| `scripts/verifier-banque.mjs` | contrôle une banque de questions avant intégration |
| `public/figures/` | les figures des questions |
