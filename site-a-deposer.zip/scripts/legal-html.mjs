/* ═══════════════════════════════════════════════════════════════════════════
   LES DEUX PAGES LÉGALES AUTONOMES — « public/cgv.html » et
   « public/confidentialite.html ».

   La page de réservation est un fichier isolé : elle ne charge pas
   l'application, donc elle ne peut pas ouvrir « PageLegale ». Un parent qui
   veut lire les conditions avant de payer n'a rien à installer ni à ouvrir :
   il lui faut deux adresses qui s'ouvrent seules.

   Ces deux pages sont fabriquées à partir de « src/data/legal.js », le même
   fichier que lit l'application. Un seul texte, deux rendus : une correction
   des CGV se répercute partout dès la publication suivante.

       npm run legal

   ═══════════════════════════════════════════════════════════════════════════ */

import { writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { CGV, CONFIDENTIALITE } from "../src/data/legal.js";

const ici = dirname(fileURLToPath(import.meta.url));
const racine = join(ici, "..");

/* ── Les caractères qui ont un sens en HTML ────────────────────────────── */
const echapper = (t) => String(t)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/* Le gras du Markdown, appliqué après l'échappement. */
const gras = (t) => echapper(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");

/* ── Le même sous-ensemble de Markdown que « legal.jsx » ───────────────── */
function rendre(texte) {
  const sortie = [];
  let liste = null, tableau = null;

  const fermer = () => {
    if (liste) {
      sortie.push("<ul>" + liste.map((i) => `<li>${gras(i)}</li>`).join("")
                + "</ul>");
      liste = null;
    }
    if (tableau) {
      const [entete, ...corps] = tableau;
      /* Chaque cellule porte le nom de sa colonne : sur un téléphone, la
         feuille de style empile les lignes et réaffiche ce nom devant la
         valeur. Un tableau de tarifs doit rester lisible sans faire glisser
         l'écran de côté. */
      const cellule = (c, i) =>
        `<td data-entete="${echapper(String(entete[i] || "")
          .replace(/\*\*/g, "")).replace(/"/g, "&quot;")}">${gras(c)}</td>`;
      sortie.push(
        '<div class="tableau"><table><thead><tr>'
        + entete.map((c) => `<th>${gras(c)}</th>`).join("")
        + "</tr></thead><tbody>"
        + corps.map((r) => "<tr>" + r.map(cellule).join("") + "</tr>").join("")
        + "</tbody></table></div>");
      tableau = null;
    }
  };

  String(texte).split("\n").forEach((ligne) => {
    const t = ligne.trim();
    if (!t) { fermer(); return; }

    if (/^\|/.test(t)) {
      if (liste) fermer();
      /* la ligne de séparation |---|---| ne porte rien à afficher */
      if (/^[|\s:-]+$/.test(t)) return;
      (tableau = tableau || []).push(
        t.replace(/^\||\|$/g, "").split("|").map((c) => c.trim()));
      return;
    }
    if (/^- /.test(t)) {
      if (tableau) fermer();
      (liste = liste || []).push(t.slice(2));
      return;
    }

    fermer();
    if (/^---+$/.test(t)) { sortie.push("<hr />"); return; }
    if (/^### /.test(t)) { sortie.push(`<h3>${gras(t.slice(4))}</h3>`); return; }
    if (/^## /.test(t))  { sortie.push(`<h2>${gras(t.slice(3))}</h2>`); return; }
    if (/^# /.test(t))   { sortie.push(`<h1>${gras(t.slice(2))}</h1>`); return; }
    sortie.push(`<p>${gras(t)}</p>`);
  });

  fermer();
  return sortie.join("\n");
}

/* ── L'habillage, repris de la page de réservation ─────────────────────── */
const page = ({ titre, description, corps, jumeau }) => `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>${titre} — Bosse ta Physique</title>
<meta name="description" content="${description}" />
<meta name="theme-color" content="#F1F4FE" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=DM+Sans:opsz,wght@9..40,400;9..40,500&family=IBM+Plex+Mono:wght@500&display=swap" rel="stylesheet" />
<style>
:root{
  --bg:#F1F4FE; --surface:#FFF; --ink:#0E1132; --ink-soft:#565E80;
  --accent:#6C63FF; --accent-2:#4E7EF3; --line:#E3E8F7;
  --fd:'Poppins',system-ui,sans-serif; --fb:'DM Sans',system-ui,sans-serif;
  --fm:'IBM Plex Mono',ui-monospace,monospace;
}
*{box-sizing:border-box;margin:0;padding:0}
html{-webkit-text-size-adjust:100%}
body{background:var(--bg);color:var(--ink-soft);font-family:var(--fb);font-size:16px;
  line-height:1.65;overflow-wrap:break-word;color-scheme:light}
.wrap{max-width:680px;margin-inline:auto;padding-inline:18px}
header{background:rgba(241,244,254,.94);backdrop-filter:blur(10px);
  border-bottom:1px solid var(--line);padding:14px 0;
  padding-top:calc(14px + env(safe-area-inset-top));position:sticky;top:0;z-index:20}
.logo{display:flex;align-items:center;gap:11px;text-decoration:none}
.logo svg{width:34px;height:34px;border-radius:9px;flex:none}
.logo b{font-family:var(--fd);font-size:1rem;color:var(--ink);line-height:1.05}
.logo b span{display:block;color:var(--accent)}
main{padding-top:24px;padding-bottom:calc(46px + env(safe-area-inset-bottom))}
.eyebrow{font-family:var(--fm);font-size:.66rem;letter-spacing:.2em;
  text-transform:uppercase;color:var(--accent-2)}
.card{background:var(--surface);border:1px solid var(--line);border-radius:18px;
  box-shadow:0 8px 24px rgba(14,17,50,.05);padding:24px 22px;margin-top:14px}
h1{font-family:var(--fd);font-weight:700;font-size:1.45rem;color:var(--ink);
  letter-spacing:-.02em;line-height:1.2;margin:0 0 4px}
h2{font-family:var(--fd);font-weight:600;font-size:1.06rem;color:var(--ink);
  margin:24px 0 6px;scroll-margin-top:80px}
h3{font-family:var(--fd);font-weight:600;font-size:.96rem;color:var(--ink);
  margin:17px 0 4px}
p{font-size:.9rem;margin:9px 0}
ul{margin:7px 0 7px 19px}
li{font-size:.9rem;margin:4px 0}
hr{border:0;border-top:1px solid var(--line);margin:20px 0}
b{color:var(--ink)}
.tableau{margin:12px 0}
table{border-collapse:collapse;width:100%}
th,td{padding:8px 10px;border-bottom:1px solid var(--line);font-size:.85rem;
  vertical-align:top;text-align:left}
th{color:var(--ink);font-weight:600;border-bottom:1.5px solid var(--line)}
/* Sur un téléphone, les colonnes deviennent des lignes : chaque valeur est
   précédée du nom de sa colonne. Rien à faire glisser de côté. */
@media(max-width:560px){
  table,tbody,tr,td{display:block;width:100%}
  thead{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);
    white-space:nowrap}
  tr{border:1px solid var(--line);border-radius:12px;padding:4px 2px;margin:9px 0}
  td{border:0;padding:5px 12px}
  td+td{border-top:1px dashed var(--line)}
  td::before{content:attr(data-entete);display:block;font-family:var(--fm);
    font-size:.6rem;letter-spacing:.12em;text-transform:uppercase;
    color:var(--accent-2);margin-bottom:2px}
  td[data-entete=""]::before{display:none}
}
.retour{display:inline-block;background:var(--surface);border:1px solid var(--line);
  border-radius:999px;padding:9px 18px;font-family:var(--fd);font-weight:600;
  font-size:.86rem;color:var(--ink);text-decoration:none;
  box-shadow:0 4px 14px rgba(14,17,50,.06)}
.retour:hover{border-color:var(--accent)}
.jumeau{margin-top:18px;text-align:center;font-size:.84rem}
.jumeau a{color:var(--accent);text-decoration:underline}
footer{margin-top:26px;text-align:center;font-size:.8rem;opacity:.75}
footer a{color:var(--ink-soft)}
@media(min-width:700px){ body{font-size:17px} .card{padding:28px 26px} }
@media print{
  header,.retour,.jumeau,footer{display:none}
  body{background:#fff} .card{border:0;box-shadow:none;padding:0}
}
</style>
</head>
<body>

<header>
  <div class="wrap">
    <a class="logo" href="paiement.html">
      <svg viewBox="0 0 64 64" fill="none" aria-hidden="true">
        <rect width="64" height="64" rx="16" fill="#6C63FF"/>
        <g fill="none" stroke="#FFFFFF" stroke-width="4">
          <ellipse cx="32" cy="32" rx="22" ry="8"/>
          <ellipse cx="32" cy="32" rx="22" ry="8" transform="rotate(60 32 32)"/>
          <ellipse cx="32" cy="32" rx="22" ry="8" transform="rotate(-60 32 32)"/>
        </g>
        <circle cx="32" cy="32" r="7" fill="#E7B24E"/>
      </svg>
      <b>Bosse ta<span>Physique</span></b>
    </a>
  </div>
</header>

<main class="wrap">
  <a class="retour" href="paiement.html">← Retour à la réservation</a>
  <div class="card">
${corps}
  </div>
  <p class="jumeau">À lire également :
    <a href="${jumeau.lien}">${jumeau.titre}</a>.</p>
  <footer>
    <p>Bosse ta Physique — Nicolas Vendasi ·
    <a href="mailto:bossetaphysique@gmail.com">bossetaphysique@gmail.com</a></p>
  </footer>
</main>

</body>
</html>
`;

/* ── Écriture ──────────────────────────────────────────────────────────── */
const pages = [
  { fichier: "cgv.html", titre: "Conditions générales de vente",
    description: "Les conditions générales de vente de l'accompagnement "
                 + "Bosse ta Physique.",
    jumeau: { lien: "confidentialite.html",
              titre: "la politique de confidentialité" },
    texte: CGV },
  { fichier: "confidentialite.html", titre: "Politique de confidentialité",
    description: "Les données recueillies par Bosse ta Physique, leur usage "
                 + "et vos droits.",
    jumeau: { lien: "cgv.html",
              titre: "les conditions générales de vente" },
    texte: CONFIDENTIALITE },
];

for (const p of pages) {
  const chemin = join(racine, "public", p.fichier);
  writeFileSync(chemin, page({ titre: p.titre, description: p.description,
                               jumeau: p.jumeau, corps: rendre(p.texte) }),
                "utf8");
  console.log(`public/${p.fichier} — ${p.texte.length} caractères rendus`);
}
