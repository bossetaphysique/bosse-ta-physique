import { JSDOM } from "jsdom";
import { writeFileSync } from "node:fs";
const dom = new JSDOM("<!DOCTYPE html><html><body><div id='r'></div></body></html>",
  { pretendToBeVisual: true, url: "https://exemple.test" });
global.window = dom.window; global.document = dom.window.document;
global.HTMLElement = dom.window.HTMLElement; global.Element = dom.window.Element;
global.Node = dom.window.Node; global.getComputedStyle = dom.window.getComputedStyle;
global.requestAnimationFrame = (f) => setTimeout(f, 0);
global.cancelAnimationFrame = (id) => clearTimeout(id);
global.MutationObserver = dom.window.MutationObserver;
global.IS_REACT_ACT_ENVIRONMENT = true;
const e0 = console.error;
console.error = (...a) => { if (!/not wrapped in act|key|error bound/i.test(String(a[0]))) e0(...a); };

const React = (await import("react")).default;
const { createRoot } = await import("react-dom/client");
const { act } = await import("react");
const App = (await import("../.apercu/apercu.mjs")).default;
const root = createRoot(document.getElementById("r"));
await act(async () => { root.render(React.createElement(App)); });

const D = document;
const tous = () => [...D.querySelectorAll("button")];
const btn = (t) => tous().find((b) => b.textContent.trim() === t)
  || tous().find((b) => b.textContent.trim().includes(t));
const clic = async (t) => { const b = btn(t); if (!b || b.disabled) return false;
  await act(async () => { b.click(); }); return true; };

const css = D.querySelector(".b > style")?.textContent || "";
const ecran = () => {
  const b = D.querySelector(".b");
  return [...b.children].filter((x) => !/^(STYLE|LINK)$/.test(x.tagName))
    .map((x) => x.outerHTML).join("");
};

const vues = {};
vues.accueil = ecran();

/* On traverse l'accueil pour atteindre l'application. Le test de positionnement
   n'est pas joué : les écrans montrent donc un compte tout neuf, ce qui
   correspond exactement à ce que découvre un élève le premier soir. */
for (let etape = 0; etape < 8; etape++) {
  const libelles = tous().filter((b) => !b.disabled).map((b) => b.textContent.trim());
  const suite = ["C'est parti", "Continuer", "Commencer"].find((t) => libelles.includes(t));
  if (suite) { await clic(suite); } else if (!(await clic(libelles[0]))) break;
  if (D.querySelector(".tabbar")) break;
}
vues.soir = ecran();

/* ── On installe une situation réaliste ────────────────────────────────────
   Un élève au milieu de son année : un chapitre terminé avec son contrôle
   derrière lui, un chapitre en cours avec son contrôle devant. Un livret qui
   montre des écrans vides n'apprend rien. */
const titre = () => D.querySelector("h1,h2,h3")?.textContent.trim() || "";

const passerLeTest = async () => {
  for (let q = 0; q < 40; q++) {
    const opt = tous().filter((b) => !b.disabled && /(^| )opt( |$)/.test(b.className));
    if (!opt.length) return q;
    await act(async () => { opt[q % opt.length].click(); });
    const valide = tous().find((b) => !b.disabled
      && b.className.includes("btn-accent") && b.className.includes("btn-block"));
    if (!valide) return q;
    await act(async () => { valide.click(); });
    /* la correction s'affiche : on passe à la question suivante */
    const suivante = tous().find((b) => !b.disabled
      && /Suivante|Suivant|Terminer/.test(b.textContent));
    if (suivante) await act(async () => { suivante.click(); });
  }
  return -1;
};

const declarer = async (nom) => {
  await clic("J'ai commencé un nouveau chapitre");
  await clic(nom);
  await clic("Commencer");
  const n = await passerLeTest();
  /* l'écran de fin de test */
  for (const t of ["Voir mon programme", "C'est parti", "Continuer", "Terminer"]) {
    if (await clic(t)) break;
  }
  console.log("  « " + nom + " » déclaré · " + n + " questions · " + titre().slice(0, 34));
};

await declarer("Diffraction");
/* Le soir de la déclaration porte un vrai programme : on le saisit avant que
   les jours n'avancent et ne le consomment. */
vues.soir = ecran();
/* L'élève travaille quelques soirées : sans cela, la carte des exercices
   faits reste vide et les gestes tous gris. */
/* Une séance quelconque, menée jusqu'au verdict. Les écrans varient — feuille
   blanche, questions flash, exercice — mais tous finissent par un bouton
   large que l'on suit jusqu'au bout. */
/* On s'en tient là : le chapitre est déclaré, le test passé, et l'écran du
   soir porte un vrai programme. Faire jouer les séances par l'automate s'est
   révélé hors de portée — les formes d'écran sont trop variées. */
await clic("Sem.");
const onglets = { semaine: "Sem.", cours: "Cours", ds: "DS", progres: "Progrès" };
for (const [cle, libelle] of Object.entries(onglets)) {
  if (await clic(libelle)) {
    /* L'onglet Cours s'ouvre sur le premier chapitre du catalogue : on le
       place sur celui que l'élève travaille, seul à être pourvu en vidéos. */
    if (cle === "cours") await clic("Diffraction");
    vues[cle] = ecran();
  }
}

writeFileSync("/tmp/vues.json", JSON.stringify({ css, vues }, null, 0));
console.log("  écrans capturés : " + Object.keys(vues).join(", "));
console.log("  css : " + css.length + " octets");
Object.entries(vues).forEach(([k, v]) => console.log("    " + k.padEnd(10) + v.length + " octets"));
