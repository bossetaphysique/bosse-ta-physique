import { readFileSync, writeFileSync } from "node:fs";

/* ═══════════════════════════════════════════════════════════════════════════
   LE GUIDE PAS À PAS.

   Un seul téléphone, qui reste à l'écran pendant que le texte défile et change
   d'écran à chaque étape. C'est le seul mouvement de la page : tout le reste
   est immobile. Les écrans sont ceux de l'application, pas des images.

   Palette et typographie reprises de l'application — c'est son mode d'emploi,
   la continuité est le sujet même. L'or ne sert qu'à une chose : marquer
   l'étape où se trouve le lecteur.
   ═══════════════════════════════════════════════════════════════════════════ */

/* L'APPLICATION ENTIÈRE, empaquetée avec React. Le guide ne montre pas des
   images : il fait tourner l'application pour de vrai dans le téléphone, dans
   un cadre isolé pour que les barres fixes se placent comme sur un écran de
   téléphone et non sur la page. Le lecteur peut tout ouvrir. */
const APP = readFileSync("/tmp/app.js", "utf8");

const ONGLETS = [["soir", "Ce soir"], ["semaine", "Sem."], ["cours", "Cours"],
                 ["ds", "DS"], ["progres", "Progrès"]];

/* ── Les étapes ────────────────────────────────────────────────────────── */
const etapes = [
  { vue: "accueil", titre: "Répondre à quatre questions",
    ancre: "",
    texte: `
    <p>La première ouverture demande quatre choses : le niveau que l'élève
    s'attribue, ses jours de cours de physique, le temps qu'il peut donner
    chaque soir, et ses jours de repos.</p>
    <p>Vingt ou trente minutes. Trente est le plus courant, et ce n'est pas un
    plafond : l'élève qui veut travailler davantage demandera des exercices
    supplémentaires le soir même.</p>
    <p class="g-note">Ces réponses se modifient à tout moment.</p>` },

  { vue: "soir", titre: "Déclarer le chapitre abordé en classe",
    ancre: "Quelque chose a changé",
    texte: `
    <p>Rien ne se met en route tant qu'un chapitre n'est pas déclaré. Dès que le
    professeur l'aborde en classe, l'élève l'annonce depuis cet écran.</p>
    <p>Un test de positionnement suit le soir même : une quinzaine de questions,
    dix minutes. Sans lui, la plateforme ne sait rien du niveau de l'élève et ne
    peut rien lui proposer.</p>
    <p class="g-note">Jusqu'à trois chapitres peuvent être menés de front.</p>` },

  { vue: "soir", titre: "Ouvrir son programme du soir",
    ancre: "Ce soir",
    texte: `
    <p>Le programme est prêt. L'élève n'a rien à choisir : il ouvre la première
    séance et la mène au bout.</p>
    <p>Chaque séance se termine par un verdict — acquis, hésité, raté. C'est ce
    verdict, et non le résultat, qui commande la suite : un geste raté revient
    vite, un geste acquis s'espace.</p>
    <p class="g-note">Une soirée manquée est proposée en rattrapage, jamais
    perdue.</p>` },

  { vue: "semaine", titre: "Voir la semaine entière",
    ancre: "Charge de la semaine",
    texte: `
    <p>Ce qui est fait, ce qui reste, ce qui a été manqué. Le temps annoncé se
    répartit sur les sept jours en tenant compte des jours de cours et des jours
    de repos.</p>
    <p>Le week-end porte les sujets type bac : un par chapitre déclaré, tiré des
    annales, avec sa durée réelle et le corrigé officiel.</p>` },

  { vue: "cours", titre: "Retrouver les vidéos et les fiches",
    ancre: "Fiches de revision",
    texte: `
    <p>Chaque chapitre réunit ses vidéos — la leçon entière, les questions types
    une à une, le résumé — et ses fiches de révision.</p>
    <p>Le coach dépose ici tout ce qu'il veut mettre à disposition. C'est
    également l'endroit où l'élève retrouve les cours en visioconférence
    passés.</p>` },

  { vue: "ds", titre: "Préparer un contrôle",
    ancre: "Contrôles",
    texte: `
    <p>Dès que la date est connue, l'élève l'annonce. Tout le programme se
    réorganise autour d'elle.</p>
    <p>Quelques jours avant, une épreuve blanche se déverrouille : un vrai sujet
    de bac, en temps limité. L'élève photographie sa copie ; le coach la lui rend
    annotée, avec un mot.</p>
    <p class="g-note">Après le contrôle, la fiche descend dans l'historique et
    les sujets d'annales se déverrouillent.</p>` },

  { vue: "progres", titre: "Suivre ses gestes, et les reprendre",
    ancre: "gestes de la fiche",
    texte: `
    <p>Pas une note, mais la liste des gestes du programme et l'état de chacun :
    acquis, hésité, raté, ou pas encore travaillé.</p>
    <p>À côté de chaque geste, un bouton pour le travailler. L'élève n'attend pas
    qu'on le lui propose : il choisit ce qu'il reprend.</p>
    <p>Plus bas, la liste de tous les exercices déjà faits, repliés par chapitre.
    Chacun se rouvre avec son énoncé et son corrigé — <b>y compris sur un
    chapitre terminé</b>. Un contrôle passé ne ferme rien.</p>` },
];

const doc = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Bosse ta Physique — guide pas à pas</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
/* ═══ le guide ═══════════════════════════════════════════════════════════ */
:root{
  --g-encre:#0E1132; --g-voile:#F6F7FC; --g-ardoise:#565E80;
  --g-violet:#6C63FF; --g-trait:#E3E8F7; --g-or:#E7B24E;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--g-voile);color:var(--g-encre);
  font-family:'Inter',system-ui,-apple-system,sans-serif;
  font-size:16px;line-height:1.7;-webkit-font-smoothing:antialiased}

/* ── ouverture ── */
.g-hero{max-width:1100px;margin:0 auto;padding:92px 32px 26px}
.g-hero > div{max-width:620px}
.g-hero h1{font-family:'Poppins',system-ui,sans-serif;font-weight:600;
  font-size:clamp(2.3rem,5vw,3.4rem);line-height:1.08;letter-spacing:-.035em;
  margin:0 0 20px}
.g-hero p{font-size:1.12rem;color:var(--g-ardoise);margin:0 0 14px;max-width:46ch}
.g-depart{display:inline-block;margin-top:18px;padding:13px 26px;
  background:var(--g-encre);color:#FFF;border-radius:999px;text-decoration:none;
  font-weight:600;font-size:.95rem}
.g-depart:focus-visible{outline:3px solid var(--g-violet);outline-offset:3px}

/* ── le corps : rail, texte, téléphone collant ── */
.g-corps{max-width:1100px;margin:0 auto;padding:0 32px 120px;
  display:grid;grid-template-columns:52px minmax(0,1fr) 380px;gap:0 40px}

.g-rail{position:relative}
.g-rail::before{content:"";position:absolute;left:9px;top:14px;bottom:14px;
  width:2px;background:var(--g-trait)}
.g-rail i{position:absolute;left:9px;top:14px;width:2px;height:0;
  background:var(--g-violet);transition:height .25s linear}
.g-puce{position:sticky;top:0;height:0}

.g-etape{padding:14vh 0;position:relative}
.g-etape:first-child{padding-top:6vh}
.g-num{position:absolute;left:-92px;top:14vh;width:20px;height:20px;
  border-radius:50%;background:var(--g-voile);border:2px solid var(--g-trait);
  display:grid;place-items:center;font-size:.66rem;font-weight:600;
  color:var(--g-ardoise);transition:border-color .3s,color .3s,background .3s}
.g-etape.vue .g-num{border-color:var(--g-violet);color:var(--g-violet)}
.g-etape.ici .g-num{background:var(--g-or);border-color:var(--g-or);color:#5A4410}
.g-etape h2{font-family:'Poppins',system-ui,sans-serif;font-weight:600;
  font-size:1.55rem;letter-spacing:-.02em;line-height:1.25;margin:0 0 16px}
.g-etape p{color:var(--g-ardoise);margin:0 0 14px;max-width:46ch}
.g-etape b{color:var(--g-encre)}
.g-note{font-size:.9rem;padding-left:14px;border-left:2px solid var(--g-or);
  color:var(--g-ardoise)}

/* ── le téléphone ── */
.g-colonne{position:relative}
.g-tel{position:sticky;top:calc(50vh - 340px);width:352px;
  background:var(--g-encre);border-radius:38px;padding:12px;
  box-shadow:0 30px 70px -20px rgba(14,17,50,.38)}
/* LE DÉFILEMENT EST PORTÉ PAR LE CADRE LUI-MÊME. L'application n'a pas de
   conteneur défilant interne : son contenu vit dans « main », et sa barre
   d'onglets est en « position:fixed ». La transformation posée ici fait deux
   choses à la fois — elle retient cette barre à l'intérieur du téléphone au
   lieu de la coller au bas de la page, et elle laisse le contenu défiler
   dessous. */
.g-ecran{width:100%;height:620px;border-radius:28px;background:#F1F4FE;
  overflow-y:auto;overflow-x:hidden;position:relative;
  transform:translateZ(0);isolation:isolate;
  -webkit-overflow-scrolling:touch;scrollbar-width:thin}
.g-ecran::-webkit-scrollbar{width:5px}
.g-ecran::-webkit-scrollbar-thumb{background:#C9CFE8;border-radius:3px}
.g-ecran .b{min-height:0;height:auto}
.g-charge{position:absolute;inset:12px;z-index:5;border-radius:28px;background:#F1F4FE;
  display:grid;place-items:center;color:#8A90AB;font-size:.88rem}
.g-charge.parti{display:none}
.g-aide{text-align:center;font-size:.82rem;color:var(--g-ardoise);
  margin:14px 0 0}
.g-aide button{border:0;background:none;color:var(--g-violet);cursor:pointer;
  font:inherit;text-decoration:underline;padding:0}
.g-aide button:focus-visible{outline:2px solid var(--g-violet);outline-offset:2px}


/* ── fin ── */
.g-fin{max-width:1100px;margin:0 auto;padding:0 32px 110px}
.g-fin-boite{border-top:1px solid var(--g-trait);padding-top:44px;
  display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:36px}
.g-fin h3{font-family:'Poppins',system-ui,sans-serif;font-weight:600;
  font-size:1.02rem;margin:0 0 8px}
.g-fin p{color:var(--g-ardoise);font-size:.94rem;margin:0}

@media (max-width:900px){
  .g-hero{padding:56px 22px 18px}
  .g-corps{grid-template-columns:1fr;padding:0 22px 80px;gap:0}
  .g-rail{display:none}
  .g-num{position:static;margin-bottom:14px}
  .g-etape{padding:44px 0}
  .g-colonne{order:-1}
  .g-tel{position:relative;top:0;width:100%;max-width:352px;margin:0 auto 8px}
}
@media (prefers-reduced-motion:reduce){
  html{scroll-behavior:auto}
  *{transition:none!important}
}
</style></head>
<body>

<header class="g-hero">
  <div>
    <h1>Un programme de travail,<br>soir après soir.</h1>
    <p>Bosse ta Physique construit chaque soirée à partir de ce que l'élève a
    réellement compris, et se réorganise dès qu'un contrôle est annoncé.</p>
    <p>Voici comment s'en servir, en sept étapes.</p>
    <a class="g-depart" href="#e1">Commencer le guide</a>
  </div>
</header>

<div class="g-corps">
  <div class="g-rail"><i id="jauge"></i><div class="g-puce"></div></div>

  <div>
    ${etapes.map((e, k) => `
    <section class="g-etape" id="e${k + 1}" data-vue="${e.vue}"
      data-ancre="${e.ancre}">
      <span class="g-num">${k + 1}</span>
      <h2>${e.titre}</h2>
      ${e.texte}
    </section>`).join("")}
  </div>

  <div class="g-colonne">
    <div class="g-tel" id="tel">
      <div class="g-ecran" id="appVivante"></div>
      <div class="g-charge" id="charge">L'application démarre…</div>
    </div>
    <p class="g-aide">
      Tout est cliquable. <button type="button" id="reprendre">Repartir de
      zéro</button>
    </p>
  </div>
</div>

<footer class="g-fin">
  <div class="g-fin-boite">
    <div>
      <h3>Une question sur un exercice</h3>
      <p>Sur le serveur Discord du groupe. Les échanges s'y font en petit comité,
      avec les notifications qui vont avec.</p>
    </div>
    <div>
      <h3>Un parent qui veut suivre</h3>
      <p>Il dispose de son propre espace : la semaine en cours de son enfant,
      l'historique des évaluations, et l'avancement chapitre par chapitre.</p>
    </div>
    <div>
      <h3>Changer de rythme</h3>
      <p>Le temps par soir se modifie quand on veut, depuis les réglages. Le
      programme se recompose aussitôt.</p>
    </div>
  </div>
</footer>

<script type="text/plain" id="source">${APP}</script>
<script>
(function () {
  var etapes = [].slice.call(document.querySelectorAll(".g-etape"));
  var jauge = document.getElementById("jauge");
  var rail = jauge.parentNode;
  var charge = document.getElementById("charge");

  /* ── l'application, montée dans le téléphone ────────────────────────────
     Pas de cadre isolé : ouvert depuis un fichier local, le navigateur en
     refuserait l'accès et l'écran resterait blanc. L'application vit donc
     dans la page, et c'est la transformation appliquée au téléphone qui
     retient ses barres fixes à l'intérieur. */
  function demarrer() {
    var sc = document.createElement("script");
    sc.textContent = document.getElementById("source").textContent;
    document.body.appendChild(sc);
    charge.classList.add("parti");
    setTimeout(function () { surDefilement(true); }, 80);
  }
  demarrer();

  document.getElementById("reprendre").addEventListener("click", function () {
    var b = boutons().find(function (x) {
      return x.textContent.trim() === "Remettre à zéro";
    });
    if (b) { b.click(); return; }
    location.reload();
  });

  /* ── désigner un onglet dans l'application ─────────────────────────────── */
  var tel = document.getElementById("appVivante");
  function boutons() {
    return [].slice.call(tel.querySelectorAll("button"));
  }
  function cliquer(libelle) {
    var b = boutons().find(function (x) {
      return !x.disabled && x.textContent.trim() === libelle;
    });
    if (b) { b.click(); return true; }
    return false;
  }
  /* La mise en route se franchit toute seule dès qu'on quitte la première
     étape : sans elle, l'application resterait sur ses questions. */
  function pretPourLesOnglets() {
    if (tel.querySelector(".tabbar, nav.nav")) return true;
    for (var n = 0; n < 8; n++) {
      var libres = boutons().filter(function (x) { return !x.disabled; });
      var suite = ["C'est parti", "Continuer", "Commencer"].find(function (t) {
        return libres.some(function (x) { return x.textContent.trim() === t; });
      });
      if (suite) cliquer(suite);
      else if (libres.length) libres[0].click();
      else break;
      if (tel.querySelector(".tabbar, nav.nav")) return true;
    }
    return !!tel.querySelector(".tabbar, nav.nav");
  }

  var ONGLET = { soir: "Ce soir", semaine: "Sem.", cours: "Cours",
                 ds: "DS", progres: "Progrès" };
  var derniere = null;
  function montrer(vue) {
    if (vue === "accueil") return;          /* la première étape reste où elle est */
    if (!pretPourLesOnglets()) return;
    cliquer(ONGLET[vue] || "Ce soir");
    if (vue === "cours") cliquer("Diffraction");
  }

  /* ── le rail et l'étape courante ───────────────────────────────────────── */
  function surDefilement(force) {
    var milieu = window.innerHeight * 0.45;
    var ici = null;
    etapes.forEach(function (s) {
      if (s.getBoundingClientRect().top <= milieu) ici = s;
    });
    if (!ici) ici = etapes[0];
    etapes.forEach(function (s, i) {
      s.classList.toggle("ici", s === ici);
      s.classList.toggle("vue", etapes.indexOf(ici) > i);
    });
    if (ici !== derniere || force) { derniere = ici; montrer(ici.dataset.vue); }
    var h = rail.getBoundingClientRect();
    var avance = (milieu - h.top) / h.height;
    jauge.style.height = Math.max(0, Math.min(1, avance)) * (h.height - 28) + "px";
  }

  var attend = false;
  window.addEventListener("scroll", function () {
    if (attend) return;
    attend = true;
    requestAnimationFrame(function () { surDefilement(); attend = false; });
  }, { passive: true });
  window.addEventListener("resize", function () { surDefilement(); },
    { passive: true });
})();
</script>
</body></html>`;

writeFileSync("/mnt/user-data/outputs/guide-pas-a-pas.html", doc);
console.log("  guide écrit : " + Math.round(doc.length / 1024) + " ko · "
  + etapes.length + " étapes");
