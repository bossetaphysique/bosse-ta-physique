/* Contrôle d'une banque de questions avant intégration.
   Usage : node scripts/verifier-banque.mjs chemin/vers/banque.json          */
import fs from "fs";

const chemin = process.argv[2];
if (!chemin) { console.error("Indiquez le fichier JSON à vérifier."); process.exit(1); }
const B = JSON.parse(fs.readFileSync(chemin, "utf8"));
const erreurs = [], alertes = [];
const ko = (m) => erreurs.push(m);

const TYPES = ["choix_simple", "choix_multiple", "ordre"];
const DIFF  = ["cours", "methode", "application"];

/* Chaque question doit renvoyer à une question type ou au socle de la fiche :
   c'est ce lien qui permet à l'élève de retourner au bon endroit. */
const SOURCE = /^(QT \d+|socle|mécanismes|vitesse de formation|typologie)$/;

const refs = new Set();
B.forEach((q) => {
  const r = q.ref || "(sans ref)";
  if (!q.ref) ko("question sans ref");
  if (refs.has(q.ref)) ko(`ref en double : ${r}`);
  refs.add(q.ref);
  if (!q.chapitre) ko(`${r} : chapitre manquant`);
  if (!TYPES.includes(q.type_question)) ko(`${r} : type_question invalide`);
  if (!DIFF.includes(q.difficulte)) ko(`${r} : difficulte invalide`);
  if (!q.source_qt) ko(`${r} : source_qt manquante — chaque question doit renvoyer à une QT ou au socle`);
  else if (!SOURCE.test(q.source_qt)) alertes.push(`${r} : source_qt inhabituelle « ${q.source_qt} »`);
  if (!q.enonce) ko(`${r} : énoncé vide`);
  if (!Array.isArray(q.options) || q.options.length < 2) ko(`${r} : moins de deux options`);
  if (!Array.isArray(q.bonne_reponse) || !q.bonne_reponse.length) ko(`${r} : bonne_reponse vide`);
  else {
    if (q.bonne_reponse.some((i) => !Number.isInteger(i) || i < 0 || i >= q.options.length))
      ko(`${r} : bonne_reponse hors des options`);
    if (q.type_question === "choix_simple" && q.bonne_reponse.length !== 1)
      ko(`${r} : choix_simple avec ${q.bonne_reponse.length} réponses`);
    if (q.type_question === "ordre" &&
        [...q.bonne_reponse].sort((a, b) => a - b).join() !== q.options.map((_, i) => i).join())
      ko(`${r} : type ordre — la bonne_reponse doit être une permutation complète`);
  }
  if (!q.explication) alertes.push(`${r} : sans explication`);
  if (!q.piege) alertes.push(`${r} : sans piège`);
});

const actives = B.filter((q) => q.actif !== false);
if (actives.length < 25 || actives.length > 35)
  alertes.push(`${actives.length} questions actives — la cible est 25 à 35`);

const parChap = {};
actives.filter((q) => q.diagnostic).forEach((q) => {
  parChap[q.chapitre] = parChap[q.chapitre] || [];
  parChap[q.chapitre].push(q);
});
Object.entries(parChap).forEach(([chap, l]) => {
  if (l.length !== 10) ko(`${chap} : ${l.length} questions de diagnostic au lieu de 10`);
  const c = DIFF.map((d) => l.filter((q) => q.difficulte === d).length);
  if (c.join() !== "4,4,2") ko(`${chap} : répartition ${c.join("/")} au lieu de 4 cours / 4 méthode / 2 application`);
  if (l.some((q) => q.type_question !== "choix_simple"))
    alertes.push(`${chap} : une question de diagnostic n'est pas à choix simple`);
});

/* Équilibre des positions : une bonne réponse presque toujours en B se devine
   sans réfléchir. On alerte au-delà de 45 % sur une même position. */
const simples = actives.filter((q) => q.type_question === "choix_simple");
if (simples.length >= 10) {
  const pos = {};
  simples.forEach((q) => { pos[q.bonne_reponse[0]] = (pos[q.bonne_reponse[0]] || 0) + 1; });
  const repartition = Object.entries(pos).sort((a, b) => a[0] - b[0])
    .map(([i, n]) => `${String.fromCharCode(65 + Number(i))} ${Math.round(100 * n / simples.length)}%`);
  const pire = Math.max(...Object.values(pos)) / simples.length;
  if (pire > 0.45) ko(`bonne réponse trop souvent à la même place — ${repartition.join(" · ")}`);
  else alertes.push(`positions des bonnes réponses : ${repartition.join(" · ")}`);
}

/* Une question « ordre » dont les étapes sont déjà rangées se résout en tapant
   de haut en bas. */
actives.filter((q) => q.type_question === "ordre").forEach((q) => {
  if (q.bonne_reponse.join() === q.options.map((_, i) => i).join())
    ko(`${q.ref} : les étapes sont affichées déjà dans le bon ordre`);
});

const qts = [...new Set(actives.map((q) => q.source_qt))].sort();
console.log(`${actives.length} questions actives · ${Object.values(parChap).flat().length} en diagnostic`);
console.log("sources citées :", qts.join(" · "));
alertes.forEach((a) => console.log("  ⚠", a));
erreurs.forEach((e) => console.log("  ✗", e));
console.log(erreurs.length ? `\n${erreurs.length} erreur(s) — banque refusée` : "\nBanque valide.");
process.exit(erreurs.length ? 1 : 0);
