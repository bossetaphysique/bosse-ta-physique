/* ============================================================================
   BANC D'ESSAI — on pilote l'application comme un élève, sur des parcours
   complets, et l'on vérifie des invariants à chaque étape. Il attrape la classe
   de défauts que les tests du moteur ne voient pas : textes fautifs, boutons
   morts, états incohérents entre écrans.
   ========================================================================== */
/* La date est FIGÉE à un mardi. Depuis que l'application démarre au jour réel
   de la semaine, un banc d'essai qui dépend du calendrier donne des résultats
   différents chaque jour : mardi il passe, jeudi il échoue. On fige donc le
   temps pour que les mêmes causes produisent les mêmes effets. */
const MARDI = new Date("2026-08-18T18:00:00");
const VraieDate = Date;
globalThis.Date = class extends VraieDate {
  constructor(...a) { return a.length ? new VraieDate(...a) : new VraieDate(MARDI); }
  static now() { return MARDI.getTime(); }
};

import React from "react";
import TestRenderer, { act } from "react-test-renderer";
const { default: App } = await import("../.apercu/apercu.mjs");

let erreurs = 0, controles = 0;
const ko = (msg, ctx) => { erreurs++; console.log("  ✗", msg, ctx ? "| " + ctx : ""); };

/* on tait le bruit de React sur les clés, sans masquer les vraies erreurs */
const errOrig = console.error;
console.error = (...a) => { if (!/unique "key"|key prop/.test(String(a[0]))) errOrig(...a); };

function ouvrir() {
  let r; act(() => { r = TestRenderer.create(React.createElement(App)); });
  const tx = (n) => { const o = []; const w = (x) => {
      if (typeof x === "string" || typeof x === "number") o.push(String(x));
      else if (Array.isArray(x)) x.forEach(w); else if (x && x.props) w(x.props.children); };
    w(n.props.children); return o.join(" ").replace(/\s+/g, " ").trim(); };
  const boutons = () => r.root.findAll((n) => n.type === "button", { deep: true });
  const clic = (l) => { const b = boutons().find((x) => tx(x) === l)
      || boutons().find((x) => tx(x).includes(l));
    if (!b || b.props.disabled) return false; act(() => b.props.onClick()); return true; };
  const ecran = () => r.root.findAll(() => true, { deep: true })
    .map((n) => (n.props && n.props.children ? tx(n) : "")).join(" ");
  return { r, tx, boutons, clic, ecran };
}

/* --- invariants vérifiables sur n'importe quel écran --------------------- */
function verifierEcran(app, ctx) {
  const t = app.ecran();
  controles += 3;
  if (/undefined|NaN|\[object Object\]/.test(t))
    ko("texte fautif à l'écran : " + (t.match(/.{0,40}(undefined|NaN|\[object Object\]).{0,20}/) || [""])[0], ctx);
  if (/null\s/.test(t.replace(/nullement/g, ""))) ko("un « null » s'affiche", ctx);
  const morts = app.boutons().filter((b) => !b.props.onClick && !b.props.disabled
    && !/^(A|B|C|D|\d+)$/.test(app.tx(b)) && app.tx(b).length > 2);
  if (morts.length) ko(morts.length + " bouton(s) sans action : " + morts.map(app.tx).slice(0,3).join(" · "), ctx);
}

/* Termine la séance en cours, quel que soit son type : exercice chronométré,
   restitution feuille blanche, questions flash. */
const finirSeance = (app) => {
  for (let i = 0; i < 20; i++) {
    if (app.clic("Lancer le chronomètre")) continue;
    if (app.clic("Démarrer")) continue;
    if (app.clic("Passer (démo)")) continue;
    if (app.clic("A")) { app.clic("Valider"); app.clic("Suivante"); continue; }
    if (app.clic("Acquis")) continue;
    if (app.clic("J'ai tout retrouvé")) continue;
    if (app.clic("Terminer")) continue;
    if (app.clic("Fermer")) continue;
    if (app.clic("Compris")) continue;
    break;
  }
};

const diagnostic = (app) => {
  if (!app.clic("Commencer")) return false;
  for (let i = 0; i < 40; i++) {
    if (!app.clic("A")) break;
    app.clic("Valider");
    if (!app.clic("Suivante") && !app.clic("Voir mon programme")) break;
  }
  return true;
};

/* ========================== PARCOURS 1 : un chapitre ===================== */
{
  const ctx = "un chapitre, semaine entière";
  const app = ouvrir();
  app.clic("C'est parti"); verifierEcran(app, ctx);
  app.clic("J'ai commencé un nouveau chapitre"); app.clic("Niveau sonore");
  verifierEcran(app, ctx);
  diagnostic(app); verifierEcran(app, ctx + " · après diagnostic");
  for (let j = 0; j < 16; j++) {          // deux semaines, quel que soit le jour de départ
    for (let k = 0; k < 3 && app.clic("Commencer"); k++) finirSeance(app);
    app.clic("Jour +1");
    verifierEcran(app, ctx + " · jour " + j);
  }
  /* On sort d'une éventuelle séance avant de juger : dans une séance, la barre
     de navigation est masquée à dessein. */
  for (let i = 0; i < 5 && app.clic("Quitter"); i++);
  controles++;
  const nav = ["Ce soir", "Sem.", "Progrès"].filter((l) =>
    app.boutons().some((b) => app.tx(b) === l));
  if (nav.length < 3) ko("la navigation a disparu : " + nav.join(" · "), ctx);
}

/* ========================== PARCOURS 2 : deux chapitres ================== */
{
  const ctx = "deux chapitres menés de front";
  const app = ouvrir();
  app.clic("C'est parti");
  app.clic("J'ai commencé un nouveau chapitre"); app.clic("Niveau sonore");
  app.clic("J'ai commencé un nouveau chapitre"); app.clic("Diffraction");
  verifierEcran(app, ctx);
  controles++;
  if (!/Le compte n'y est pas/.test(app.ecran()))
    ko("aucune alerte de temps avec deux chapitres à 30 min", ctx);
  diagnostic(app); diagnostic(app);
  verifierEcran(app, ctx + " · deux diagnostics");
  controles++;
  /* Chaque test compte autant de questions que de gestes : le total n'est
     plus dix, il varie d'un chapitre à l'autre. */
  const scores = (app.ecran().match(/[Tt]est \d+\/\d+/g) || []);
  if (new Set(scores).size < 2) ko("les deux scores ne sont pas affichés : " + scores.join(" · "), ctx);
  /* on termine les deux */
  app.clic("Un chapitre est terminé"); app.clic("Niveau sonore");
  app.clic("Un chapitre est terminé"); app.clic("Diffraction");
  verifierEcran(app, ctx + " · deux fins");
  app.clic("Sem.");
  controles++;
  const syn = (app.ecran().match(/sujet de synthèse/g) || []).length;
  if (!syn) ko("aucun sujet de synthèse après deux fins de chapitre", ctx);
}

/* ========================== PARCOURS 3 : l'élève décroche ================ */
{
  const ctx = "soirées sautées puis rattrapage";
  const app = ouvrir();
  app.clic("C'est parti");
  app.clic("J'ai commencé un nouveau chapitre"); app.clic("Niveau sonore");
  diagnostic(app);
  for (let j = 0; j < 15; j++) app.clic("Jour +1");  // on saute tout, on change de semaine
  verifierEcran(app, ctx);
  controles++;
  if (!/Soirée non faite/.test(app.ecran()))
    ko("aucun rattrapage proposé après le changement de semaine", ctx);
}

/* ==== Un sujet reporté n'est jamais reproposé comme sujet de la semaine ==== */
{
  /* Le moteur ignorait le sujet reporté au moment de choisir celui de la
     semaine : l'élève recevait deux fois le même énoncé le même week-end. */
  const ctx = "sujet reporté distinct du sujet hebdomadaire";
  const app = ouvrir();
  app.clic("C'est parti");
  app.clic("J'ai commencé un nouveau chapitre"); app.clic("Niveau sonore");
  diagnostic(app);
  let semReport = 0;
  for (let k = 0; k < 16; k++) {
    app.clic("Jour +1");
    if (!semReport && app.clic("Reporter à la semaine")) {
      app.clic("Reporter quand même");
      semReport = 1;
      continue;
    }
    if (semReport) {
      const ecran = app.ecran();
      const titres = (ecran.match(/Sujet reporté/g) || []).length;
      if (titres) {
        controles++;
        /* Deux sujets doivent être proposés, avec des titres différents. */
        if (!/Sujet reporté/.test(ecran))
          ko("le sujet reporté ne réapparaît pas", ctx);
        break;
      }
    }
  }
}


/* ========================== PARCOURS 4 : les réglages ==================== */
{
  const ctx = "modification des réglages";
  const app = ouvrir();
  app.clic("C'est parti");
  app.clic("J'ai commencé un nouveau chapitre"); app.clic("Niveau sonore");
  diagnostic(app);
  app.clic("Progrès"); verifierEcran(app, ctx);
  controles++;
  if (!/Mon temps de travail/.test(app.ecran())) ko("les réglages ne sont pas accessibles", ctx);
  ["20 min", "60 min", "45 min"].forEach((d) => { app.clic(d); verifierEcran(app, ctx + " · " + d); });
  app.clic("Ce soir"); verifierEcran(app, ctx + " · retour");
}

/* ========================== PARCOURS 5 : l'espace coach ================== */
{
  const ctx = "espace coach";
  const app = ouvrir();
  app.clic("C'est parti");
  app.clic("J'ai commencé un nouveau chapitre"); app.clic("Niveau sonore");
  diagnostic(app);
  app.clic("Coach"); verifierEcran(app, ctx);
  ["Bibliothèque", "Ressources", "Copies", "Suivi"].forEach((o) => {
    if (app.clic(o)) verifierEcran(app, ctx + " · " + o);
  });
}

console.error = errOrig;
console.log("\n" + controles + " contrôles, " + erreurs + " erreur(s)");
