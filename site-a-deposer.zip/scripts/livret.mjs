import { readFileSync, writeFileSync } from "node:fs";

/* ═══════════════════════════════════════════════════════════════════════════
   LE LIVRET D'UTILISATION.

   Les illustrations ne sont pas des captures d'écran : ce sont les VRAIS
   écrans de l'application, rendus une fois pour toutes et rangés dans le
   livret avec la feuille de style d'origine. Ils resteront donc fidèles à
   l'application tant que celle-ci ne change pas — et se régénèrent en une
   commande quand elle change.

   Le fichier s'ouvre dans n'importe quel navigateur et s'imprime en PDF.
   ═══════════════════════════════════════════════════════════════════════════ */

const { css, vues } = JSON.parse(readFileSync("/tmp/vues.json", "utf8"));

/* Les écrans viennent de l'aperçu autonome, qui porte un bandeau « mode
   démonstration ». Il n'a rien à faire dans un livret destiné aux familles :
   on le retire par le DOM, l'élément portant du contenu imbriqué. */
const { JSDOM } = await import("jsdom");
Object.keys(vues).forEach((k) => {
  const d = new JSDOM("<body>" + vues[k] + "</body>");
  const D = d.window.document;
  [...D.querySelectorAll("div")]
    .filter((x) => /Mode démonstration/.test(x.textContent) && x.children.length < 4)
    .forEach((x) => x.remove());
  /* L'aperçu ouvre les outils du coach à tous et affiche une barre de pilotage
     — « Jour +1 », « Remettre à zéro ». Rien de tout cela n'existe pour un
     élève : le livret ne doit pas le lui montrer. */
  [...D.querySelectorAll("button")]
    .filter((b) => /^(Espace coach|Oral|Jour \+1|Coach|Remettre à zéro)$/
      .test(b.textContent.trim()))
    .forEach((b) => b.remove());
  [...D.querySelectorAll("div")]
    .filter((x) => /Remettre à zéro/.test(x.textContent) && x.children.length < 6)
    .forEach((x) => x.remove());
  vues[k] = d.window.document.body.innerHTML;
});

/* LE TÉLÉPHONE EST NAVIGABLE : les cinq onglets du bas fonctionnent, et le
   contenu de chaque écran défile à l'intérieur du cadre. Le lecteur parcourt
   l'application au lieu de regarder une image figée. */
let nTel = 0;
const ONGLETS = [["soir", "Ce soir"], ["semaine", "Sem."], ["cours", "Cours"],
                 ["ds", "DS"], ["progres", "Progrès"]];

const telephone = (ouvertSur, legende, ancre) => {
  const id = "tel" + (++nTel);
  return `
  <figure class="liv-fig">
    <div class="liv-tel" id="${id}"${ancre ? ` data-ancre="${ancre}"` : ""}>
      ${ONGLETS.map(([cle]) => `
        <div class="liv-ecran${cle === ouvertSur ? " on" : ""}" data-vue="${cle}">
          ${vues[cle] || "<p>écran indisponible</p>"}
        </div>`).join("")}
      <nav class="liv-onglets">
        ${ONGLETS.map(([cle, lib]) => `
          <button type="button" data-cible="${cle}"
            class="${cle === ouvertSur ? "on" : ""}">${lib}</button>`).join("")}
      </nav>
    </div>
    ${legende ? `<figcaption class="liv-leg">${legende}</figcaption>` : ""}
  </figure>`;
};

/* Un écran seul, sans navigation : pour la mise en route, qui n'a pas
   d'onglets. */
const ecranSeul = (cle, legende) => `
  <figure class="liv-fig">
    <div class="liv-tel">
      <div class="liv-ecran on">${vues[cle] || "<p>écran indisponible</p>"}</div>
    </div>
    ${legende ? `<figcaption class="liv-leg">${legende}</figcaption>` : ""}
  </figure>`;

const ecran = (cle, legende, ancre) => (cle === "accueil"
  ? ecranSeul(cle, legende) : telephone(cle, legende, ancre));

const sections = [

  { titre: "À qui s'adresse ce livret",
    corps: `
    <p>Cette plateforme accompagne un élève de Terminale spécialité
    physique-chimie tout au long de son année. Elle lui construit un programme
    de travail soir après soir, à partir de ce qu'il a réellement compris.</p>
    <p>Ce livret décrit l'application telle que <b>l'élève</b> la voit. Le
    parent et le coach ont chacun leur propre espace, décrits ailleurs.</p>
    <div class="liv-encadre">
      <b>Le principe</b> — l'élève déclare le chapitre qu'il aborde en classe.
      Un court test mesure ce qu'il maîtrise déjà. Le programme se construit
      ensuite tout seul, et se réorganise dès qu'un contrôle est annoncé.
    </div>` },

  { titre: "La première ouverture",
    corps: `
    <p>Quatre questions, une seule fois. L'élève indique son niveau, ses jours
    de cours, le temps qu'il peut donner chaque soir, et ses jours de repos.</p>
    ${ecran("accueil", "Ces réponses se modifient à tout moment depuis les réglages.")}
    <div class="liv-encadre">
      <b>Le temps par soir</b> — vingt ou trente minutes. Trente est le plus
      courant. Ce n'est pas un plafond : l'élève qui veut travailler davantage
      demande des exercices supplémentaires, jusqu'à trois par soir.
    </div>` },

  { titre: "Ce soir — l'écran principal",
    corps: `
    <p>C'est l'écran que l'élève ouvre chaque jour. Il y trouve son programme du
    soir, prêt, sans avoir à choisir quoi que ce soit.</p>
    ${ecran("soir", "Le programme d'un soir. Faites défiler l'écran, ou changez d'onglet en bas.", "Ce soir")}
    <p>Le verdict compte plus que le résultat : c'est lui qui commande les
    exercices suivants. Un geste raté revient, un geste acquis s'espace.</p>
    <div class="liv-encadre">
      <b>Déclarer un chapitre</b> — dès qu'un chapitre est abordé en classe,
      l'élève l'annonce depuis cet écran. Un test de positionnement suit le soir
      même : sans lui, la plateforme ne sait rien de son niveau et ne peut rien
      lui proposer.
    </div>
    <div class="liv-encadre">
      <b>Déclarer un contrôle</b> — dès que la date est connue. Tout le
      programme se réorganise autour d'elle : révisions rapprochées, épreuve
      blanche quelques jours avant, puis reprise du chapitre suivant.
    </div>` },

  { titre: "Ma semaine",
    corps: `
    <p>La vue d'ensemble : ce qui est fait, ce qui reste, ce qui a été manqué.</p>
    ${ecran("semaine", "La semaine entière, jour après jour. Faites défiler pour la parcourir.", "Charge de la semaine")}
    <p>Le week-end porte les sujets type bac. Un sujet par chapitre déclaré,
    tiré des annales, avec sa durée réelle et le corrigé officiel.</p>` },

  { titre: "Le cours",
    corps: `
    <p>Les fiches de cours, les sujets d'annales et les cours en visioconférence
    déposés par le coach.</p>
    ${ecran("cours", "Les ressources du chapitre choisi. Les onglets du bas mènent aux autres écrans.", "Fiches de revision")}
    <div class="liv-encadre">
      <b>Le cours en visioconférence</b> — le coach en programme un par semaine.
      L'élève s'y inscrit depuis l'écran « Ce soir ». Le cours s'ajoute à sa
      soirée sans rien lui retirer : le travail personnel du jour reste entier.
    </div>` },

  { titre: "Les devoirs surveillés",
    corps: `
    <p>Cet écran réunit tous les contrôles, ceux qui arrivent et ceux qui sont
    derrière. Chacun a sa fiche.</p>
    ${ecran("ds", "Tant qu'aucun contrôle n'est déclaré, l'écran explique quoi faire.", "Contrôles")}

    <h3 class="liv-h3">Un contrôle à venir</h3>
    <p>Dès que l'élève annonce la date, sa fiche apparaît en haut de l'écran et
    contient, dans cet ordre :</p>
    <ul class="liv-l">
      <li><b>L'épreuve blanche</b> — un vrai sujet de bac à composer en temps
      limité, quelques jours avant le contrôle. Elle se déverrouille au bon
      moment, pas avant.</li>
      <li><b>Les gestes de la fiche</b> — ceux qui restent à reprendre avant
      l'épreuve, avec le compte : « 7 acquis sur 11 ».</li>
      <li><b>Les sujets de bac non traités</b>, groupés par chapitre. Ils
      restent verrouillés tant que l'épreuve blanche n'est pas rendue : on ne
      s'entraîne pas sur le sujet qu'on va composer.</li>
    </ul>

    <h3 class="liv-h3">Un contrôle passé</h3>
    <p>Une fois la date franchie, la fiche descend dans l'historique et change
    de contenu :</p>
    <ul class="liv-l">
      <li><b>La copie</b> — l'élève photographie sa copie depuis cet écran. Le
      coach la lui rend annotée, avec un mot écrit ou vocal. Une pastille
      apparaît sur l'onglet DS quand la correction arrive.</li>
      <li><b>Les gestes disparaissent</b> — il n'y a plus rien à préparer, et
      les montrer laisserait croire à un travail encore attendu.</li>
      <li><b>Les sujets de bac restent</b>, et se déverrouillent. Un élève peut
      vouloir s'entraîner sur ce chapitre bien après son contrôle, en vue du
      bac.</li>
    </ul>
    <div class="liv-encadre">
      <b>Pourquoi l'épreuve blanche</b> — un chapitre su n'est pas un chapitre
      rendu. Composer deux heures sur un vrai sujet, avec le chronomètre,
      révèle ce que dix exercices bien faits n'auraient pas montré.
    </div>` },

  { titre: "Les progrès — le cœur de la plateforme",
    corps: `
    <p>Pas une note, mais la liste des <b>gestes</b> de la fiche officielle,
    chapitre par chapitre, et l'état de chacun.</p>
    ${ecran("progres", "La liste des gestes du chapitre, avec l'état de chacun. Faites défiler : elle est longue.", "gestes de la fiche")}

    <h3 class="liv-h3">Les gestes</h3>
    <p>Un geste, c'est une chose précise que le programme attend : « déterminer
    l'interfrange sur un graphe », « écrire une équation de désintégration ».
    Chacun porte une marque :</p>
    <ul class="liv-l">
      <li><b>Acquis</b> — l'élève l'a réussi sans hésiter.</li>
      <li><b>Hésité</b> — il y est arrivé, mais péniblement. Le geste reviendra.</li>
      <li><b>Raté</b> — il reviendra vite, et plusieurs fois.</li>
      <li><b>Pas encore travaillé</b> — aucun exercice ne l'a encore abordé.</li>
    </ul>
    <p>À côté de chaque geste, un bouton <b>Travailler</b>. L'élève n'attend pas
    que la plateforme le lui propose : il choisit lui-même ce qu'il reprend, à
    n'importe quel moment, sur n'importe quel geste.</p>
    <div class="liv-encadre">
      <b>Pourquoi des gestes et non des notes</b> — « je n'ai pas compris la
      radioactivité » ne dit rien d'exploitable. « je ne sais pas écrire une
      équation de désintégration » se travaille en un exercice de dix minutes.
    </div>

    <h3 class="liv-h3">Les exercices déjà faits</h3>
    <p>Plus bas sur le même écran, une carte réunit <b>tous les exercices que
    l'élève a traités</b>, repliés par chapitre : « Le niveau sonore · 8 sur
    15 ». Chacun s'affiche avec son titre et son résultat, les ratés et les
    hésités en tête — ceux qu'il faut reprendre.</p>
    <p>Un bouton <b>Rouvrir</b> relance n'importe lequel, avec son énoncé et son
    corrigé. <b>Y compris sur un chapitre terminé.</b> Un contrôle passé ne
    ferme rien : l'élève qui prépare le bac en juin peut rouvrir un exercice
    d'octobre.</p>
    <div class="liv-encadre">
      <b>Rouvrir ne dérange pas le programme</b> — la séance est comptée comme
      supplémentaire. Le travail du soir reste ce qu'il était, et rien n'est
      retiré des jours suivants.
    </div>` },

  { titre: "Les questions fréquentes",
    corps: `
    <dl class="liv-faq">
      <dt>L'élève a manqué plusieurs soirs. Que se passe-t-il ?</dt>
      <dd>Les soirées manquées lui sont proposées en rattrapage, une à la fois.
      Le programme ne s'accumule pas : il s'adapte.</dd>

      <dt>Peut-on mener deux chapitres en même temps ?</dt>
      <dd>Oui, jusqu'à trois. La plateforme prévient que la charge augmente et
      demande confirmation. Le temps par soir passe alors de trente à soixante
      minutes pour deux chapitres, quatre-vingt-dix pour trois.</dd>

      <dt>Que devient un chapitre une fois le contrôle passé ?</dt>
      <dd>Il quitte le programme du soir et revient de loin en loin, en
      questions flash, pour ne pas être oublié d'ici le bac.</dd>

      <dt>L'élève peut-il travailler plus un soir ?</dt>
      <dd>Oui — trois exercices supplémentaires par soir au maximum. Au-delà, la
      plateforme lui conseille de garder les autres pour les soirs suivants :
      chaque chapitre ne compte que quinze exercices.</dd>

      <dt>Où poser une question au coach ?</dt>
      <dd>Sur le serveur Discord du groupe. Les échanges s'y font en petit
      comité, avec les notifications qui vont avec.</dd>
    </dl>` },
];

const doc = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Bosse ta Physique — livret d'utilisation</title>
<style>
/* ── la feuille de style de l'application, pour les écrans ── */
${css}

/* ── le livret lui-même ── */
*{box-sizing:border-box}
body{margin:0;background:#F1F4FE;color:#0E1132;
  font-family:'Inter',system-ui,-apple-system,sans-serif;line-height:1.65}
.liv{max-width:840px;margin:0 auto;padding:44px 26px 80px}
.liv-tete{text-align:center;padding:52px 0 40px;border-bottom:1px solid #E3E8F7}
.liv-tete .sur{font-size:.76rem;letter-spacing:.16em;text-transform:uppercase;
  color:#6C63FF;font-weight:600;margin:0}
.liv-tete h1{font-family:'Poppins',system-ui,sans-serif;font-size:2.3rem;
  letter-spacing:-.03em;margin:12px 0 8px}
.liv-tete p{color:#565E80;margin:0;font-size:1.02rem}
.liv-som{background:#FFF;border:1px solid #E3E8F7;border-radius:18px;
  padding:22px 26px;margin:34px 0 8px}
.liv-som h2{font-family:'Poppins',system-ui,sans-serif;font-size:1rem;margin:0 0 10px}
.liv-som ol{margin:0;padding-left:20px;color:#565E80;font-size:.92rem}
.liv-som li{margin:5px 0}
.liv-som a{color:#4E4BC4;text-decoration:none}
section.liv-s{margin-top:46px;padding-top:30px;border-top:1px solid #E3E8F7}
section.liv-s:first-of-type{border-top:0}
section.liv-s > h2{font-family:'Poppins',system-ui,sans-serif;font-size:1.5rem;
  letter-spacing:-.02em;margin:0 0 14px}
section.liv-s > p{color:#565E80;margin:12px 0}
.liv-encadre{background:#FFF;border:1px solid #E3E8F7;border-left:3px solid #E7B24E;
  border-radius:12px;padding:14px 18px;margin:18px 0;font-size:.92rem;color:#565E80}
.liv-encadre b{color:#0E1132}
.liv-fig{margin:26px 0;text-align:center}
.liv-leg{font-size:.84rem;color:#8A90AB;margin-top:12px;font-style:italic}
.liv-h3{font-family:'Poppins',system-ui,sans-serif;font-size:1.06rem;
  margin:26px 0 8px;color:#0E1132}
.liv-l{color:#565E80;margin:10px 0;padding-left:20px;font-size:.94rem}
.liv-l li{margin:6px 0}
.liv-l b{color:#0E1132}
.liv-faq dt{font-weight:600;margin-top:16px}
.liv-faq dd{margin:5px 0 0;color:#565E80;font-size:.94rem}
.liv-pied{margin-top:56px;padding-top:22px;border-top:1px solid #E3E8F7;
  text-align:center;color:#8A90AB;font-size:.82rem}

/* ── le cadre de téléphone qui porte les vrais écrans ── */
.liv-tel{width:352px;margin:0 auto;background:#0E1132;border-radius:34px;
  padding:11px;box-shadow:0 18px 44px rgba(14,17,50,.18);position:relative}
.liv-ecran{background:#F1F4FE;border-radius:25px;overflow-y:auto;overflow-x:hidden;
  height:600px;position:relative;display:none;
  -webkit-overflow-scrolling:touch;scrollbar-width:thin}
.liv-ecran.on{display:block}
.liv-ecran::-webkit-scrollbar{width:5px}
.liv-ecran::-webkit-scrollbar-thumb{background:#C9CFE8;border-radius:3px}
/* la barre d'onglets du livret, sous l'écran */
.liv-onglets{display:flex;gap:2px;margin-top:9px;background:#1A1E44;
  border-radius:14px;padding:4px}
.liv-onglets button{flex:1;border:0;background:transparent;color:#9AA2CC;
  font-family:'Inter',system-ui,sans-serif;font-size:.68rem;font-weight:600;
  padding:7px 2px;border-radius:10px;cursor:pointer}
.liv-onglets button.on{background:#6C63FF;color:#FFF}
/* Les écrans capturés portent des positions fixes et des hauteurs d'écran
   entier : on les ramène à l'intérieur du cadre. */

.liv-ecran .tabbar,.liv-ecran nav.nav{display:none!important}
.liv-ecran .b,.liv-ecran .wrapc,.liv-ecran .wrap{height:auto;min-height:0;
  overflow:visible}
.liv-ecran main{overflow:visible;padding-bottom:16px}
.liv-ecran *{animation:none!important;transition:none!important}

@media print{
  body{background:#FFF}
  .liv{max-width:none;padding:0 12mm}
  section.liv-s{page-break-inside:avoid}
  .liv-fig{page-break-inside:avoid}
  .liv-tel{box-shadow:none;border:1px solid #0E1132}
  .liv-ecran{height:auto;max-height:none;overflow:visible}
  .liv-onglets{display:none}
}
@media (max-width:420px){ .liv-tel{width:100%} }
</style></head>
<body><div class="liv">

<header class="liv-tete">
  <p class="sur">Bosse ta Physique</p>
  <h1>Livret d'utilisation</h1>
  <p>Terminale spécialité physique-chimie</p>
</header>

<nav class="liv-som">
  <h2>Ce que contient ce livret</h2>
  <ol>${sections.map((s, k) =>
    `<li><a href="#s${k}">${s.titre}</a></li>`).join("")}</ol>
</nav>

${sections.map((s, k) => `
<section class="liv-s" id="s${k}">
  <h2>${s.titre}</h2>
  ${s.corps}
</section>`).join("")}

<footer class="liv-pied">
  Bosse ta Physique — les écrans reproduits dans ce livret sont ceux de
  l'application.
</footer>

</div>
<script>
/* La navigation des téléphones du livret : un clic change d'écran. */
/* Chaque téléphone s'ouvre sur la carte dont parle la section : on la
   remonte en haut de l'écran, sinon le lecteur ne la voit pas. */
function viser(tel) {
  var a = tel.dataset.ancre;
  if (!a) return;
  var vue = tel.querySelector(".liv-ecran.on");
  if (!vue) return;
  var cibles = vue.querySelectorAll(".card, section, h3, h4");
  for (var i = 0; i < cibles.length; i++) {
    if (cibles[i].textContent.indexOf(a) >= 0) {
      vue.scrollTop = Math.max(0, cibles[i].offsetTop - 12);
      return;
    }
  }
}
document.querySelectorAll(".liv-tel").forEach(function (tel) {
  viser(tel);
  tel.querySelectorAll(".liv-onglets button").forEach(function (b) {
    b.addEventListener("click", function () {
      tel.querySelectorAll(".liv-onglets button")
        .forEach(function (x) { x.classList.remove("on"); });
      b.classList.add("on");
      tel.querySelectorAll(".liv-ecran").forEach(function (e) {
        e.classList.toggle("on", e.dataset.vue === b.dataset.cible);
        if (e.dataset.vue === b.dataset.cible) e.scrollTop = 0;
      });
    });
  });
});
</script>
</body></html>`;

writeFileSync("/mnt/user-data/outputs/livret-utilisation.html", doc);
console.log("  livret écrit : " + Math.round(doc.length / 1024) + " ko · "
  + sections.length + " sections");
