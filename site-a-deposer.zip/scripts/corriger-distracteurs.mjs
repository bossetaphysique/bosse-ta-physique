/* Travail et énergie, Les titrages, La radioactivité — les questions que le
   coach n'avait pas reprises. */
export const CORRECTIONS = {

  /* ---------------- Travail et énergie ---------------- */

  "ene-05": [
    "la force est verticale : son travail vaut alors m·g·h",
    "W &lt; 0 : force et déplacement sont de sens contraires",
    "W = 0 : force et déplacement sont perpendiculaires",
    "W > 0 : force et déplacement sont de même sens",
  ],

  "ene-09": [
    "de la vitesse du système, qui fixe la durée du trajet",
    "de la masse seulement, l'altitude n'intervenant pas",
    "de la différence d'altitude seulement, et de la masse",
    "du chemin suivi entre le point de départ et celui d'arrivée",
  ],

  "ene-14": [
    "W = E·AB/q = U_AB/q, quotient de la tension par la charge",
    "W = q·E/AB = q·U_AB/AB², la tension divisée par la distance",
    "W = q/U_AB = q/(E·AB), la charge divisée par la tension",
    "W = q·E·AB = q·U_AB, la charge multipliée par la tension",
  ],

  "ene-16": [
    "elle est constante en direction, en sens et en valeur",
    "son travail ne dépend pas du chemin, mais des seules positions",
    "elle est verticale, comme le poids ou la force électrostatique",
    "son travail est toujours positif, quel que soit le déplacement",
  ],

  "ene-17": [
    "en calculant sa norme, plus grande que celle des autres forces",
    "en mesurant la température, qui s'élève au cours du trajet",
    "en montrant que l'expression de son travail contient la longueur du trajet",
    "en disant qu'elle freine le système, donc qu'elle dissipe l'énergie",
  ],

  "ene-18": [
    "calculer la masse du système à partir du travail des forces",
    "déterminer le sens du mouvement à partir du signe du travail",
    "choisir le référentiel dans lequel écrire le bilan des forces",
    "savoir si l'énergie mécanique se conserve ou non au cours du trajet",
  ],

  "ene-20": [
    "calculer la vitesse initiale, qui fixe l'énergie cinétique de départ",
    "regarder si l'énoncé mentionne des frottements le long du trajet",
    "tracer la trajectoire, dont dépend le travail des forces en jeu",
    "vérifier la masse, qui doit rester constante tout au long du trajet",
  ],

  "ene-23": [
    "ΔE_c = ΣW(forces extérieures)",
    "ΔE_c = W(poids) seulement",
    "ΔE_c = 0 dans tous les cas",
    "ΔE_c = ΔE_pp, les deux variations étant égales",
  ],

  "ene-25": [
    "quand l'altitude varie, l'énergie potentielle intervenant alors",
    "dès que la question demande une vitesse, avec ou sans frottements",
    "quand il y a des frottements, l'énergie mécanique ne se conservant plus",
    "jamais : l'énergie mécanique suffit dans tous les cas de figure",
  ],

  "ene-26": [
    "l'énergie cinétique, puisqu'elle croît au cours de la chute",
    "l'énergie mécanique, puisqu'elle est la somme des deux autres",
    "l'énergie potentielle, puisqu'elle vaut m·g·h au point le plus haut",
    "cela dépend du cas : l'ordre des courbes change selon le mouvement",
  ],

  "ene-27": [
    "s'annule, l'énergie se transformant entièrement en potentielle",
    "reste constante, car la masse du système ne varie pas",
    "décroît, car l'altitude du système diminue au cours de la chute",
    "croît, car la vitesse du système augmente au cours de la chute",
  ],

  "ene-28": [
    "en vérifiant qu'à chaque instant, E_m vaut la somme des deux autres",
    "en mesurant les aires sous chacune des trois courbes tracées",
    "en comparant les pentes des trois courbes en un même instant",
    "en regardant les couleurs, l'énoncé fixant une couleur par énergie",
  ],

  "ene-35": [
    "la force motrice, dirigée dans le sens du déplacement",
    "le poids, dont le travail vaut m·g·h sur tout trajet",
    "la réaction normale, perpendiculaire au déplacement",
    "les frottements, opposés au sens du déplacement",
  ],

  "energie-t04": [
    "elle ne varie pas au cours du temps, ni en valeur ni en direction",
    "elle est verticale, comme le poids ou la poussée d'Archimède",
    "son travail est toujours positif, quel que soit le trajet suivi",
    "son travail ne dépend pas du chemin, mais des seuls points de départ et d'arrivée",
  ],

  "energie-t07": [
    "E_c constante, E_p et E_m décroissantes, avec E_c + E_p = E_m",
    "les trois courbes croissantes, avec E_c + E_p = E_m à chaque instant",
    "E_m décroissante, E_c et E_p croissantes, avec E_c + E_p = E_m",
    "E_m constante, E_p décroissante, E_c croissante, avec E_c + E_p = E_m",
  ],

  /* ---------------- Les titrages ---------------- */

  "tit-02": [
    "à mesurer le pH d'une solution de concentration inconnue",
    "à déterminer la quantité de matière d'une espèce en solution",
    "à séparer deux espèces présentes dans une même solution",
    "à accélérer une réaction lente entre deux espèces dissoutes",
  ],

  "tit-03": [
    "un pH-mètre, pour suivre l'évolution du pH au cours du versement",
    "un conductimètre, pour suivre la conductivité de la solution",
    "aucun : l'équivalence se repère au changement de couleur",
    "un spectrophotomètre, pour suivre l'absorbance de la solution",
  ],

  "tit-05": [
    "pour que la sonde reste immergée pendant tout le versement",
    "pour que le titrage se déroule plus vite, la réaction étant rapide",
    "pour que la solution change nettement de couleur à l'équivalence",
    "sinon les réactifs ne seraient pas entièrement consommés à l'équivalence",
  ],

  "tit-06": [
    "pour éviter une réaction parasite qui consommerait le réactif titrant",
    "pour que le pH varie nettement au voisinage de l'équivalence",
    "pour économiser du réactif titrant, qui coûte cher à préparer",
    "pour que la courbe obtenue soit une droite de part et d'autre",
  ],

  "tit-08": [
    "le moment où le pH de la solution atteint exactement 7,0",
    "la fin du versement, quand la burette est entièrement vidée",
    "l'instant où les réactifs sont dans les proportions stœchiométriques",
    "le moment où la solution change de couleur dans le bécher",
  ],

  "tit-15": [
    "à la rupture de pente, intersection des deux portions de droite",
    "au premier point de mesure, avant tout versement de titrant",
    "au maximum de σ, atteint au voisinage de l'équivalence",
    "quand σ s'annule, tous les ions ayant alors été consommés",
  ],

  "tit-19": [
    "la loi de Beer-Lambert avant puis après l'équivalence",
    "la relation à l'équivalence avant puis après le point équivalent",
    "l'équation de la réaction support avant puis après l'équivalence",
    "la loi de Kohlrausch avant puis après l'équivalence",
  ],

  "tit-24": [
    "oui : il augmente le volume équivalent, donc la concentration trouvée",
    "non : la quantité de matière de l'espèce titrée reste inchangée",
    "oui : il divise la concentration trouvée par le facteur de dilution",
    "cela dépend du volume ajouté, au-delà de 10 mL le résultat change",
  ],

  "tit-25": [
    "le volume équivalent double, la conductivité étant divisée par deux",
    "la réaction ne se produit pas, faute de contact entre les réactifs",
    "la surface des plaques en contact varie, et la mesure est faussée",
    "rien : la sonde mesure la conductivité quelle que soit l'immersion",
  ],

  "tit-31": [
    "la différence brute entre la valeur trouvée et celle de référence",
    "le z-score, quotient de l'écart par l'incertitude sur la mesure",
    "l'écart relatif, rapporté à la valeur de référence",
    "la moyenne des deux valeurs, trouvée et de référence",
  ],

  "tit-33": [
    "le résultat n'est pas cohérent avec la valeur de référence",
    "l'incertitude est nulle, le z-score étant alors très grand",
    "le résultat est cohérent avec la valeur de référence",
    "la mesure est parfaite, le z-score dépassant l'unité",
  ],

  "tit-34": [
    "mal lire la burette, et fausser ainsi le volume équivalent",
    "oublier les coefficients stœchiométriques dans la relation à l'équivalence",
    "oublier de convertir les volumes en litres avant le calcul",
    "ne pas agiter la solution, et fausser ainsi la mesure de la sonde",
  ],

  "titrages-t02": [
    "C_A = C_B·V_A/V_éq = 0,10 × 20,0/12,0 = 0,17 mol·L⁻¹",
    "C_A·V_A = C_B·V_éq, donc C_A = 0,10 × 12,0/20,0 = 6,0 × 10⁻² mol·L⁻¹",
    "C_A = C_B = 0,10 mol·L⁻¹, les volumes se simplifiant à l'équivalence",
    "C_A = C_B·V_éq = 0,10 × 12,0 = 1,2 mol·L⁻¹, sans diviser par V_A",
  ],

  "titrages-t04": [
    "l'hélianthine (3,1 – 4,4), dont le virage est le plus visible",
    "celui dont la zone de virage est la plus large, pour être sûr de la voir",
    "n'importe lequel : le choix de l'indicateur ne change pas V_éq",
    "celui dont la zone de virage contient 8,7 : la phénolphtaléine (8,2 – 10,0)",
  ],

  /* ---------------- La radioactivité ---------------- */

  "rad-07": [
    "on lit le type de désintégration sur le diagramme (N,Z), puis on conclut",
    "on écrit les conservations de A et de Z, qui donnent la particule émise",
    "on cherche le noyau fils dans la classification périodique des éléments",
    "on calcule la demi-vie, dont la valeur indique le type d'émission",
  ],

  "rad-17": [
    "« le noyau X se situe au-dessus de la vallée : trop de neutrons, émetteur β⁻ »",
    "« le noyau X se situe en dessous de la vallée : trop de neutrons, émetteur β⁻ »",
    "« le noyau X se situe au-dessus de la vallée : trop de protons, émetteur β⁺ »",
    "« le noyau X se situe sur la vallée de stabilité : il n'émet aucune particule »",
  ],

  "rad-18": [
    "chercher le noyau dans la classification, puis appliquer Soddy",
    "lire le diagramme pour le type, puis appliquer Soddy pour le noyau fils",
    "calculer la demi-vie, puis en déduire l'activité du noyau père",
    "appliquer Soddy pour le noyau fils, puis lire le diagramme pour le type",
  ],

  "rad-23": [
    "tracer la courbe et vérifier qu'elle décroît bien vers zéro",
    "vérifier que N(0) = N₀, ce qui suffit à établir la solution",
    "calculer la demi-vie, puis vérifier qu'elle vaut bien ln 2/λ",
    "dériver, reporter dans dN/dt + λ·N, et montrer que le résultat vaut 0",
  ],

  "rad-26": [
    "la constante λ est divisée par deux, la décroissance ralentissant",
    "l'activité s'annule, tous les noyaux s'étant désintégrés",
    "la moitié des noyaux initialement présents s'est désintégrée",
    "tous les noyaux se sont désintégrés, l'échantillon étant épuisé",
  ],

  "rad-30": [
    "en vérifiant que N s'annule à 2·t₁/₂, puis reste nul ensuite",
    "en vérifiant qu'il reste N₀/4 à 2·t₁/₂ et N₀/8 à 3·t₁/₂",
    "en comparant à λ : le produit λ·t₁/₂ doit valoir exactement 1",
    "aucun contrôle n'est possible : la lecture graphique est unique",
  ],

  "rad-38": [
    "du même ordre de grandeur que la durée à mesurer, ou plus grande",
    "exactement égale à la durée à mesurer, à quelques pour cent près",
    "très courte devant la durée à mesurer, pour que l'activité ait décru",
    "sans importance : tout radionucléide convient à toute datation",
  ],

  "radioactivite-t13": [
    "il est présent dans tous les objets, organiques comme minéraux",
    "sa demi-vie est du même ordre que les âges à mesurer : l'activité reste mesurable",
    "sa demi-vie est très courte : l'activité décroît vite et se mesure bien",
    "sa demi-vie est très longue : l'activité reste forte et se mesure bien",
  ],

};
export const ENONCES = {};
