/* ============================================================================
   Fabrique la version autonome de l'application, celle que le banc d'essai
   pilote : le code de src/, débarrassé de Supabase, en un seul fichier.
   Appelé automatiquement par « npm run parcours ».
   ========================================================================== */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ici = dirname(fileURLToPath(import.meta.url));
const src = (p) => readFileSync(resolve(ici, "..", "src", p), "utf8");

const banques = src("data/banques.js")
  /* LA FEUILLE DE STYLE DE KATEX ne passe pas par esbuild dans cet aperçu :
     on la retire, les formules s'y afficheront en texte brut. L'aperçu sert à
     parcourir les écrans, pas à juger le rendu des formules. */
  .replace('import "katex/dist/katex.min.css";\n', "")
  .replace("export const BANQUES", "const BANQUES")
  .replace("export const TITRES_QT", "const TITRES_QT")
  .replace("export const RAPPELS_QT", "const RAPPELS_QT");

/* Les sujets type bac vivent dans leur propre fichier : l'aperçu doit les
   embarquer comme les banques, sinon le moteur ne les trouve pas. */
const sujets = src("data/sujets-bac.js")
  .replace("export { SUJETS_BAC };", "");

const moteur = src("lib/planning.js")
  .replace('import { BANQUES, TITRES_QT, RAPPELS_QT } from "../data/banques.js";\n', "")
  .replace('import { SUJETS_BAC } from "../data/sujets-bac.js";\n', "")
  .split("\nexport {")[0];

/* Les textes légaux et leur pied de page : l'aperçu les embarque comme le
   reste, sinon l'import reste pendant et la construction échoue. */
const legalData = src("data/legal.js")
  .replace("export const CGV", "const CGV")
  .replace("export const CONFIDENTIALITE", "const CONFIDENTIALITE");
const legalVue = src("lib/legal.jsx")
  .replace('import React, { useState } from "react";\n', "")
  .replace('import { CGV, CONFIDENTIALITE } from "../data/legal.js";\n', "")
  .replace(/export function /g, "function ");

let app = src("App.jsx")
  /* LA FEUILLE DE STYLE DE KATEX ne passe pas par esbuild ici : elle réclame
     ses fichiers de polices, qu'aucun chargeur ne traite dans cet aperçu. On
     la retire — les formules s'y affichent en texte brut, l'aperçu servant à
     parcourir les écrans, pas à juger le rendu des formules. */
  .replace('import "katex/dist/katex.min.css";\n', "");
const d = app.indexOf("import {\n  CHAPITRES,");
const f = app.indexOf('} from "./lib/db.js";') + '} from "./lib/db.js";'.length;
app = (app.slice(0, d) + app.slice(f))
  .replace('import { useState, useEffect, useMemo, useRef } from "react";\n', "")
  .replace('import { SUJETS_BAC } from "./data/sujets-bac.js";\n', "")
  .replace('import { PiedLegal } from "./lib/legal.jsx";\n', "");

/* La base de données est remplacée par des fonctions inertes : le banc d'essai
   éprouve l'interface et le moteur, pas Supabase. */
const bouchons = `
const supabaseActif = false;
const rien = async () => null;
const chargerEtat = rien, chargerBiblio = rien, chargerSujets = rien, monProfil = rien;
const chargerRessources = rien, ajouterRessourceDb = rien, chargerBanque = rien;
const chargerDirects = rien, enregistrerDirect = rien;
const chargerIdeesOral = rien, ajouterIdeeOral = rien;
const sauverEtat = () => {};
const ajouterExerciceDb = rien, creerSujet = rien, repondreSujet = rien;
const envoyerVocalDb = rien, envoyerFichierDb = rien, deconnexion = rien;
/* L'envoi groupé — texte, vocal et document dans un seul message. */
const envoyerMessageComplet = rien;
const epinglerSujetDb = rien, transformerEnRessourceDb = rien, retirerRessourceDb = rien;
const validerReponseDb = rien, signalerMessageDb = rien;

`;

mkdirSync(resolve(ici, "..", ".apercu"), { recursive: true });
writeFileSync(resolve(ici, "..", ".apercu", "apercu.jsx"),
  'import { useState, useEffect, useMemo, useRef } from "react";\n\n'
  + banques + "\n" + sujets + "\n" + moteur + bouchons
  + legalData + "\n" + legalVue + "\n" + app);
console.log("aperçu autonome préparé");
