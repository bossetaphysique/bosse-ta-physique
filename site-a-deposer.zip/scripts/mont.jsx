import React from "react";
import { createRoot } from "react-dom/client";
import App from "../.apercu/apercu.jsx";
const cible = document.getElementById("appVivante");
if (cible) createRoot(cible).render(React.createElement(App));
