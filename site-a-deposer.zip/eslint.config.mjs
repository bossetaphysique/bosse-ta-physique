/* ═══════════════════════════════════════════════════════════════════════════
   Le contrôle des RÉFÉRENCES : une variable employée hors de la fonction où
   elle est déclarée passe la construction sans bruit, puis laisse la page
   blanche à l'exécution. C'est ainsi que l'espace parent est tombé.
   Lancé par « npm run verifier ».
   ═══════════════════════════════════════════════════════════════════════════ */
export default [{
  files: ["src/**/*.{js,jsx}"],
  languageOptions: {
    ecmaVersion: 2022, sourceType: "module",
    parserOptions: { ecmaFeatures: { jsx: true } },
    globals: { window: "readonly", document: "readonly", console: "readonly",
      setTimeout: "readonly", clearTimeout: "readonly", setInterval: "readonly",
      clearInterval: "readonly", fetch: "readonly", navigator: "readonly",
      localStorage: "readonly", FileReader: "readonly", Blob: "readonly",
      URL: "readonly", File: "readonly", FormData: "readonly", Audio: "readonly",
      MediaRecorder: "readonly", AbortController: "readonly", Image: "readonly",
      performance: "readonly", alert: "readonly", confirm: "readonly",
      requestAnimationFrame: "readonly", globalThis: "readonly",
      atob: "readonly", btoa: "readonly", crypto: "readonly", Intl: "readonly",
      TextDecoder: "readonly", TextEncoder: "readonly", process: "readonly",
      DecompressionStream: "readonly", Response: "readonly",
      createImageBitmap: "readonly" },
  },
  rules: { "no-undef": "error" },
}];
