// ============================================================================
// WEBHOOK STRIPE — met a jour l'abonnement de l'eleve
// A deployer plus tard, quand vous ouvrirez les paiements.
// Deploiement : supabase functions deploy stripe-webhook --no-verify-jwt
// Secrets a definir : STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
//                     SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
// ============================================================================

import Stripe from "https://esm.sh/stripe@14?target=deno";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, { apiVersion: "2024-06-20" });
const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

Deno.serve(async (req) => {
  const signature = req.headers.get("stripe-signature");
  const corps = await req.text();
  let evenement;
  try {
    evenement = await stripe.webhooks.constructEventAsync(
      corps, signature!, Deno.env.get("STRIPE_WEBHOOK_SECRET")!,
    );
  } catch (e) {
    return new Response("Signature invalide : " + e.message, { status: 400 });
  }

  const majAbonnement = async (email: string, statut: string, objet: any) => {
    const { data: profil } = await supabase
      .from("profils").select("id").eq("email_facturation", email).maybeSingle();
    const eleveId = profil?.id;
    if (!eleveId) return;
    await supabase.from("abonnements").upsert({
      eleve_id: eleveId,
      stripe_customer_id: objet.customer ?? null,
      stripe_subscription_id: objet.id ?? null,
      statut,
      maj_le: new Date().toISOString(),
    });
  };

  switch (evenement.type) {
    case "checkout.session.completed": {
      const s: any = evenement.data.object;
      await majAbonnement(s.customer_details?.email ?? s.customer_email, "actif", s);
      break;
    }
    case "customer.subscription.updated":
    case "customer.subscription.deleted": {
      const s: any = evenement.data.object;
      const client: any = await stripe.customers.retrieve(s.customer as string);
      const statut = s.status === "active" || s.status === "trialing" ? "actif" : "inactif";
      await majAbonnement(client.email, statut, s);
      break;
    }
  }

  return new Response(JSON.stringify({ recu: true }), {
    headers: { "Content-Type": "application/json" },
  });
});
