-- ═══════════════════════════════════════════════════════════════════════════
--  RATTACHER LES CORRIGÉS DÉJÀ DÉPOSÉS
--
--  Le dépôt d'un corrigé, fichier par fichier, ne mettait à jour que l'écran :
--  le PDF montait bien dans le stockage, mais « exercices.corrige_url » n'était
--  jamais écrit. Les fichiers sont donc intacts, seulement non rattachés.
--
--  Ce script les raccroche. Il ne touche QUE les lignes dont le corrigé est
--  absent : un corrigé déjà en place n'est jamais remplacé.
--
--  À PASSER UNE SEULE FOIS, dans l'éditeur SQL de Supabase. La correction de
--  l'application évite que le cas se reproduise.
-- ═══════════════════════════════════════════════════════════════════════════

-- ── 1. CE QUI SERA ÉCRIT, sans rien modifier ──────────────────────────────
--  Vérifiez d'abord en ouvrant une des adresses dans votre navigateur : si le
--  PDF s'affiche, l'écriture de l'étape 2 est sûre.

with racine as (
  select regexp_replace(enonce_url, '/storage/v1/object/public/.*$', '') as base
  from exercices
  where enonce_url like 'http%'
  limit 1
),
dernier as (
  -- Le fichier le plus récent pour chaque référence : un corrigé redéposé
  -- plusieurs fois laisse plusieurs objets, seul le dernier compte.
  -- Le chapitre vient du dossier (« corriges/<chapitre>/… ») et la référence
  -- du nom de fichier : on ne rapproche que si les deux concordent.
  select distinct on (split_part(name, '/', 2),
                      substring(name from '[a-z]{2,4}-[a-z0-9]+-corrige'))
         split_part(name, '/', 2) as chapitre,
         regexp_replace(
           substring(name from '[a-z]{2,4}-[a-z0-9]+-corrige'),
           '-corrige$', '') as ref,
         name
  from storage.objects
  where bucket_id = 'documents'
    and name like 'corriges/%-corrige.pdf'
  order by split_part(name, '/', 2),
           substring(name from '[a-z]{2,4}-[a-z0-9]+-corrige'),
           created_at desc
)
select e.chapitre, e.ref, e.titre,
       (select base from racine)
         || '/storage/v1/object/public/documents/' || d.name as corrige_a_poser
from exercices e
join dernier d on d.ref = e.ref and d.chapitre = e.chapitre
where e.corrige_url is null
order by e.chapitre, e.ref;


-- ── 2. L'ÉCRITURE ─────────────────────────────────────────────────────────
--  À ne passer qu'une fois l'étape 1 vérifiée.

with racine as (
  select regexp_replace(enonce_url, '/storage/v1/object/public/.*$', '') as base
  from exercices
  where enonce_url like 'http%'
  limit 1
),
dernier as (
  -- Le chapitre vient du dossier (« corriges/<chapitre>/… ») et la référence
  -- du nom de fichier : on ne rapproche que si les deux concordent.
  select distinct on (split_part(name, '/', 2),
                      substring(name from '[a-z]{2,4}-[a-z0-9]+-corrige'))
         split_part(name, '/', 2) as chapitre,
         regexp_replace(
           substring(name from '[a-z]{2,4}-[a-z0-9]+-corrige'),
           '-corrige$', '') as ref,
         name
  from storage.objects
  where bucket_id = 'documents'
    and name like 'corriges/%-corrige.pdf'
  order by split_part(name, '/', 2),
           substring(name from '[a-z]{2,4}-[a-z0-9]+-corrige'),
           created_at desc
)
update exercices e
set corrige_url = (select base from racine)
                  || '/storage/v1/object/public/documents/' || d.name
from dernier d
where d.ref = e.ref
  and d.chapitre = e.chapitre
  and e.corrige_url is null;


-- ── 3. CONTRÔLE ───────────────────────────────────────────────────────────
--  Ce qui reste sans corrigé après l'écriture : ceux-là n'ont jamais eu de
--  PDF déposé, il faut les déposer depuis l'espace coach.

select chapitre, ref, titre
from exercices
where corrige_url is null
order by chapitre, ref;
