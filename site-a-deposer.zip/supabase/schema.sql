-- ============================================================================
-- BOSSE TA PHYSIQUE — schema complet
-- A coller dans Supabase > SQL Editor > New query, puis "Run".
-- Peut etre relance sans risque : tout est en "if not exists".
-- ============================================================================

-- ---------------------------------------------------------------- profils --
create table if not exists profils (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'eleve' check (role in ('eleve','coach','parent')),
  prenom text,
  classe text,
  parent_email text,
  cree_le timestamptz not null default now()
);

-- ------------------------------------------------- etat de travail eleve --
-- Le planning, les chapitres et les reglages sont stockes en JSON :
-- c'est l'etat que l'application relit a chaque connexion.
create table if not exists etat_eleve (
  eleve_id uuid primary key references auth.users on delete cascade,
  donnees jsonb not null default '{}'::jsonb,
  maj_le timestamptz not null default now()
);

-- ------------------------------------------------------------ exercices --
create table if not exists exercices (
  id uuid primary key default gen_random_uuid(),
  chapitre text not null,
  usage text not null default 'entrainement'
    check (usage in ('entrainement','bac','evaluation')),
  titre text not null,
  duree int not null check (duree between 5 and 240),
  niveau text not null default 'moyen' check (niveau in ('facile','moyen','difficile')),
  enonce_url text,
  corrige_url text,
  cree_le timestamptz not null default now()
);
create index if not exists exercices_chapitre_idx on exercices (chapitre, usage);

-- ------------------------------------------- ressources par chapitre --
create table if not exists videos_chapitre (
  id uuid primary key default gen_random_uuid(),
  chapitre text not null,
  type text not null default 'Lecon' check (type in ('Lecon','Question type','Resume')),
  titre text not null,
  duree text,
  url_vimeo text not null,
  ordre int not null default 0,
  cree_le timestamptz not null default now()
);
create index if not exists videos_chapitre_idx on videos_chapitre (chapitre, type, ordre);

create table if not exists fiches_chapitre (
  id uuid primary key default gen_random_uuid(),
  chapitre text not null,
  titre text not null,
  pages int,
  chemin text,            -- PDF depose dans le bucket prive "ressources"
  url text,               -- ou lien externe
  premium boolean not null default false,
  cree_le timestamptz not null default now()
);
create index if not exists fiches_chapitre_idx on fiches_chapitre (chapitre);

-- ------------------------------------------------------------ ressources --
-- Videos Vimeo et fiches de revision, saisies par le coach.
create table if not exists ressources (
  id uuid primary key default gen_random_uuid(),
  chapitre text not null,
  type text not null check (type in ('Leçon','Question type','Résumé','Fiche')),
  titre text not null,
  url text not null,
  duree text,
  pages int,
  cree_le timestamptz not null default now()
);
create index if not exists ressources_chapitre_idx on ressources (chapitre, type);

-- ------------------------------------------------ idees de Grand oral --
-- Une fiche alimente deux choses : le carrousel d'idees des eleves sans piste,
-- et les questions tirees au sort pendant l'entrainement a l'echange.
create table if not exists idees_grand_oral (
  id uuid primary key default gen_random_uuid(),
  chapitre text not null,
  niveau text not null default 'accessible' check (niveau in ('accessible','ambitieux')),
  question text not null,
  notions text,
  pistes jsonb not null default '[]'::jsonb,
  jury jsonb not null default '[]'::jsonb,
  cree_le timestamptz not null default now()
);

-- ------------------------------------------------- banque de questions --
-- Alimente le test diagnostic (diagnostic = true, 10 par chapitre) et les
-- questions flash du soir (tout le reste). Une ligne = une question.
create table if not exists banque_questions (
  ref text primary key,                       -- ex. cin-07
  chapitre text not null,                     -- identifiant du chapitre
  niveau text not null default 'terminale',
  type_question text not null default 'choix_simple'
    check (type_question in ('choix_simple','choix_multiple','ordre')),
  difficulte text not null default 'cours'
    check (difficulte in ('cours','methode','application')),
  source_qt text,
  enonce text not null,
  options jsonb not null,
  bonne_reponse jsonb not null,               -- toujours un tableau d'index
  explication text,
  piege text,
  image text,
  tags jsonb not null default '[]'::jsonb,
  diagnostic boolean not null default false,
  actif boolean not null default true,
  cree_le timestamptz not null default now()
);
create index if not exists banque_chapitre_idx on banque_questions (chapitre, diagnostic, actif);

-- --------------------------------------------- questions de diagnostic --
create table if not exists questions_diagnostic (
  id uuid primary key default gen_random_uuid(),
  chapitre text not null,
  enonce text not null,
  options jsonb not null,
  bonne_reponse int not null,
  cree_le timestamptz not null default now()
);

-- ----------------------------------------------------------- permanence --
create table if not exists sujets_permanence (
  id uuid primary key default gen_random_uuid(),
  chapitre text not null,
  auteur_id uuid not null references auth.users on delete cascade,
  titre text not null,
  piece_jointe_url text,
  statut text not null default 'attente' check (statut in ('attente','resolu','archive')),
  epingle boolean not null default false,      -- mis en avant par le coach, en tete du chapitre
  ressource boolean not null default false,    -- transforme en ressource d'apprentissage
  ressource_titre text,
  ressource_resume text,
  cree_le timestamptz not null default now()
);

alter table sujets_permanence add column if not exists ressource boolean not null default false;
alter table sujets_permanence add column if not exists ressource_titre text;
alter table sujets_permanence add column if not exists ressource_resume text;
create index if not exists sujets_chapitre_idx on sujets_permanence (chapitre, epingle desc, cree_le desc);

create table if not exists messages_permanence (
  id uuid primary key default gen_random_uuid(),
  sujet_id uuid not null references sujets_permanence on delete cascade,
  auteur_id uuid not null references auth.users on delete cascade,
  auteur_nom text,
  role text not null default 'eleve' check (role in ('eleve','prof')),
  corps text not null,
  piece_jointe_url text,
  reponse_validee boolean not null default false,   -- reponse d'eleve validee par le coach
  signale boolean not null default false,           -- message contenant une erreur
  signale_commentaire text,
  audio_chemin text,          -- vocal : chemin dans le bucket prive "permanence"
  audio_duree int,            -- duree en secondes
  fichier_chemin text,        -- photo de copie ou PDF, meme bucket prive
  fichier_type text,          -- image/jpeg, application/pdf...
  fichier_nom text,
  cree_le timestamptz not null default now()
);

-- si la table existait deja sans ces colonnes
alter table messages_permanence add column if not exists audio_chemin text;
alter table messages_permanence add column if not exists audio_duree int;
alter table messages_permanence add column if not exists fichier_chemin text;
alter table messages_permanence add column if not exists fichier_type text;
alter table messages_permanence add column if not exists fichier_nom text;
alter table messages_permanence add column if not exists signale_commentaire text;
create index if not exists messages_sujet_idx on messages_permanence (sujet_id);

-- --------------------------------------------------------------- directs --
create table if not exists directs (
  id uuid primary key default gen_random_uuid(),
  semaine int not null,
  jour int,                      -- 0 = lundi
  heure text,                    -- "18:00"
  duree int default 60,
  titre text not null,
  chapitre text,
  date_heure timestamptz,
  lien_visio text,
  replay_url text,
  correction_url text
);
alter table directs add column if not exists jour int;
alter table directs add column if not exists heure text;
alter table directs add column if not exists duree int default 60;
create unique index if not exists directs_semaine_idx on directs (semaine);

create table if not exists inscriptions_direct (
  direct_id uuid not null references directs on delete cascade,
  eleve_id uuid not null references auth.users on delete cascade,
  statut text not null default 'inscrit',
  primary key (direct_id, eleve_id)
);

create table if not exists questions_direct (
  id uuid primary key default gen_random_uuid(),
  direct_id uuid not null references directs on delete cascade,
  eleve_id uuid not null references auth.users on delete cascade,
  corps text not null,
  traitee boolean not null default false,
  cree_le timestamptz not null default now()
);

-- ------------------------------------------------- evaluations blanches --
create table if not exists copies (
  id uuid primary key default gen_random_uuid(),
  eleve_id uuid not null references auth.users on delete cascade,
  semaine int,
  exercices jsonb,
  fichier_url text,
  statut text not null default 'en_attente' check (statut in ('en_attente','corrigee')),
  conseils text,
  cree_le timestamptz not null default now()
);

-- ------------------------------------------------------------ abonnement --
create table if not exists abonnements (
  eleve_id uuid primary key references auth.users on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text,
  statut text not null default 'inactif',
  maj_le timestamptz not null default now()
);

-- ---------------------------------------------------------------- bilans --
create table if not exists bilans (
  id uuid primary key default gen_random_uuid(),
  eleve_id uuid not null references auth.users on delete cascade,
  type text not null check (type in ('hebdo','mensuel')),
  periode text not null,
  contenu text not null,
  envoye_le timestamptz
);

-- ============================================================================
-- REGLES D'ACCES
-- Sans ces regles, n'importe qui pourrait lire les donnees de n'importe qui.
-- ============================================================================

create or replace function est_coach() returns boolean
language sql security definer stable as $$
  select exists (select 1 from profils where id = auth.uid() and role = 'coach');
$$;

alter table profils enable row level security;
alter table etat_eleve enable row level security;
alter table exercices enable row level security;
alter table ressources enable row level security;
alter table idees_grand_oral enable row level security;
alter table banque_questions enable row level security;
alter table questions_diagnostic enable row level security;
alter table videos_chapitre enable row level security;
alter table fiches_chapitre enable row level security;
alter table sujets_permanence enable row level security;
alter table messages_permanence enable row level security;
alter table directs enable row level security;
alter table inscriptions_direct enable row level security;
alter table questions_direct enable row level security;
alter table copies enable row level security;
alter table abonnements enable row level security;
alter table bilans enable row level security;

-- profils : chacun le sien, le coach voit tout
drop policy if exists profils_lecture on profils;
create policy profils_lecture on profils for select
  using (id = auth.uid() or est_coach());
drop policy if exists profils_ecriture on profils;
create policy profils_ecriture on profils for insert
  with check (id = auth.uid());
drop policy if exists profils_maj on profils;
create policy profils_maj on profils for update
  using (id = auth.uid() or est_coach());

-- etat de l'eleve : strictement personnel, le coach lit
drop policy if exists etat_lecture on etat_eleve;
create policy etat_lecture on etat_eleve for select
  using (eleve_id = auth.uid() or est_coach());
drop policy if exists etat_ecriture on etat_eleve;
create policy etat_ecriture on etat_eleve for insert
  with check (eleve_id = auth.uid());
drop policy if exists etat_maj on etat_eleve;
create policy etat_maj on etat_eleve for update
  using (eleve_id = auth.uid()) with check (eleve_id = auth.uid());

-- bibliotheque et diagnostics : lisibles par tous les connectes, ecrits par le coach
drop policy if exists exercices_lecture on exercices;
create policy exercices_lecture on exercices for select using (auth.uid() is not null);
drop policy if exists exercices_ecriture on exercices;
create policy exercices_ecriture on exercices for all using (est_coach()) with check (est_coach());

drop policy if exists videos_lecture on videos_chapitre;
create policy videos_lecture on videos_chapitre for select using (auth.uid() is not null);
drop policy if exists videos_ecriture on videos_chapitre;
create policy videos_ecriture on videos_chapitre for all using (est_coach()) with check (est_coach());

drop policy if exists fiches_lecture on fiches_chapitre;
create policy fiches_lecture on fiches_chapitre for select using (auth.uid() is not null);
drop policy if exists fiches_ecriture on fiches_chapitre;
create policy fiches_ecriture on fiches_chapitre for all using (est_coach()) with check (est_coach());

drop policy if exists ressources_lecture on ressources;
create policy ressources_lecture on ressources for select using (auth.uid() is not null);
drop policy if exists ressources_ecriture on ressources;
create policy ressources_ecriture on ressources for all using (est_coach()) with check (est_coach());

drop policy if exists banque_lecture on banque_questions;
create policy banque_lecture on banque_questions for select using (auth.uid() is not null);
drop policy if exists banque_ecriture on banque_questions;
create policy banque_ecriture on banque_questions for all using (est_coach()) with check (est_coach());

drop policy if exists idees_oral_lecture on idees_grand_oral;
create policy idees_oral_lecture on idees_grand_oral for select using (auth.uid() is not null);
drop policy if exists idees_oral_ecriture on idees_grand_oral;
create policy idees_oral_ecriture on idees_grand_oral for all using (est_coach()) with check (est_coach());

drop policy if exists questions_lecture on questions_diagnostic;
create policy questions_lecture on questions_diagnostic for select using (auth.uid() is not null);
drop policy if exists questions_ecriture on questions_diagnostic;
create policy questions_ecriture on questions_diagnostic for all using (est_coach()) with check (est_coach());

-- permanence : visible par tous les eleves, chacun ecrit en son nom
drop policy if exists sujets_lecture on sujets_permanence;
create policy sujets_lecture on sujets_permanence for select using (auth.uid() is not null);
drop policy if exists sujets_ecriture on sujets_permanence;
create policy sujets_ecriture on sujets_permanence for insert with check (auteur_id = auth.uid());
drop policy if exists sujets_maj on sujets_permanence;
create policy sujets_maj on sujets_permanence for update using (auteur_id = auth.uid() or est_coach());

drop policy if exists messages_lecture on messages_permanence;
create policy messages_lecture on messages_permanence for select using (auth.uid() is not null);
drop policy if exists messages_ecriture on messages_permanence;
create policy messages_ecriture on messages_permanence for insert with check (auteur_id = auth.uid());
drop policy if exists messages_maj on messages_permanence;
create policy messages_maj on messages_permanence for update using (auteur_id = auth.uid() or est_coach());

-- directs
drop policy if exists directs_lecture on directs;
create policy directs_lecture on directs for select using (auth.uid() is not null);
drop policy if exists directs_ecriture on directs;
create policy directs_ecriture on directs for all using (est_coach()) with check (est_coach());

drop policy if exists inscriptions_perso on inscriptions_direct;
create policy inscriptions_perso on inscriptions_direct for all
  using (eleve_id = auth.uid() or est_coach()) with check (eleve_id = auth.uid());

drop policy if exists questions_direct_perso on questions_direct;
create policy questions_direct_perso on questions_direct for select
  using (eleve_id = auth.uid() or est_coach());
drop policy if exists questions_direct_ecriture on questions_direct;
create policy questions_direct_ecriture on questions_direct for insert with check (eleve_id = auth.uid());

-- copies : l'eleve depose, le coach corrige
drop policy if exists copies_lecture on copies;
create policy copies_lecture on copies for select using (eleve_id = auth.uid() or est_coach());
drop policy if exists copies_depot on copies;
create policy copies_depot on copies for insert with check (eleve_id = auth.uid());
drop policy if exists copies_correction on copies;
create policy copies_correction on copies for update using (est_coach());

-- abonnements : lecture seule cote eleve, ecriture par le webhook Stripe (cle service)
drop policy if exists abonnements_lecture on abonnements;
create policy abonnements_lecture on abonnements for select
  using (eleve_id = auth.uid() or est_coach());

-- bilans : l'eleve lit les siens, le coach tous
drop policy if exists bilans_lecture on bilans;
create policy bilans_lecture on bilans for select using (eleve_id = auth.uid() or est_coach());
drop policy if exists bilans_ecriture on bilans;
create policy bilans_ecriture on bilans for all using (est_coach()) with check (est_coach());


-- ============================================================================
-- GARDE-FOUS DE MODERATION
-- Les regles d'acces autorisent un eleve a modifier SES messages (corriger une
-- faute de frappe). Sans le garde-fou ci-dessous, il pourrait aussi se decerner
-- lui-meme le badge "valide par le professeur" en appelant l'API directement.
-- L'interface ne suffit pas : c'est la base qui doit refuser.
-- ============================================================================

create or replace function garde_messages_permanence() returns trigger
language plpgsql security definer as $$
begin
  if est_coach() then
    return new;
  end if;
  if tg_op = 'INSERT' then
    new.reponse_validee := false;
    new.signale := false;
    new.signale_commentaire := null;
    new.role := 'eleve';
    return new;
  end if;
  if new.reponse_validee is distinct from old.reponse_validee
     or new.signale is distinct from old.signale
     or new.signale_commentaire is distinct from old.signale_commentaire
     or new.role is distinct from old.role then
    raise exception 'Seul le coach peut valider ou signaler un message.';
  end if;
  return new;
end $$;

drop trigger if exists garde_messages on messages_permanence;
create trigger garde_messages
  before insert or update on messages_permanence
  for each row execute function garde_messages_permanence();

create or replace function garde_sujets_permanence() returns trigger
language plpgsql security definer as $$
begin
  if est_coach() then
    return new;
  end if;
  if tg_op = 'INSERT' then
    new.epingle := false;
    new.ressource := false;
    new.ressource_titre := null;
    new.ressource_resume := null;
    return new;
  end if;
  if new.epingle is distinct from old.epingle
     or new.ressource is distinct from old.ressource
     or new.ressource_titre is distinct from old.ressource_titre
     or new.ressource_resume is distinct from old.ressource_resume then
    raise exception 'Seul le coach peut epingler ou publier une ressource.';
  end if;
  return new;
end $$;

drop trigger if exists garde_sujets on sujets_permanence;
create trigger garde_sujets
  before insert or update on sujets_permanence
  for each row execute function garde_sujets_permanence();

-- un eleve ne peut pas non plus se declarer coach
create or replace function garde_role_profil() returns trigger
language plpgsql security definer as $$
begin
  if tg_op = 'INSERT' and not est_coach() then
    new.role := 'eleve';
  elsif tg_op = 'UPDATE' and not est_coach() and new.role is distinct from old.role then
    raise exception 'Le role ne peut pas etre modifie depuis l''application.';
  end if;
  return new;
end $$;

drop trigger if exists garde_profil on profils;
create trigger garde_profil
  before insert or update on profils
  for each row execute function garde_role_profil();

-- ============================================================================
-- STOCKAGE DES VOCAUX, PHOTOS ET PDF
-- Bucket prive : les fichiers ne sont jamais accessibles par une URL publique,
-- l'application genere des liens signes valables une heure.
-- ============================================================================

insert into storage.buckets (id, name, public)
values ('permanence', 'permanence', false)
on conflict (id) do nothing;

-- bucket des fiches de revision : lecture pour tous les connectes, depot par le coach
insert into storage.buckets (id, name, public)
values ('ressources', 'ressources', false)
on conflict (id) do nothing;

drop policy if exists ressources_lecture on storage.objects;
create policy ressources_lecture on storage.objects for select
  using (bucket_id = 'ressources' and auth.uid() is not null);

drop policy if exists ressources_depot on storage.objects;
create policy ressources_depot on storage.objects for insert
  with check (bucket_id = 'ressources' and est_coach());

drop policy if exists ressources_suppression on storage.objects;
create policy ressources_suppression on storage.objects for delete
  using (bucket_id = 'ressources' and est_coach());

-- chacun depose dans son propre dossier (nomme avec son identifiant)
drop policy if exists vocaux_depot on storage.objects;
create policy vocaux_depot on storage.objects for insert
  with check (
    bucket_id = 'permanence'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- tous les eleves connectes peuvent ouvrir les fichiers de la permanence
drop policy if exists vocaux_lecture on storage.objects;
create policy vocaux_lecture on storage.objects for select
  using (bucket_id = 'permanence' and auth.uid() is not null);

-- chacun peut supprimer les siens, le coach tous
drop policy if exists vocaux_suppression on storage.objects;
create policy vocaux_suppression on storage.objects for delete
  using (
    bucket_id = 'permanence'
    and ((storage.foldername(name))[1] = auth.uid()::text or est_coach())
  );

-- ============================================================================
-- VUE DE SUIVI POUR LE COACH
-- Agrege le JSON de chaque eleve en une ligne lisible.
-- ============================================================================

create or replace view vue_coach_semaine as
select
  p.id                                   as eleve_id,
  p.prenom,
  p.classe,
  (e.donnees ->> 'semaine')::int          as semaine,
  coalesce(sum((t ->> 'duree')::int) filter (where t ->> 'statut' = 'fait'), 0) as minutes_faites,
  count(*) filter (where t ->> 'statut' = 'fait'
                     and t ->> 'type' in ('flash','exo','bac'))                 as seances_faites,
  count(*) filter (where t ->> 'type' in ('flash','exo','bac'))                 as seances_prevues,
  count(*) filter (where t ->> 'type' = 'restitution'
                     and t ->> 'statut' = 'fait')                               as feuilles_faites,
  count(*) filter (where t ->> 'type' = 'restitution')                          as feuilles_prevues,
  count(*) filter (where (t ->> 'retardJours')::int > 0
                     and t ->> 'statut' <> 'fait')                              as restitutions_en_retard,
  e.maj_le                                as derniere_activite
from profils p
join etat_eleve e on e.eleve_id = p.id
left join lateral jsonb_array_elements(coalesce(e.donnees -> 'taches', '[]'::jsonb)) t on true
where p.role = 'eleve'
group by p.id, p.prenom, p.classe, e.donnees, e.maj_le;

-- Suivi du Grand oral : extrait de l'etat de chaque eleve ce dont le coach
-- a besoin, sans ouvrir son planning.
create or replace view vue_coach_oral as
select
  p.id as eleve_id, p.prenom, p.classe,
  (e.donnees -> 'oral' ->> 'etape')::int            as etape,
  e.donnees -> 'oral' ->> 'statut'                  as statut_question,
  e.donnees -> 'oral' ->> 'question'                as question,
  e.donnees -> 'oral' ->> 'ancrage'                 as ancrage,
  jsonb_array_length(coalesce(e.donnees -> 'oral' -> 'prises', '[]'::jsonb))   as prises,
  jsonb_array_length(coalesce(e.donnees -> 'oral' -> 'tirages', '[]'::jsonb))  as tirages,
  jsonb_array_length(coalesce(e.donnees -> 'oral' -> 'sechees', '[]'::jsonb))  as sechees,
  (e.donnees -> 'oral' -> 'oralBlanc' ->> 'demande')::boolean as oral_blanc_demande,
  e.maj_le
from profils p
join etat_eleve e on e.eleve_id = p.id
where p.role = 'eleve' and e.donnees ? 'oral';

-- ============================================================================
-- DONNEES DE DEPART : la bibliotheque d'exercices
-- (a completer depuis l'espace coach de l'application)
-- ============================================================================

insert into exercices (chapitre, usage, titre, duree, niveau)
select * from (values
  ('cin','entrainement','Decomposition de l''eau oxygenee — suivi par titrage',22,'moyen'),
  ('cin','entrainement','Ordre 1 : exploitation d''un trace ln[A] = f(t)',15,'facile'),
  ('cin','evaluation','Suivi spectrophotometrique du bleu de bromophenol',25,'difficile'),
  ('cin','entrainement','Temps de demi-reaction et facteurs cinetiques',12,'facile'),
  ('cin','evaluation','Catalyse enzymatique — etude d''un document',18,'moyen'),
  ('cin','bac','Sujet bac — suivi d''une saponification',60,'difficile'),
  ('cin','bac','Sujet bac — ordre de reaction et temps de demi-reaction',30,'moyen'),
  ('ond','entrainement','Diffraction par une fente — determination de lambda',18,'moyen'),
  ('ond','entrainement','Niveau d''intensite sonore et attenuation',14,'facile'),
  ('ond','evaluation','Effet Doppler — vitesse d''un mobile',22,'difficile'),
  ('ond','entrainement','Mesure de la celerite d''une onde le long d''une corde',16,'moyen'),
  ('ond','evaluation','Interferences en lumiere monochromatique',20,'difficile'),
  ('ond','bac','Sujet bac — acoustique d''une salle : intensite et attenuation',60,'difficile'),
  ('ond','bac','Sujet bac — longueur d''onde par diffraction',30,'moyen'),
  ('mec','entrainement','Chute libre avec vitesse initiale — etude vectorielle',20,'moyen'),
  ('mec','evaluation','Deuxieme loi de Newton sur un plan incline',24,'difficile'),
  ('mec','entrainement','Lecture d''une chronophotographie',12,'facile'),
  ('mec','entrainement','Theoreme de l''energie cinetique — freinage',16,'moyen'),
  ('mec','evaluation','Mouvement circulaire uniforme d''un satellite',22,'difficile'),
  ('mec','bac','Sujet bac — projectile et bilan d''energie',60,'difficile'),
  ('mec','bac','Sujet bac — plan incline avec frottements',30,'moyen')
) as v(chapitre, usage, titre, duree, niveau)
where not exists (select 1 from exercices);
