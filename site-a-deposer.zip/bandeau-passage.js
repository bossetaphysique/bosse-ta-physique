/* ═══════════════════════════════════════════════════════════════════════════
   Bosse ta Physique · le passage à la nouvelle plateforme (2 novembre 2026)

   « Passage à la nouvelle plateforme le 16/11 au plus tard avec un bouton je
   passe maintenant en conservant mes données » (le coach).

   Un petit script, à côté de l'application (il n'y touche pas) : il lit la
   session de l'élève connecté (celle que l'application garde dans ce
   navigateur), demande à la nouvelle plateforme si le bandeau s'affiche pour
   lui (fonction « passage », action « etat » : d'abord aux comptes de test,
   puis à tous quand le coach l'ouvre), et l'affiche en haut de la page.
   « Je passe maintenant » : la nouvelle plateforme invite l'élève (Terminale,
   son groupe) et garde ses chapitres et ses réglages ; il y crée son mot de
   passe avec « Première connexion ». Après la date limite, il ne voit plus
   que ce message. Le coach, les parents et les visiteurs ne voient rien.
   Rien n'est écrit sur cette plateforme.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
  "use strict";

  var URL_PASSAGE = "https://zljigtxckfcjxrspnstf.supabase.co/functions/v1/passage";
  var CLE_SESSION = "sb-fohpsrdopdbhvzhjnkmk-auth-token";
  var MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  var JOURS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  var NBSP = " ";

  var etat = null; // la dernière réponse « etat »
  var pret = null; // la réponse « passer »
  var envoi = false;
  var erreur = "";
  var boite = null;

  /** « lundi 16 novembre » (AAAA-MM-JJ). */
  function dateEnClair(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || ""));
    if (!m) return "";
    var d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    var j = d.getDate();
    return JOURS[d.getDay()] + " " + (j === 1 ? "1er" : j) + " " + MOIS[d.getMonth()];
  }

  /** Le jeton de l'élève connecté (ou null), tant qu'il n'est pas expiré. */
  function jeton() {
    try {
      var s = JSON.parse(localStorage.getItem(CLE_SESSION) || "null");
      var session = s && s.currentSession ? s.currentSession : s;
      if (!session || !session.access_token) return null;
      if (session.expires_at && session.expires_at * 1000 < Date.now() + 15000) return "expire";
      return session.access_token;
    } catch (e) {
      return null;
    }
  }

  function appeler(action, j) {
    return fetch(URL_PASSAGE, {
      method: "POST",
      headers: { Authorization: "Bearer " + j, "Content-Type": "application/json" },
      body: JSON.stringify({ action: action }),
    }).then(function (r) {
      return r
        .json()
        .catch(function () {
          return {};
        })
        .then(function (corps) {
          if (!r.ok) {
            var e = new Error(corps.erreur || "la nouvelle plateforme n'a pas répondu (" + r.status + ")");
            e.statut = r.status;
            throw e;
          }
          return corps;
        });
    });
  }

  function el(balise, style, texte) {
    var x = document.createElement(balise);
    if (style) x.setAttribute("style", style);
    if (texte != null) x.textContent = texte;
    return x;
  }

  function retirer() {
    if (boite && boite.parentNode) boite.parentNode.removeChild(boite);
    boite = null;
    document.documentElement.style.overflow = "";
  }

  var POLICE = "font-family:'DM Sans',system-ui,-apple-system,'Segoe UI',sans-serif;";
  var TITRE = "font-family:Poppins,'DM Sans',system-ui,sans-serif;font-weight:700;font-size:1.08rem;line-height:1.3;margin:6px 0 0;color:#0E1132;";
  var SURTITRE =
    "font-family:'IBM Plex Mono',ui-monospace,monospace;font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;color:#4E7EF3;margin:0;";
  var TEXTE = "font-size:.9rem;line-height:1.5;margin:8px 0 0;color:#2B2F55;";
  var BOUTON =
    "display:block;width:100%;box-sizing:border-box;margin-top:12px;padding:13px 20px;border:0;border-radius:999px;font-family:Poppins,'DM Sans',sans-serif;font-weight:600;font-size:1rem;text-align:center;text-decoration:none;cursor:pointer;";

  function carte() {
    var passe = !!pret || !!(etat && etat.passe);
    var c = el(
      "div",
      POLICE +
        "background:#FFF;border:2px solid " +
        (passe ? "#6C63FF" : "#E7B24E") +
        ";border-radius:18px;box-shadow:0 8px 24px rgba(14,17,50,.08);padding:18px 18px 16px;max-width:640px;margin:12px auto;box-sizing:border-box;",
    );
    c.setAttribute("role", "region");
    c.setAttribute("aria-label", "Passage à la nouvelle plateforme");
    c.setAttribute("data-passage", passe ? "passe" : "a-passer");
    c.appendChild(el("p", SURTITRE, "Bosse ta Physique change de plateforme"));
    var site = (pret && pret.site) || (etat && etat.site);
    if (passe) {
      var compte = pret ? pret.compte : etat.compte;
      var adresse = pret && pret.email ? " " + pret.email : " (la même qu'ici)";
      c.appendChild(el("h2", TITRE, pret ? "C'est prêt" + NBSP + "!" : "Tu es passé sur la nouvelle plateforme"));
      c.appendChild(
        el(
          "p",
          TEXTE,
          compte
            ? "Connecte-toi sur la nouvelle plateforme avec ton adresse" + adresse + NBSP + ": c'est là que tu travailles maintenant."
            : "Sur la nouvelle plateforme, choisis «" +
                NBSP +
                "Première connexion" +
                NBSP +
                "» avec ton adresse" +
                adresse +
                " et crée ton mot de passe" +
                NBSP +
                ": tes chapitres et tes réglages t'y attendent. C'est là que tu travailles maintenant.",
        ),
      );
      if (site) {
        var a = el("a", BOUTON + "background:#6C63FF;color:#FFF;", "Aller sur la nouvelle plateforme");
        a.href = site;
        c.appendChild(a);
      }
    } else {
      c.appendChild(
        el(
          "h2",
          TITRE,
          etat.apresLimite ? "Pour continuer, passe sur la nouvelle plateforme" : "Passe sur la nouvelle d'ici le " + dateEnClair(etat.limite),
        ),
      );
      c.appendChild(
        el(
          "p",
          TEXTE,
          "Tes chapitres et tes réglages te suivent. Le soir même, le test d'entrée de tes chapitres en cours" +
            NBSP +
            ": les questions types ont changé. Et pendant les vacances, un programme de révision t'attend.",
        ),
      );
      var b = el("button", BOUTON + "background:#E7B24E;color:#0E1132;", envoi ? "Un instant…" : "Je passe maintenant");
      b.type = "button";
      b.disabled = envoi;
      b.addEventListener("click", passer);
      c.appendChild(b);
      if (erreur) {
        var e = el("p", TEXTE + "color:#8C332C;", erreur);
        e.setAttribute("role", "alert");
        c.appendChild(e);
      }
    }
    return c;
  }

  function afficher() {
    if (!etat || !etat.afficher) return retirer();
    var nouvelle = el("div", "");
    nouvelle.id = "passage-nouvelle-plateforme";
    if (etat.apresLimite) {
      // Après la date limite : plus que ce message, par-dessus tout le reste.
      nouvelle.setAttribute(
        "style",
        "position:fixed;inset:0;z-index:2147483000;background:#F1F4FE;overflow-y:auto;padding:8vh 16px 24px;box-sizing:border-box;",
      );
      document.documentElement.style.overflow = "hidden";
    } else {
      nouvelle.setAttribute("style", "padding:0 12px;");
      document.documentElement.style.overflow = "";
    }
    nouvelle.appendChild(carte());
    if (boite && boite.parentNode) boite.parentNode.replaceChild(nouvelle, boite);
    else document.body.insertBefore(nouvelle, document.body.firstChild);
    boite = nouvelle;
  }

  function passer() {
    var j = jeton();
    if (!j || j === "expire") {
      erreur = "Ta session vient d'expirer : recharge la page, puis réessaie.";
      return afficher();
    }
    envoi = true;
    erreur = "";
    afficher();
    appeler("passer", j)
      .then(function (r) {
        pret = r;
      })
      .catch(function (e) {
        erreur = (e && e.message) || "Le passage n'a pas pu se faire : réessaie dans un moment.";
      })
      .then(function () {
        envoi = false;
        afficher();
      });
  }

  // Toutes les cinq secondes, un coup d'œil à la session (sans réseau) : une connexion ou une déconnexion est vue tout
  // de suite. La nouvelle plateforme n'est appelée que pour une nouvelle session, puis une fois par minute.
  var enCours = false;
  var dernierJeton = null;
  var dernierAppel = 0;
  var refusePour = null; // une session refusée (le coach, un parent) : plus d'appel tant qu'elle dure
  function tic(force) {
    if (enCours || envoi) return;
    var j = jeton();
    if (!j) {
      dernierJeton = null;
      if (etat || pret || boite) {
        etat = null;
        pret = null;
        retirer();
      }
      return;
    }
    if (j === "expire") return; // l'application renouvelle sa session : on réessaiera
    if (j === refusePour) return;
    if (!force && j === dernierJeton && Date.now() - dernierAppel < 60000) return;
    dernierJeton = j;
    dernierAppel = Date.now();
    enCours = true;
    appeler("etat", j)
      .then(function (r) {
        etat = r;
        afficher();
      })
      .catch(function (e) {
        // 401 (session refusée) ou 403 (le coach, un parent) : rien à afficher.
        if (e && (e.statut === 401 || e.statut === 403)) {
          refusePour = j;
          etat = null;
          retirer();
        }
      })
      .then(function () {
        enCours = false;
      });
  }

  function demarrer() {
    setTimeout(tic, 1500);
    setInterval(tic, 5000);
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "visible") tic(true);
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", demarrer);
  else demarrer();
})();
