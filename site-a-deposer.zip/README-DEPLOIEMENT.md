# Mettre la plateforme en ligne

*Guide pas à pas. Aucune connaissance en code n'est nécessaire : vous allez copier des fichiers et cliquer dans deux interfaces web.*

**Temps prévu : une soirée.** Comptez 40 minutes pour les étapes 1 à 4, le reste dépend de vos allers-retours.

---

## Ce que vous avez dans ce dossier

| Fichier | À quoi ça sert |
|---|---|
| `src/` | l'application elle-même |
| `src/lib/planning.js` | le moteur de planning — **le cœur du produit** |
| `src/lib/planning.test.js` | ses 871 tests de vérification |
| `supabase/schema.sql` | toutes les tables de la base, à coller une fois |
| `supabase/functions/stripe-webhook/` | le paiement, pour plus tard |
| `public/landing.html` | votre page de vente |
| `.env.example` | le modèle du fichier de configuration |

---

## Étape 1 — créer la base de données (10 min)

1. Allez sur **supabase.com**, créez un compte, puis **New project**.
2. Nom : `bosse-ta-physique`. **Region : `Europe (Frankfurt)`** — c'est important pour le RGPD, et ce choix est **définitif**.
3. Notez le mot de passe de la base dans votre gestionnaire de mots de passe.
4. Une fois le projet créé, ouvrez **SQL Editor** dans le menu de gauche, puis **New query**.
5. Ouvrez le fichier `supabase/schema.sql`, **copiez tout son contenu**, collez-le dans la fenêtre, cliquez **Run**.
6. Vous devez lire « Success. No rows returned ». C'est normal et c'est bon signe.

À ce stade, toutes vos tables existent, avec leurs règles d'accès et la bibliothèque d'exercices de départ.

---

## Étape 2 — récupérer vos deux clés (2 min)

Dans Supabase : **Project Settings → API**. Vous avez besoin de deux valeurs :

- **Project URL** — ressemble à `https://abcdefgh.supabase.co`
- **anon public** — une longue chaîne qui commence par `eyJ...`

La clé `service_role` sur la même page ne doit **jamais** sortir de chez vous : elle donne tous les droits. Ne la mettez nulle part dans l'application.

---

## Étape 3 — mettre le site en ligne (15 min)

1. Créez un compte sur **github.com**, puis un dépôt vide nommé `bosse-ta-physique`, en **Private**.
2. Sur la page du dépôt, cliquez **uploading an existing file** et glissez-y **tout le contenu de ce dossier** — sauf `node_modules` s'il existe. Cliquez **Commit changes**.
3. Créez un compte sur **cloudflare.com** → **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → choisissez votre dépôt.
4. Renseignez :
   - Framework preset : **Vite**
   - Build command : `npm run build`
   - Build output directory : `dist`
5. Ouvrez **Environment variables** et ajoutez les deux valeurs de l'étape 2 :
   - `VITE_SUPABASE_URL` → votre Project URL
   - `VITE_SUPABASE_ANON_KEY` → votre clé anon public
6. **Save and Deploy**. Deux minutes plus tard, votre application est en ligne sur une adresse en `.pages.dev`.

> **Si vous sautez l'étape des variables**, l'application fonctionne quand même, mais en mode démonstration : rien n'est enregistré. C'est utile pour montrer le produit, pas pour l'utiliser.

---

## Étape 4 — activer la connexion par email (5 min)

Dans Supabase : **Authentication → Providers → Email**.

1. Activez **Email**, et **désactivez « Confirm email »** si vous voulez que le premier lien connecte directement.
2. Dans **Authentication → URL Configuration**, mettez l'adresse de votre site (`https://xxx.pages.dev` ou votre domaine) dans **Site URL** et dans **Redirect URLs**.

Testez : ouvrez votre site, saisissez votre email, cliquez sur le lien reçu. Vous devez arriver sur l'écran de mise en route.

---

## Étape 5 — vocaux, photos et PDF (déjà prêts)

Rien à faire : le schéma SQL a créé un espace de stockage **privé** nommé `permanence`,
et les règles d'accès qui vont avec. Chaque élève dépose dans son propre dossier, les
fichiers ne sont jamais accessibles par une adresse publique, et l'application génère
des liens d'écoute valables une heure.

Trois points à connaître :

- Le micro ne fonctionne que sur une adresse en **https** — c'est le cas avec Cloudflare Pages, mais pas si vous testez depuis un fichier ouvert en local.
- Sur iPhone et iPad, le navigateur demande l'autorisation du micro à la première utilisation. Si l'élève refuse, il faut la réactiver dans les réglages Safari.
- Les vocaux sont **limités à 2 minutes**, volontairement. Au-delà, personne ne les réécoute et votre temps de réponse explose.
- Les photos sont **redimensionnées automatiquement** avant l'envoi (côté le plus long ramené à 1600 pixels). Une photo d'iPhone passe ainsi de 4 Mo à environ 400 Ko : le stockage tient, et vous ouvrez la copie sans attendre.
- Un fichier ne peut pas dépasser **10 Mo**. Au-delà, l'élève est invité à photographier une seule page à la fois.

Pensez à ajouter une ligne dans votre politique de confidentialité : les enregistrements
vocaux et les photos de copies sont des données personnelles, et il s'agit ici de mineurs —
une copie photographiée porte souvent le nom et la classe de l'élève. Annoncez une durée de
conservation (par exemple 12 mois) et tenez-la.

---

## Étape 6 — vous déclarer comme coach (2 min)

C'est ce rôle qui débloque, dans la permanence, les boutons **Épingler** et
**En faire une ressource** — invisibles pour les élèves.

Par défaut, tout nouveau compte est un compte élève. Pour avoir accès à l'espace coach :

1. Connectez-vous une fois sur l'application avec **votre** email.
2. Dans Supabase : **Table Editor → profils**, trouvez votre ligne, changez `role` de `eleve` en `coach`, enregistrez.

---

## Qui peut faire quoi dans la permanence

| Action | Élève | Coach |
|---|---|---|
| Écrire un message, déposer une photo, un PDF, un vocal | oui | oui |
| Lire les questions du groupe, filtrer par chapitre, retrouver les siennes | oui | oui |
| Répondre à un camarade | oui | oui |
| Valider une réponse (badge « validée par le professeur ») | **non** | oui |
| Signaler une erreur dans un message | **non** | oui |
| Épingler une discussion, la transformer en ressource | **non** | oui |
| Réponses pré-rédigées | **non** | oui |
| Déposer une vidéo ou une fiche dans Cours | **non** | oui |
| Programmer un direct, déposer le replay | **non** | oui |

Ce n'est pas seulement l'interface qui masque ces boutons : la base de données **refuse**
ces opérations à un compte élève, même envoyées directement à l'API. Trois garde-fous
sont posés par le schéma SQL — un élève ne peut ni se décerner un badge, ni épingler,
ni se déclarer coach.

---

## Étape 7 — l'application sur tous les supports

Rien à configurer, mais deux choses à savoir :

- **L'interface s'adapte seule** : une tâche par ligne sur téléphone, deux colonnes sur tablette,
  menu latéral sur ordinateur. Le téléphone en paysage et l'impression du planning sont prévus.
- **L'application s'installe sur l'écran d'accueil.** Sur iPhone ou iPad : ouvrir le site dans
  Safari, bouton Partager, « Sur l'écran d'accueil ». Sur Android : « Installer l'application ».
  Elle s'ouvre alors en plein écran, sans barre de navigateur, comme une vraie application.
  **Dites-le à vos élèves dès le premier rendez-vous** : un raccourci sur l'écran d'accueil change
  radicalement la fréquence d'ouverture.

---

## Étape 8 — votre domaine (10 min)

1. Achetez votre nom de domaine (OVH, Gandi, Cloudflare Registrar…).
2. Dans Cloudflare Pages : **Custom domains → Set up a domain**, saisissez `app.votredomaine.fr` et suivez les instructions DNS.
3. Retournez dans Supabase **Authentication → URL Configuration** et remplacez l'adresse `.pages.dev` par `https://app.votredomaine.fr`.

Pour la page de vente, créez un **second projet Cloudflare Pages** avec seulement le fichier `public/landing.html` renommé `index.html`, et pointez-le sur `www.votredomaine.fr`. Elle reste ainsi en ligne même si vous travaillez sur l'application.

---

## Étape 9 — le paiement (à faire plus tard)

Ne branchez Stripe qu'une fois vos premiers élèves accompagnés gratuitement ou manuellement. Le fichier est prêt dans `supabase/functions/stripe-webhook/`. Il faudra :

1. créer un produit d'abonnement dans Stripe ;
2. installer l'outil Supabase CLI et lancer `supabase functions deploy stripe-webhook --no-verify-jwt` ;
3. déclarer l'adresse de la fonction comme webhook dans Stripe ;
4. tester un abonnement complet, **résiliation comprise**, avec votre propre carte.

---

## Avant le premier élève

- [ ] Vous vous êtes connecté et avez fait un parcours complet vous-même.
- [ ] Le rôle `coach` est bien attribué à votre compte.
- [ ] Vos mentions légales, CGV et politique de confidentialité sont en ligne.
- [ ] Vous avez signé le DPA de Supabase (**Settings → Legal**) et de Stripe.
- [ ] Pour les moins de 15 ans, l'accord parental est recueilli et conservé.
- [ ] Vous avez testé une suppression de compte de bout en bout.

---

## Modifier le produit ensuite

Deux règles simples, et vous ne casserez rien :

1. **Ne touchez jamais à `src/lib/planning.js` sans relancer les tests.** Dans un terminal, à la racine du dossier : `npm test`. La dernière ligne doit afficher `0 erreur(s)`. Si ce n'est pas le cas, annulez votre modification.
2. **Tout ce qui est visuel est dans `src/App.jsx`**, en haut du fichier, dans le bloc `CSS`. Les couleurs, les arrondis et les polices y sont regroupés : les changer ne peut rien casser du planning.

Pour le reste — nouvelles pages, nouvelles règles — décrivez ce que vous voulez à un assistant de code en lui donnant ce dossier. Il aura tout ce qu'il faut : le moteur est documenté, testé, et isolé du reste.

---

## En cas de problème

| Symptôme | Cause la plus fréquente |
|---|---|
| Le site affiche une page blanche | erreur de build : regardez l'onglet **Deployments** de Cloudflare |
| Rien ne s'enregistre entre deux connexions | les deux variables d'environnement sont absentes ou mal orthographiées |
| Le lien de connexion ne marche pas | l'adresse du site n'est pas dans **Redirect URLs** côté Supabase |
| « Row level security » dans les erreurs | le schéma SQL n'a pas été exécuté en entier : relancez-le, il est rejouable |
| L'espace coach est vide | votre profil est encore en `eleve` dans la table `profils` |

---

## Messages privés : la confidentialité se règle dans Supabase

Les relances du coach sont des messages **adressés à un seul élève**. Dans
l'application, ils portent `prive = true` et `pour_eleve = <identifiant>`, et
l'écran de permanence n'affiche que ceux du destinataire.

**Ce filtre est un confort d'affichage, pas une sécurité.** Tout ce que le
navigateur reçoit est lisible par qui sait regarder. La confidentialité réelle
tient à une règle de sécurité au niveau des lignes, à poser dans Supabase :

```sql
-- Un fil privé n'est lisible que par son destinataire et par le coach.
alter table sujets enable row level security;

create policy "lecture des fils"
  on sujets for select
  using (
    prive is not true
    or pour_eleve = auth.uid()
    or exists (select 1 from profils p
               where p.id = auth.uid() and p.role = 'coach')
  );

-- Seul le coach écrit un message privé.
create policy "ecriture des relances"
  on sujets for insert
  with check (
    prive is not true
    or exists (select 1 from profils p
               where p.id = auth.uid() and p.role = 'coach')
  );
```

Sans ces deux règles, un élève curieux peut lire les relances adressées aux
autres. **À poser avant d'ouvrir la plateforme à plus d'un élève.**

---

## Les fichiers : deux seaux de stockage à créer

Les PDF — fiches de révision, énoncés, corrigés, copies d'élèves — ne sont pas
stockés dans la base. Une fiche pèse quelques centaines de kilo-octets ; sur
vingt-deux chapitres, avec les énoncés et les corrigés, cela représente
plusieurs centaines de fichiers. Rangés dans une colonne de table, ils
feraient exploser la taille des lignes et le temps de chargement.

Ils vont donc dans le **stockage** de Supabase, et la base ne retient que leur
adresse. Deux seaux à créer dans **Storage → New bucket** :

| Seau | Accès | Contenu |
|---|---|---|
| `documents` | **public** | fiches, énoncés, corrigés — ce que tous les élèves peuvent lire |
| `copies` | **privé** | copies d'évaluation blanche, copies annotées |

### Règles d'accès

```sql
-- Tout le monde lit les documents pédagogiques ; seul le coach y dépose.
create policy "lecture des documents"
  on storage.objects for select
  using (bucket_id = 'documents');

create policy "depot par le coach"
  on storage.objects for insert
  with check (
    bucket_id = 'documents'
    and exists (select 1 from profils p where p.id = auth.uid() and p.role = 'coach')
  );

-- Une copie n'est lisible que par son auteur et par le coach.
create policy "lecture des copies"
  on storage.objects for select
  using (
    bucket_id = 'copies'
    and (owner = auth.uid()
         or exists (select 1 from profils p where p.id = auth.uid() and p.role = 'coach'))
  );

create policy "depot des copies"
  on storage.objects for insert
  with check (bucket_id = 'copies' and owner = auth.uid());
```

### Tant que ce n'est pas fait

L'application accepte quand même les dépôts, mais les fichiers restent en
mémoire du navigateur : **ils disparaissent au rechargement**. L'écran le dit
explicitement au moment du dépôt. C'est suffisant pour vérifier que tout
fonctionne, pas pour ouvrir aux élèves.
