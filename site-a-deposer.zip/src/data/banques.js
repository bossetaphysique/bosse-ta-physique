/* ============================================================================
   BANQUES DE QUESTIONS — une entrée par chapitre
   Vecteurs : <span class="vec">v</span> · indices : <sub> · noyaux :
   <span class="noyau"><sup>14</sup><sub>6</sub></span>C
   Chaque énoncé se suffit à lui-même : les questions flash étant tirées au
   hasard, aucun ne renvoie à une question précédente, et toute constante
   nécessaire y est rappelée.
   Figures : celles des fiches quand elles existent, recadrées sur les bandes
   blanches et débarrassées de tout ce qui donne la réponse.
   Régénéré depuis les JSON — ne pas éditer à la main.
   ========================================================================== */

export const BANQUES = {
  son: [
    {
      "ref": "son-01",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Une onde sonore est une onde <b>mécanique</b>. Cela signifie que :",
      "options": [
        "elle se propage dans un milieu matériel, sans transport de matière",
        "elle est toujours longitudinale par définition",
        "elle se propage dans le vide",
        "elle transporte de la matière"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Une onde mécanique propage une perturbation dans un milieu matériel : elle transporte de l'énergie, pas de la matière.",
      "piege": "Oublier « sans transport de matière » : c'est précisément le mot qui rapporte le point.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "son-02",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Pourquoi le son ne se propage-t-il pas dans le vide ?",
      "options": ["parce que son intensité y devient nulle, faute de source assez puissante", "parce que c'est une onde mécanique : elle a besoin d'un milieu matériel", "parce que sa fréquence est trop faible pour franchir un espace vide", "parce que le vide absorbe les ondes, quelle que soit leur nature"],
      "bonne_reponse": [
        1
      ],
      "explication": "Sans milieu matériel, il n'y a rien à comprimer ni à dilater : la perturbation ne peut pas se propager.",
      "piege": "Invoquer la fréquence ou l'intensité : ce sont des caractéristiques de l'onde, pas la raison de fond.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-03",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Une onde est dite <b>longitudinale</b> lorsque :",
      "options": [
        "la direction de propagation est perpendiculaire à la perturbation",
        "elle se propage dans une seule direction",
        "la direction de propagation est parallèle à celle de la perturbation",
        "sa longueur d'onde est grande"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Pour le son, les couches d'air se compriment et se dilatent <b>dans le sens de propagation</b>.",
      "piege": "Confondre avec une onde transversale, comme une vague ou une corde secouée.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-04",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Quelles affirmations sont correctes ? <b>Plusieurs réponses.</b>",
      "options": ["le niveau sonore L s'exprime en décibels", "l'intensité sonore I s'exprime en W·m⁻²", "le niveau sonore L s'exprime en W·m⁻²", "l'intensité de référence vaut I₀ = 1,0 × 10⁻¹² W·m⁻²"],
      "bonne_reponse": [
        0,
        1,
        3
      ],
      "explication": "I est une puissance par unité de surface, L est une échelle logarithmique en décibels, et I₀ fixe le zéro de cette échelle.",
      "piege": "Mélanger les deux grandeurs : on n'additionne jamais des W·m⁻² et des dB.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-05",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Multiplier l'intensité sonore par 10, c'est ajouter :",
      "options": [
        "1 dB",
        "3 dB",
        "100 dB",
        "10 dB"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "L = 10·log(I/I₀) : multiplier I par 10 ajoute 10·log(10) = 10 dB. Multiplier par 2 n'ajoute que 3 dB.",
      "piege": "Croire que le niveau est proportionnel à l'intensité : l'échelle est logarithmique.",
      "image": null,
      "tags": [
        "ordre de grandeur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-06",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "À quoi correspond un niveau sonore de 85 dB ?",
      "options": ["au seuil de risque pour l'oreille, au-delà duquel elle s'abîme", "au seuil de douleur, au-delà duquel l'oreille souffre aussitôt", "au seuil d'audibilité, en deçà duquel l'oreille n'entend plus", "à une conversation ordinaire, à un mètre de l'interlocuteur"],
      "bonne_reponse": [
        0
      ],
      "explication": "L'échelle : 0 dB seuil d'audibilité, 20 dB chuchotement, 60 dB conversation, 85 dB seuil de risque, 120 dB seuil de douleur.",
      "piege": "Confondre seuil de risque (85 dB) et seuil de douleur (120 dB).",
      "image": null,
      "tags": [
        "ordre de grandeur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-07",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Que faut-il écrire pour définir complètement une onde sonore ? <b>Plusieurs réponses.</b>",
      "options": [
        "elle est longitudinale",
        "elle transporte de la matière d'un point à un autre",
        "c'est une onde mécanique",
        "elle se propage dans un milieu matériel, sans transport de matière"
      ],
      "bonne_reponse": [
        0,
        2,
        3
      ],
      "explication": "Trois éléments attendus : mécanique, propagation dans un milieu matériel sans transport de matière, et longitudinale.",
      "piege": "S'arrêter à « onde mécanique » : la définition est incomplète sans le caractère longitudinal.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-08",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Un élève écrit : « le son est une onde qui transporte de l'énergie et de la matière ». Que faut-il corriger ?",
      "options": [
        "il transporte de la matière mais pas d'énergie",
        "il ne transporte ni l'un ni l'autre",
        "il transporte de l'énergie mais PAS de matière",
        "rien, c'est exact"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Les couches d'air oscillent autour de leur position, elles ne se déplacent pas globalement : l'énergie avance, pas la matière.",
      "piege": "Imaginer que l'air « voyage » de la source à l'oreille — c'est la perturbation qui voyage.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-09",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "À la distance r d'une source ponctuelle, l'intensité sonore vaut :",
      "options": [
        "I = P/(2πr)",
        "I = P × 4πr²",
        "I = P/(4πr²)",
        "I = P/(πr²)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L'énergie se répartit sur la <b>sphère</b> de rayon r, dont la surface vaut S = 4πr².",
      "piege": "Utiliser πr², la surface d'un disque : le son ne part pas dans un plan mais dans toutes les directions.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "son-10",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 6",
      "enonce": "Une source de puissance P = 0,50 W émet dans toutes les directions. Que vaut l'intensité sonore à 5,0 m ?",
      "options": [
        "3,2×10⁻² W·m⁻²",
        "6,4×10⁻³ W·m⁻²",
        "0,10 W·m⁻²",
        "1,6×10⁻³ W·m⁻²"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "S = 4π × 5,0² = 314 m², donc I = 0,50/314 = 1,6×10⁻³ W·m⁻².",
      "piege": "Calculer π × 5,0² = 78,5 m² et trouver 6,4×10⁻³ : c'est l'erreur du disque.",
      "image": "son_sphere.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-11",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Si on double la distance à la source, l'intensité sonore est :",
      "options": [
        "divisée par 4",
        "divisée par 8",
        "divisée par 2",
        "inchangée"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "I varie en 1/r² : doubler r divise I par 2² = 4. C'est ce qui donne les −6 dB de la QT 6.",
      "piege": "Raisonner en proportionnalité simple : l'intensité décroît comme le <b>carré</b> de la distance.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      
      "actif": true
    },
    {
      "ref": "son-12",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "La définition du niveau sonore est :",
      "options": [
        "L = 10·log(I₀/I)",
        "L = 10·log(I/I₀)",
        "L = 10·log(I) / I₀",
        "L = log(I/I₀)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le facteur 10 transforme les bels en décibels, et le rapport I/I₀ se fait <b>avant</b> le logarithme.",
      "piege": "Oublier le facteur 10 — on obtient des bels — ou diviser par I₀ après le logarithme.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "son-13",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "L'énoncé donne la puissance P de la source et la distance x. Quelle est la première ligne à écrire ?",
      "options": ["I = P/(4πx²), la répartition de la puissance sur une sphère", "A = L₁ − L₂, l'atténuation entre les deux points considérés", "L = 10·log(I/I₀), la définition du niveau sonore", "L(x) = L₁ − A, le niveau au point d'arrivée après atténuation"],
      "bonne_reponse": [
        2
      ],
      "explication": "On part toujours de la définition, puis on y remplace I par P/(4πx²).",
      "piege": "Se jeter sur le calcul numérique sans écrire la définition : les points de méthode sont perdus.",
      "image": null,
      "tags": [
        "demarrage"
      ],
      "actif": true
    },
    {
      "ref": "son-14",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "En un point, l'intensité sonore vaut I = 1,6×10⁻³ W·m⁻². Que vaut le niveau sonore en ce point ? <i>Donnée : I<sub>0</sub> = 1,0×10⁻¹² W·m⁻².</i>",
      "options": [
        "62 dB",
        "82 dB",
        "112 dB",
        "92 dB"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "L = 10·log(1,6×10⁻³ / 1,0×10⁻¹²) = 10·log(1,6×10⁹) ≈ 92 dB.",
      "piege": "Se tromper d'exposant sur I₀ : c'est 10⁻¹², pas 10⁻⁶.",
      "image": null,
      "tags": [
        "calcul"
      ],
      
      "actif": true
    },
    {
      "ref": "son-15",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "L'énoncé donne L₁ = 92 dB à 5,0 m et une atténuation A = 6 dB jusqu'à 10 m. Que vaut L(10) ?",
      "options": [
        "86 dB",
        "98 dB",
        "46 dB",
        "92 dB"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "A = L₁ − L(x), donc L(x) = L₁ − A = 92 − 6 = 86 dB : le point le plus éloigné est toujours plus faible.",
      "piege": "Ajouter l'atténuation au lieu de la retrancher.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-16",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre la démonstration de I = I₀ × 10^(L/10) :",
      "options": [
        "on prend la puissance de 10 : 10^(L/10) = 10^log(I/I₀)",
        "coin maths : 10^log(X) = X, donc 10^(L/10) = I/I₀",
        "on divise par 10 : L/10 = log(I/I₀)",
        "on part de L = 10·log(I/I₀)",
        "on isole : I = I₀ × 10^(L/10)"
      ],
      "bonne_reponse": [
        3,
        2,
        0,
        1,
        4
      ],
      "explication": "Chaque ligne est une équivalence : c'est la suite des étapes qui rapporte les points, pas le résultat encadré.",
      "piege": "Sauter le passage à la puissance de 10 et « deviner » le résultat.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-17",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Connaissant L, comment retrouve-t-on l'intensité sonore I ?",
      "options": [
        "I = 10·log(L/I₀)",
        "I = I₀ × 10^(L/10)",
        "I = I₀ × L/10",
        "I = I₀ × 10^L"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L'exposant est L/10, pas L : c'est la réciproque de L = 10·log(I/I₀).",
      "piege": "Écrire 10^L : avec L = 92 dB, on obtiendrait une intensité absurde.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-18",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Un sonomètre indique L = 85 dB à 10 m d'une source. Quelle est l'intensité sonore reçue ?",
      "options": [
        "8,5×10⁻⁴ W·m⁻²",
        "1,0×10⁻¹² W·m⁻²",
        "3,2×10⁻⁴ W·m⁻²",
        "3,2×10⁻⁸ W·m⁻²"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "I = I₀ × 10^(85/10) = 1,0×10⁻¹² × 10^8,5 = 3,2×10⁻⁴ W·m⁻².",
      "piege": "Utiliser 10^85 ou oublier de multiplier par I₀.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-19",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "L'atténuation A d'une onde sonore est :",
      "options": [
        "une différence de deux intensités, en W·m⁻²",
        "un rapport de deux intensités, sans unité",
        "une puissance perdue, en watts",
        "une différence de deux niveaux sonores, en dB"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "A = L₁ − L₂ : on soustrait des <b>niveaux</b>, et le résultat est en décibels.",
      "piege": "Soustraire des intensités en W·m⁻² : l'atténuation ne s'exprime jamais ainsi.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-20",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Une cloison reçoit un niveau L<sub>i</sub> = 78 dB et n'en laisse passer que L′ = 47 dB. Que vaut l'atténuation ?",
      "options": [
        "31 dB",
        "125 dB",
        "1,7 dB",
        "31 W·m⁻²"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "A = L<sub>i</sub> − L′ = 78 − 47 = 31 dB : c'est une atténuation par absorption.",
      "piege": "Donner le résultat en W·m⁻² alors qu'on a soustrait des décibels.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-21",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Deux matériaux sont proposés pour isoler une pièce. Comment choisir ?",
      "options": [
        "celui qui laisse passer la plus grande intensité",
        "celui dont l'atténuation par absorption est la plus grande",
        "celui dont l'épaisseur est la plus faible",
        "celui dont le niveau transmis est le plus élevé"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Isoler, c'est atténuer : on retient le matériau qui retire le plus de décibels.",
      "piege": "Comparer des intensités quand l'énoncé donne des décibels — ou l'inverse.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-22",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Remets dans l'ordre la démonstration de L(2d) = L(d) − 6 dB :",
      "options": [
        "P et d se simplifient : A = 10·log(4) ≈ 6,0 dB",
        "on remplace I<sub>d</sub> = P/(4πd²) et I<sub>2d</sub> = P/(16πd²)",
        "A = L(d) − L(2d) = 10·log(I<sub>d</sub>/I₀) − 10·log(I<sub>2d</sub>/I₀)",
        "log(a) − log(b) = log(a/b) : A = 10·log(I<sub>d</sub>/I<sub>2d</sub>)",
        "on factorise par 10"
      ],
      "bonne_reponse": [
        2,
        4,
        3,
        1,
        0
      ],
      "explication": "La factorisation par 10 puis le regroupement des logarithmes sont les deux étapes notées.",
      "piege": "Sauter la factorisation et le regroupement pour aller directement au résultat.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-23",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Doubler la distance à la source retire environ :",
      "options": [
        "3 dB",
        "10 dB",
        "6 dB",
        "20 dB"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "A = 10·log(4) ≈ 6,0 dB, car l'intensité est divisée par 4 quand la distance double.",
      "piege": "Confondre avec les 3 dB, qui correspondent à un doublement de l'<b>intensité</b>.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "actif": true
    },
    {
      "ref": "son-24",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Les 6 dB perdus par doublement de distance dépendent-ils de la puissance de la source ?",
      "options": [
        "oui, une source plus puissante perd moins",
        "oui, cela dépend aussi de la fréquence",
        "seulement au-delà de 100 m",
        "non, P se simplifie dans le calcul"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Dans A = 10·log(I<sub>d</sub>/I<sub>2d</sub>), la puissance P se simplifie : le résultat est universel.",
      "piege": "Croire qu'une source puissante « porte plus loin » en décibels — elle part de plus haut, mais perd autant.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "son-25",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 10",
      "enonce": "À 5,0 m d'une enceinte on mesure 92 dB. Que mesure-t-on à 20 m ?",
      "options": [
        "80 dB",
        "86 dB",
        "23 dB",
        "74 dB"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "De 5 à 20 m, la distance double deux fois : 92 − 6 − 6 = 80 dB.",
      "piege": "Diviser le niveau par 4 comme on divise l'intensité : les décibels se soustraient, ils ne se divisent pas.",
      "image": "son_attenuation.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-26",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 11",
      "enonce": "Deux haut-parleurs identiques émettent chacun 60 dB. Ensemble, ils produisent :",
      "options": [
        "120 dB",
        "63 dB",
        "60 dB",
        "66 dB"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Les <b>intensités</b> s'additionnent : L = 10·log(2·I/I₀) = 10·log(2) + 60 ≈ 63 dB.",
      "piege": "Additionner les niveaux : 60 + 60 = 120 dB, ce qui dépasserait le seuil de douleur.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-27",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 11",
      "enonce": "Pour x sources identiques de même intensité I, le niveau total vaut :",
      "options": [
        "L(x) = L(1 source) + x",
        "L(x) = 10·log(x × I₀)",
        "L(x) = 10·log(x) + L(1 source)",
        "L(x) = x × L(1 source)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L(x) = 10·log(x·I/I₀) = 10·log(x) + 10·log(I/I₀), en séparant le logarithme d'un produit.",
      "piege": "Multiplier le niveau par le nombre de sources.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-28",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 11",
      "enonce": "Dix machines identiques produisent chacune 70 dB. Quel est le niveau total ?",
      "options": [
        "70 dB",
        "700 dB",
        "73 dB",
        "80 dB"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "L(10) = 10·log(10) + 70 = 10 + 70 = 80 dB : dix sources ajoutent exactement 10 dB.",
      "piege": "Confondre avec le doublement, qui n'ajoute que 3 dB.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "son-29",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 11",
      "enonce": "Un élève écrit : « quatre sources de 80 dB donnent 320 dB ». Où est l'erreur ?",
      "options": ["les niveaux ne s'additionnent pas : ce sont les intensités qui s'ajoutent", "il fallait diviser par 4 : le niveau se répartit entre les sources", "il fallait multiplier par 10 : le décibel est une échelle décimale", "il n'y a pas d'erreur : les niveaux sonores s'additionnent bien"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le bon calcul : 10·log(4) + 80 ≈ 86 dB. 320 dB n'a aucun sens physique — le seuil de douleur est à 120 dB.",
      "piege": "Traiter les décibels comme des grandeurs additives.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {
      "ref": "son-30",
      "chapitre": "le-niveau-sonore",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 11",
      "enonce": "À 10 m d'une source, on mesure L = 85 dB, soit I = 3,16×10⁻⁴ W·m⁻². Quelle est la puissance de la source ?",
      "options": [
        "0,04 W",
        "0,40 W",
        "3,16×10⁻⁴ W",
        "4,0 W"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "P = I × 4πr² = 3,16×10⁻⁴ × 4π × 10² = 0,40 W.",
      "piege": "Oublier de multiplier par la surface, ou utiliser πr² au lieu de 4πr².",
      "image": "son_sphere.png",
      "tags": [
        "calcul"
      ],
      
      "actif": true
    },
    {"ref": "son-n1", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 2", "enonce": "Un éclair est vu 3,0 s avant que le tonnerre soit entendu. À quelle distance est l'orage ? (v<sub>son</sub> = 340 m·s⁻¹)", "options": ["d = v·τ = 340 × 3,0 = 1,0 × 10³ m", "d = v/τ = 340 / 3,0 = 113 m", "d = τ/v = 3,0 / 340 = 8,8 × 10⁻³ m", "on ne peut pas conclure sans la fréquence"], "bonne_reponse": [0], "explication": "Le retard τ est la durée mise par le son : <b>d = v·τ</b>. La lumière, elle, arrive quasi instantanément.", "piege": "Inverser la relation : v = d/τ donne bien d = v·τ, jamais v/τ.", "actif": true},
    {"ref": "son-n2", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "La <b>célérité</b> d'une onde sonore dépend :", "options": ["du milieu de propagation et de sa température", "de la fréquence du son émis", "de l'intensité sonore de la source", "de la distance parcourue"], "bonne_reponse": [0], "explication": "La célérité est une propriété du <b>milieu</b> : environ 340 m·s⁻¹ dans l'air, 1500 dans l'eau, davantage dans les solides.", "piege": "Croire qu'un son aigu va plus vite qu'un son grave : la fréquence n'y change rien.", "actif": true},
    {"ref": "son-n3", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 3", "enonce": "Sur l'enregistrement u = f(t), comment mesurer la période T avec le moins d'erreur ?", "options": ["mesurer la durée de plusieurs périodes, puis diviser par leur nombre", "mesurer l'écart entre deux maxima voisins", "mesurer la largeur d'un pic", "lire directement l'abscisse du premier maximum"], "bonne_reponse": [0], "explication": "Mesurer <b>n périodes d'un coup</b> puis diviser par n réduit l'incertitude de lecture d'un facteur n.", "piege": "Se contenter de deux maxima voisins : c'est juste dans son principe, mais bien trop imprécis.", "actif": true},
    {"ref": "son-n4", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "La fréquence f et la période T sont reliées par :", "options": ["f = 1/T, en Hz si T est en s", "f = T, à un facteur près", "f = 2π/T", "f = T/2π"], "bonne_reponse": [0], "explication": "<b>f = 1/T</b> : une période de 2,0 ms donne f = 1/(2,0 × 10⁻³) = 5,0 × 10² Hz.", "piege": "Oublier de convertir la période en secondes avant de calculer.", "actif": true},
    {"ref": "son-n5", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 4", "enonce": "Sur le graphe u = f(x), que mesure-t-on entre deux motifs identiques ?", "options": ["la longueur d'onde λ, en mètres", "la période T, en secondes", "la célérité v", "la fréquence f"], "bonne_reponse": [0], "explication": "L'axe est une <b>distance</b> : la double périodicité se lit en mètres, c'est λ. Sur u = f(t), le même motif donnerait T.", "piege": "Confondre les deux graphes : c'est l'unité de l'axe des abscisses qui décide.", "actif": true},
    {"ref": "son-n6", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 5", "enonce": "Un son de fréquence 440 Hz se propage à 340 m·s⁻¹. Que vaut λ ?", "options": ["λ = v/f = 340 / 440 = 0,77 m", "λ = v·f = 340 × 440 = 1,5 × 10⁵ m", "λ = f/v = 440 / 340 = 1,3 m", "λ = v·T = 340 × 440 = 1,5 × 10⁵ m"], "bonne_reponse": [0], "explication": "λ = v·T = <b>v/f</b> : la longueur d'onde est la distance parcourue pendant une période.", "piege": "Multiplier au lieu de diviser : un contrôle d'ordre de grandeur suffit à écarter 10⁵ m.", "actif": true},
    {"ref": "son-n7", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Un son passe de l'air dans l'eau, où la célérité est plus grande. Que devient sa longueur d'onde ?", "options": ["elle augmente, la fréquence étant imposée par la source", "elle diminue, la fréquence étant imposée par le milieu", "elle est inchangée, la célérité n'agissant pas sur λ", "elle dépend de l'intensité sonore, et non de la célérité"], "bonne_reponse": [0], "explication": "La <b>fréquence ne change jamais</b> : elle est imposée par la source. De λ = v/f, une célérité plus grande donne une longueur d'onde plus grande.", "piege": "Croire que la fréquence change en changeant de milieu — c'est la célérité qui change.", "actif": true},
    {"ref": "son-t01", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Une onde sonore est une onde mécanique progressive. Cela signifie qu'elle :", "options": ["transporte de la matière d'un point à un autre du milieu", "se propage dans le vide comme la lumière, en transportant de l'énergie", "se propage dans un milieu matériel, transportant de l'énergie sans matière", "reste immobile et fait vibrer l'air sur place, sans se déplacer"], "bonne_reponse": [2], "explication": "Une onde progressive transporte de l'énergie sans transport de matière ; mécanique, elle a besoin d'un milieu. Le son ne se propage donc pas dans le vide.", "piege": "Croire que l'air « voyage » avec le son : chaque tranche d'air vibre sur place.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t02", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un coup de tonnerre est entendu 4,0 s après l'éclair. À quelle distance est l'orage ? On donne v = 340 m·s⁻¹.", "options": ["d = v/τ = 340 / 4,0 = 85 m", "On ne peut pas conclure sans la fréquence", "d = τ/v = 4,0 / 340 = 1,2 × 10⁻² m", "d = v·τ = 340 × 4,0 = 1,4 × 10³ m"], "bonne_reponse": [3], "explication": "Le retard τ est la durée que met le son pour parcourir la distance d : d = v·τ. La lumière arrive quasi instantanément.", "piege": "Diviser au lieu de multiplier : v = d/τ, donc d = v·τ.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t03", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Sur l'enregistrement u(t) d'un son, on mesure 5 périodes sur 12,5 ms. La fréquence est :", "options": ["T = 12,5/5 = 2,5 ms donc f = 1/T = 4,0 × 10² Hz", "T = 12,5 ms donc f = 1/T = 80 Hz", "T = 1/(5 × 12,5) s donc f = 5 × 12,5 = 62,5 Hz", "T = 5/12,5 = 0,40 s donc f = 12,5/5 = 2,5 Hz"], "bonne_reponse": [0], "explication": "On mesure plusieurs périodes pour réduire l'incertitude, puis on divise : T = 2,5 ms = 2,5 × 10⁻³ s, et f = 1/T = 400 Hz.", "piege": "Oublier de diviser par le nombre de périodes, ou de convertir les millisecondes en secondes.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t04", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Sur une représentation de l'onde en fonction de la position, u = f(x), la longueur d'onde λ se lit comme :", "options": ["l'amplitude maximale de la courbe", "la durée entre deux maxima", "la distance entre deux points consécutifs dans le même état vibratoire", "la distance entre un maximum et le minimum suivant"], "bonne_reponse": [2], "explication": "λ est la période SPATIALE : la plus petite distance séparant deux points qui vibrent en phase. Elle se lit sur un axe des positions, en mètres.", "piege": "Confondre avec la période T, qui se lit sur un axe des temps — c'est l'unité de l'axe qui décide.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t05", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Un son de fréquence f = 680 Hz se propage dans l'air à v = 340 m·s⁻¹. Sa longueur d'onde vaut :", "options": ["λ = f/v = 680/340 = 2,0 m", "λ = v·T = 340 × 680 = 2,3 × 10⁵ m", "λ = v·f = 340 × 680 = 2,3 × 10⁵ m", "λ = v/f = 340/680 = 0,50 m"], "bonne_reponse": [3], "explication": "λ = v·T = v/f : la longueur d'onde est la distance parcourue pendant une période.", "piege": "Multiplier au lieu de diviser — un ordre de grandeur de 10⁵ m doit alerter.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t06", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Une source ponctuelle émet une puissance P = 2,0 × 10⁻³ W dans toutes les directions. L'intensité sonore à r = 4,0 m est :", "options": ["I = P/(4πr²) = 2,0 × 10⁻³/(4π × 4,0²) = 9,9 × 10⁻⁶ W·m⁻²", "I = P/(4πr) = 2,0 × 10⁻³/(4π × 4,0) = 4,0 × 10⁻⁵ W·m⁻²", "I = P × 4πr² = 0,40 W·m⁻²", "I = P/r² = 2,0 × 10⁻³/16 = 1,3 × 10⁻⁴ W·m⁻²"], "bonne_reponse": [0], "explication": "La puissance se répartit sur une sphère de rayon r, d'aire 4πr². L'intensité est la puissance par unité de surface : I = P/(4πr²).", "piege": "Oublier le 4π, ou le carré sur r — l'aire d'une sphère est 4πr².", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t07", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "L'intensité sonore en un point vaut I = 1,0 × 10⁻⁵ W·m⁻². Avec I₀ = 1,0 × 10⁻¹² W·m⁻², le niveau sonore est :", "options": ["L = 10·log(I/I₀) = 10·log(10⁷) = 70 dB", "L = 10·log(I₀/I) = 10·log(10⁻⁷) = −70 dB", "L = log(I/I₀) = log(10⁷) = 7 dB", "L = I/I₀ = 10⁻⁵/10⁻¹² = 10⁷ dB"], "bonne_reponse": [0], "explication": "L = 10·log(I/I₀). Ici I/I₀ = 10⁷, donc L = 10 × 7 = 70 dB.", "piege": "Oublier le facteur 10, ou inverser le rapport, ce qui donne un niveau négatif.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t08", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Pour retrouver l'intensité I à partir du niveau L, on part de L = 10·log(I/I₀). La première étape correcte est :", "options": ["log(I/I₀) = L/10, puis I/I₀ = 10^(L/10)", "I/I₀ = L/10, puis I = I₀·L/10", "log(I/I₀) = 10·L, puis I/I₀ = 10^(10L)", "I = 10·log(L/I₀)"], "bonne_reponse": [0], "explication": "On isole le logarithme en divisant par 10, puis on applique 10^ des deux côtés : I/I₀ = 10^(L/10), donc I = I₀ × 10^(L/10).", "piege": "Diviser par 10 sans passer par le logarithme, ou multiplier au lieu de diviser.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t09", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Un mur fait passer le niveau sonore de 85 dB à 55 dB. L'atténuation vaut :", "options": ["A = 10·log(85/55) = 1,9 dB", "A = L₂ − L₁ = −30 dB", "A = L₁ − L₂ = 85 − 55 = 30 dB", "A = L₁/L₂ = 1,5 dB"], "bonne_reponse": [2], "explication": "L'atténuation est la différence de niveau sonore entre l'entrée et la sortie : A = L_avant − L_après, positive quand le son est atténué.", "piege": "Prendre un rapport ou un logarithme des niveaux : les décibels se soustraient.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t10", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "Une source ponctuelle est entendue à L(d) à la distance d. Pour montrer que L(2d) = L(d) − 6 dB, on calcule A = 10·log(I_d/I_2d). Que vaut I_d/I_2d ?", "options": ["I_d/I_2d = (2d)²/d² = 4, donc A = 10·log 4 ≈ 6 dB", "I_d/I_2d = 2d/d = 2, donc A = 2 dB", "I_d/I_2d = 1/4, donc A = −6 dB", "I_d/I_2d = 2, donc A = 10·log 2 ≈ 3 dB"], "bonne_reponse": [0], "explication": "I = P/(4πr²) : à distance double, l'intensité est divisée par 4. A = 10·log 4 = 10 × 0,60 = 6,0 dB.", "piege": "Oublier le carré : c'est r² qui apparaît dans l'aire de la sphère, donc doubler r divise I par 4, pas par 2.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "son-t11", "chapitre": "son", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 11", "enonce": "Un haut-parleur produit 60 dB. Quatre haut-parleurs identiques produisent :", "options": ["L = 4 × 60 = 240 dB", "L = 60 + 10·log 4 = 66 dB", "L = 60 dB, le niveau ne change pas", "L = 60 + 4 = 64 dB"], "bonne_reponse": [1], "explication": "Les INTENSITÉS s'additionnent, pas les niveaux : I devient 4I, et L = 10·log(4I/I₀) = L₁ + 10·log 4 = 60 + 6 = 66 dB.", "piege": "Additionner ou multiplier les décibels : ce sont des logarithmes, ils ne s'additionnent jamais directement.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  doppler: [
    {
      "ref": "dop-01",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La double périodicité d'une onde, ce sont :",
      "options": ["une période temporelle T et une période spatiale λ", "deux fréquences différentes, l'une émise et l'autre perçue", "une amplitude et une phase, mesurées en un point donné", "deux célérités, l'une dans l'air et l'autre dans l'eau"],
      "bonne_reponse": [
        0
      ],
      "explication": "T est la durée au bout de laquelle le signal se reproduit en un point ; λ est la distance au bout de laquelle il se reproduit à un instant donné.",
      "piege": "Croire que « double périodicité » signifie deux fréquences : il s'agit d'une périodicité dans le temps et d'une dans l'espace.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-02",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Quelle relation lie λ, c, T et f ?",
      "options": [
        "λ = T/c = 1/(c·f)",
        "λ = c × T = c/f",
        "λ = c/T = c·f",
        "λ = c + T"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "λ = c × T, et comme f = 1/T, on a aussi λ = c/f.",
      "piege": "Inverser T et f dans la formule : une longueur d'onde ne se divise pas par une période.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-03",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Une onde change de milieu. Qu'est-ce qui reste inchangé ?",
      "options": [
        "la longueur d'onde",
        "la célérité",
        "la fréquence",
        "rien"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "La fréquence est <b>imposée par la source</b> : elle ne change pas. C'est la célérité qui change, et λ suit.",
      "piege": "Croire que la longueur d'onde est la grandeur conservée : elle s'adapte justement au nouveau milieu.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "actif": true
    },
    {
      "ref": "dop-04",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "socle",
      "enonce": "Un son de fréquence f = 850 Hz se propage à c = 340 m·s⁻¹. Que vaut sa longueur d'onde ?",
      "options": [
        "2,9×10⁵ m",
        "2,5 m",
        "0,40 cm",
        "0,40 m"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "λ = c/f = 340/850 = 0,40 m.",
      "piege": "Calculer f/c au lieu de c/f : le résultat n'a alors pas la dimension d'une longueur.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-05",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Quels mots doivent figurer dans la définition de l'effet Doppler ? <b>Plusieurs réponses.</b>",
      "options": ["phénomène ondulatoire, quelle que soit la nature de l'onde", "mouvement relatif entre la source et le récepteur", "la fréquence perçue diffère de la fréquence émise", "la source doit être sonore, l'effet étant propre au son"],
      "bonne_reponse": [
        0,
        1,
        2
      ],
      "explication": "Trois éléments rapportent les points : phénomène ondulatoire, mouvement <b>relatif</b>, et fréquence perçue ≠ fréquence émise.",
      "piege": "Parler de la source seule, sans le récepteur : la définition est alors incomplète.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-06",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "L'effet Doppler concerne :",
      "options": [
        "les ondes sonores comme les ondes lumineuses",
        "seulement les ondes lumineuses",
        "seulement les ondes sonores",
        "seulement les ondes mécaniques"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le phénomène est ondulatoire : il vaut pour le son comme pour la lumière — d'où son usage en astronomie.",
      "piege": "Le limiter au son parce que l'exemple de l'ambulance est le plus connu.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-07",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Quand n'y a-t-il <b>pas</b> d'effet Doppler ?",
      "options": [
        "quand la source est très éloignée",
        "quand f<sub>R</sub> = f<sub>E</sub>, c'est-à-dire sans mouvement relatif",
        "quand la source est immobile mais le récepteur mobile",
        "quand l'onde est lumineuse"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Ce qui compte est le mouvement <b>relatif</b> : si la distance source-récepteur ne varie pas, f<sub>R</sub> = f<sub>E</sub>.",
      "piege": "Croire qu'il faut que la source soit immobile : un récepteur qui bouge produit aussi l'effet.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "dop-08",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Que faut-il citer systématiquement en répondant à « relier λ, T et f » ?",
      "options": ["que la célérité dépend de la fréquence dans un milieu donné", "que f = c × λ, la fréquence étant le produit des deux", "que la fréquence est imposée par la source et ne change pas de milieu", "que λ est toujours plus grande que T, quelle que soit la célérité"],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est la phrase attendue par le correcteur : f est imposée par la source, c change avec le milieu, λ suit.",
      "piege": "Donner la formule sans la phrase : la moitié des points est perdue.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-09",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "La source <b>s'éloigne</b> du récepteur. Quelle relation en fréquences ?",
      "options": [
        "f<sub>R</sub> = f<sub>E</sub> · v/c",
        "f<sub>R</sub> = f<sub>E</sub> · c/(c − v)",
        "f<sub>R</sub> = f<sub>E</sub> · (c + v)/c",
        "f<sub>R</sub> = f<sub>E</sub> · c/(c + v)"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "En s'éloignant, la fréquence perçue diminue : le dénominateur c + v est plus grand que c.",
      "piege": "Intervertir les deux cas : c − v correspond au rapprochement.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "dop-10",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "La source s'éloigne. Que vaut la longueur d'onde perçue λ<sub>R</sub> ?",
      "options": [
        "λ<sub>R</sub> = λ<sub>E</sub> × (c + v)/c, donc λ<sub>R</sub> > λ<sub>E</sub>",
        "λ<sub>R</sub> = λ<sub>E</sub>, la longueur d'onde ne change pas",
        "λ<sub>R</sub> = λ<sub>E</sub> × v/c",
        "λ<sub>R</sub> = λ<sub>E</sub> × (c − v)/c, donc λ<sub>R</sub> &lt; λ<sub>E</sub>"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Si la fréquence perçue diminue, la longueur d'onde perçue augmente : les fronts d'onde s'écartent.",
      "piege": "Conclure sur la fréquence sans dire ce que devient λ — c'est ce que l'énoncé demande.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-11",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre le passage des fréquences aux longueurs d'onde (source qui s'éloigne) :",
      "options": [
        "f<sub>R</sub> = f<sub>E</sub> · c/(c + v)",
        "λ<sub>R</sub> = 1 / [ (1/λ<sub>E</sub>) · c/(c + v) ]",
        "λ<sub>R</sub> = λ<sub>E</sub> (c + v)/c",
        "c/λ<sub>R</sub> = (c/λ<sub>E</sub>) · c/(c + v)",
        "1/λ<sub>R</sub> = (1/λ<sub>E</sub>) · c/(c + v)"
      ],
      "bonne_reponse": [
        0,
        3,
        4,
        1,
        2
      ],
      "explication": "On remplace chaque fréquence par c/λ, on simplifie par c, puis on inverse : ce sont les équivalences écrites qui rapportent les points.",
      "piege": "Sauter des étapes pour aller au résultat : c'est exactement ce qui est noté ici.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-12",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "La source <b>se rapproche</b> du récepteur. Le son perçu paraît :",
      "options": [
        "plus grave, car λ<sub>R</sub> > λ<sub>E</sub>",
        "plus aigu, car λ<sub>R</sub> &lt; λ<sub>E</sub>",
        "plus fort, mais de même hauteur",
        "identique"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Les fronts d'onde se resserrent : λ<sub>R</sub> diminue, f<sub>R</sub> augmente, le son est plus aigu.",
      "piege": "Confondre hauteur et intensité : un son plus aigu n'est pas un son plus fort.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "dop-13",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "L'énoncé demande : « le son perçu est-il plus aigu ou plus grave ? ». Que doit contenir la réponse ?",
      "options": ["la valeur de la célérité, sans laquelle rien ne peut être conclu", "le calcul complet de v, seul à justifier la conclusion attendue", "la conclusion, justifiée par ce que devient la longueur d'onde", "seulement la conclusion aigu ou grave, sans autre justification"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le correcteur attend le raisonnement : rapprochement → λ<sub>R</sub> &lt; λ<sub>E</sub> → f<sub>R</sub> > f<sub>E</sub> → plus aigu.",
      "piege": "Conclure sans dire ce que devient λ : la justification manque.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-14",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Pour passer de λ<sub>R</sub> = λ<sub>E</sub>(c − v)/c à λ<sub>R</sub> = λ<sub>E</sub>(1 − v/c), il faut :",
      "options": ["prendre le logarithme des deux membres, puis simplifier", "développer le numérateur, puis regrouper les termes en v", "multiplier par c des deux côtés, puis simplifier par λ_E", "factoriser le numérateur par c, puis simplifier par c"],
      "bonne_reponse": [
        3
      ],
      "explication": "c − v = c(1 − v/c) : on factorise par c au numérateur, et le c du dénominateur se simplifie.",
      "piege": "Développer au lieu de factoriser : on tourne alors en rond.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "actif": true
    },
    {
      "ref": "dop-15",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Quelle écriture correspond à une source qui <b>s'éloigne</b> ?",
      "options": [
        "λ<sub>R</sub> = λ<sub>E</sub>(1 + v/c)",
        "λ<sub>R</sub> = λ<sub>E</sub>(1 − v/c)",
        "λ<sub>R</sub> = λ<sub>E</sub>/(1 + v/c)",
        "λ<sub>R</sub> = λ<sub>E</sub>(v/c − 1)"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "L'éloignement allonge la longueur d'onde : le facteur est (1 + v/c), supérieur à 1.",
      "piege": "Confondre les deux signes : le moyen sûr est de vérifier que λ<sub>R</sub> doit augmenter.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-16",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Remets dans l'ordre l'isolement de v dans λ<sub>R</sub> = λ<sub>E</sub>(1 − v/c) :",
      "options": [
        "λ<sub>R</sub>/λ<sub>E</sub> − 1 = − v/c",
        "λ<sub>R</sub>/λ<sub>E</sub> = 1 − v/c",
        "v/c = 1 − λ<sub>R</sub>/λ<sub>E</sub>",
        "v = c(1 − λ<sub>R</sub>/λ<sub>E</sub>)"
      ],
      "bonne_reponse": [
        1,
        0,
        2,
        3
      ],
      "explication": "On divise par λ<sub>E</sub>, on ajoute −1, on multiplie par −1, puis par c : chaque opération se justifie.",
      "piege": "Oublier le passage par −1 et se tromper de signe dans le résultat final.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-17",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "La relation v = c(1 − λ<sub>R</sub>/λ<sub>E</sub>) donne :",
      "options": [
        "une vitesse en km·h⁻¹",
        "v > 0 si la source se rapproche",
        "v > 0 si la source s'éloigne",
        "toujours v > 0"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Elle a été établie pour un rapprochement : un résultat négatif signale donc un éloignement.",
      "piege": "Intervertir λ<sub>R</sub> et λ<sub>E</sub> dans le quotient — le signe change alors du tout au tout.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-18",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 6",
      "enonce": "Une raie mesurée à λ<sub>E</sub> = 500,0 nm est observée à λ<sub>R</sub> = 499,0 nm. Que vaut la vitesse radiale ? (c = 3,00×10⁸ m·s⁻¹)",
      "options": [
        "1,0×10⁵ m·s⁻¹, la source s'éloigne",
        "6,0×10⁵ m·s⁻¹, la source s'éloigne",
        "6,0×10⁵ m·s⁻¹, la source se rapproche",
        "6,0×10⁶ m·s⁻¹, la source se rapproche"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "v = 3,00×10⁸ × (1 − 499,0/500,0) = 3,00×10⁸ × 2,0×10⁻³ = 6,0×10⁵ m·s⁻¹, positif donc rapprochement (λ<sub>R</sub> &lt; λ<sub>E</sub>).",
      "piege": "Se tromper de sens : ici λ diminue, c'est un décalage vers le bleu.",
      "image": "dop_spectre.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-19",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "On mesure f<sub>A</sub> à l'approche et f<sub>É</sub> à l'éloignement d'une source qui passe. Pourquoi cette méthode est-elle commode ?",
      "options": [
        "parce qu'elle donne la vitesse en km·h⁻¹",
        "parce qu'elle évite de mesurer la distance",
        "parce qu'elle ne nécessite pas la célérité",
        "parce que la fréquence émise f<sub>E</sub> se simplifie dans le rapport"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "En faisant f<sub>A</sub>/f<sub>É</sub>, la fréquence émise — souvent inconnue — disparaît : il ne reste que c, v et les deux mesures.",
      "piege": "Confondre f<sub>É</sub>, la fréquence reçue pendant l'éloignement, avec f<sub>E</sub>, la fréquence émise.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "dop-20",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Quelle est l'expression de la vitesse en fonction de f<sub>A</sub> et f<sub>É</sub> ?",
      "options": [
        "v = c · (f<sub>A</sub> − f<sub>É</sub>)/(f<sub>A</sub> + f<sub>É</sub>)",
        "v = c · (f<sub>A</sub> − f<sub>É</sub>)/c",
        "v = c · (f<sub>A</sub> + f<sub>É</sub>)/(f<sub>A</sub> − f<sub>É</sub>)",
        "v = c · f<sub>A</sub>/f<sub>É</sub>"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le rapport f<sub>A</sub>/f<sub>É</sub> = (c + v)/(c − v) donne, après produit en croix et factorisation, v = c(f<sub>A</sub> − f<sub>É</sub>)/(f<sub>A</sub> + f<sub>É</sub>).",
      "piege": "Inverser numérateur et dénominateur : on obtiendrait une vitesse supérieure à c.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-21",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Une sirène est perçue à 900 Hz à l'approche et 800 Hz après le passage (c = 340 m·s⁻¹). Que vaut la vitesse ?",
      "options": [
        "34 m·s⁻¹",
        "20 m·s⁻¹",
        "2,0 m·s⁻¹",
        "40 m·s⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "v = 340 × (900 − 800)/(900 + 800) = 340 × 100/1700 = 20 m·s⁻¹, soit environ 72 km·h⁻¹.",
      "piege": "Diviser par la différence au lieu de la somme : on obtiendrait une valeur absurde.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "dop-22",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Une sirène est perçue à f<sub>A</sub> = 900 Hz alors que le véhicule s'approche à v = 20 m·s⁻¹. Quelle est la fréquence émise ? <i>Donnée : c = 340 m·s⁻¹.</i>",
      "options": [
        "800 Hz",
        "900 Hz",
        "847 Hz",
        "850 Hz"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "f<sub>E</sub> = f<sub>A</sub>·(c − v)/c = 900 × 320/340 = 847 Hz — bien comprise entre les deux mesures.",
      "piege": "Prendre la moyenne des deux fréquences reçues : le résultat est proche, mais ce n'est pas la méthode attendue.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-23",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Le décalage Doppler Δf = f<sub>R</sub> − f<sub>E</sub> est <b>positif</b>. Que peut-on conclure ?",
      "options": [
        "la source est immobile",
        "la source se rapproche, le son est plus aigu",
        "la source s'éloigne, le son est plus grave",
        "on ne peut rien conclure sans la vitesse"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Δf > 0 signifie f<sub>R</sub> > f<sub>E</sub> : les fronts se resserrent, le son est plus aigu, la source se rapproche.",
      "piege": "Inverser les deux conclusions. Le repère infaillible : une ambulance qui arrive est plus aiguë.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "dop-24",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Δf = 0 signifie :",
      "options": ["qu'il n'y a pas de mouvement relatif entre la source et l'observateur", "que l'observateur est sourd, et ne perçoit donc aucun écart", "que la source est arrêtée, l'observateur pouvant se déplacer", "que la distance est nulle, la source touchant l'observateur"],
      "bonne_reponse": [
        0
      ],
      "explication": "Ce qui compte est le mouvement relatif : source et observateur peuvent bouger, tant que la distance ne varie pas.",
      "piege": "Conclure que la source est immobile : elle peut se déplacer perpendiculairement à la ligne de visée.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-25",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Un observateur perçoit 1 020 Hz pour un signal émis à 1 000 Hz. Que se passe-t-il ?",
      "options": [
        "la source s'éloigne",
        "la source se rapproche",
        "la source est immobile",
        "le signal a changé de milieu"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Δf = +20 Hz > 0 : la fréquence perçue est plus grande, la source se rapproche.",
      "piege": "Croire qu'un changement de milieu peut modifier la fréquence : elle est imposée par la source.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-26",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "Dans le spectre d'une galaxie, une raie apparaît à une longueur d'onde <b>plus grande</b> qu'au laboratoire. On parle de :",
      "options": [
        "décalage vers le rouge, la galaxie se rapproche",
        "décalage vers le bleu, la galaxie se rapproche",
        "décalage vers le rouge, la galaxie s'éloigne",
        "absorption atmosphérique"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Les grandes longueurs d'onde sont du côté rouge du spectre : λ<sub>R</sub> > λ<sub>E</sub> signale un éloignement.",
      "piege": "Confondre « décalage vers le rouge » et « la galaxie est rouge » : il s'agit d'un déplacement de raie, pas d'une couleur.",
      "image": "dop_spectre.png",
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-27",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Une raie de l'hydrogène vaut λ<sub>E</sub> = 656,3 nm au laboratoire et λ<sub>R</sub> = 660,1 nm dans le spectre d'une galaxie. Que vaut la vitesse radiale ? <i>Donnée : c = 3,00×10⁸ m·s⁻¹.</i>",
      "options": [
        "3,8×10⁸ m·s⁻¹, en éloignement",
        "1,7×10⁶ m·s⁻¹, en rapprochement",
        "1,7×10³ m·s⁻¹, en éloignement",
        "1,7×10⁶ m·s⁻¹, en éloignement"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "v = 3,00×10⁸ × (1 − 660,1/656,3) = −1,7×10⁶ m·s⁻¹ : le signe négatif traduit l'éloignement.",
      "piege": "Oublier de convertir le signe en une conclusion physique, ou confondre m·s⁻¹ et km·s⁻¹.",
      "image": "dop_spectre.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "dop-28",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Après avoir trouvé v = 1,7×10⁶ m·s⁻¹, quelle vérification s'impose ?",
      "options": [
        "que v/c ≪ 1, pour rester dans le domaine de validité",
        "que λ<sub>R</sub> soit un multiple de λ<sub>E</sub>",
        "que v soit inférieure à la vitesse du son",
        "aucune, le calcul suffit"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Ici v/c ≈ 6×10⁻³ : très inférieur à 1, la relation non relativiste reste valable.",
      "piege": "Ne pas vérifier : au-delà de quelques pourcents de c, la formule utilisée ne vaut plus.",
      "image": null,
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dop-29",
      "chapitre": "l-effet-doppler",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Un élève écrit : « λ<sub>R</sub> > λ<sub>E</sub>, donc la galaxie se rapproche ». Que faut-il lui répondre ?",
      "options": ["il faut convertir en nanomètres avant de comparer les deux longueurs", "λ_R > λ_E est un décalage vers le rouge : la galaxie s'éloigne", "il faut d'abord calculer la fréquence, seule à donner le sens", "c'est correct : une longueur d'onde plus grande signale un rapprochement"],
      "bonne_reponse": [
        1
      ],
      "explication": "Une longueur d'onde qui augmente correspond à une fréquence qui diminue, donc à un éloignement.",
      "piege": "Associer « plus grand » à « se rapproche » par réflexe.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {"ref": "doppler-t01", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "L'effet Doppler est :", "options": ["le changement de célérité d'une onde qui change de milieu de propagation", "la diminution de l'intensité sonore quand la distance à la source croît", "la réflexion d'une onde sur un obstacle lui-même en mouvement", "le décalage entre fréquence émise et perçue, quand il y a mouvement relatif"], "bonne_reponse": [3], "explication": "L'effet Doppler concerne la FRÉQUENCE : elle est perçue différemment de celle émise dès qu'il y a mouvement relatif entre source et récepteur.", "piege": "Le confondre avec l'atténuation — l'intensité baisse avec la distance, mais la fréquence, elle, ne change qu'avec le mouvement.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t02", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Une onde progressive périodique possède une double périodicité. Ses deux périodes sont :", "options": ["la période T, en secondes, et la fréquence f, en hertz", "la fréquence f, en hertz, et la célérité v, en mètres par seconde", "la période temporelle T, en secondes, et la longueur d'onde λ, en mètres", "l'amplitude, en mètres, et la fréquence f, en hertz"], "bonne_reponse": [2], "explication": "Périodicité temporelle : T, le motif se répète dans le temps. Périodicité spatiale : λ, le motif se répète dans l'espace. Elles sont liées par λ = v·T.", "piege": "Citer f et T : ce sont la même périodicité, exprimée de deux façons.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t03", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Une source s'éloigne du récepteur à la vitesse v. Pendant une période T_E, elle émet une onde et recule de v·T_E. La longueur d'onde reçue est :", "options": ["λ_R = λ_E − v·T_E = λ_E(c − v)/c", "λ_R = λ_E × v/c", "λ_R = λ_E + v·T_E = λ_E(c + v)/c", "λ_R = λ_E, la longueur d'onde ne change pas"], "bonne_reponse": [2], "explication": "En s'éloignant, la source étire l'onde : λ_R = λ_E + v·T_E. Avec T_E = λ_E/c, on obtient λ_R = λ_E(1 + v/c) = λ_E(c + v)/c.", "piege": "Soustraire au lieu d'ajouter : une source qui s'éloigne ALLONGE la longueur d'onde reçue.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t04", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Une source se rapproche du récepteur à la vitesse v. La longueur d'onde reçue est :", "options": ["λ_R = λ_E/(c − v)", "λ_R = λ_E × c/v", "λ_R = λ_E − v·T_E = λ_E(c − v)/c", "λ_R = λ_E + v·T_E = λ_E(c + v)/c"], "bonne_reponse": [2], "explication": "En se rapprochant, la source comprime l'onde : chaque front est émis un peu plus près du précédent, λ_R = λ_E − v·T_E = λ_E(c − v)/c.", "piege": "Inverser le signe : une source qui se rapproche RACCOURCIT la longueur d'onde, donc augmente la fréquence perçue.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t05", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Les deux cas — source qui s'éloigne, source qui se rapproche — se résument par λ_R = λ_E(1 ∓ v/c). Le signe − correspond à :", "options": ["une source qui se rapproche : λ diminue", "une source qui s'éloigne : λ diminue", "un récepteur qui s'éloigne", "une source immobile"], "bonne_reponse": [0], "explication": "Le signe − réduit λ_R : c'est le rapprochement. Le signe + l'augmente : c'est l'éloignement. On retrouve λ_E(c ∓ v)/c en multipliant par c/c.", "piege": "Associer le signe au sens du mouvement au lieu de l'associer à l'effet sur λ.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t06", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Une source se rapproche. Pour obtenir sa vitesse à partir de λ_R = λ_E(1 − v/c), on écrit :", "options": ["λ_R/λ_E = 1 − v/c, donc v/c = λ_R/λ_E, donc v = c·λ_R/λ_E", "λ_R/λ_E = 1 − v/c, donc v/c = λ_R/λ_E − 1, donc v = c(λ_R/λ_E − 1)", "λ_R/λ_E = 1 − v/c, donc v = λ_E − λ_R, sans intervention de c", "λ_R/λ_E = 1 − v/c, donc v/c = 1 − λ_R/λ_E, donc v = c(1 − λ_R/λ_E)"], "bonne_reponse": [3], "explication": "On divise par λ_E, on isole v/c, on multiplie par c. Pour un rapprochement, λ_R &lt; λ_E, et v est bien positive.", "piege": "Se tromper d'ordre dans la soustraction : λ_R/λ_E − 1 est négatif quand la source se rapproche.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t07", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Un radar émet à f_É = 24,0 GHz et reçoit, après réflexion sur une voiture qui se rapproche, f_R = 24,0 GHz + 3,2 kHz. Avec Δf = 2·f_É·v/c pour un radar, la vitesse de la voiture vaut :", "options": ["v = Δf/(2·f_É) = 3,2 × 10³/(2 × 24,0 × 10⁹) = 6,7 × 10⁻⁸ m·s⁻¹", "v = c·Δf/f_É = 3,0 × 10⁸ × 3,2 × 10³/(24,0 × 10⁹) = 40 m·s⁻¹", "v = 2·f_É·Δf/c = 2 × 24,0 × 10⁹ × 3,2 × 10³/(3,0 × 10⁸) = 5,1 × 10⁵ m·s⁻¹", "v = c·Δf/(2·f_É) = 3,0 × 10⁸ × 3,2 × 10³/(2 × 24,0 × 10⁹) = 20 m·s⁻¹"], "bonne_reponse": [3], "explication": "On isole v dans la relation donnée : v = c·Δf/(2·f_É). Le facteur 2 vient de l'aller-retour de l'onde radar.", "piege": "Oublier le facteur 2 du radar, ou confondre f_É et Δf dans le rapport.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t08", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Un observateur mesure une fréquence reçue f_R plus grande que la fréquence émise f_É. On en déduit que :", "options": ["la source tourne autour de lui", "la source est immobile", "la source s'éloigne de lui", "la source se rapproche de lui"], "bonne_reponse": [3], "explication": "Si f_R > f_É, alors λ_R &lt; λ_E : l'onde est comprimée, la source se rapproche. C'est le son plus aigu d'une sirène qui arrive.", "piege": "Inverser : un décalage vers les hautes fréquences signale un rapprochement, pas un éloignement.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "doppler-t09", "chapitre": "doppler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Dans le spectre d'une galaxie, une raie de l'hydrogène attendue à λ_E = 656,3 nm est observée à λ_R = 658,5 nm. On en conclut :", "options": ["la galaxie est immobile, la différence vient de l'incertitude de mesure", "décalage vers le bleu : la galaxie se rapproche", "la galaxie s'éloigne, à v = c·λ_R/λ_E", "décalage vers le rouge : la galaxie s'éloigne, à v = c(λ_R − λ_E)/λ_E ≈ 1,0 × 10³ km·s⁻¹"], "bonne_reponse": [3], "explication": "λ_R > λ_E : décalage vers le rouge, éloignement. v = c(λ_R − λ_E)/λ_E = 3,0 × 10⁸ × 2,2/656,3 ≈ 1,0 × 10⁶ m·s⁻¹ = 1,0 × 10³ km·s⁻¹.", "piege": "Confondre le sens du décalage : rouge = plus grande longueur d'onde = éloignement.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  diffraction: [
    {
      "ref": "dif-01",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La diffraction est le phénomène par lequel une onde :",
      "options": [
        "subit un étalement des directions de sa propagation",
        "se réfléchit sur un obstacle",
        "perd de l'énergie dans un matériau",
        "change de fréquence en traversant une ouverture"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "En rencontrant une ouverture ou un obstacle de faible dimension, l'onde s'étale : elle ne se propage plus en ligne droite.",
      "piege": "Confondre avec la réflexion ou l'absorption : la diffraction est un étalement, pas un renvoi.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "dif-02",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Pour une onde lumineuse, on retient en pratique que la diffraction se produit si :",
      "options": [
        "a > λ",
        "a ≲ 100 λ",
        "a = 2λ exactement",
        "a ≳ 100 λ"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La condition générale est a ≃ λ ou a ≪ λ ; en pratique, pour la lumière, on retient a ≲ 100 λ.",
      "piege": "Inverser l'inégalité : plus l'ouverture est <b>petite</b>, plus la diffraction est marquée.",
      "image": null,
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "dif-03",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Dans la relation L = 2λD/a, que désigne D ?",
      "options": [
        "la largeur de la fente",
        "la largeur de la tache centrale",
        "la distance entre la fente et l'écran",
        "la distance entre deux franges"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "a est la largeur de la fente, D la distance fente-écran, L la largeur de la tache centrale.",
      "piege": "Confondre a et D — l'une est microscopique, l'autre de l'ordre du mètre.",
      "image": "dif_montage.png",
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-04",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Comment répond-on à « le phénomène de diffraction se produit-il ? »",
      "options": ["à l'œil, en regardant la figure obtenue sur l'écran", "en mesurant la largeur de la tache, puis en concluant", "en calculant l'interfrange, puis en le comparant à λ", "en comparant a et λ par un calcul, puis en concluant"],
      "bonne_reponse": [
        3
      ],
      "explication": "On écrit les deux ordres de grandeur, on les compare, puis on conclut : on ne conclut jamais à l'œil.",
      "piege": "Conclure sans écrire le rapport a/λ : c'est le calcul qui est noté.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "dif-05",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Une porte de largeur a = 60 cm est éclairée par une lumière de longueur d'onde λ = 650 nm. Y a-t-il diffraction ?",
      "options": ["oui, car a ∼ 10⁰ m reste supérieur à λ ∼ 10⁻⁷ m", "non, car a ∼ 10⁰ m est très supérieur à 100 λ ∼ 10⁻⁴ m", "oui, car a ∼ 10⁰ m est du même ordre que 100 λ ∼ 10⁻⁴ m", "non, car a ∼ 10⁰ m est très inférieur à 100 λ ∼ 10⁻⁴ m"],
      "bonne_reponse": [
        1
      ],
      "explication": "a = 6,0×10⁻¹ m et 100 λ = 6,5×10⁻⁵ m : a est bien supérieur, il n'y a pas de diffraction visible.",
      "piege": "Croire que « a > λ » suffit à conclure à la diffraction — c'est l'inverse.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-06",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Un cheveu de diamètre a = 60 μm est éclairé par un laser λ = 650 nm. Y a-t-il diffraction ?",
      "options": [
        "oui, mais seulement si D est grand",
        "oui : a = 6,0×10⁻⁵ m &lt; 100 λ = 6,50×10⁻⁵ m",
        "non, un cheveu n'est pas une ouverture",
        "non, a est trop grand"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La comparaison est serrée mais nette : 6,0×10⁻⁵ &lt; 6,50×10⁻⁵, il y a diffraction.",
      "piege": "Se tromper de conversion : 60 μm = 6,0×10⁻⁵ m, pas 6,0×10⁻⁶ m.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-07",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Remets dans l'ordre la démonstration de L = 2λD/a :",
      "options": [
        "dans le triangle rectangle : tan θ = (L/2)/D",
        "approximation des petits angles : tan θ ≈ θ",
        "donc λ/a = L/(2D)",
        "or l'écart angulaire vaut θ = λ/a",
        "d'où L = 2λD/a"
      ],
      "bonne_reponse": [
        0,
        1,
        3,
        2,
        4
      ],
      "explication": "Le point clé est l'approximation des petits angles : sans elle, on ne peut pas relier θ = λ/a à la géométrie du montage.",
      "piege": "Poser la formule sans passer par tan θ ni par l'approximation : la démonstration est alors absente.",
      "image": "dif_montage.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-08",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Dans le triangle rectangle du montage, à quoi correspond le côté opposé à l'angle θ ?",
      "options": [
        "la distance D",
        "la largeur totale L de la tache",
        "la <b>demi</b>-largeur L/2 de la tache",
        "la largeur a de la fente"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L'angle θ est mesuré depuis l'axe : le côté opposé est la demi-largeur, d'où le facteur 2 dans la formule finale.",
      "piege": "Prendre L au lieu de L/2 : on perd alors le facteur 2.",
      "image": "dif_montage.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-09",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "λ = 650 nm, a = 80 μm, D = 2,0 m. Quelle est la largeur de la tache centrale ?",
      "options": [
        "1,6 cm",
        "3,3 mm",
        "6,5 cm",
        "3,3 cm"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "L = 2λD/a = 2 × 650×10⁻⁹ × 2,0 / 80×10⁻⁶ = 3,3×10⁻² m = 3,3 cm.",
      "piege": "Oublier le facteur 2 et trouver 1,6 cm : la tache centrale est deux fois plus large que les autres.",
      "image": "dif_montage.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "dif-10",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "On mesure L = 3,3 cm à D = 2,0 m avec λ = 650 nm. Quelle est la largeur a de la fente ?",
      "options": [
        "80 μm",
        "160 μm",
        "8,0 mm",
        "40 μm"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "a = 2λD/L = 2 × 650×10⁻⁹ × 2,0 / 3,3×10⁻² = 8,0×10⁻⁵ m = 80 μm.",
      "piege": "Mesurer une demi-largeur au lieu de la largeur totale, ou oublier de convertir les cm en mètres.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-11",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Avant tout calcul de diffraction, quel réflexe s'impose ?",
      "options": [
        "calculer d'abord l'interfrange",
        "convertir toutes les longueurs en mètres",
        "vérifier que D > 1 m",
        "convertir λ en micromètres"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "nm, μm, cm : les unités se mélangent dans ces énoncés. Une conversion oubliée fausse tout le résultat.",
      "piege": "Mener le calcul en unités mixtes et obtenir un résultat faux d'un facteur 1 000.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "dif-12",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Quelles conditions faut-il réunir pour observer des interférences ? <b>Plusieurs réponses.</b>",
      "options": [
        "une onde incidente issue d'une source unique",
        "deux ondes de même nature",
        "deux ondes de même fréquence",
        "deux sources de puissances égales"
      ],
      "bonne_reponse": [
        0,
        1,
        2
      ],
      "explication": "La condition discriminante est la <b>source unique</b> : elle rend les deux ondes cohérentes et synchrones.",
      "piege": "Oublier la source unique : c'est pourtant elle qui explique que deux lampes ne donnent jamais d'interférences.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-13",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Pourquoi deux lampes identiques ne produisent-elles jamais de franges ?",
      "options": [
        "parce qu'elles n'ont pas la même puissance",
        "parce que la lumière blanche n'interfère pas",
        "parce que leurs émissions ne sont pas synchronisées",
        "parce qu'elles sont trop éloignées"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Sans source unique, les ondes ne sont pas cohérentes : les figures se brouillent instantanément.",
      "piege": "Invoquer la puissance ou la distance, qui ne changent rien à la cohérence.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-14",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "L'interfrange i est :",
      "options": ["la distance entre les deux fentes du dispositif", "la distance entre le plan des fentes et l'écran", "la largeur d'une seule frange brillante de la figure", "la distance entre deux franges successives de même nature"],
      "bonne_reponse": [
        3
      ],
      "explication": "Deux franges successives de même nature : deux brillantes, ou deux sombres.",
      "piege": "Confondre i avec b, la distance entre les fentes.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-15",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Remets dans l'ordre la démonstration de i = λD/b :",
      "options": [
        "par définition, i = x_(k+1) − x<sub>k</sub>",
        "i = (k+1)·λD/b − k·λD/b = λD/b",
        "on isole : x<sub>k</sub> = k·λD/b",
        "interférences constructives : δ = k·λ",
        "or δ = b·x<sub>k</sub>/D, donc k·λ = b·x<sub>k</sub>/D"
      ],
      "bonne_reponse": [
        0,
        3,
        4,
        2,
        1
      ],
      "explication": "Le résultat ne dépend pas de k : c'est ce qui prouve que les franges sont régulièrement espacées.",
      "piege": "Poser la formule sans passer par δ = b·x/D : la démonstration attendue est perdue.",
      "image": "dif_young.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-16",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "Dans i = λD/b, que se passe-t-il si on <b>rapproche</b> les deux fentes ?",
      "options": [
        "l'interfrange augmente",
        "les franges disparaissent",
        "rien ne change",
        "l'interfrange diminue"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "b est au dénominateur : diminuer b augmente i, les franges s'écartent.",
      "piege": "Raisonner sur l'intensité lumineuse au lieu de lire la formule.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-17",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "λ = 633 nm, b = 0,50 mm, D = 2,0 m. Que vaut l'interfrange ?",
      "options": [
        "0,63 mm",
        "2,5 mm",
        "1,3 mm",
        "2,5 cm"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "i = λD/b = 633×10⁻⁹ × 2,0 / 0,50×10⁻³ = 2,5×10⁻³ m = 2,5 mm.",
      "piege": "Ajouter un facteur 2 par analogie avec la tache de diffraction : ici il n'y en a pas.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "dif-18",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Comment mesure-t-on correctement un interfrange sur une figure ?",
      "options": [
        "en comptant les franges sombres",
        "en mesurant la largeur de la tache centrale",
        "en mesurant plusieurs interfranges d'un coup, puis en divisant par leur nombre",
        "en mesurant une seule frange, le plus précisément possible"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L'interfrange est souvent très petit : en mesurer dix d'un coup divise l'erreur relative par dix.",
      "piege": "Mesurer une seule frange : l'incertitude devient énorme devant la valeur mesurée.",
      "image": "dif_franges.png",
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "dif-19",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 10",
      "enonce": "Dix interfranges consécutifs couvrent 2,4 cm. Que vaut l'interfrange ?",
      "options": [
        "2,4 cm",
        "24 mm",
        "0,24 mm",
        "2,4 mm"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "i = 2,4/10 = 0,24 cm = 2,4 mm.",
      "piege": "Se tromper d'un facteur 10 en oubliant de convertir les centimètres.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-20",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Pourquoi la mesure sur plusieurs interfranges est-elle plus juste ?",
      "options": ["parce que l'erreur relative est divisée par le nombre d'interfranges", "parce que le laser est instable, et que la moyenne le compense", "parce que les franges ne sont pas régulières près du centre", "parce que l'écran est courbe, et que l'écart varie avec x"],
      "bonne_reponse": [
        0
      ],
      "explication": "L'erreur absolue de lecture reste la même, mais elle porte sur une longueur bien plus grande.",
      "piege": "Justifier par une irrégularité des franges : elles sont au contraire parfaitement régulières.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-21",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 12",
      "enonce": "Une frange est <b>brillante</b> lorsque :",
      "options": [
        "δ = 0 uniquement",
        "δ = k·λ avec k entier",
        "δ = (k + ½)·λ",
        "δ = λ/2"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "δ multiple entier de λ : les ondes arrivent en phase, les interférences sont constructives.",
      "piege": "Confondre avec la condition des franges sombres, où le demi-entier apparaît.",
      "image": null,
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "dif-22",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 12",
      "enonce": "Quel est le réflexe pour déterminer la nature d'une frange en un point M ?",
      "options": [
        "mesurer son intensité",
        "mesurer la distance à la source",
        "calculer δ, puis diviser δ par λ",
        "compter les franges depuis le centre"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Si δ/λ tombe sur un entier, la frange est brillante ; sur un demi-entier, elle est sombre.",
      "piege": "Répondre sans passer par la différence de marche δ.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "dif-23",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 12",
      "enonce": "En un point M, δ = 1,90 μm avec λ = 633 nm. Quelle est la nature de la frange ?",
      "options": [
        "sombre, car δ/λ = 3,00",
        "brillante, car δ/λ = 2,50",
        "sombre, car δ/λ = 2,50",
        "brillante, car δ/λ = 3,00"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "δ/λ = 1,90×10⁻⁶ / 633×10⁻⁹ = 3,00 : un entier, donc interférences constructives, frange brillante.",
      "piege": "Se tromper de conversion entre μm et nm et tomber sur un demi-entier.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-24",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 12",
      "enonce": "Deux ondes en <b>opposition de phase</b> produisent :",
      "options": [
        "une frange brillante",
        "une frange deux fois plus large",
        "une frange sombre",
        "aucune frange"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Opposition de phase → interférences destructives → frange sombre, avec δ = (k + ½)·λ.",
      "piege": "Associer « opposition » à « annulation totale de la lumière » sur tout l'écran : seule cette frange est sombre.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-25",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 13",
      "enonce": "Au centre O de la figure d'interférences, que vaut la différence de marche δ ?",
      "options": [
        "λ/2",
        "0",
        "λ",
        "b·D"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Les deux trajets S₁O et S₂O ont la même longueur : δ = S₂O − S₁O = 0.",
      "piege": "Croire que δ vaut λ au centre parce que la frange y est brillante — c'est k = 0.",
      "image": "dif_franges.png",
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "dif-26",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 13",
      "enonce": "Remets dans l'ordre le raisonnement par l'absurde montrant que la frange centrale est brillante :",
      "options": [
        "or −½ n'est pas entier : l'hypothèse est rejetée",
        "hypothèse 2 — frange sombre : δ = (k + ½)·λ = 0, donc k = −½",
        "hypothèse 1 — frange brillante : δ = k·λ, donc k = 0, qui est bien entier",
        "au centre, les deux trajets sont égaux : δ = 0",
        "la frange centrale est donc brillante"
      ],
      "bonne_reponse": [
        3,
        2,
        1,
        0,
        4
      ],
      "explication": "Les deux hypothèses doivent être testées : c'est ce qui fait la rigueur du raisonnement par l'absurde.",
      "piege": "Conclure directement que la frange est brillante sans tester l'hypothèse contraire.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-27",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 13",
      "enonce": "Un élève écrit : « au centre δ = 0 donc la frange est sombre ». Où est l'erreur ?",
      "options": ["δ ne peut pas valoir 0 : les chemins sont toujours différents", "δ = 0 correspond à k = 0, un entier : la frange est brillante", "δ = 0 correspond à k = ½, un demi-entier : la frange est sombre", "il n'y a pas d'erreur : δ = 0 donne bien une frange sombre"],
      "bonne_reponse": [
        1
      ],
      "explication": "δ = 0 vérifie la condition δ = k·λ avec k = 0 : les interférences y sont constructives.",
      "piege": "Associer « zéro » à « rien », donc à l'obscurité — alors que c'est la frange la plus lumineuse.",
      "image": "dif_franges.png",
      "tags": [
        "reperage erreur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "dif-28",
      "chapitre": "diffraction-et-interferences",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Que devient la figure si on remplace le laser rouge par un laser vert, de plus courte longueur d'onde ?",
      "options": ["les franges s'écartent, car i = λD/b augmente", "la figure disparaît, car i = λD/b devient nul", "seule la couleur change, i = λD/b ne dépendant pas de λ", "les franges se resserrent, car i = λD/b diminue"],
      "bonne_reponse": [
        3
      ],
      "explication": "i est proportionnel à λ : une longueur d'onde plus courte donne un interfrange plus petit.",
      "piege": "Raisonner sur l'intensité perçue au lieu de lire la formule.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "dif-n1", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 3", "enonce": "Sur le graphe I = f(x) d'une figure de diffraction, la largeur L de la tache centrale se mesure :", "options": ["entre les deux premiers minima, de part et d'autre du maximum", "entre le maximum central et le premier minimum qui le suit", "entre les deux premiers maxima secondaires de la figure", "à mi-hauteur du pic central, entre ses deux flancs"], "bonne_reponse": [0], "explication": "La tache centrale s'étend d'un minimum nul à l'autre : L est la distance entre les <b>deux premiers minima</b>, encadrant le maximum.", "piege": "Ne mesurer qu'une demi-largeur : on obtient alors L/2 et un facteur deux d'erreur sur a.", "actif": true},
    {"ref": "dif-n2", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 5", "enonce": "On trace L en fonction de 1/a. Que vaut le coefficient directeur de la droite obtenue ?", "options": ["2λD", "λD", "2λ/D", "λ/(2D)"], "bonne_reponse": [0], "explication": "De L = 2λD/a on tire L = (2λD)·(1/a) : la pente vaut <b>2λD</b>. Elle donne λ si D est connue, ou D si λ l'est.", "piege": "Oublier le facteur 2 : c'est lui qui distingue la diffraction des interférences, où i = λD/b.", "actif": true},
    {"ref": "dif-n3", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 6", "enonce": "L'énoncé donne θ = f(a). Comment obtenir λ par une régression linéaire ?", "options": ["tracer θ en fonction de 1/a : la pente vaut λ", "tracer θ en fonction de a : la pente vaut λ", "tracer 1/θ en fonction de a : la pente vaut λ", "tracer θ² en fonction de a : la pente vaut λ"], "bonne_reponse": [0], "explication": "θ = λ/a n'est pas une fonction affine de a. En posant X = 1/a, on obtient θ = λ·X : la droite a pour pente <b>λ</b>.", "piege": "Tracer θ = f(a) et chercher une droite : on obtient une hyperbole, dont on ne tire rien.", "actif": true},
    {"ref": "dif-n4", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "On remplace une fente par une fente deux fois plus fine. Que devient la tache centrale ?", "options": ["deux fois plus large", "deux fois plus étroite", "inchangée", "quatre fois plus large"], "bonne_reponse": [0], "explication": "L = 2λD/a : L et a sont <b>inversement proportionnels</b>. Diviser a par deux multiplie L par deux.", "piege": "Croire qu'une fente plus fine donne une tache plus fine : c'est l'inverse, et c'est tout le paradoxe de la diffraction.", "actif": true},
    {"ref": "dif-n5", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 11", "enonce": "Sur le graphe I = f(x) d'une figure d'interférences, comment déterminer l'interfrange i ?", "options": ["repérer deux maxima éloignés, mesurer l'écart, diviser par leur nombre", "mesurer l'écart entre deux maxima voisins, puis le doubler", "mesurer la largeur d'un pic à mi-hauteur, qui vaut i", "mesurer l'écart entre un maximum et le minimum suivant"], "bonne_reponse": [0], "explication": "Mesurer <b>plusieurs interfranges d'un coup</b> puis diviser réduit l'erreur relative : sur un seul écart, l'incertitude de lecture serait énorme.", "piege": "Se contenter de deux maxima voisins : la mesure est juste dans son principe, mais bien trop imprécise.", "actif": true},
    {"ref": "diffraction-t01", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "La diffraction d'une onde par une ouverture est marquée lorsque :", "options": ["l'ouverture est beaucoup plus grande que la longueur d'onde", "l'ouverture est circulaire, quelle que soit la longueur d'onde", "l'onde est de forte intensité, quelle que soit l'ouverture", "l'ouverture est du même ordre que la longueur d'onde, ou plus petite"], "bonne_reponse": [3], "explication": "La diffraction est sensible quand a ≲ λ. Une fente de 0,1 mm diffracte un laser (λ ≈ 600 nm) ; une porte d'un mètre ne diffracte pas la lumière mais diffracte le son (λ ≈ 1 m).", "piege": "Croire que toute ouverture diffracte visiblement : c'est le RAPPORT a/λ qui décide.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t02", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "L'angle de diffraction vérifie θ = λ/a. Sur un écran à distance D, la tache centrale a pour largeur L. Comment obtient-on L = 2λD/a ?", "options": ["tan θ ≈ θ pour un petit angle, et L = D/θ, donc L = D·a/λ", "tan θ ≈ θ pour un petit angle, et L = D·θ, donc L = D·λ/a", "tan θ ≈ θ pour un petit angle, et L = a·θ, donc L = λ", "tan θ ≈ θ pour un petit angle, et L/2 = D·θ, donc L = 2·D·λ/a"], "bonne_reponse": [3], "explication": "La tache s'étend de −θ à +θ : sa demi-largeur est L/2 = D·tan θ ≈ D·θ. D'où L = 2Dθ = 2Dλ/a.", "piege": "Oublier le facteur 2 : θ n'est que le DEMI-angle, la tache est symétrique.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t03", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Sur le profil d'intensité I = f(x) d'une figure de diffraction, la largeur L de la tache centrale se mesure :", "options": ["entre les deux premiers minima, de part et d'autre du maximum central", "entre le maximum central et le premier minimum qui le suit", "entre deux maxima secondaires voisins de la figure", "à mi-hauteur du pic central, entre ses deux flancs"], "bonne_reponse": [0], "explication": "La tache centrale s'étend d'un minimum nul à l'autre : L est la distance entre les deux premiers minima qui encadrent le pic.", "piege": "Ne mesurer qu'une demi-largeur, ce qui donne L/2 et une erreur d'un facteur 2 sur a.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t04", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Un laser de λ = 650 nm éclaire une fente située à D = 2,00 m d'un écran. La tache centrale mesure L = 2,6 cm. La largeur de la fente est :", "options": ["a = L/(2·λ·D) = 2,6 × 10⁻² / (2 × 650 × 10⁻⁹ × 2,00) = 1,0 × 10⁴ m", "a = 2·λ·D/L = 2 × 650 × 10⁻⁹ × 2,00 / 2,6 × 10⁻² = 1,0 × 10⁻⁴ m", "a = 2·λ·L/D = 2 × 650 × 10⁻⁹ × 2,6 × 10⁻² / 2,00 = 1,7 × 10⁻⁸ m", "a = λ·D/L = 650 × 10⁻⁹ × 2,00 / 2,6 × 10⁻² = 5,0 × 10⁻⁵ m"], "bonne_reponse": [1], "explication": "On isole a dans L = 2λD/a : a = 2λD/L. Toutes les longueurs en mètres : λ = 650 × 10⁻⁹ m, L = 2,6 × 10⁻² m.", "piege": "Oublier le facteur 2, ou mélanger les unités — le nanomètre et le centimètre doivent tous deux passer en mètres.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t05", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "On trace L en fonction de 1/a et l'on obtient une droite passant par l'origine, de coefficient directeur k = 2,6 × 10⁻⁶ m². Avec D = 2,00 m, la longueur d'onde vaut :", "options": ["k = 1/(2·λ·D), donc λ = 1/(2·k·D) = 1/(2,08 × 10⁻⁵) = 1,0 × 10⁻⁵ m", "k = 2·λ·D, donc λ = k/(2·D) = 2,6 × 10⁻⁶ / 4,00 = 6,5 × 10⁻⁷ m", "k = λ, donc λ = k = 2,6 × 10⁻⁶ m, sans intervention de D", "k = λ·D, donc λ = k/D = 2,6 × 10⁻⁶ / 2,00 = 1,3 × 10⁻⁶ m"], "bonne_reponse": [1], "explication": "De L = (2λD)·(1/a), la pente de la droite L = f(1/a) est 2λD. On en tire λ = k/(2D).", "piege": "Oublier le facteur 2 dans la pente — c'est lui qui distingue la diffraction des interférences.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t06", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "On dispose des valeurs de θ pour plusieurs fentes de largeur a. Pour obtenir λ par une régression linéaire, on trace :", "options": ["θ en fonction de a² : la pente vaut λ", "1/θ en fonction de a : la pente vaut λ", "θ en fonction de a : la pente vaut λ", "θ en fonction de 1/a : la pente vaut λ"], "bonne_reponse": [3], "explication": "θ = λ/a n'est pas affine en a. En posant X = 1/a, on a θ = λ·X : droite passant par l'origine, de pente λ.", "piege": "Tracer θ = f(a) et chercher une droite : on obtient une hyperbole, dont on ne tire rien.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t07", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "On remplace la fente par une fente deux fois plus étroite. La tache centrale de diffraction devient :", "options": ["deux fois plus étroite", "deux fois plus large", "inchangée", "quatre fois plus large"], "bonne_reponse": [1], "explication": "L = 2λD/a : L et a sont inversement proportionnels. Diviser a par 2 multiplie L par 2.", "piege": "Croire qu'une fente plus fine donne une tache plus fine : c'est l'inverse, et c'est tout le paradoxe de la diffraction.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t08", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Deux ondes lumineuses donnent des interférences observables à condition qu'elles soient :", "options": ["de fréquences différentes", "de même fréquence et cohérentes, c'est-à-dire issues d'une même source", "issues de deux lampes distinctes de même couleur", "de même amplitude uniquement"], "bonne_reponse": [1], "explication": "Il faut la même fréquence ET une relation de phase constante — la cohérence. On l'obtient en divisant une source unique, jamais avec deux sources indépendantes.", "piege": "Croire que deux lampes identiques interfèrent : leurs phases sont aléatoires, la figure se brouille.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t09", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Deux fentes distantes de b éclairent un écran à distance D. Pour montrer que i = λD/b, on utilise la différence de marche δ. Une frange brillante correspond à :", "options": ["δ = λ/b avec b l'écart des fentes, d'où x_k = k·D/λ et i = D/λ", "δ = k·λ avec k entier, et δ ≈ b·x/D, d'où x_k = k·λ·D/b et i = λ·D/b", "δ = (k + ½)·λ avec k entier, et δ ≈ b·x/D, d'où i = λ·D/(2·b)", "δ = b·D/x avec x l'abscisse, d'où x_k = k·b·D/λ et i = λ·b/D"], "bonne_reponse": [1], "explication": "Frange brillante : δ = kλ. Avec δ ≈ b·x/D, les franges sont en x_k = kλD/b, séparées de i = λD/b.", "piege": "Prendre la condition des franges sombres, ou inverser b et D dans l'expression de δ.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t10", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "Sur une figure d'interférences, on mesure 12,0 mm entre le centre de la première frange brillante et le centre de la neuvième. L'interfrange vaut :", "options": ["i = 12,0/10 = 1,20 mm", "i = 12,0 mm", "i = 12,0/8 = 1,50 mm", "i = 12,0/9 = 1,33 mm"], "bonne_reponse": [2], "explication": "Entre la 1re et la 9e frange, il y a 8 interfranges, pas 9. Mesurer plusieurs interfranges puis diviser réduit l'erreur de lecture.", "piege": "Compter les franges au lieu des intervalles : n franges délimitent n − 1 interfranges.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t11", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 11", "enonce": "Sur le profil d'intensité I = f(x) d'une figure d'interférences, l'interfrange i correspond à :", "options": ["la hauteur d'un pic, mesurée depuis la ligne de base", "la largeur d'un pic à mi-hauteur, entre ses deux flancs", "la distance entre un maximum et le minimum qui le suit", "la distance entre deux maxima consécutifs, ou deux minima consécutifs"], "bonne_reponse": [3], "explication": "Les franges brillantes sont régulièrement espacées de i : on le lit entre deux maxima voisins. Pour plus de précision, on mesure plusieurs intervalles et on divise.", "piege": "Mesurer entre un maximum et un minimum, ce qui donne i/2.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t12", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 12", "enonce": "En un point de l'écran, la différence de marche vaut δ = 1,5 λ. La frange y est :", "options": ["brillante : δ > λ", "sombre : δ = (k + ½)λ avec k = 1, interférences destructives", "ni l'une ni l'autre : δ doit être entier", "brillante : δ est un multiple de λ"], "bonne_reponse": [1], "explication": "δ = 1,5λ = (1 + ½)λ : les deux ondes arrivent en opposition de phase, elles s'annulent. Frange sombre.", "piege": "Croire que δ doit être un entier : δ est une longueur, c'est δ/λ qui est entier ou demi-entier.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "diffraction-t13", "chapitre": "diffraction", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 13", "enonce": "Au centre de l'écran, à égale distance des deux fentes, la frange est brillante parce que :", "options": ["les deux fentes y envoient le maximum de lumière : δ vaut λ/2", "la différence de marche y est nulle : δ = 0 = 0 × λ, ondes en phase", "c'est le point le plus proche des deux fentes : δ vaut λ/4", "la différence de marche y vaut λ/2 : les ondes arrivent en phase"], "bonne_reponse": [1], "explication": "À égale distance des deux fentes, les deux chemins sont égaux : δ = 0. C'est un multiple de λ (k = 0), donc interférence constructive.", "piege": "Confondre brillance et proximité : c'est la différence de marche nulle qui fait la frange centrale, pas la distance aux fentes.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  lumiere: [
    {
      "ref": "lum-01",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "L'énergie d'un photon s'écrit :",
      "options": ["E = h·ν = h·c/λ", "E = h·ν = h·c·λ", "E = h/ν = h·λ/c", "E = ν/h = c/(h·λ)"],
      "bonne_reponse": [
        0
      ],
      "explication": "E = h·ν, et comme ν = c/λ, on a aussi E = h·c/λ, avec λ <b>en mètres</b>.",
      "piege": "Écrire E = h·λ : l'énergie doit augmenter quand λ diminue, pas l'inverse.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "lum-02",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Plus la longueur d'onde d'un photon est <b>petite</b> :",
      "options": [
        "moins il est énergétique",
        "plus il est énergétique",
        "son énergie ne change pas",
        "sa vitesse augmente"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "E = h·c/λ : λ au dénominateur. C'est ce qui explique la nocivité des UV face aux infrarouges.",
      "piege": "Raisonner en proportionnalité directe entre λ et E.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-03",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Un photon du domaine visible transporte une énergie de l'ordre de :",
      "options": [
        "2 à 3 meV",
        "2 à 3 J",
        "2 à 3 eV",
        "2 à 3 keV"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Ordre de grandeur à connaître : un photon visible vaut 2 à 3 eV, soit environ 4×10⁻¹⁹ J.",
      "piege": "Confondre eV et joule : 1 eV = 1,60×10⁻¹⁹ J, l'écart est de dix-neuf ordres de grandeur.",
      "image": null,
      "tags": [
        "ordre de grandeur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-04",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Les domaines spectraux se répartissent ainsi :",
      "options": [
        "λ &lt; 800 nm ultraviolet · λ > 800 nm visible",
        "λ &lt; 400 nm visible · 400–800 nm ultraviolet · λ > 800 nm infrarouge",
        "λ &lt; 400 nm infrarouge · 400–800 nm visible · λ > 800 nm ultraviolet",
        "λ &lt; 400 nm ultraviolet · 400–800 nm visible · λ > 800 nm infrarouge"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Sous 400 nm : ultraviolet, plus énergétique. Au-delà de 800 nm : infrarouge, moins énergétique.",
      "piege": "Inverser UV et IR — l'UV a la <b>petite</b> longueur d'onde, donc la grande énergie.",
      "image": null,
      "tags": [
        "ordre de grandeur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-05",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Dire que l'énergie d'un atome est <b>quantifiée</b> signifie que :",
      "options": [
        "elle ne peut prendre que certaines valeurs, les niveaux d'énergie",
        "elle est toujours positive",
        "elle augmente continûment avec la température",
        "elle peut prendre n'importe quelle valeur"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Un photon n'est absorbé ou émis que si son énergie correspond <b>exactement</b> à l'écart entre deux niveaux.",
      "piege": "Imaginer un continuum d'énergies : c'est justement ce que la quantification interdit.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-06",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Lors d'une <b>absorption</b> :",
      "options": [
        "l'entité descend vers un niveau plus bas",
        "le photon est absorbé et l'entité s'excite",
        "le photon traverse sans interagir",
        "le photon est émis et l'entité se désexcite"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le photon incident disparaît, l'entité monte vers un niveau plus élevé : E<sub>f</sub> − E<sub>i</sub> est positif.",
      "piege": "Inverser avec l'émission, où le photon apparaît et l'entité descend.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-07",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Avant d'appliquer E = h·c/λ avec λ donné en nanomètres, il faut :",
      "options": ["convertir E en eV, en divisant par 1,60 × 10⁻¹⁹", "diviser λ par c, pour obtenir une durée en secondes", "convertir λ en mètres, en multipliant par 10⁻⁹", "convertir λ en micromètres, en multipliant par 10⁻³"],
      "bonne_reponse": [
        2
      ],
      "explication": "Toutes les grandeurs doivent être dans le système international : λ en mètres.",
      "piege": "Mener le calcul avec λ en nanomètres : le résultat est faux de neuf ordres de grandeur.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "lum-08",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Quelle est l'énergie d'un photon de longueur d'onde λ = 500 nm ? (h = 6,63×10⁻³⁴ J·s, c = 3,00×10⁸ m·s⁻¹)",
      "options": [
        "4,0×10⁻¹² J",
        "3,98×10⁻²⁸ J",
        "1,99×10⁻²⁵ J",
        "3,98×10⁻¹⁹ J"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "E = 6,63×10⁻³⁴ × 3,00×10⁸ / 500×10⁻⁹ = 3,98×10⁻¹⁹ J.",
      "piege": "Oublier de convertir les nanomètres : on obtient alors 3,98×10⁻²⁸ J.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-09",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Un photon transporte une énergie de 3,98×10⁻¹⁹ J. Combien cela fait-il en électronvolts ? <i>Donnée : 1 eV = 1,60×10⁻¹⁹ J.</i>",
      "options": [
        "2,5 eV",
        "0,40 eV",
        "25 eV",
        "6,4×10⁻³⁸ eV"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "On divise par 1,60×10⁻¹⁹ : 3,98×10⁻¹⁹ / 1,60×10⁻¹⁹ = 2,5 eV — cohérent avec un photon visible.",
      "piege": "Multiplier au lieu de diviser : le sens de la conversion se contrôle sur l'ordre de grandeur attendu.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-10",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Un photon de longueur d'onde 250 nm appartient au domaine :",
      "options": [
        "infrarouge",
        "ultraviolet",
        "visible",
        "des rayons X"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "250 nm &lt; 400 nm : c'est de l'ultraviolet, plus énergétique que le visible.",
      "piege": "Le classer dans le visible parce que la valeur « paraît » proche de 400 nm.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-11",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La condition d'absorption ou d'émission d'un photon s'écrit :",
      "options": [
        "h·ν = E<sub>f</sub> + E<sub>i</sub>",
        "h·ν = c/λ",
        "h·ν = |E<sub>f</sub> − E<sub>i</sub>|",
        "h·ν = E<sub>f</sub> × E<sub>i</sub>"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le photon n'interagit que si son énergie vaut <b>exactement</b> l'écart entre les deux niveaux.",
      "piege": "Oublier la valeur absolue : l'énergie d'un photon est toujours positive.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "lum-12",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Remets dans l'ordre le calcul de la longueur d'onde d'une transition :",
      "options": [
        "convertir cet écart en joules (×1,60×10⁻¹⁹ si donné en eV)",
        "calculer l'écart |ΔE| entre les deux niveaux",
        "appliquer λ = h·c/|ΔE|",
        "conclure sur le domaine spectral, puis sur absorption ou émission"
      ],
      "bonne_reponse": [
        1,
        0,
        2,
        3
      ],
      "explication": "L'oubli de la conversion en joules est l'erreur qui coûte le plus de points sur ce chapitre.",
      "piege": "Appliquer λ = h·c/ΔE avec ΔE encore en électronvolts.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-13",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Un atome possède E₁ = −5,40 eV et E₂ = −3,00 eV. Quel est l'écart entre ces deux niveaux, en joules ? <i>Donnée : 1 eV = 1,60×10⁻¹⁹ J.</i>",
      "options": [
        "2,40 J",
        "1,50×10⁻¹⁹ J",
        "8,40 eV, soit 1,34×10⁻¹⁸ J",
        "2,40 eV, soit 3,84×10⁻¹⁹ J"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "ΔE = −3,00 − (−5,40) = 2,40 eV, puis ×1,60×10⁻¹⁹ = 3,84×10⁻¹⁹ J.",
      "piege": "Additionner les deux valeurs au lieu de les soustraire, à cause des signes négatifs.",
      "image": "lum_niveaux.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "lum-14",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Avec ΔE = 3,84×10⁻¹⁹ J, quelle est la longueur d'onde du photon ? <i>Données : h = 6,63×10⁻³⁴ J·s · c = 3,00×10⁸ m·s⁻¹.</i>",
      "options": [
        "518 nm, domaine visible",
        "518 m",
        "5,18×10⁻¹⁰ m, domaine des rayons X",
        "1,93×10⁶ nm"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "λ = 6,63×10⁻³⁴ × 3,00×10⁸ / 3,84×10⁻¹⁹ = 5,18×10⁻⁷ m = 518 nm : visible, dans le vert.",
      "piege": "Inverser le quotient et obtenir une longueur d'onde absurde.",
      "image": "lum_niveaux.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-15",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "L'atome passe du niveau 1 au niveau 2, plus élevé. Il s'agit :",
      "options": [
        "d'une émission, l'atome se désexcite",
        "d'une absorption, l'atome est excité",
        "d'un effet photoélectrique",
        "d'une ionisation"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Monter vers un niveau plus élevé exige de recevoir de l'énergie : c'est une absorption.",
      "piege": "Conclure d'après le signe de ΔE sans revenir au sens physique : on monte, donc on absorbe.",
      "image": "lum_niveaux.png",
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "lum-16",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "L'interaction <b>lumière-molécule</b> met en jeu :",
      "options": [
        "des transitions électroniques, domaine UV-visible",
        "l'extraction d'un électron, domaine UV",
        "des transitions de vibration des liaisons, domaine infrarouge",
        "la production d'un courant"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est la spectroscopie infrarouge : elle permet d'identifier les groupes caractéristiques.",
      "piege": "La confondre avec l'interaction lumière-atome, qui donne un spectre de raies dans l'UV-visible.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-17",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Quel est le réflexe pour identifier le type d'interaction en jeu ?",
      "options": [
        "regarder l'intensité du rayonnement",
        "calculer le rendement",
        "mesurer la vitesse des électrons",
        "lire le domaine spectral donné par l'énoncé"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "UV-visible → lumière-atome · infrarouge → lumière-molécule · UV le plus souvent → lumière-métal.",
      "piege": "Chercher la réponse dans l'intensité lumineuse, qui ne renseigne pas sur la nature de l'interaction.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "lum-18",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Un spectre de <b>raies</b> caractéristique d'un élément provient de :",
      "options": ["l'interaction lumière-atome, par transitions électroniques", "l'interaction lumière-molécule, par vibrations des liaisons", "l'effet photoélectrique, par arrachement d'électrons au métal", "l'effet photovoltaïque, par séparation des charges à la jonction"],
      "bonne_reponse": [
        0
      ],
      "explication": "Les niveaux électroniques étant propres à chaque élément, les raies constituent sa signature.",
      "piege": "L'attribuer aux vibrations moléculaires, qui donnent des bandes d'absorption en infrarouge.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-19",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "L'effet photoélectrique se produit si :",
      "options": [
        "λ ≥ λ<sub>S</sub>",
        "ν ≥ ν_S",
        "l'intensité lumineuse est suffisante",
        "ν ≤ ν_S"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L'énergie de <b>chaque</b> photon, h·ν, doit atteindre le travail d'extraction h·ν_S.",
      "piege": "Croire qu'augmenter l'intensité suffit : c'est le nombre de photons qui augmente, pas leur énergie.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-20",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Si l'énoncé donne une longueur d'onde seuil λ<sub>S</sub>, l'effet se produit si :",
      "options": [
        "quelle que soit λ",
        "λ ≥ λ<sub>S</sub>",
        "λ ≤ λ<sub>S</sub>",
        "λ = λ<sub>S</sub>"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "ν et λ sont inversement proportionnels : l'inégalité <b>s'inverse</b>. Une longueur d'onde plus petite, c'est un photon plus énergétique.",
      "piege": "Garder le sens de l'inégalité des fréquences — c'est le piège numéro un du chapitre.",
      "image": null,
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "lum-21",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Un métal a pour fréquence seuil ν<sub>S</sub> = 5,5×10¹⁴ Hz. On l'éclaire avec λ = 400 nm. L'effet se produit-il ? <i>Donnée : c = 3,00×10⁸ m·s⁻¹.</i>",
      "options": [
        "non, car 400 nm &lt; 545 nm",
        "oui, car ν = 7,5×10¹⁴ Hz > 5,5×10¹⁴ Hz",
        "non, car la fréquence est trop élevée",
        "impossible sans l'intensité lumineuse"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "ν = c/λ = 3,00×10⁸/400×10⁻⁹ = 7,5×10¹⁴ Hz, supérieure au seuil : l'effet se produit.",
      "piege": "Comparer les longueurs d'onde sans inverser l'inégalité, et conclure au contraire.",
      "image": "lum_photoelectrique.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-22",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "On éclaire un métal sous le seuil et on augmente fortement l'intensité lumineuse. Que se passe-t-il ?",
      "options": ["rien : c'est l'énergie de chaque photon qui compte, pas leur nombre", "le métal chauffe puis émet des électrons, l'énergie s'accumulant", "les électrons sortent plus lentement, l'énergie étant partagée", "l'effet finit par se produire, le seuil étant franchi en nombre"],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est précisément cette observation qui a imposé le modèle du photon.",
      "piege": "Raisonner en énergie totale reçue : chaque photon interagit individuellement avec un électron.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-23",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Le bilan d'énergie de l'effet photoélectrique s'écrit :",
      "options": [
        "h·ν = ½·m·v² − W<sub>ext</sub>",
        "h·ν = ½·m·v² + W<sub>ext</sub>",
        "h·ν = W<sub>ext</sub> − ½·m·v²",
        "h·ν = 2·m·v² + W<sub>ext</sub>"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L'énergie du photon sert d'abord à arracher l'électron (W<sub>ext</sub>), le reste part en énergie cinétique.",
      "piege": "Mettre un signe − : ce serait dire que l'extraction fournit de l'énergie.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-24",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre l'isolement de la vitesse d'éjection :",
      "options": [
        "h·ν = ½·m·v² + h·ν_S",
        "½·m·v² = h·(ν − ν_S)",
        "v = √( 2·h·(ν − ν_S)/m )",
        "v² = 2·h·(ν − ν_S)/m"
      ],
      "bonne_reponse": [
        0,
        1,
        3,
        2
      ],
      "explication": "On isole le terme cinétique, on factorise par h, on multiplie par 2, on divise par m, puis on prend la racine.",
      "piege": "Oublier le facteur 2 ou la racine carrée en isolant v.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-25",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Avec ν = 7,5×10¹⁴ Hz, ν_S = 5,5×10¹⁴ Hz et m = 9,11×10⁻³¹ kg, que vaut la vitesse d'éjection ?",
      "options": [
        "5,4×10⁸ m·s⁻¹",
        "1,3×10⁻¹⁹ m·s⁻¹",
        "5,4×10⁵ m·s⁻¹",
        "2,9×10¹¹ m·s⁻¹"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "E<sub>c</sub> = h·(ν − ν_S) = 1,33×10⁻¹⁹ J, puis v = √(2 × 1,33×10⁻¹⁹ / 9,11×10⁻³¹) = 5,4×10⁵ m·s⁻¹.",
      "piege": "Oublier la racine carrée et rendre v² à la place de v.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-26",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Comment contrôler la vraisemblance d'une vitesse d'éjection ?",
      "options": [
        "vérifier qu'elle dépasse la vitesse de la lumière",
        "vérifier qu'elle est négative",
        "vérifier qu'elle vaut quelques 10⁵ m·s⁻¹, soit moins de 1 % de c",
        "aucun contrôle n'est possible"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Quelques 10⁵ m·s⁻¹ : cohérent avec un traitement non relativiste. Au-delà de c, le calcul est faux.",
      "piege": "Ne pas contrôler et rendre une vitesse supérieure à celle de la lumière.",
      "image": null,
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-27",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Dans un semi-conducteur éclairé, un courant apparaît lorsque :",
      "options": [
        "h·ν ≥ E<sub>gap</sub>",
        "h·ν ≤ E<sub>gap</sub>",
        "le matériau est chauffé",
        "l'éclairement dépasse 1 000 W·m⁻²"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "L'électron franchit le gap et passe dans la bande de conduction : il devient mobile.",
      "piege": "Inverser l'inégalité : un photon moins énergétique que le gap traverse sans rien produire.",
      "image": null,
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "lum-28",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Un matériau dont les deux bandes sont <b>confondues</b> est :",
      "options": [
        "un semi-conducteur",
        "un conducteur",
        "un isolant",
        "un supraconducteur"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Gap très grand → isolant · gap petit → semi-conducteur · bandes confondues → conducteur.",
      "piege": "Confondre « gap petit » et « bandes confondues » : le semi-conducteur a besoin d'un photon, le conducteur non.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-29",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Pourquoi une cellule photovoltaïque n'exploite-t-elle pas tout le spectre solaire ?",
      "options": [
        "parce que la surface est trop petite",
        "parce que le soleil n'émet pas assez",
        "parce que les photons d'énergie inférieure au gap la traversent sans effet",
        "parce que le rendement est limité par la température"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Et pour ceux qui dépassent le gap, l'excédent d'énergie est dissipé en chaleur : deux pertes distinctes.",
      "piege": "Attribuer la perte au seul échauffement, en oubliant les photons trop peu énergétiques.",
      "image": "lum_bandes.png",
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-30",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "La puissance lumineuse reçue par une cellule s'écrit :",
      "options": [
        "P = E × S²",
        "P = E / S",
        "P = E + S",
        "P = E × S"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "E est un <b>éclairement</b>, en W·m⁻² : il faut le multiplier par la surface éclairée pour obtenir des watts.",
      "piege": "Confondre éclairement et puissance, et oublier de multiplier par la surface.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lum-31",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Une cellule de surface S = 1,6 m² reçoit un éclairement de 8,0×10² W·m⁻² et délivre 2,1×10² W. Quel est son rendement ?",
      "options": [
        "16 %",
        "1,6 %",
        "6,1 %",
        "160 %"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "P_lumineuse = 8,0×10² × 1,6 = 1,3×10³ W, puis η = 2,1×10² / 1,3×10³ = 0,16, soit 16 %.",
      "piege": "Oublier de multiplier l'éclairement par la surface, ou inverser le quotient.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "lum-32",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Un élève trouve un rendement de 6,2. Que faut-il en conclure ?",
      "options": ["la cellule est très performante : elle restitue plus qu'elle ne reçoit", "le quotient a été inversé : un rendement est toujours inférieur à 1", "le calcul est juste mais l'unité manque : il fallait écrire 6,2 W", "il faut convertir en pourcentage : le rendement vaut donc 620 %"],
      "bonne_reponse": [
        1
      ],
      "explication": "η = P_électrique/P_lumineuse est sans unité et toujours inférieur à 1. Ici, c'est 1/6,2 ≈ 0,16.",
      "piege": "Rendre un rendement supérieur à 1 sans réagir.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {
      "ref": "lum-33",
      "chapitre": "interaction-lumiere-matiere",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Quelles pertes expliquent qu'un rendement soit loin de 100 % ? <b>Plusieurs réponses.</b>",
      "options": [
        "les photons d'énergie inférieure au gap traversent sans effet",
        "les pertes par réflexion et par effet Joule",
        "la cellule renvoie une partie du courant vers le soleil",
        "l'excédent d'énergie au-delà du gap est dissipé en chaleur"
      ],
      "bonne_reponse": [
        0,
        1,
        3
      ],
      "explication": "Trois causes à citer : photons trop peu énergétiques, excédent thermique, pertes optiques et électriques.",
      "piege": "Inventer une perte sans fondement physique plutôt que de citer les trois causes de la fiche.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "lumiere-t01", "chapitre": "lumiere", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Un photon a une longueur d'onde λ = 500 nm. Son énergie vaut (h = 6,63 × 10⁻³⁴ J·s, c = 3,00 × 10⁸ m·s⁻¹) :", "options": ["E = h·c/λ = 6,63 × 10⁻³⁴ × 3,00 × 10⁸/(500 × 10⁻⁹) = 3,98 × 10⁻¹⁹ J", "E = h/λ = 6,63 × 10⁻³⁴/(500 × 10⁻⁹) = 1,3 × 10⁻²⁷ J", "E = h·λ/c = 6,63 × 10⁻³⁴ × 500 × 10⁻⁹/(3,00 × 10⁸) = 1,1 × 10⁻⁴⁸ J", "E = h·c·λ = 6,63 × 10⁻³⁴ × 3,00 × 10⁸ × 500 × 10⁻⁹ = 9,9 × 10⁻³² J"], "bonne_reponse": [0], "explication": "E = h·ν = h·c/λ. Avec λ en mètres : 500 nm = 5,00 × 10⁻⁷ m. 500 nm est dans le visible (400–800 nm). En eV : 3,98 × 10⁻¹⁹/1,60 × 10⁻¹⁹ = 2,5 eV.", "piege": "Laisser λ en nanomètres, ou multiplier par λ au lieu de diviser.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lumiere-t02", "chapitre": "lumiere", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un atome passe d'un niveau E₂ = −3,4 eV à E₁ = −13,6 eV. Le photon émis a pour longueur d'onde :", "options": ["ΔE = E₂ = 3,4 eV = 5,4 × 10⁻¹⁹ J, donc λ = h·c/ΔE = 3,7 × 10⁻⁷ m", "ΔE = E₁ = 13,6 eV = 2,2 × 10⁻¹⁸ J, donc λ = h·c/ΔE = 9,1 × 10⁻⁸ m", "ΔE = E₂ + E₁ = 17,0 eV = 2,7 × 10⁻¹⁸ J, donc λ = h·c/ΔE = 7,3 × 10⁻⁸ m", "ΔE = E₂ − E₁ = 10,2 eV = 1,63 × 10⁻¹⁸ J, donc λ = h·c/ΔE = 1,22 × 10⁻⁷ m"], "bonne_reponse": [3], "explication": "L'énergie du photon est la DIFFÉRENCE des niveaux : ΔE = |E₂ − E₁|. On convertit en joules (× 1,60 × 10⁻¹⁹), puis λ = hc/ΔE. 122 nm : UV.", "piege": "Prendre l'énergie d'un seul niveau : c'est l'écart entre les deux qui est libéré.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lumiere-t03", "chapitre": "lumiere", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "L'émission stimulée, à la base du laser, est le processus par lequel :", "options": ["un atome se désexcite seul et émet un photon, sans photon incident", "un photon incident provoque la désexcitation d'un atome, qui en émet un second", "un photon est diffusé par un atome, sans changer d'énergie ni de phase", "un atome absorbe un photon incident et passe à un niveau supérieur"], "bonne_reponse": [1], "explication": "Absorption : le photon disparaît, l'atome monte. Émission spontanée : l'atome descend seul, photon dans une direction aléatoire. Émission stimulée : un photon déclenche l'émission d'un jumeau — même fréquence, même direction, même phase.", "piege": "Confondre stimulée et spontanée : dans la stimulée, il y a un photon AVANT et deux APRÈS.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lumiere-t04", "chapitre": "lumiere", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Un métal a un travail d'extraction W₀ = 2,3 eV. Éclairé par des photons de 2,0 eV, il :", "options": ["émet des électrons de 0,3 eV : E_photon &lt; W₀, mais l'écart est faible", "émet des électrons si l'intensité est suffisante : E_photon &lt; W₀, mais le nombre compense", "n'émet aucun électron : E_photon &lt; W₀, quelle que soit l'intensité", "émet des électrons après un délai : E_photon &lt; W₀, mais l'énergie s'accumule"], "bonne_reponse": [2], "explication": "L'effet photoélectrique est un phénomène à seuil : chaque photon interagit avec un seul électron. Si E_photon &lt; W₀, aucun électron ne sort, même avec une lumière très intense.", "piege": "Croire que l'intensité compense : elle change le NOMBRE de photons, pas leur énergie individuelle.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lumiere-t05", "chapitre": "lumiere", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Un photon de 4,0 eV frappe un métal de travail d'extraction 2,3 eV. L'électron éjecté a une vitesse (m_e = 9,1 × 10⁻³¹ kg) :", "options": ["E_c = 4,0 eV = 6,4 × 10⁻¹⁹ J, donc v = √(2E_c/m_e) = 1,2 × 10⁶ m·s⁻¹", "E_c = 4,0 − 2,3 = 1,7 eV = 2,7 × 10⁻¹⁹ J, donc v = √(E_c/m_e) = 5,5 × 10⁵ m·s⁻¹", "E_c = 4,0 + 2,3 = 6,3 eV = 1,0 × 10⁻¹⁸ J, donc v = √(2E_c/m_e) = 1,5 × 10⁶ m·s⁻¹", "E_c = 4,0 − 2,3 = 1,7 eV = 2,7 × 10⁻¹⁹ J, donc v = √(2E_c/m_e) = 7,7 × 10⁵ m·s⁻¹"], "bonne_reponse": [3], "explication": "Conservation de l'énergie : E_photon = W₀ + E_c. L'énergie cinétique est le surplus. Puis E_c = ½m_ev², donc v = √(2E_c/m_e). Bien convertir les eV en joules.", "piege": "Oublier de soustraire W₀, ou le facteur 2 sous la racine.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lumiere-t06", "chapitre": "lumiere", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Dans une cellule photovoltaïque, la lumière produit un courant électrique parce que :", "options": ["la cellule chauffe sous l'effet du rayonnement, et la chaleur crée le courant", "les photons se transforment directement en électrons dans le semi-conducteur", "la lumière est réfléchie par la cellule, ce qui met les charges en mouvement", "les photons absorbés libèrent des électrons qu'une jonction sépare et met en mouvement"], "bonne_reponse": [3], "explication": "Un photon d'énergie suffisante libère un électron dans le semi-conducteur. La jonction entre deux zones crée un champ qui entraîne ces électrons : c'est le courant. Le photon disparaît, il ne devient pas électron.", "piege": "Invoquer la chaleur : c'est un effet PHOTOélectrique, pas thermique — la chaleur dégrade même le rendement.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lumiere-t07", "chapitre": "lumiere", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Une cellule de surface S = 0,50 m² reçoit un éclairement de 800 W·m⁻² et délivre une puissance électrique de 60 W. Son rendement vaut :", "options": ["η = 60/800 = 7,5 %, la surface n'intervenant pas dans le rendement", "η = 60 × 0,50/800 = 3,8 %, la puissance étant rapportée à la surface", "η = 800/60 = 13, l'éclairement étant rapporté à la puissance délivrée", "P_reçue = 800 × 0,50 = 400 W, donc η = 60/400 = 0,15, soit 15 %"], "bonne_reponse": [3], "explication": "Rendement = P_électrique/P_lumineuse reçue. La puissance reçue est l'éclairement fois la SURFACE : 400 W. η = 60/400 = 15 %.", "piege": "Diviser par l'éclairement sans multiplier par la surface : 800 W·m⁻² n'est pas une puissance.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  acidebase: [
    {
      "ref": "acb-01",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Selon Brønsted, un <b>acide</b> est une espèce capable de :",
      "options": [
        "céder un ou plusieurs protons H⁺",
        "libérer des ions HO⁻",
        "capter un ou plusieurs protons H⁺",
        "abaisser le pH d'une solution"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le mot qui rapporte le point est <b>proton</b> : la définition porte sur un transfert de H⁺.",
      "piege": "Définir par le pH plutôt que par le transfert de proton — c'est une conséquence, pas la définition.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "acb-02",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Selon Brønsted, une <b>base</b> est une espèce capable de :",
      "options": [
        "libérer des ions HO⁻ en solution",
        "capter un ou plusieurs protons H⁺",
        "céder un proton H⁺",
        "élever la température de la solution"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Base = capte le proton. C'est le pendant exact de la définition de l'acide.",
      "piege": "Définir la base par la libération d'ions hydroxyde : c'est la définition d'Arrhenius, pas celle de Brønsted.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-03",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Un élève définit : « un acide est une espèce dont le pH est inférieur à 7 ». Que faut-il corriger ?",
      "options": ["il fallait parler d'ions hydroxyde, et non de protons cédés", "il fallait dire inférieur à 14, borne haute de l'échelle", "la définition porte sur la capacité à céder un proton, pas sur le pH", "rien : un acide est bien une espèce dont le pH est inférieur à 7"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le pH décrit une solution, pas une espèce chimique. Brønsted définit l'acide par le transfert de H⁺.",
      "piege": "Confondre la propriété d'une solution et la définition d'une espèce.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-04",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La demi-équation acido-basique d'un couple AH/A⁻ s'écrit :",
      "options": [
        "AH + H⁺ = A⁻",
        "A⁻ = AH + H⁺",
        "AH = A⁻ + HO⁻",
        "AH = A⁻ + H⁺"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est cette demi-équation qui <b>définit</b> le couple, noté toujours dans l'ordre acide / base.",
      "piege": "Écrire la demi-équation dans le sens de la base : le couple se note AH/A⁻, l'acide d'abord.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "acb-05",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Quelle est la base conjuguée de l'acide éthanoïque CH₃COOH ?",
      "options": ["CH₃COO⁻, ion éthanoate", "CH₃CO⁻, ion éthanoyle", "CH₃COOH₂⁺, ion éthanoïque protoné", "CH₃OH, méthanol"],
      "bonne_reponse": [
        0
      ],
      "explication": "CH₃COOH = CH₃COO⁻ + H⁺ : la base conjuguée porte une charge négative de plus que l'acide.",
      "piege": "Oublier la charge de la base conjuguée — c'est l'erreur la plus fréquente de cette QT.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-06",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Quel est le couple associé à l'ion méthylammonium CH₃NH₃⁺ ?",
      "options": [
        "CH₃NH₃⁺ / CH₃NH₄²⁺",
        "CH₃NH₃⁺ / CH₃NH₂",
        "CH₃NH₃⁺ / CH₃NH⁻",
        "CH₃NH₂ / CH₃NH₃⁺"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "CH₃NH₃⁺ = CH₃NH₂ + H⁺ : l'acide d'abord, sa base conjuguée ensuite.",
      "piege": "Inverser l'ordre du couple : on écrit toujours acide / base.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-07",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "En passant de l'acide à sa base conjuguée, la charge :",
      "options": [
        "ne change pas",
        "est toujours nulle",
        "diminue d'une unité",
        "augmente d'une unité"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L'acide perd un H⁺, donc une charge positive : sa base conjuguée est plus négative d'une unité.",
      "piege": "Recopier la formule sans ajuster la charge : l'équation n'est alors pas équilibrée.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "acb-08",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Quelle est la base conjuguée de l'ion hydrogénocarbonate HCO₃⁻ ?",
      "options": [
        "H₂CO₃",
        "HCO₃²⁻",
        "CO₂",
        "CO₃²⁻"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "HCO₃⁻ = CO₃²⁻ + H⁺ : on retire un H⁺, la charge passe de −1 à −2.",
      "piege": "Donner H₂CO₃, qui est l'acide conjugué et non la base.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-09",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre l'écriture d'une équation de réaction acide-base :",
      "options": [
        "retourner celle de la base qui capte le proton",
        "identifier les deux couples et écrire leurs demi-équations",
        "vérifier la conservation des éléments et de la charge globale",
        "sommer les deux demi-équations : le proton se simplifie"
      ],
      "bonne_reponse": [
        1,
        0,
        3,
        2
      ],
      "explication": "L'étape 2 est celle qu'on oublie : sans elle, le H⁺ ne peut pas se simplifier.",
      "piege": "Sommer les deux demi-équations écrites dans le même sens : un H⁺ subsiste alors dans le bilan.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-10",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Dans l'équation bilan d'une réaction acide-base :",
      "options": [
        "le proton H⁺ ne doit pas figurer",
        "il faut ajouter de l'eau",
        "le proton H⁺ doit apparaître des deux côtés",
        "le proton H⁺ doit apparaître à gauche"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le proton est <b>échangé</b> d'un couple à l'autre : il ne peut pas rester libre dans le bilan.",
      "piege": "Laisser un H⁺ dans l'équation — c'est le signe qu'une demi-équation n'a pas été retournée.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-11",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Quelle est l'équation de la réaction entre l'acide éthanoïque CH₃COOH et la méthylamine CH₃NH₂ ?",
      "options": [
        "CH₃COO⁻ + CH₃NH₃⁺ → CH₃COOH + CH₃NH₂",
        "CH₃COOH + CH₃NH₂ → CH₃COO⁻ + CH₃NH₃⁺",
        "CH₃COOH + CH₃NH₃⁺ → CH₃COO⁻ + CH₃NH₂",
        "CH₃COOH + CH₃NH₂ → CH₃COO⁻ + CH₃NH₂ + H⁺"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L'acide du couple 1 cède son proton à la base du couple 2 : le H⁺ se simplifie dans la somme.",
      "piege": "Garder le H⁺ dans le bilan, ou faire réagir deux acides entre eux.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "acb-12",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Une réaction acide-base met toujours en jeu :",
      "options": ["un seul couple, dont l'acide et la base réagissent entre eux", "une base et de l'eau, l'eau jouant toujours le rôle d'acide", "l'acide d'un couple et la base d'un autre couple", "deux acides, chacun cédant un proton à l'autre"],
      "bonne_reponse": [
        2
      ],
      "explication": "Il faut quelqu'un pour céder le proton et quelqu'un pour le capter : deux couples différents.",
      "piege": "Faire réagir l'acide et la base du <b>même</b> couple : aucun transfert n'est alors possible.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "acb-13",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Après avoir écrit l'équation bilan, que doit-on vérifier ?",
      "options": [
        "que les deux couples ont le même pKa",
        "que le pH est inférieur à 7",
        "seulement le nombre d'atomes de carbone",
        "la conservation des éléments et de la charge globale"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Deux vérifications, systématiques : les éléments d'un côté et de l'autre, et la charge totale.",
      "piege": "Ne vérifier que les atomes en oubliant les charges, souvent déséquilibrées après un transfert.",
      "image": null,
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-14",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Sur une formule, le <b>caractère acide</b> se justifie par :",
      "options": ["une liaison polarisée entre H et un atome électronégatif, O ou N", "la présence d'un doublet non liant sur un atome O ou N", "une charge positive portée par la molécule entière", "la présence d'une double liaison C=O dans la molécule"],
      "bonne_reponse": [
        0
      ],
      "explication": "La rupture de cette liaison polarisée libère un proton : c'est ce qui rend l'espèce acide.",
      "piege": "Confondre avec le critère du caractère basique, qui repose sur les doublets non liants.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "acb-15",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Sur une formule, le <b>caractère basique</b> se justifie par :",
      "options": ["une liaison O—H polarisée, dont la rupture libère un proton", "un atome tel que O ou N portant un doublet non liant", "la présence d'un ion H⁺ déjà libre dans la molécule", "une chaîne carbonée longue, qui délocalise la charge"],
      "bonne_reponse": [
        1
      ],
      "explication": "Un doublet non liant peut capter un proton : c'est le critère du caractère basique.",
      "piege": "Confondre doublet non liant et liaison polarisée : deux critères différents, l'un pour la base, l'autre pour l'acide.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-16",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Pourquoi la méthylamine CH₃NH₂ est-elle une base ?",
      "options": ["parce qu'elle contient une liaison N—H polarisée, qui cède H⁺", "parce qu'elle contient des atomes d'hydrogène mobiles", "parce que l'azote porte un doublet non liant, capable de capter H⁺", "parce que son pH est supérieur à 7 en solution aqueuse"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le doublet non liant de l'azote accueille le proton : CH₃NH₂ + H⁺ → CH₃NH₃⁺.",
      "piege": "Invoquer les liaisons N—H : elles justifieraient un caractère acide, pas basique.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-17",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Pourquoi l'ion méthylammonium CH₃NH₃⁺ est-il un acide ?",
      "options": ["parce qu'il réagit avec les métaux en libérant du dihydrogène", "parce que l'azote porte un doublet non liant, capable de capter H⁺", "parce qu'il est chargé positivement, ce qui attire les électrons", "parce qu'il porte des liaisons N—H polarisées, qui libèrent H⁺"],
      "bonne_reponse": [
        3
      ],
      "explication": "L'azote étant bien plus électronégatif que l'hydrogène, la liaison N—H est polarisée et peut se rompre.",
      "piege": "Justifier par la charge : elle accompagne le caractère acide sans l'expliquer.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "acb-18",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Un élève écrit : « CH₃COOH est un acide parce que c'est un acide carboxylique ». Que manque-t-il ?",
      "options": ["le calcul du pH de la solution, seul à prouver le caractère acide", "la justification sur la formule : la liaison O—H polarisée libère H⁺", "le nom de la base conjuguée, sans lequel le couple n'existe pas", "rien : appartenir à la famille des acides carboxyliques suffit"],
      "bonne_reponse": [
        1
      ],
      "explication": "La question demande de justifier <b>à partir de la formule</b> : il faut nommer la liaison polarisée.",
      "piege": "Répondre « parce qu'elle est acide » sans regarder la formule — le piège explicitement listé dans la fiche.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-19",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Quels couples usuels faut-il savoir reconnaître ? <b>Plusieurs réponses.</b>",
      "options": ["R—OH / R—O⁺ et R—CHO / R—CHO⁻", "R—COOH / R—COO⁻", "H₃O⁺ / H₂O et H₂O / HO⁻", "R—NH₃⁺ / R—NH₂"],
      "bonne_reponse": [
        1,
        2,
        3
      ],
      "explication": "Acide carboxylique/carboxylate, alkylammonium/alkylamine, et les deux couples de l'eau.",
      "piege": "Inventer un couple à partir d'un alcool : ce n'est pas un couple usuel du programme.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-20",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Les deux couples acide-base de l'eau sont :",
      "options": [
        "H₃O⁺/HO⁻ et H₂O/H₂O",
        "H₃O⁺/H₂O et H₂O/HO⁻",
        "H₂O/H₃O⁺ et HO⁻/H₂O",
        "H₂O/H⁺ et HO⁻/H⁺"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Dans le premier, l'eau est la base ; dans le second, elle est l'acide. Chaque couple s'écrit acide / base.",
      "piege": "Inverser l'ordre à l'intérieur des couples.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-21",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Une espèce <b>amphotère</b> est une espèce qui :",
      "options": [
        "a un pH neutre",
        "ne réagit ni avec les acides ni avec les bases",
        "appartient à deux couples et peut jouer les deux rôles",
        "est toujours un solide"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L'eau appartient aux deux couples H₃O⁺/H₂O et H₂O/HO⁻ : elle est donc amphotère.",
      "piege": "Croire qu'amphotère signifie neutre : c'est une propriété de l'espèce, pas de la solution.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "acb-22",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Pour justifier que l'eau est amphotère, il faut :",
      "options": ["mesurer son pH, qui vaut 7 et prouve le double caractère", "calculer son pKa, dont la valeur intermédiaire suffit à conclure", "citer un seul de ses couples, avec sa demi-équation", "citer les deux couples, avec leurs demi-équations"],
      "bonne_reponse": [
        3
      ],
      "explication": "H₃O⁺ = H₂O + H⁺ et H₂O = HO⁻ + H⁺ : les deux demi-équations sont attendues.",
      "piege": "N'en citer qu'un seul — la justification exige les deux, c'est le piège de la fiche.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "acb-23",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Quelle conséquence du caractère amphotère de l'eau faut-il citer ?",
      "options": [
        "l'eau peut réagir sur elle-même : c'est l'autoprotolyse",
        "l'eau est un bon solvant",
        "l'eau a une masse molaire de 18 g·mol⁻¹",
        "l'eau conduit le courant"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est parce qu'elle est à la fois acide et base que l'eau peut réagir sur elle-même — au cœur du chapitre suivant.",
      "piege": "Citer une propriété physique sans lien avec le transfert de proton.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-24",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Dans le couple H₂O / HO⁻, l'eau joue le rôle :",
      "options": [
        "de solvant uniquement",
        "d'acide",
        "de base",
        "de catalyseur"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "H₂O = HO⁻ + H⁺ : l'eau cède un proton, elle est donc l'acide de ce couple.",
      "piege": "Se fier au fait que l'eau est « neutre » plutôt qu'à la position dans le couple.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-25",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Dans le couple H₃O⁺ / H₂O, l'eau joue le rôle :",
      "options": [
        "d'aucun des deux",
        "des deux à la fois",
        "de base",
        "d'acide"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "H₃O⁺ = H₂O + H⁺ : c'est l'ion oxonium qui cède le proton, l'eau est la base conjuguée.",
      "piege": "Confondre les deux couples : l'eau change de rôle de l'un à l'autre.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-26",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Une équation bilan comporte un H⁺ isolé à droite. Que faut-il en conclure ?",
      "options": ["il manque une molécule d'eau à gauche, pour équilibrer les charges", "une demi-équation n'a pas été retournée : le proton doit se simplifier", "c'est correct : le proton libre figure bien dans le bilan", "les deux couples sont identiques, d'où le proton en excès"],
      "bonne_reponse": [
        1
      ],
      "explication": "Le proton est échangé entre les deux couples : s'il subsiste, la somme a été mal faite.",
      "piege": "Laisser le H⁺ et poursuivre l'exercice : toute la suite en dépend.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {
      "ref": "acb-27",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Dans quel ordre écrit-on un couple acide-base ?",
      "options": [
        "acide / base",
        "base / acide",
        "dans l'ordre alphabétique",
        "du plus fort au plus faible"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Toujours acide / base — par exemple CH₃COOH / CH₃COO⁻.",
      "piege": "L'inverser : le piège explicitement listé dans le tableau des formulations.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-28",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "typologie",
      "enonce": "Parmi ces espèces, laquelle peut jouer le rôle d'acide <b>et</b> de base ?",
      "options": [
        "CH₃COO⁻",
        "H₂O",
        "CH₃NH₂",
        "CH₃COOH"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L'eau appartient à deux couples : elle est amphotère, contrairement aux trois autres espèces.",
      "piege": "Choisir l'acide éthanoïque parce qu'il « contient » de l'eau dans sa formule.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "acb-29",
      "chapitre": "reactions-acide-base",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Pour faire réagir l'acide AH₁ avec la base A₂⁻, quelle demi-équation faut-il retourner ?",
      "options": ["celle du couple 2, car A₂⁻ capte le proton", "celle du couple 1, car AH₁ capte le proton", "les deux, chaque espèce échangeant un proton", "aucune, les deux demi-équations s'additionnant telles quelles"],
      "bonne_reponse": [
        0
      ],
      "explication": "La base capte le proton : sa demi-équation s'écrit donc A₂⁻ + H⁺ = AH₂.",
      "piege": "Retourner celle de l'acide : le proton apparaît alors du mauvais côté.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "acidebase-t01", "chapitre": "acidebase", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Selon Brønsted, un acide est une espèce chimique :", "options": ["capable de céder un proton H⁺", "dont le pH est inférieur à 7", "capable de capter un proton H⁺", "qui contient de l'hydrogène"], "bonne_reponse": [0], "explication": "Acide de Brønsted : donneur de proton. Base : accepteur de proton. La définition porte sur l'échange de H⁺, pas sur le pH.", "piege": "Croire que toute espèce contenant H est un acide : CH₄ contient de l'hydrogène et n'en cède aucun.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "acidebase-t02", "chapitre": "acidebase", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "La demi-équation du couple NH₄⁺/NH₃ s'écrit :", "options": ["NH₄⁺ + H⁺ = NH₃", "NH₄⁺ + H₂O = NH₃ + H₃O⁺", "NH₃ = NH₄⁺ + H⁺", "NH₄⁺ = NH₃ + H⁺"], "bonne_reponse": [3], "explication": "Dans le couple AH/A⁻, l'acide est à gauche et cède un proton : AH = A⁻ + H⁺. L'ion ammonium NH₄⁺ est l'acide, l'ammoniac NH₃ la base.", "piege": "Écrire la réaction avec l'eau : ce n'est plus une demi-équation mais une équation complète.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "acidebase-t03", "chapitre": "acidebase", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "L'acide éthanoïque CH₃COOH réagit avec l'ion hydroxyde HO⁻. L'équation de la réaction est :", "options": ["CH₃COOH + H₂O → CH₃COO⁻ + HO⁻", "CH₃COO⁻ + HO⁻ → CH₃COOH + O²⁻", "CH₃COOH + HO⁻ → CH₃COO⁻ + H₃O⁺", "CH₃COOH + HO⁻ → CH₃COO⁻ + H₂O"], "bonne_reponse": [3], "explication": "L'acide cède H⁺ : CH₃COOH → CH₃COO⁻ + H⁺. La base le capte : HO⁻ + H⁺ → H₂O. On additionne, H⁺ disparaît.", "piege": "Faire apparaître H₃O⁺ à droite : c'est HO⁻ qui capte le proton, il devient H₂O.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "acidebase-t04", "chapitre": "acidebase", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "L'ion carbonate CO₃²⁻ est une base parce que :", "options": ["il peut capter un proton pour donner HCO₃⁻", "il porte une charge négative", "sa solution a un pH élevé", "il contient de l'oxygène"], "bonne_reponse": [0], "explication": "On justifie par la demi-équation : CO₃²⁻ + H⁺ = HCO₃⁻. L'ion carbonate accepte un proton, c'est une base au sens de Brønsted.", "piege": "Justifier par la charge ou le pH : seule la capacité à échanger un proton définit le caractère acide ou basique.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "acidebase-t05", "chapitre": "acidebase", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "L'eau est une espèce amphotère car elle appartient à deux couples :", "options": ["H₃O⁺/H₂O où elle est la base, et H₂O/HO⁻ où elle est l'acide", "H₂O/H₂ où elle est l'acide, et O₂/H₂O où elle est la base", "H₃O⁺/HO⁻ où elle est à la fois l'acide et la base du couple", "H₂O/H₃O⁺ où elle est l'acide, et HO⁻/H₂O où elle est la base"], "bonne_reponse": [0], "explication": "Dans H₃O⁺/H₂O, l'eau capte un proton : base. Dans H₂O/HO⁻, elle en cède un : acide. Une espèce à la fois acide et base est amphotère.", "piege": "Inverser l'ordre dans les couples : l'acide s'écrit toujours à gauche.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  forceacide: [
    {
      "ref": "for-01",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "L'équation de l'autoprotolyse de l'eau s'écrit :",
      "options": [
        "2 H₂O ⇌ H₃O⁺ + HO⁻",
        "H₂O ⇌ H₃O⁺ + HO⁻",
        "H₂O ⇌ H⁺ + HO⁻",
        "H₃O⁺ + HO⁻ ⇌ 2 H₂O"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "L'eau étant amphotère, elle réagit sur elle-même : une molécule cède le proton, l'autre le capte.",
      "piege": "N'écrire qu'une seule molécule d'eau à gauche : l'équation n'est alors pas équilibrée.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-02",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Le produit ionique de l'eau s'exprime :",
      "options": [
        "Ke = [H₃O⁺] + [HO⁻]",
        "Ke = [H₃O⁺] × [HO⁻] / (c⁰)²",
        "Ke = [H₂O]²",
        "Ke = [H₃O⁺] / [HO⁻]"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est la constante d'équilibre de l'autoprotolyse. Le c⁰ = 1 mol·L⁻¹ rend la constante sans unité.",
      "piege": "Oublier c⁰ : sans lui, la constante aurait une unité, ce qui est impossible.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "for-03",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "À 25 °C, le pKe vaut :",
      "options": [
        "0",
        "1,0×10⁻¹⁴",
        "14,0",
        "7,0"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "pKe = −log(Ke) = 14,0 à 25 °C, avec Ke = 1,0×10⁻¹⁴.",
      "piege": "Confondre pKe = 14,0 et Ke = 1,0×10⁻¹⁴, ou donner 7,0 qui est le pH de neutralité.",
      "image": null,
      "tags": [
        "ordre de grandeur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-04",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Une solution a [HO⁻] = 1,0×10⁻³ mol·L⁻¹ à 25 °C. Que vaut [H₃O⁺] ? <i>Donnée : K<sub>e</sub> = 1,0×10⁻¹⁴ à 25 °C.</i>",
      "options": [
        "1,0×10⁻³ mol·L⁻¹",
        "1,0×10⁻¹⁷ mol·L⁻¹",
        "1,0×10⁻⁷ mol·L⁻¹",
        "1,0×10⁻¹¹ mol·L⁻¹"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "[H₃O⁺] = Ke·(c⁰)²/[HO⁻] = 1,0×10⁻¹⁴/1,0×10⁻³ = 1,0×10⁻¹¹ mol·L⁻¹.",
      "piege": "Multiplier au lieu de diviser, ou oublier que le produit vaut 10⁻¹⁴.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-05",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Un acide est dit <b>fort</b> lorsque :",
      "options": [
        "sa réaction avec l'eau est totale",
        "sa concentration est élevée",
        "son pH est très bas",
        "son pKa est élevé"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "La force décrit le <b>caractère total ou non</b> de la réaction avec l'eau, jamais la concentration.",
      "piege": "Confondre acide fort et acide concentré : le piège numéro un du chapitre.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "for-06",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Le taux d'avancement final d'un acide s'écrit :",
      "options": [
        "τ = 10⁻ᵖᴴ × C",
        "τ = c⁰·10⁻ᵖᴴ / C",
        "τ = pH / C",
        "τ = C / (c⁰·10⁻ᵖᴴ)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "x<sub>max</sub> = C·V et x<sub>eq</sub> = c⁰·10⁻ᵖᴴ·V : le rapport donne τ = c⁰·10⁻ᵖᴴ/C.",
      "piege": "Inverser le quotient : le taux d'avancement ne peut jamais dépasser 1.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-07",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Si τ = 1, alors :",
      "options": ["le pKa vaut 7 : la réaction est totale dans les deux sens", "l'acide est faible : la réaction avec l'eau est limitée", "l'acide est fort : la réaction avec l'eau est totale", "la solution est neutre : autant d'ions H₃O⁺ que d'ions HO⁻"],
      "bonne_reponse": [
        2
      ],
      "explication": "τ = 1 signifie que tout l'acide a réagi : la transformation est totale, l'acide est fort. Si τ &lt; 1, il est faible.",
      "piege": "Conclure sur la concentration au lieu de la nature de la réaction.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "for-08",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Remets dans l'ordre la méthode « par le pH » pour trancher fort ou faible :",
      "options": [
        "on compare cette valeur au pH donné par l'énoncé",
        "on fait l'hypothèse que l'acide est fort",
        "on calcule le pH correspondant : pH = −log(C/c⁰)",
        "si les deux coïncident l'acide est fort, sinon il est faible"
      ],
      "bonne_reponse": [
        1,
        2,
        0,
        3
      ],
      "explication": "C'est un raisonnement par hypothèse : on suppose, on calcule, on compare, on tranche.",
      "piege": "Calculer le pH sans annoncer l'hypothèse : la conclusion n'a alors aucune valeur logique.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-09",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Une solution d'acide de concentration C = 1,0×10⁻² mol·L⁻¹ a un pH mesuré de 3,4. L'acide est-il fort ?",
      "options": ["oui : un acide fort donnerait pH = 3,4, c'est bien le cas", "non : un acide fort donnerait pH = 2,0, ce n'est pas le cas", "oui : un pH de 3,4 est inférieur à 7, donc l'acide est fort", "impossible à dire : il faudrait connaître le pKa du couple"],
      "bonne_reponse": [
        1
      ],
      "explication": "pH = −log(1,0×10⁻²) = 2,0. Le pH mesuré vaut 3,4, donc la réaction n'est pas totale : l'acide est faible.",
      "piege": "Conclure « fort » parce que le pH est acide : tout acide donne un pH inférieur à 7.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "for-10",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "La relation d'Henderson s'écrit :",
      "options": [
        "pH = pKa + log([A⁻]/[AH])",
        "pH = pKa × log([A⁻]/[AH])",
        "pH = pKa + log([AH]/[A⁻])",
        "pH = pKa − log([A⁻]/[AH])"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Elle vient de Ka = [A⁻][H₃O⁺]/([AH]·c⁰), auquel on applique −log en séparant les deux logarithmes.",
      "piege": "Inverser le rapport dans le logarithme : à pH > pKa, c'est la base qui prédomine.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "for-11",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre la démonstration de la relation d'Henderson :",
      "options": [
        "on sépare les deux logarithmes : pKa = −log([A⁻]/[AH]) − log([H₃O⁺]/c⁰)",
        "le second terme vaut pH, d'où pH = pKa + log([A⁻]/[AH])",
        "on applique −log aux deux membres",
        "on part de Ka = [A⁻]×[H₃O⁺] / ([AH]×c⁰)"
      ],
      "bonne_reponse": [
        3,
        2,
        0,
        1
      ],
      "explication": "L'étape 3, la séparation des logarithmes, est celle qui est notée.",
      "piege": "Sauter la séparation des logarithmes et « retrouver » la formule de mémoire.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-12",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Dans une solution où [A⁻] = [AH], le pH vaut :",
      "options": [
        "0",
        "pKa",
        "7,0",
        "pKe/2"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "log(1) = 0, donc pH = pKa. C'est le cas d'une solution tampon.",
      "piege": "Répondre 7,0 par réflexe : le pH d'une solution tampon vaut le pKa du couple, pas 7.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-13",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "On connaît [HO⁻] et on cherche le pH. Par quoi passe-t-on ?",
      "options": [
        "on applique directement pH = −log([HO⁻]/c⁰)",
        "on utilise la relation d'Henderson",
        "on passe par le produit ionique pour obtenir [H₃O⁺]",
        "on calcule le pKa"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "[H₃O⁺] = Ke·c⁰/[HO⁻], puis pH = −log([H₃O⁺]/c⁰). La définition du pH porte sur l'ion oxonium.",
      "piege": "Appliquer la définition du pH directement à [HO⁻] — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "for-14",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Une solution a [HO⁻] = 2,0×10⁻² mol·L⁻¹ à 25 °C. Que vaut son pH ? <i>Donnée : K<sub>e</sub> = 1,0×10⁻¹⁴ à 25 °C.</i>",
      "options": [
        "1,7",
        "7,0",
        "2,0",
        "12,3"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "[H₃O⁺] = 1,0×10⁻¹⁴/2,0×10⁻² = 5,0×10⁻¹³, puis pH = −log(5,0×10⁻¹³) = 12,3 : la solution est basique.",
      "piege": "Appliquer le −log à [HO⁻] et trouver 1,7 — un pH acide pour une solution basique.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-15",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Une solution est acide lorsque :",
      "options": [
        "[H₃O⁺] > [HO⁻]",
        "[H₃O⁺] &lt; [HO⁻]",
        "[H₃O⁺] = [HO⁻]",
        "[HO⁻] = 0"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est le point de départ de la démonstration montrant que pH &lt; 7 à 25 °C.",
      "piege": "Inverser l'inégalité : plus il y a d'ions oxonium, plus la solution est acide.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-16",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre la démonstration de pH &lt; 7 pour une solution acide :",
      "options": [
        "on part de [H₃O⁺] > [HO⁻]",
        "on applique −log : le sens de l'inégalité s'inverse, −2·log([H₃O⁺]) &lt; pKe",
        "donc pH &lt; pKe/2 = 7,0",
        "on multiplie les deux membres par [H₃O⁺] : [H₃O⁺]² > Ke"
      ],
      "bonne_reponse": [
        0,
        3,
        1,
        2
      ],
      "explication": "Le passage au logarithme <b>inverse</b> le sens de l'inégalité : c'est l'étape décisive.",
      "piege": "Garder le même sens d'inégalité en passant au −log, et conclure pH > 7.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-17",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Pourquoi le sens de l'inégalité change-t-il lors du passage à −log ?",
      "options": [
        "parce que le logarithme est négatif",
        "parce que la fonction −log est décroissante",
        "parce que Ke est très petit",
        "parce qu'on divise par 2"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Multiplier par −1 inverse toujours une inégalité : la fonction −log est décroissante.",
      "piege": "Oublier cette inversion : c'est l'erreur listée dans le tableau des pièges.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-18",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Pour exprimer [H₃O⁺] à partir de Ka et de C, on commence par :",
      "options": [
        "mesurer le pH",
        "appliquer la relation d'Henderson",
        "dresser le tableau d'avancement de l'hydrolyse",
        "calculer le pKe"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le tableau donne [A⁻] = [H₃O⁺] et [AH] = C − [H₃O⁺], que l'on reporte ensuite dans Ka.",
      "piege": "Vouloir appliquer Henderson : elle donne un rapport, pas une concentration.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-19",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "En reportant dans Ka, on obtient une équation :",
      "options": [
        "du premier degré en [H₃O⁺]",
        "exponentielle",
        "logarithmique",
        "du second degré en [H₃O⁺]"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "[H₃O⁺]² + Ka·c⁰·[H₃O⁺] − Ka·C·c⁰ = 0 : on calcule Δ et on garde la racine positive.",
      "piege": "Chercher à isoler [H₃O⁺] directement : le terme au carré l'en empêche.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "for-20",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Après résolution, quelle racine faut-il conserver ?",
      "options": ["la racine positive, la seule qui ait un sens physique", "la racine négative, seule compatible avec une disparition", "la plus grande en valeur absolue, la plus proche de C", "la moyenne des deux, l'équilibre se plaçant entre elles"],
      "bonne_reponse": [
        0
      ],
      "explication": "Une concentration ne peut pas être négative : la racine négative est écartée, et on le dit.",
      "piege": "Garder la racine négative sans réagir — piège explicitement listé dans la fiche.",
      "image": null,
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-21",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Le rapport [A⁻]/[AH] vaut :",
      "options": [
        "10^(pH + pKa)",
        "10^(pH − pKa)",
        "pH − pKa",
        "10^(pKa − pH)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "On part de Ka, on remplace Ka = 10^(−pKa) et [H₃O⁺]/c⁰ = 10^(−pH) : les c⁰ se simplifient.",
      "piege": "Inverser l'exposant : c'est pH − pKa, pas pKa − pH.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-22",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Pour un couple de pKa = 4,8 dans une solution à pH = 6,8, que vaut [A⁻]/[AH] ?",
      "options": [
        "0,01",
        "2,0",
        "100",
        "10"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "10^(6,8 − 4,8) = 10² = 100 : la base est cent fois plus concentrée que l'acide, cohérent avec pH > pKa.",
      "piege": "Inverser l'exposant et trouver 0,01, ce qui ferait prédominer l'acide à pH élevé.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-23",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Pour établir [AH]/C × 100 = 100/(1 + 10^(pH − pKa)), on combine la QT 7 avec :",
      "options": ["le produit ionique de l'eau : Ke = [H₃O⁺]·[HO⁻] = 10⁻¹⁴", "la définition du taux d'avancement : τ = x_f/x_max", "la relation d'Henderson : pH = pKa + log([A⁻]/[AH])", "le tableau d'avancement, qui donne [AH] = C − [A⁻]"],
      "bonne_reponse": [
        3
      ],
      "explication": "La somme des deux formes vaut C : c'est ce qui permet de factoriser [AH](1 + 10^(pH − pKa)) = C.",
      "piege": "Oublier que [AH] + [A⁻] = C — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "actif": true
    },
    {
      "ref": "for-24",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "À pH = pKa, quel pourcentage de la forme acide subsiste ?",
      "options": [
        "50 %",
        "25 %",
        "100 %",
        "0 %"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "10⁰ = 1, donc 100/(1 + 1) = 50 %. Les deux formes sont en proportions égales.",
      "piege": "Répondre 100 % en pensant que le pKa marque le début de la dissociation.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "for-25",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "En fonction du taux d'avancement τ, la constante d'acidité s'écrit :",
      "options": [
        "Ka = τ / (C·(1 − τ))",
        "Ka = C·τ² / ((1 − τ)·c⁰)",
        "Ka = C·τ / (1 − τ)",
        "Ka = τ² / ((1 − τ)·c⁰)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "[A⁻] = [H₃O⁺] = τ·C et [AH] = C(1 − τ) : en reportant, Ka = C·τ²/((1 − τ)·c⁰).",
      "piege": "Oublier le facteur C au numérateur en simplifiant trop vite.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-26",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Le taux d'avancement final est défini par τ = x<sub>eq</sub>/x<sub>max</sub>, avec x<sub>max</sub> = C·V. Que vaut x<sub>eq</sub> en fonction de τ ?",
      "options": [
        "x<sub>eq</sub> = τ / (C·V)",
        "x<sub>eq</sub> = C·V / τ",
        "x<sub>eq</sub> = τ·C·V",
        "x<sub>eq</sub> = τ + C·V"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Par définition τ = x<sub>eq</sub>/x<sub>max</sub> avec x<sub>max</sub> = C·V, donc x<sub>eq</sub> = τ·C·V.",
      "piege": "Inverser le rapport de définition du taux d'avancement.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-27",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Sur un diagramme de prédominance, si pH &lt; pKa alors :",
      "options": [
        "[AH] = [A⁻]",
        "A⁻ prédomine",
        "AH prédomine",
        "aucune espèce ne prédomine"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "À pH faible, le milieu est riche en protons : la forme acide AH prédomine.",
      "piege": "Inverser la lecture du diagramme — le repère : à pH élevé, c'est la base qui domine.",
      "image": "for_predominance.png",
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-28",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Un acide est d'autant plus <b>fort</b> que son pKa est :",
      "options": [
        "faible",
        "proche de 7",
        "élevé",
        "égal au pKe"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Et une base est d'autant plus forte que le pKa de son couple est élevé. Phrase à replacer dès qu'on classe des acides.",
      "piege": "Inverser la règle : un pKa élevé caractérise une base forte, pas un acide fort.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-29",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Sur un diagramme de <b>distribution</b>, où lit-on le pKa ?",
      "options": [
        "à l'origine",
        "à l'intersection des deux courbes",
        "au maximum d'une courbe",
        "au point d'inflexion"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "En ce point [A⁻] = [AH], donc d'après Henderson pH = pKa + log(1) = pKa : on lit l'abscisse.",
      "piege": "Lire le pKa au maximum d'une courbe — le piège explicitement cité dans la fiche.",
      "image": "for_distribution_nu.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-30",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 10",
      "enonce": "Un diacide AH₂ a pKa₁ = 2,1 et pKa₂ = 7,2. Quelle espèce prédomine à pH = 5,0 ?",
      "options": [
        "AH₂",
        "A²⁻",
        "AH⁻",
        "les trois en proportions égales"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "5,0 est compris entre pKa₁ et pKa₂ : c'est la forme intermédiaire AH⁻ qui prédomine.",
      "piege": "Se tromper de zone : le diagramme se lit de gauche à droite en pH croissant.",
      "image": "for_predominance.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-31",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Le pH d'une solution <b>tampon</b> :",
      "options": ["augmente avec la dilution, la concentration en H₃O⁺ diminuant", "vaut pKe/2, soit 7,0, quelles que soient les espèces présentes", "vaut toujours 7,0, le tampon compensant tout écart à la neutralité", "ne varie pas ou peu par ajout modéré d'acide ou par dilution"],
      "bonne_reponse": [
        3
      ],
      "explication": "Dans une solution tampon [A⁻] = [AH], donc pH = pKa.",
      "piege": "Croire qu'une solution tampon est neutre : son pH vaut le pKa du couple.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "for-32",
      "chapitre": "force-d-un-acide",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Un élève annonce un taux d'avancement τ = 1,4. Que faut-il en conclure ?",
      "options": ["le calcul est faux : τ ne peut pas dépasser 1", "le pKa est négatif : τ dépasse alors 1", "la solution est concentrée : τ croît avec C", "l'acide est très fort : τ dépasse alors 1"],
      "bonne_reponse": [
        0
      ],
      "explication": "τ = x<sub>eq</sub>/x<sub>max</sub> est un rapport à un maximum : il est nécessairement compris entre 0 et 1.",
      "piege": "Accepter une valeur supérieure à 1 sans réagir — souvent le signe d'un quotient inversé.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {"ref": "forceacide-t01", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "L'autoprotolyse de l'eau s'écrit 2 H₂O = H₃O⁺ + HO⁻. Son produit ionique est :", "options": ["Ke = [H₃O⁺]·[HO⁻] = 10⁻¹⁴ à 25 °C", "Ke = [H₃O⁺]/[HO⁻]", "Ke = [H₃O⁺]·[HO⁻]/[H₂O]²", "Ke = [H₃O⁺] + [HO⁻]"], "bonne_reponse": [0], "explication": "Ke est la constante d'équilibre de l'autoprotolyse : produit des concentrations des ions, sans l'eau qui est le solvant. Ke = 10⁻¹⁴ à 25 °C, d'où pKe = 14.", "piege": "Faire apparaître [H₂O] : le solvant n'intervient jamais dans une constante d'équilibre.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t02", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Une solution d'acide de concentration C = 1,0 × 10⁻² mol·L⁻¹ a un pH de 3,4. Cet acide est :", "options": ["faible : pH = 3,4 > −log C = 2,0, la réaction n'est pas totale", "fort : pH = 3,4 &lt; 7, la réaction avec l'eau est donc totale", "faible : sa concentration est faible, la réaction est limitée", "fort : pH = 3,4 = −log C = 2,0, la réaction est donc totale"], "bonne_reponse": [0], "explication": "Pour un acide fort, pH = −log C = 2,0. Ici pH = 3,4 > 2,0 : il y a moins de H₃O⁺ que d'acide apporté, la réaction est limitée. Acide faible.", "piege": "Juger par la concentration ou par pH &lt; 7 : c'est la comparaison entre pH et −log C qui décide.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t03", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "À partir de Ka = [A⁻]·[H₃O⁺]/[AH], on prend le logarithme et l'on obtient :", "options": ["pH = pKa + log([A⁻]/[AH])", "pH = pKa + log([AH]/[A⁻])", "pH = pKa × [A⁻]/[AH]", "pH = pKa − log([A⁻]/[AH])"], "bonne_reponse": [0], "explication": "log Ka = log[H₃O⁺] + log([A⁻]/[AH]). Avec pKa = −log Ka et pH = −log[H₃O⁺] : −pKa = −pH + log([A⁻]/[AH]), soit pH = pKa + log([A⁻]/[AH]).", "piege": "Inverser le rapport : c'est la base A⁻ au numérateur — plus il y a de base, plus le pH est élevé.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t04", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Une solution contient [HO⁻] = 1,0 × 10⁻³ mol·L⁻¹. À 25 °C, son pH vaut :", "options": ["pH = −log[HO⁻] = 3", "pH = 14 − 3 = 11, donc [H₃O⁺] = 10⁻³", "[H₃O⁺] = Ke/[HO⁻] = 10⁻¹¹ mol·L⁻¹, donc pH = 11", "pH = 3, car [HO⁻] = 10⁻³"], "bonne_reponse": [2], "explication": "On passe par Ke : [H₃O⁺] = Ke/[HO⁻] = 10⁻¹⁴/10⁻³ = 10⁻¹¹. Puis pH = −log(10⁻¹¹) = 11. Raccourci : pH = pKe − pOH = 14 − 3.", "piege": "Prendre −log[HO⁻] pour le pH : ça donne le pOH, pas le pH.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t05", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Une solution est acide si [H₃O⁺] > [HO⁻]. Avec Ke = [H₃O⁺]·[HO⁻] = 10⁻¹⁴, on en déduit :", "options": ["[H₃O⁺]² > Ke, donc [H₃O⁺] > 10⁻⁷, donc pH &lt; 7", "[H₃O⁺]² &lt; Ke, donc [H₃O⁺] &lt; 10⁻⁷, donc pH > 7", "[HO⁻]² > Ke, donc [HO⁻] > 10⁻⁷, donc pH &lt; 7", "[H₃O⁺]² = Ke, donc [H₃O⁺] = 10⁻⁷, donc pH = 7"], "bonne_reponse": [0], "explication": "[HO⁻] = Ke/[H₃O⁺]. La condition [H₃O⁺] > [HO⁻] devient [H₃O⁺] > Ke/[H₃O⁺], soit [H₃O⁺]² > Ke = 10⁻¹⁴, donc [H₃O⁺] > 10⁻⁷, et pH = −log[H₃O⁺] &lt; 7.", "piege": "Se tromper de sens : plus [H₃O⁺] est grande, plus le pH est PETIT — le logarithme change le sens de l'inégalité.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t06", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Un acide faible AH de concentration C et de constante Ka réagit peu avec l'eau. En notant x = [H₃O⁺] = [A⁻] et [AH] ≈ C, on a :", "options": ["Ka = x/C, donc x = Ka·C", "Ka = C/x², donc x = √(C/Ka)", "Ka = x²/C, donc x = √(Ka·C)", "Ka = x², donc x = √Ka"], "bonne_reponse": [2], "explication": "Ka = [A⁻][H₃O⁺]/[AH] = x·x/C = x²/C. On isole x = √(Ka·C). L'approximation [AH] ≈ C vaut si l'acide est peu dissocié.", "piege": "Oublier le carré : les deux concentrations x et x se multiplient au numérateur.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t07", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "De pH = pKa + log([A⁻]/[AH]), on tire :", "options": ["log([A⁻]/[AH]) = (pH − pKa)/10, donc [A⁻]/[AH] = (pH − pKa)/10", "log([A⁻]/[AH]) = pH − pKa, donc [A⁻]/[AH] = 10^(pH − pKa)", "log([A⁻]/[AH]) = pKa − pH, donc [A⁻]/[AH] = 10^(pKa − pH)", "log([A⁻]/[AH]) = pH − pKa, donc [A⁻]/[AH] = pH − pKa"], "bonne_reponse": [1], "explication": "On isole le logarithme, puis on applique 10^ des deux côtés. Si pH > pKa, le rapport dépasse 1 : la base prédomine.", "piege": "Oublier de « défaire » le logarithme : pH − pKa est un log, il faut 10^ pour retrouver le rapport.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t08", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Avec C = [AH] + [A⁻] et [A⁻]/[AH] = 10^(pH − pKa) = r, le pourcentage d'acide vaut :", "options": ["[AH]/C = [AH]/(r·[AH]) = 1/r, soit 100/10^(pH − pKa) en %", "[AH]/C = [AH]/([AH] + r·[AH]) = 1/(1 + r), soit 100/(1 + 10^(pH − pKa)) en %", "[AH]/C = r·[AH]/([AH] + r·[AH]) = r/(1 + r), soit 100·r/(1 + r) en %", "[AH]/C = ([AH] − r·[AH])/[AH] = 1 − r, soit 100(1 − r) en %"], "bonne_reponse": [1], "explication": "[A⁻] = r·[AH]. Donc C = [AH](1 + r), et [AH]/C = 1/(1 + r). En pourcentage : 100/(1 + 10^(pH − pKa)). C'est la formule du diagramme de distribution.", "piege": "Intervertir numérateur et dénominateur : r/(1 + r) est le pourcentage de BASE, pas d'acide.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t09", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Un acide AH de concentration C a un taux d'avancement final τ. À l'état final, [A⁻] = [H₃O⁺] = τ·C et [AH] = C(1 − τ). Alors :", "options": ["Ka = (τ)²/(1 − τ) = τ²/(1 − τ), la concentration se simplifiant", "Ka = (τ·C)²/(C(1 − τ)) = C·τ²/(1 − τ)", "Ka = (τ·C)/(C(1 − τ))² = C·τ/(1 − τ)², le dénominateur au carré", "Ka = (τ·C)/(C(1 − τ)) = τ·C/(1 − τ), sans élever au carré"], "bonne_reponse": [1], "explication": "Ka = [A⁻][H₃O⁺]/[AH] = (τC)(τC)/(C(1 − τ)) = C·τ²/(1 − τ). Un acide fort a τ = 1 ; un acide faible, τ ≪ 1.", "piege": "Oublier un facteur C : il y en a deux au numérateur et un au dénominateur, il en reste un.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "forceacide-t10", "chapitre": "forceacide", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "Le couple acide/base a un pKa de 4,8. À pH = 6,8, l'espèce qui prédomine est :", "options": ["aucune : pH − pKa = 2, écart trop grand pour qu'une espèce domine", "l'acide AH : pH > pKa, et pH − pKa = 2 donne [AH]/[A⁻] = 100", "les deux à parts égales : pH − pKa = 2 donne [A⁻]/[AH] = 1", "la base A⁻ : pH > pKa, et pH − pKa = 2 donne [A⁻]/[AH] = 100"], "bonne_reponse": [3], "explication": "pH > pKa : la base prédomine. Deux unités au-dessus du pKa, elle est 100 fois plus abondante que l'acide.", "piege": "Croire que « pH élevé » signifie « acide » : au-dessus du pKa, c'est la base qui domine.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  cinetique: [
    {
      "ref": "cin-01",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Une transformation est dite <b>lente</b> lorsque :",
      "options": [
        "tout changement du milieu réactionnel est visible à l'œil nu",
        "la constante de vitesse k est très grande",
        "le temps de demi-réaction est inférieur à la seconde",
        "aucun changement du milieu réactionnel n'est visible à l'œil nu"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Une transformation est lente si l'évolution du milieu réactionnel est <b>visible à l'œil nu</b> ; elle est rapide dans le cas contraire.",
      "piege": "Croire que « lente » signifie invisible : c'est l'inverse.",
      "image": null,
      "tags": [
        "definitions"
      ],
      "actif": true
    },
    {
      "ref": "cin-02",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Quels sont les <b>facteurs cinétiques</b> au programme ?",
      "options": [
        "la concentration initiale des réactifs",
        "la masse molaire des réactifs",
        "le volume du bécher utilisé",
        "la température du milieu réactionnel"
      ],
      "bonne_reponse": [
        0,
        3
      ],
      "explication": "Deux facteurs cinétiques : plus la <b>température</b> est élevée, plus la réaction est rapide ; plus la <b>concentration initiale des réactifs</b> est élevée, plus la réaction est rapide.",
      "piege": "Ajouter le catalyseur à la liste : il accélère la réaction mais n'est pas un facteur cinétique.",
      "image": null,
      "tags": [
        "facteurs cinetiques"
      ],
      "actif": true
    },
    {
      "ref": "cin-03",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Un catalyseur est une espèce qui :",
      "options": [
        "déplace l'équilibre dans le sens direct",
        "augmente la vitesse de réaction sans participer au bilan",
        "augmente la quantité de produit formé à l'état final",
        "est consommé en quantité stœchiométrique"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le catalyseur <b>augmente la vitesse</b> de la réaction et <b>n'apparaît pas dans le bilan</b> : il est consommé à une étape puis régénéré à une autre.",
      "piege": "Croire qu'un catalyseur augmente le rendement : il n'agit que sur la vitesse.",
      "image": null,
      "tags": [
        "catalyse"
      ],
      "actif": true
    },
    {
      "ref": "cin-04",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La vitesse de <b>consommation</b> d'un réactif R s'écrit :",
      "options": [
        "v = + d[P]/dt",
        "v = + d[R]/dt",
        "v = − d[R]/dt",
        "v = k/[R]"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le signe − rend la vitesse <b>positive</b>, puisque la concentration du réactif diminue au cours du temps. Pour un produit, la vitesse de formation s'écrit v = + d[P]/dt.",
      "piege": "Oublier le signe − et obtenir une vitesse négative.",
      "image": null,
      "tags": [
        "definitions"
      ],
      "actif": true
    },
    {
      "ref": "cin-05",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Pour une cinétique d'<b>ordre 1</b>, la loi de vitesse s'écrit :",
      "options": [
        "v(t) = k/[R](t)",
        "v(t) = k·[R](t)²",
        "v(t) = k",
        "v(t) = k·[R](t)"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Ordre 1 signifie que la vitesse est <b>proportionnelle à la concentration</b> du réactif : v = k·[R], avec k en s⁻¹.",
      "piege": "Confondre avec l'ordre 2, où la vitesse est proportionnelle au carré de la concentration.",
      "image": null,
      "tags": [
        "ordre 1"
      ],
      "actif": true
    },
    {
      "ref": "cin-06",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "En combinant v = −d[R]/dt et v = k·[R], l'équation différentielle vérifiée par [R] est :",
      "options": [
        "d[R]/dt + k·[R] = 0",
        "d[R]/dt + k = 0",
        "d[R]/dt + [R]/k = 0",
        "d[R]/dt − k·[R] = 0"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "En égalant les deux expressions : − d[R]/dt = k·[R], soit <b>d[R]/dt + k·[R] = 0</b> — une équation différentielle du premier ordre, linéaire et sans second membre.",
      "piege": "Se tromper de signe et obtenir une exponentielle croissante.",
      "image": null,
      "tags": [
        "equation differentielle"
      ],
      "actif": true
    },
    {
      "ref": "cin-07",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Pour montrer que [R](t) = [R]₀·e^(−kt) est solution de d[R]/dt + k·[R] = 0, il faut :",
      "options": ["vérifier qu'à t = 0 l'expression vaut bien [R]₀, ce qui suffit", "dériver l'expression, la reporter dans l'équation, trouver 0", "tracer la courbe et vérifier qu'elle décroît bien vers zéro", "vérifier que la limite en +∞ est nulle, ce qui suffit à conclure"],
      "bonne_reponse": [
        1
      ],
      "explication": "La méthode attendue : on dérive, on remplace dans le membre de gauche, et on montre que le résultat vaut <b>0</b>. La vérification de la condition initiale ne suffit pas.",
      "piege": "Se contenter de vérifier la condition initiale.",
      "image": null,
      "tags": [
        "equation differentielle"
      ],
      "actif": true
    },
    {
      "ref": "cin-08",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "La dérivée de [R](t) = [R]₀·e^(−kt) vaut :",
      "options": [
        "− k·e^(−kt)",
        "− [R]₀·e^(−kt)/k",
        "− k·[R]₀·e^(−kt)",
        "+ k·[R]₀·e^(−kt)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "d[R]/dt = [R]₀ × (−k) × e^(−kt) = <b>− k·[R]₀·e^(−kt)</b>. Reportée dans l'équation, elle donne bien −k[R] + k[R] = 0.",
      "piege": "Oublier le facteur −k issu de la dérivation de l'exponentielle.",
      "image": null,
      "tags": [
        "derivation"
      ],
      "actif": true
    },
    {
      "ref": "cin-09",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "On écrit [R](t) = A·e^(−kt), où A est une constante. Que vaut A ?",
      "options": [
        "A = [R]₀/2",
        "A = 1/[R]₀",
        "A = k",
        "A = [R]₀"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "À t = 0 : [R](0) = A·e⁰ = A. Or [R](0) = [R]₀, donc <b>A = [R]₀</b>. Toute constante d'intégration se détermine par la condition initiale.",
      "piege": "Chercher A par dérivation au lieu d'utiliser la condition initiale.",
      "image": null,
      "tags": [
        "condition initiale"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-10",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Sur la courbe [R] = f(t), la vitesse de consommation à une date donnée correspond :",
      "options": [
        "à l'opposé du coefficient directeur de la tangente en ce point",
        "au coefficient directeur de la tangente en ce point",
        "à l'ordonnée du point",
        "à l'aire sous la courbe jusqu'à cette date"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "La vitesse de consommation est l'<b>opposé</b> du coefficient directeur de la tangente, puisque la concentration décroît et que la vitesse doit être positive.",
      "piege": "Lire une ordonnée au lieu d'une pente, ou oublier de prendre l'opposé.",
      "image": "cin_tangentes.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-11",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "La tangente à t = 0 passe par A (0 ; 10) et B (10 ; 0), en mmol·L⁻¹ et en secondes. Que vaut la vitesse initiale v₀ ?",
      "options": [
        "10 mmol·L⁻¹·s⁻¹",
        "1,0 mmol·L⁻¹·s⁻¹",
        "− 1,0 mmol·L⁻¹·s⁻¹",
        "0,10 mmol·L⁻¹·s⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "a = (0 − 10)/(10 − 0) = − 1,0 mmol·L⁻¹·s⁻¹, donc v₀ = <b>1,0 mmol·L⁻¹·s⁻¹</b> en prenant l'opposé.",
      "piege": "Donner une vitesse négative en oubliant l'opposé.",
      "image": "cin_tangentes.png",
      "tags": [
        "lecture graphique",
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "cin-12",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "La tangente à t = 15 s passe par C (10 ; 3,35) et D (25 ; 0). Que vaut la vitesse à cette date ?",
      "options": [
        "0,34 mmol·L⁻¹·s⁻¹",
        "1,0 mmol·L⁻¹·s⁻¹",
        "0,22 mmol·L⁻¹·s⁻¹",
        "3,35 mmol·L⁻¹·s⁻¹"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "a = (0 − 3,35)/(25 − 10) = − 0,22 mmol·L⁻¹·s⁻¹, d'où v = <b>0,22 mmol·L⁻¹·s⁻¹</b>.",
      "piege": "Utiliser un seul point au lieu des deux points de la tangente.",
      "image": "cin_tangentes.png",
      "tags": [
        "lecture graphique",
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "cin-13",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Pourquoi la vitesse de réaction diminue-t-elle au cours du temps ?",
      "options": ["parce que la température du milieu diminue au cours du temps", "parce que le catalyseur est consommé au fil de la réaction", "parce que le volume du milieu augmente et dilue les réactifs", "parce que les tangentes à la courbe deviennent plus horizontales"],
      "bonne_reponse": [
        3
      ],
      "explication": "La justification attendue est <b>graphique</b> : les tangentes s'aplatissent, donc leur pente — qui représente la vitesse instantanée — diminue.",
      "piege": "Invoquer la concentration sans parler des tangentes quand la question demande une justification graphique.",
      "image": "cin_tangentes.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-14",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Le temps de demi-réaction t₁/₂ est la durée au bout de laquelle :",
      "options": [
        "l'avancement atteint la moitié de sa valeur finale",
        "la vitesse de réaction est divisée par deux",
        "le réactif limitant a totalement disparu",
        "la constante de vitesse est divisée par deux"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "t₁/₂ est la durée au bout de laquelle l'<b>avancement atteint la moitié de sa valeur finale</b> — soit, à l'ordre 1, la durée au bout de laquelle [R] est divisée par deux.",
      "piege": "Confondre avec la division par deux de la vitesse.",
      "image": null,
      "tags": [
        "definitions"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-15",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Remets dans l'ordre la construction graphique de t₁/₂ :",
      "options": [
        "on repère [R]₀/2 sur l'axe des ordonnées",
        "on lit l'abscisse : c'est t₁/₂",
        "on descend à la verticale jusqu'à l'axe des temps",
        "on trace l'horizontale jusqu'à la courbe"
      ],
      "bonne_reponse": [
        0,
        3,
        2,
        1
      ],
      "explication": "Les traits de construction doivent rester <b>visibles</b> sur la copie : c'est ce que le correcteur attend.",
      "piege": "Donner la valeur sans laisser la construction apparente.",
      "image": "cin_t12.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-16",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Avec [R]₀ = 10 mmol·L⁻¹, on lit t₁/₂ ≈ 6,9 s. Que doit-on lire à t = 13,9 s pour valider la lecture ?",
      "options": [
        "1,25 mmol·L⁻¹",
        "2,5 mmol·L⁻¹",
        "0 mmol·L⁻¹",
        "5,0 mmol·L⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Au bout de 2·t₁/₂, la concentration est divisée par 4 : 10/4 = <b>2,5 mmol·L⁻¹</b>. C'est le contrôle qui valide la construction.",
      "piege": "Croire que la concentration est nulle après deux demi-vies.",
      "image": "cin_t12.png",
      "tags": [
        "controle",
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-17",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre la démonstration de t₁/₂ = ln(2)/k :",
      "options": [
        "on simplifie par [R]₀ : e^(−k·t₁/₂) = 1/2",
        "on écrit [R]₀·e^(−k·t₁/₂) = [R]₀/2",
        "on prend le logarithme népérien : − k·t₁/₂ = − ln(2)",
        "on pose [R](t₁/₂) = [R]₀/2",
        "on isole : t₁/₂ = ln(2)/k"
      ],
      "bonne_reponse": [
        3,
        1,
        0,
        2,
        4
      ],
      "explication": "La simplification par [R]₀ est l'étape clé : c'est elle qui montre que t₁/₂ <b>ne dépend pas</b> de la concentration initiale.",
      "piege": "Sauter la simplification par [R]₀ et croire que t₁/₂ en dépend.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-18",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Pour une cinétique d'ordre 1, le temps de demi-réaction :",
      "options": [
        "dépend du volume de la solution",
        "dépend de la nature du solvant uniquement",
        "ne dépend que de la constante de vitesse k",
        "dépend de la concentration initiale du réactif"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "t₁/₂ = ln(2)/k : il <b>ne dépend pas</b> de [R]₀. C'est la signature d'une cinétique d'ordre 1.",
      "piege": "Croire que doubler la concentration initiale double le temps de demi-réaction.",
      "image": null,
      "tags": [
        "ordre 1"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-19",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Une réaction d'ordre 1 a pour constante de vitesse k = 0,10 s⁻¹. Que vaut son temps de demi-réaction ?",
      "options": [
        "10 s",
        "0,069 s",
        "69 s",
        "6,9 s"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "t₁/₂ = ln(2)/k = 0,693/0,10 = <b>6,9 s</b>.",
      "piege": "Calculer 1/k = 10 s, qui est le temps caractéristique τ, pas la demi-vie.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-20",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Le graphe v = f([R]) est une droite passant par l'origine. Qu'en déduit-on ?",
      "options": [
        "la cinétique est d'ordre 1 et k est le coefficient directeur",
        "la réaction est terminée",
        "la cinétique est d'ordre 1 et k est l'ordonnée à l'origine",
        "la cinétique est d'ordre 2"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "v = k·[R] : une <b>fonction linéaire</b>, donc une droite passant par l'origine dont le coefficient directeur vaut <b>k</b>.",
      "piege": "Chercher k dans l'ordonnée à l'origine, qui est nulle ici.",
      "image": "cin_v_de_R.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-21",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Le graphe ln([R]) = f(t) est une droite. Que vaut son coefficient directeur ?",
      "options": [
        "1/k",
        "− k",
        "+ k",
        "ln([R]₀)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "ln([R](t)) = ln([R]₀) − k·t : c'est une <b>fonction affine</b> de coefficient directeur <b>− k</b> et d'ordonnée à l'origine ln([R]₀).",
      "piege": "Oublier le signe − et annoncer une constante de vitesse négative.",
      "image": "cin_lnR_de_t.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-22",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Sur ln([R]) = f(t), on lit I (0 ; −4,61) et J (20 ; −6,61). Que vaut k ?",
      "options": [
        "− 0,10 s⁻¹",
        "0,33 s⁻¹",
        "0,10 s⁻¹",
        "2,0 s⁻¹"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "a = (−6,61 + 4,61)/(20 − 0) = − 0,10 s⁻¹. Or a = − k, donc <b>k = 0,10 s⁻¹</b> : la constante de vitesse est positive.",
      "piege": "Donner k = − 0,10 s⁻¹ en confondant la pente et la constante.",
      "image": "cin_lnR_de_t.png",
      "tags": [
        "calcul",
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-23",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Quelle différence entre les graphes ln([R]) = f(t) et ln([R]/[R]₀) = f(t) ?",
      "options": [
        "le premier est linéaire, le second affine",
        "le premier est affine, le second linéaire (il passe par l'origine)",
        "les deux passent par l'origine",
        "aucune : les deux ont la même ordonnée à l'origine"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "ln([R]) = ln([R]₀) − kt est <b>affine</b> ; ln([R]/[R]₀) = − kt est <b>linéaire</b> et passe donc par l'origine. Les deux ont le même coefficient directeur − k.",
      "piege": "Confondre linéaire et affine, et chercher une ordonnée à l'origine là où il n'y en a pas.",
      "image": "cin_deux_ln.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-24",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Si l'énoncé fournit le graphe v = f(t) au lieu de v = f([R]), comment obtenir k ?",
      "options": ["en lisant la durée au bout de laquelle v est divisée par deux, puis k = ln 2/t½", "c'est impossible sans la concentration, que ce graphe ne donne pas", "en lisant l'ordonnée à l'origine du graphe, qui vaut directement k", "en calculant l'aire sous la courbe, qui vaut k multiplié par [R]₀"],
      "bonne_reponse": [
        0
      ],
      "explication": "La vitesse décroît exponentiellement comme [R], avec la même constante : on lit sur la courbe la durée au bout de laquelle v est divisée par deux — c'est t₁/₂ — puis <b>k = ln(2)/t₁/₂</b>.",
      "piege": "Chercher une pente sur une courbe qui n'est pas une droite.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-25",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Pour un <b>produit</b> P, la vitesse de formation se lit sur la courbe [P] = f(t) :",
      "options": [
        "comme l'aire sous la courbe",
        "comme le coefficient directeur de la tangente, directement",
        "comme l'ordonnée du point considéré",
        "comme l'opposé du coefficient directeur de la tangente"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La courbe croît : le coefficient directeur est <b>positif</b> et vaut directement la vitesse de formation — il n'y a pas de signe − à appliquer.",
      "piege": "Appliquer le signe − comme pour un réactif.",
      "image": "cin_formation.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-26",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Dans un mécanisme réactionnel, un <b>intermédiaire réactionnel</b> est une espèce :",
      "options": [
        "toujours à l'état solide",
        "présente dans le bilan de la réaction",
        "formée à une étape puis consommée à l'étape suivante",
        "consommée à la première étape et régénérée à la dernière"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L'intermédiaire réactionnel est <b>formé puis consommé</b> : il n'apparaît pas dans le bilan. L'espèce consommée puis régénérée, c'est le <b>catalyseur</b>.",
      "piege": "Confondre intermédiaire réactionnel et catalyseur, tous deux absents du bilan.",
      "image": null,
      "tags": [
        "mecanismes"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-27",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Une flèche courbe dans un mécanisme représente :",
      "options": ["le transfert d'un proton, du site donneur vers le site accepteur", "le sens d'évolution de la réaction, des réactifs vers les produits", "le déplacement d'un atome, du site donneur vers le site accepteur", "le transfert d'un doublet d'électrons, du donneur vers l'accepteur"],
      "bonne_reponse": [
        3
      ],
      "explication": "La flèche courbe indique le transfert d'un <b>doublet d'électrons</b>, toujours orientée du site <b>donneur</b> vers le site <b>accepteur</b>.",
      "piege": "Tracer la flèche dans le sens inverse, de l'accepteur vers le donneur.",
      "image": "cin_fleches.png",
      "tags": [
        "mecanismes"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-28",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Un site <b>donneur</b> de doublet d'électrons se reconnaît à :",
      "options": [
        "un doublet non liant, ou une liaison polarisée du côté δ⁻",
        "la présence d'un catalyseur",
        "un atome porteur d'une charge δ⁺",
        "un atome porteur d'une lacune électronique"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Site donneur : <b>doublet non liant</b> ou liaison polarisée côté <b>δ⁻</b>. Le site accepteur, lui, porte un δ⁺ ou une lacune.",
      "piege": "Intervertir les sites donneur et accepteur.",
      "image": null,
      "tags": [
        "mecanismes"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-29",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Un élève écrit : « [R]₀·e^(−k·t₁/₂) = [R]₀/2, donc e^(−k·t₁/₂) = 1/2, donc − k·t₁/₂ = ln(2), donc t₁/₂ = − ln(2)/k ». Où est l'erreur ?",
      "options": [
        "à la deuxième ligne : on ne peut pas simplifier par [R]₀",
        "à la troisième ligne : ln(1/2) = − ln(2), pas + ln(2)",
        "à la première ligne : la définition de t₁/₂ est fausse",
        "il n'y a pas d'erreur"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "ln(1/2) = ln(1) − ln(2) = <b>− ln(2)</b>. En rétablissant le signe, on obtient bien t₁/₂ = + ln(2)/k, une durée positive.",
      "piege": "Oublier que le logarithme d'un nombre inférieur à 1 est négatif.",
      "image": null,
      "tags": [
        "reperage erreur",
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin-30",
      "chapitre": "cinetique-chimique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Un élève annonce : « la vitesse à t = 15 s vaut 3,35 mmol·L⁻¹ car c'est l'ordonnée du point C ». Que faut-il lui répondre ?",
      "options": ["il faut diviser cette valeur par 2, l'ordonnée valant le double", "il faut prendre l'opposé, la concentration du réactif diminuant", "une vitesse est une pente, pas une ordonnée : il faut deux points", "c'est correct : l'ordonnée du point donne bien la vitesse"],
      "bonne_reponse": [
        2
      ],
      "explication": "Une vitesse se lit toujours comme une <b>pente</b> : il faut nommer deux points de la tangente et calculer (y<sub>B</sub> − y<sub>A</sub>)/(t<sub>B</sub> − t<sub>A</sub>), puis prendre l'opposé pour un réactif.",
      "piege": "Lire une ordonnée au lieu d'une pente — l'erreur la plus fréquente du chapitre.",
      "image": "cin_tangentes.png",
      "tags": [
        "reperage erreur",
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "cin-n1", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Sur la courbe [R] = f(t) d'une cinétique d'ordre 1, pourquoi la vitesse diminue-t-elle ?", "options": ["les tangentes deviennent plus horizontales : leur pente diminue", "la température du milieu baisse peu à peu au cours du temps", "le catalyseur se consomme progressivement au fil des étapes", "la vitesse reste constante, c'est la concentration qui diminue"], "bonne_reponse": [0], "explication": "La vitesse se lit sur la <b>pente de la tangente</b> : elle s'aplatit à mesure que [R] diminue, puisque v = k·[R].", "piege": "Invoquer la température ou le catalyseur : rien dans l'énoncé ne les fait varier.", "actif": true},
    {"ref": "cin-n2", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 11", "enonce": "Dans un mécanisme réactionnel, comment reconnaît-on le <b>catalyseur</b> ?", "options": ["il est consommé à la première étape et régénéré à la dernière", "il est formé à une étape et consommé à la suivante", "il figure parmi les réactifs du bilan", "il apparaît dans les produits du bilan"], "bonne_reponse": [0], "explication": "Le catalyseur est <b>consommé puis régénéré</b> : il n'apparaît donc pas dans le bilan, tout en accélérant la transformation.", "piege": "Le confondre avec l'intermédiaire réactionnel, qui est formé PUIS consommé — l'ordre inverse.", "actif": true},
    {"ref": "cin-n3", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 12", "enonce": "Dans une étape d'un mécanisme, dans quel sens tracer la flèche courbe ?", "options": ["du site donneur — doublet non liant ou liaison — vers le site accepteur", "du site accepteur vers le site donneur", "toujours du réactif vers le produit", "de l'atome le plus électronégatif vers le moins électronégatif"], "bonne_reponse": [0], "explication": "La flèche courbe suit le mouvement des <b>électrons</b> : elle part du site donneur, riche en électrons, vers le site accepteur, appauvri (δ⁺ ou lacune).", "piege": "Tracer la flèche dans le sens de la réaction : elle décrit un déplacement d'électrons, pas une transformation.", "actif": true},
    {"ref": "cin-n4", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "methode", "source_qt": "QT 13", "enonce": "Une équation de mécanisme fait apparaître une espèce manquante A. Comment la trouver ?", "options": ["faire le bilan atomique élément par élément entre réactifs et produits", "prendre l'espèce absente du bilan global", "choisir toujours le catalyseur", "regarder quelle espèce a la plus grande masse molaire"], "bonne_reponse": [0], "explication": "On compte chaque élément de part et d'autre : ce qui manque donne la formule de A — c'est très souvent <b>H₂O</b>.", "piege": "Deviner sans compter : le bilan atomique est une vérification, pas une intuition.", "actif": true},
    {"ref": "cinetique-t01", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Une réaction R → P suit une loi de vitesse d'ordre 1 : v = k·[R]. La vitesse de consommation de R étant v = −d[R]/dt, l'équation différentielle est :", "options": ["d[R]/dt = −k", "[R] = −k·t", "d[R]/dt = k·[R]", "d[R]/dt = −k·[R]"], "bonne_reponse": [3], "explication": "On égale les deux expressions de la vitesse : −d[R]/dt = k[R], soit d[R]/dt = −k[R]. Le signe − traduit que [R] diminue.", "piege": "Oublier le signe : [R] décroît, sa dérivée est négative.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t02", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Pour vérifier que [R](t) = [R]₀·e^(−kt) est solution de d[R]/dt = −k·[R], on :", "options": ["intègre l'équation entre 0 et t, ce qui redonne l'expression", "remplace t par 0 : [R](0) = [R]₀, ce qui vérifie l'équation", "calcule [R] à t = 1/k : on trouve [R]₀/e, ce qui la vérifie", "dérive : d[R]/dt = −k·[R]₀·e^(−kt) = −k·[R], c'est l'équation"], "bonne_reponse": [3], "explication": "Vérifier une solution, c'est la dériver et constater qu'elle satisfait l'équation. Ici la dérivée de e^(−kt) est −k·e^(−kt), et l'on retrouve −k[R].", "piege": "Confondre vérifier et résoudre : on n'intègre pas, on dérive la solution proposée.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t03", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "La solution générale est [R](t) = A·e^(−kt). À t = 0, [R] = 0,20 mol·L⁻¹. La constante A vaut :", "options": ["A = 0,20·k mol·L⁻¹·s⁻¹, car la dérivée vaut −k·A à t = 0", "A = [R](0) = 0,20 mol·L⁻¹, car e⁰ = 1", "A = 0,20/k mol·L⁻¹·s, car l'exponentielle vaut k à t = 0", "A = 0 mol·L⁻¹, car l'exponentielle s'annule à l'origine"], "bonne_reponse": [1], "explication": "À t = 0, e^(−k×0) = 1, donc [R](0) = A. La constante d'intégration est fixée par la condition initiale.", "piege": "Faire intervenir k : à t = 0 l'exponentielle vaut 1 quel que soit k.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t04", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Sur la courbe [R] = f(t), la tangente en t = 10 s passe par (0 ; 0,20) et (40 ; 0). La vitesse de consommation de R à t = 10 s vaut :", "options": ["v = −pente = −(0 − 0,20)/(40 − 0) = 5,0 × 10⁻³ mol·L⁻¹·s⁻¹", "v = 0,20 × 40 = 8,0 mol·L⁻¹·s⁻¹, produit des deux ordonnées", "v = 0,20/10 = 2,0 × 10⁻² mol·L⁻¹·s⁻¹, ordonnée divisée par t", "v = pente = (0 − 0,20)/(40 − 0) = −5,0 × 10⁻³ mol·L⁻¹·s⁻¹"], "bonne_reponse": [0], "explication": "La vitesse de consommation est l'opposé de la pente de la tangente à [R] = f(t). La pente est négative, la vitesse positive.", "piege": "Prendre la pente sans changer de signe, ou calculer [R]/t au lieu de la pente de la tangente.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t05", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Sur la courbe [P] = f(t) d'un produit, la vitesse de formation de P à une date donnée est :", "options": ["la pente de la tangente à la courbe en ce point, positive", "l'opposé de la pente de la tangente en ce point, positive", "la pente de la corde tracée depuis l'origine jusqu'au point", "la valeur de [P] en ce point, divisée par la date t"], "bonne_reponse": [0], "explication": "v_formation = +d[P]/dt : [P] augmente, la pente est positive, on la prend telle quelle. Pour un réactif, on prend l'opposé.", "piege": "Changer le signe par réflexe : c'est pour un RÉACTIF qu'on prend l'opposé de la pente.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t06", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Sur la courbe [R] = f(t), les tangentes sont de moins en moins inclinées au cours du temps. On en déduit :", "options": ["la réaction s'est arrêtée, tout le réactif ayant été consommé", "la vitesse diminue, car la concentration du réactif diminue", "la vitesse augmente, car les tangentes se rapprochent de zéro", "la vitesse est constante, la pente ne changeant pas de signe"], "bonne_reponse": [1], "explication": "Pente qui s'aplatit = vitesse qui décroît. Cause : [R] baisse, et la concentration est un facteur cinétique. Pour un ordre 1, v = k[R] le dit directement.", "piege": "Invoquer la température ou un catalyseur : rien ne les fait varier, c'est la concentration qui explique tout.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t07", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Le temps de demi-réaction t½ est :", "options": ["la durée au bout de laquelle [R] atteint zéro sur la courbe", "la durée au bout de laquelle l'avancement atteint la moitié du final", "la moitié de la durée totale de la réaction, lue sur la courbe", "la durée au bout de laquelle la réaction s'arrête définitivement"], "bonne_reponse": [1], "explication": "x(t½) = x_f/2. Pour une réaction totale d'ordre 1, c'est la date où [R] = [R]₀/2 : on trace l'horizontale à [R]₀/2, on lit l'abscisse.", "piege": "Confondre avec la moitié de la durée totale : t½ se définit par l'avancement, pas par le temps.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t08", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Avec [R](t) = [R]₀·e^(−kt), on cherche t½ tel que [R](t½) = [R]₀/2. On obtient :", "options": ["e^(−k·t½) = 2, donc −k·t½ = ln 2, donc t½ = 1/(2·k)", "e^(−k·t½) = 1/2, donc k·t½ = ln 2 / 2, donc t½ = k·ln 2", "e^(−k·t½) = 1/2, donc −k·t½ = −ln 2, donc t½ = ln 2/k", "e^(−k·t½) = 1/2, donc −k·t½ = −2, donc t½ = 2/k"], "bonne_reponse": [2], "explication": "On divise par [R]₀, on prend le logarithme népérien : −k·t½ = ln(1/2) = −ln 2. Donc t½ = ln 2/k. Il ne dépend pas de [R]₀ : c'est la signature d'un ordre 1.", "piege": "Oublier le logarithme, ou écrire ln(1/2) = ln 2 sans le signe.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t09", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "On trace ln([R]/[R]₀) en fonction de t et l'on obtient une droite de pente −0,050 s⁻¹. La constante de vitesse vaut :", "options": ["k = 1/0,050 = 20 s, inverse de la pente de la droite", "k = −0,050 s⁻¹, égal à la pente elle-même, donc négatif", "k = 0,050 s⁻¹, opposé de la pente de la droite tracée", "k = e^(−0,050) = 0,95 s⁻¹, exponentielle de la pente"], "bonne_reponse": [2], "explication": "ln([R]/[R]₀) = −k·t : droite passant par l'origine, de pente −k. On lit la pente, on change le signe.", "piege": "Garder le signe négatif : une constante de vitesse est toujours positive.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t10", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "Dans un mécanisme, une espèce est un intermédiaire réactionnel si elle est :", "options": ["présente dans le bilan comme produit", "formée dans une étape et consommée dans une étape suivante, absente du bilan", "présente dans le bilan comme réactif", "consommée à la première étape et régénérée à la dernière"], "bonne_reponse": [1], "explication": "Formé PUIS consommé : il n'apparaît ni dans les réactifs ni dans les produits du bilan. Il existe en cours de réaction seulement.", "piege": "Le confondre avec le catalyseur, qui suit l'ordre inverse : consommé puis régénéré.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t11", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 11", "enonce": "Dans un mécanisme, le catalyseur est reconnaissable parce qu'il est :", "options": ["un réactif du bilan, consommé dès la première étape", "consommé dans une étape et régénéré dans une suivante", "formé dans une étape puis consommé dans une suivante", "un produit du bilan, formé au cours de la dernière étape"], "bonne_reponse": [1], "explication": "Consommé PUIS régénéré : il accélère la réaction sans être modifié au final. Comme l'intermédiaire, il est absent du bilan — mais dans l'ordre inverse.", "piege": "Inverser l'ordre avec l'intermédiaire : le catalyseur est là AVANT et APRÈS, l'intermédiaire seulement PENDANT.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t12", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 12", "enonce": "Dans une étape de mécanisme, une flèche courbe se trace :", "options": ["toujours du réactif vers le produit", "de l'atome le moins électronégatif vers le plus électronégatif", "du site donneur d'électrons — doublet non liant ou liaison — vers le site accepteur", "du site accepteur vers le site donneur"], "bonne_reponse": [2], "explication": "La flèche suit le mouvement d'un doublet d'électrons : elle part d'où ils sont — doublet libre, liaison — et arrive où ils vont — atome δ⁺, lacune électronique.", "piege": "Tracer la flèche dans le sens de la réaction : elle décrit un déplacement d'électrons, pas une transformation.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinetique-t13", "chapitre": "cinetique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 13", "enonce": "Une étape de mécanisme s'écrit CH₃COOH + HO⁻ → CH₃COO⁻ + A. L'espèce A est :", "options": ["O₂ : la conservation des éléments impose un oxygène à droite", "H₂ : la conservation des éléments impose un hydrogène à droite", "H⁺ : la conservation des charges impose un proton à droite", "H₂O : la conservation des éléments impose une eau à droite"], "bonne_reponse": [3], "explication": "On compte : à gauche, C₂H₅O₃ et une charge −. À droite, CH₃COO⁻ = C₂H₃O₂⁻. Il manque H₂O, neutre. C'est le bilan atomique qui décide.", "piege": "Deviner sans compter : le bilan élément par élément est une vérification, pas une intuition.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  piles: [
    {
      "ref": "pil-01",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Une transformation est <b>totale</b> si et seulement si :",
      "options": [
        "un des réactifs est totalement consommé",
        "le taux d'avancement vaut 0",
        "la constante K(T) est grande",
        "la réaction est rapide"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le critère chiffré est le taux d'avancement final : τ = 1 → totale, τ &lt; 1 → limitée.",
      "piege": "Confondre « totale » et « rapide » : la vitesse et l'avancement final sont deux notions distinctes.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-02",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Le taux d'avancement final s'écrit :",
      "options": [
        "τ = 1 − x<sub>eq</sub>",
        "τ = x<sub>eq</sub> / x<sub>max</sub>",
        "τ = x<sub>max</sub> / x<sub>eq</sub>",
        "τ = x<sub>eq</sub> × x<sub>max</sub>"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est le rapport de l'avancement atteint à l'avancement maximal : il est compris entre 0 et 1.",
      "piege": "Inverser le quotient et obtenir un taux supérieur à 1.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-03",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Dans l'expression du quotient de réaction, l'activité d'un <b>solide</b> vaut :",
      "options": ["sa masse molaire : elle figure donc au numérateur", "0 : le terme correspondant disparaît du quotient", "1 : il n'apparaît donc pas dans l'expression", "sa concentration : elle figure donc au dénominateur"],
      "bonne_reponse": [
        2
      ],
      "explication": "Même chose pour le solvant liquide : leur activité est égale à 1, ils sont absents de Q<sub>r</sub>.",
      "piege": "Faire figurer un solide ou le solvant dans le quotient — l'erreur la plus fréquente du chapitre.",
      "image": null,
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "pil-05",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Remets dans l'ordre la démarche pour trancher totale ou limitée :",
      "options": [
        "faire l'hypothèse que la réaction est totale et déterminer x<sub>max</sub> par le tableau d'avancement",
        "conclure : τ = 1 → totale, τ &lt; 1 → limitée",
        "calculer x<sub>eq</sub> à partir d'une donnée expérimentale : pH, conductivité, concentration d'un produit",
        "calculer τ = x<sub>eq</sub> / x<sub>max</sub>"
      ],
      "bonne_reponse": [
        0,
        2,
        3,
        1
      ],
      "explication": "L'étape 2 est celle qu'on saute : sans donnée expérimentale, on ne peut pas calculer x<sub>eq</sub>.",
      "piege": "Conclure sans calculer x<sub>eq</sub> à partir d'une mesure — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-06",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "L'énoncé donne le pH et des ions oxonium sont formés. Que vaut x<sub>eq</sub> ?",
      "options": [
        "x<sub>eq</sub> = pH × V",
        "x<sub>eq</sub> = V / 10⁻ᵖᴴ",
        "x<sub>eq</sub> = 10^pH · V",
        "x<sub>eq</sub> = c⁰ · 10⁻ᵖᴴ · V"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "[H₃O⁺]_eq = c⁰·10⁻ᵖᴴ, et x<sub>eq</sub> = [H₃O⁺]_eq × V d'après le tableau d'avancement.",
      "piege": "Oublier de multiplier par le volume : x est une quantité de matière, pas une concentration.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "pil-07",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Une solution d'acide de concentration C = 1,0×10⁻² mol·L⁻¹ dans V = 100 mL a un pH de 3,4. Que vaut τ ?",
      "options": [
        "τ ≈ 0,04, la réaction est limitée",
        "τ = 3,4",
        "τ = 1, la réaction est totale",
        "τ ≈ 0,34, la réaction est limitée"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "x<sub>max</sub> = C·V = 1,0×10⁻³ mol et x<sub>eq</sub> = 10⁻³·⁴ × 0,100 = 4,0×10⁻⁵ mol, donc τ ≈ 0,04 : l'acide est faible.",
      "piege": "Comparer directement le pH mesuré à une valeur seuil sans passer par les avancements.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-08",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Le quotient de réaction s'écrit :",
      "options": ["réactifs sur produits, chacun élevé à son coefficient stœchiométrique", "produits sur réactifs, chacun élevé à son coefficient stœchiométrique", "la somme des concentrations, chacune élevée à son coefficient", "le produit des concentrations, chacune élevée à son coefficient"],
      "bonne_reponse": [
        1
      ],
      "explication": "Les produits au numérateur, les réactifs au dénominateur, avec les coefficients en exposant.",
      "piege": "Inverser le quotient : la constante d'équilibre serait alors l'inverse de la bonne valeur.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-09",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Pour α A(aq) + β B(ℓ) ⇌ γ C(aq) + δ D(s), avec B le solvant et D un solide, Q<sub>r</sub> vaut :",
      "options": [
        "([A]/c⁰)^α / ([C]/c⁰)^γ",
        "([C]/c⁰) / ([A]/c⁰)",
        "([C]/c⁰)^γ / ([A]/c⁰)^α",
        "([C]/c⁰)^γ × ([D]/c⁰)^δ / (([A]/c⁰)^α × ([B]/c⁰)^β)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le solvant B et le solide D ont une activité égale à 1 : ils disparaissent de l'expression.",
      "piege": "Écrire toutes les espèces, y compris le solide et le solvant.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-10",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Quelle règle rapporte le point sur cette question ?",
      "options": ["citer la température, dont dépend la valeur du quotient", "citer la valeur de c⁰, qui rend le quotient sans dimension", "donner la valeur numérique, seule attendue par le correcteur", "préciser que l'activité d'un solide ou du solvant vaut 1"],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est la justification attendue par le correcteur, et elle explique pourquoi certaines espèces sont absentes.",
      "piege": "Écrire le bon quotient sans justifier l'absence du solide : le point de raisonnement est perdu.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "pil-11",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Si Q<sub>r</sub>,i &lt; K(T), le système évolue :",
      "options": ["il n'évolue pas : le système est déjà à l'équilibre", "dans le sens indirect, de la droite vers la gauche", "dans le sens direct, de la gauche vers la droite", "cela dépend de la température, qui fixe le sens d'évolution"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le quotient doit augmenter pour atteindre K : la réaction consomme donc les réactifs.",
      "piege": "Inverser les deux sens. Repère : le quotient tend toujours vers K.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "pil-12",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Si Q<sub>r</sub>,i = K(T), alors :",
      "options": [
        "la réaction est totale",
        "le système est déjà à l'équilibre : il n'évolue pas",
        "le système évolue dans le sens direct",
        "la température est de 25 °C"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le quotient a déjà la valeur qu'il prend à l'équilibre : plus rien ne bouge à l'échelle macroscopique.",
      "piege": "Croire qu'un système à l'équilibre est un système où rien ne se passe : les deux sens coexistent.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-13",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre la prévision du sens d'évolution :",
      "options": [
        "conclure : Q<sub>r</sub>,i &lt; K → sens direct · Q<sub>r</sub>,i > K → sens indirect",
        "calculer Q<sub>r</sub>,i à partir des concentrations initiales",
        "comparer Q<sub>r</sub>,i à K(T), valeur du quotient à l'équilibre"
      ],
      "bonne_reponse": [
        1,
        2,
        0
      ],
      "explication": "Deux calculs, une comparaison : c'est toute la démarche du chapitre.",
      "piege": "Comparer des concentrations au lieu du quotient — le piège explicitement listé.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-14",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Pour une réaction de constante K = 1,0×10⁻³, on calcule Q<sub>r</sub>,i = 5,0×10⁻². Que se passe-t-il ?",
      "options": [
        "le système est à l'équilibre",
        "évolution dans le sens indirect",
        "évolution dans le sens direct",
        "impossible à dire"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Q<sub>r</sub>,i > K : le quotient doit diminuer, la réaction évolue donc de la droite vers la gauche.",
      "piege": "Comparer les exposants sans regarder lequel est le plus grand : 5,0×10⁻² > 1,0×10⁻³.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "pil-15",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "La constante d'équilibre K(T) est :",
      "options": [
        "le produit des concentrations initiales",
        "le quotient de réaction à l'état initial",
        "le taux d'avancement final",
        "le quotient de réaction à l'équilibre"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Elle s'écrit avec les concentrations à l'équilibre, et elle ne dépend que de la température.",
      "piege": "La confondre avec Q<sub>r</sub>,i, le quotient initial, qui varie d'une expérience à l'autre.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-16",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "De quoi K(T) <b>ne</b> dépend-elle pas ? <b>Plusieurs réponses.</b>",
      "options": ["de la présence d'un catalyseur", "des concentrations initiales", "du volume du récipient", "de la température du milieu"],
      "bonne_reponse": [
        0,
        1,
        2
      ],
      "explication": "K ne dépend que de la température : c'est la phrase à citer systématiquement.",
      "piege": "Croire qu'un catalyseur déplace l'équilibre : il change la vitesse, jamais l'état final.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-17",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Dans le cas de l'hydrolyse d'un acide, la constante d'équilibre vaut :",
      "options": [
        "Ka",
        "le taux d'avancement",
        "le produit ionique",
        "Ke"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "K(T) = Ka, la constante d'acidité du couple : c'est le cas d'application privilégié au bac.",
      "piege": "Confondre Ka, propre au couple, et Ke, le produit ionique de l'eau.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "pil-18",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Pour déterminer x<sub>eq</sub> à partir de K(T), on commence par :",
      "options": ["mesurer le pH, dont on déduit l'avancement à l'équilibre", "dresser le tableau d'avancement de la réaction", "tracer la courbe x = f(t), dont on lit le palier final", "calculer le taux d'avancement, qui donne x_éq par produit"],
      "bonne_reponse": [
        1
      ],
      "explication": "Le tableau donne les concentrations à l'équilibre en fonction de x<sub>eq</sub>, qu'on reporte ensuite dans K.",
      "piege": "Vouloir isoler x<sub>eq</sub> directement dans l'expression de K sans passer par le tableau.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-19",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Le report dans K conduit à une équation :",
      "options": [
        "logarithmique",
        "exponentielle",
        "du second degré en x<sub>eq</sub>",
        "du premier degré en x<sub>eq</sub>"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "(x<sub>eq</sub>/V)² + Ka·c⁰·(x<sub>eq</sub>/V) − Ka·C·c⁰ = 0 : on calcule Δ et on garde la racine positive.",
      "piege": "Chercher à simplifier pour éliminer le carré : il vient du produit de deux concentrations égales.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-20",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Quelle racine faut-il conserver ?",
      "options": ["la racine positive : une quantité de matière n'est pas négative", "la plus petite des deux : l'avancement est toujours minimal", "la racine négative : elle correspond au sens indirect", "les deux : elles décrivent les deux sens d'évolution possibles"],
      "bonne_reponse": [
        0
      ],
      "explication": "Et il faut le dire explicitement : c'est une justification attendue, pas un choix implicite.",
      "piege": "Garder la racine négative sans réagir — piège explicitement listé dans la fiche.",
      "image": null,
      "tags": [
        "controle"
      ],
      "actif": true
    },
    {
      "ref": "pil-21",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "À l'anode d'une pile, il se produit :",
      "options": [
        "une oxydation, c'est le pôle ⊕",
        "une oxydation, c'est le pôle ⊖",
        "une réduction, c'est le pôle ⊕",
        "aucune réaction"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Anode → Oxydation → pôle ⊖. Cathode → Réduction → pôle ⊕.",
      "piege": "Confondre anode et cathode — le moyen sûr est de retenir les deux mots qui commencent par une voyelle : Anode, Oxydation.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-22",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "La cathode d'une pile est :",
      "options": [
        "l'électrode reliée au pont salin",
        "le pôle ⊕, siège d'une réduction",
        "toujours à gauche du schéma",
        "le pôle ⊖, siège d'une oxydation"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Cathode → Réduction → pôle ⊕, quelle que soit sa position sur le schéma.",
      "piege": "Se fier à la position sur le dessin plutôt qu'à la nature de la réaction.",
      "image": "pil_daniell.png",
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-23",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Quelles informations de l'énoncé permettent d'identifier la polarité ? <b>Plusieurs réponses.</b>",
      "options": ["la couleur des solutions de chaque demi-pile", "le sens de déplacement des ions du pont salin", "le sens de déplacement du courant ou des électrons", "l'électrode qui subit une oxydation"],
      "bonne_reponse": [
        1,
        2,
        3
      ],
      "explication": "L'énoncé fournit toujours au moins l'une de ces trois informations, ou le signe affiché par un appareil.",
      "piege": "Chercher une information que l'énoncé ne donne pas au lieu d'exploiter celle qui est fournie.",
      "image": "pil_daniell.png",
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-24",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Pour qu'un voltmètre affiche une valeur positive, sa borne COM doit être reliée :",
      "options": [
        "à la borne ⊕ de la pile",
        "au pont salin",
        "à la borne ⊖ de la pile",
        "à l'anode ou à la cathode indifféremment"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est le repère qui permet de déduire la polarité du signe affiché.",
      "piege": "Intervertir les bornes et conclure à une polarité inverse.",
      "image": "pil_daniell.png",
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-25",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Dans la pile Daniell, la demi-équation à l'anode s'écrit :",
      "options": [
        "Zn²⁺ + 2 e⁻ → Zn",
        "Cu²⁺ + 2 e⁻ → Cu",
        "Cu → Cu²⁺ + 2 e⁻",
        "Zn → Zn²⁺ + 2 e⁻"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "À l'anode il y a oxydation : le zinc perd deux électrons.",
      "piege": "Écrire la réduction du zinc : à l'anode, l'espèce est oxydée, elle cède des électrons.",
      "image": "pil_daniell.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-26",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "L'équation de fonctionnement de la pile Daniell est :",
      "options": [
        "Zn + Cu²⁺ → Cu + Zn²⁺",
        "Zn + Cu²⁺ + 2 e⁻ → Cu + Zn²⁺",
        "Zn + Cu → Zn²⁺ + Cu²⁺",
        "Zn²⁺ + Cu → Cu²⁺ + Zn"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Les deux demi-équations échangent deux électrons : ils se simplifient dans la somme.",
      "piege": "Laisser des électrons dans l'équation de fonctionnement — le piège explicite de cette QT.",
      "image": "pil_daniell.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-27",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Remets dans l'ordre l'écriture de l'équation de fonctionnement :",
      "options": [
        "égaliser le nombre d'électrons échangés",
        "sommer : les électrons se simplifient",
        "écrire l'oxydation à l'anode",
        "écrire la réduction à la cathode"
      ],
      "bonne_reponse": [
        2,
        3,
        0,
        1
      ],
      "explication": "L'égalisation est indispensable dès que les deux couples n'échangent pas le même nombre d'électrons.",
      "piege": "Sommer sans égaliser, et se retrouver avec des électrons dans le bilan.",
      "image": "pil_daniell.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-28",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Dans le circuit extérieur, les électrons se déplacent :",
      "options": [
        "dans les deux sens",
        "de l'anode vers la cathode",
        "de la cathode vers l'anode",
        "dans le pont salin"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Toujours de l'anode vers la cathode. Le courant, lui, circule en sens inverse.",
      "piege": "Confondre le sens des électrons et celui du courant conventionnel.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "actif": true
    },
    {
      "ref": "pil-29",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Dans le pont salin, les <b>cations</b> migrent vers :",
      "options": [
        "la cathode",
        "l'anode",
        "les deux électrodes",
        "aucune électrode"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le repère : cations → cathode, anions → anode. Les deux mots commencent par la même lettre.",
      "piege": "Appliquer aux ions le sens de déplacement des électrons — le piège explicite de cette QT.",
      "image": "pil_daniell.png",
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-30",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Quels sont les rôles du pont salin ? <b>Plusieurs réponses.</b>",
      "options": ["transporter les électrons d'une demi-pile à l'autre", "fermer le circuit électrique entre les deux demi-piles", "assurer l'électroneutralité de chaque demi-pile", "augmenter la tension délivrée par la pile"],
      "bonne_reponse": [
        1,
        2
      ],
      "explication": "Les porteurs de charge y sont les <b>ions</b>, jamais les électrons.",
      "piege": "Croire que les électrons traversent le pont salin : ils circulent dans le circuit extérieur.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-31",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "La capacité d'une pile se calcule par :",
      "options": ["Q = I/Δt = n(e⁻)/F", "Q = F/n(e⁻) = I/Δt", "Q = n(e⁻)/F = I/Δt", "Q = I × Δt = n(e⁻) × F"],
      "bonne_reponse": [
        3
      ],
      "explication": "Deux expressions de la même charge : l'une par la mesure électrique, l'autre par la chimie.",
      "piege": "Diviser par Δt au lieu de multiplier : la capacité est une charge, en coulombs.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-32",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Remets dans l'ordre le calcul de la durée de vie d'une pile à partir d'une masse consommée :",
      "options": [
        "n(e⁻) = N × n(métal), avec N lu sur la demi-équation",
        "Δt = Q / I",
        "n(métal) = m / M",
        "Q = n(e⁻) × F"
      ],
      "bonne_reponse": [
        2,
        0,
        3,
        1
      ],
      "explication": "L'étape 2 est celle qu'on oublie : la demi-équation donne le nombre d'électrons par atome.",
      "piege": "Oublier le facteur N — deux électrons par atome de zinc, pas un.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-33",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Une masse m = 10 g de zinc a été consommée (M = 65,4 g·mol⁻¹). Quelle quantité d'électrons a circulé ?",
      "options": [
        "0,306 mol",
        "0,076 mol",
        "0,153 mol",
        "10 mol"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "n(Zn) = 10/65,4 = 0,153 mol, et la demi-équation Zn → Zn²⁺ + 2 e⁻ donne n(e⁻) = 2 × 0,153 = 0,306 mol.",
      "piege": "Rendre n(Zn) au lieu de n(e⁻) : il faut passer par la demi-équation.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-34",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Avec n(e⁻) = 0,306 mol, F = 9,65×10⁴ C·mol⁻¹ et I = 0,10 A, quelle est la durée de vie ?",
      "options": ["Δt = n(e⁻)·F/(10·I) = 2,95 × 10⁴ s, soit environ 8,2 h", "Δt = n(e⁻)·F/I = 2,95 × 10⁵ s, soit environ 82 h", "Δt = n(e⁻)/(F·I) = 3,2 × 10⁻⁵ s, soit une durée nulle", "Δt = I/(n(e⁻)·F) = 3,4 × 10⁻⁶ s, soit une durée nulle"],
      "bonne_reponse": [
        1
      ],
      "explication": "Q = 0,306 × 9,65×10⁴ = 2,95×10⁴ C, puis Δt = Q/I = 2,95×10⁵ s ≈ 82 h.",
      "piege": "Rendre la capacité en coulombs à la place de la durée : il reste à diviser par I.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "pil-35",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelles sont les deux comparaisons qui résument tout le chapitre ?",
      "options": [
        "K contre 1, et τ contre 0",
        "Q<sub>r</sub> contre c⁰, et K contre T",
        "τ contre 1, et Q<sub>r</sub>,i contre K(T)",
        "x<sub>eq</sub> contre V, et I contre Δt"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "τ dit si la transformation est totale ; Q<sub>r</sub>,i contre K dit dans quel sens le système évolue.",
      "piege": "Chercher une troisième idée : tout le reste, piles comprises, découle de ces deux comparaisons.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "pil-36",
      "chapitre": "sens-d-evolution-spontanee-et-piles",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Un élève écrit Q<sub>r</sub> en y faisant figurer le solvant liquide. Que faut-il corriger ?",
      "options": ["l'activité du solvant vaut 1 : il n'apparaît pas au quotient", "l'activité du solvant vaut sa concentration : 55,5 mol·L⁻¹", "l'activité du solvant s'élève au carré, l'eau étant en excès", "rien : le solvant figure bien dans l'expression du quotient"],
      "bonne_reponse": [
        0
      ],
      "explication": "Même règle pour les solides. C'est la première chose que le correcteur vérifie.",
      "piege": "Recopier tous les termes de l'équation dans le quotient sans réfléchir aux activités.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {"ref": "piles-t01", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Une transformation est dite limitée lorsque :", "options": ["la réaction est lente : l'équilibre met du temps à s'établir", "l'avancement final est inférieur au maximal : il reste des réactifs", "elle libère peu d'énergie : l'avancement s'arrête de lui-même", "un seul réactif est consommé : l'autre reste intégralement"], "bonne_reponse": [1], "explication": "On compare x_f à x_max. Si x_f &lt; x_max, aucun réactif n'a disparu : la transformation est limitée. Le taux d'avancement τ = x_f/x_max est alors inférieur à 1.", "piege": "Confondre limitée et lente : une réaction limitée peut être très rapide.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t02", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Pour la réaction Cu²⁺(aq) + Zn(s) → Cu(s) + Zn²⁺(aq), le quotient de réaction s'écrit :", "options": ["Q_r = [Cu²⁺]·[Zn²⁺]", "Q_r = [Cu²⁺]/[Zn²⁺]", "Q_r = [Zn²⁺]/[Cu²⁺]", "Q_r = [Zn²⁺]·[Cu]/([Cu²⁺]·[Zn])"], "bonne_reponse": [2], "explication": "Produits au numérateur, réactifs au dénominateur, chaque concentration à la puissance de son coefficient. Les solides n'apparaissent pas : leur activité vaut 1.", "piege": "Faire apparaître les solides Cu et Zn : seules les espèces dissoutes et les gaz interviennent.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t03", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Le quotient de réaction initial vaut Q_r,i = 10 et la constante d'équilibre K = 10³⁷. Le système évolue :", "options": ["dans le sens direct, car K est grand", "dans le sens indirect, car Q_r,i &lt; K", "dans le sens direct, car Q_r,i &lt; K", "il n'évolue pas"], "bonne_reponse": [2], "explication": "Le système évolue de façon à ce que Q_r tende vers K. Si Q_r &lt; K, Q_r doit augmenter : les produits se forment, sens direct.", "piege": "Justifier par la seule grandeur de K : c'est la COMPARAISON de Q_r,i à K qui donne le sens.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t04", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "La constante d'équilibre K est :", "options": ["le rapport des quantités de matière finales, propre à chaque essai", "la valeur du quotient de réaction à l'équilibre, qui ne dépend que de T", "la valeur de Q_r à l'état initial, avant toute évolution du système", "une grandeur qui dépend des concentrations initiales du mélange"], "bonne_reponse": [1], "explication": "K = Q_r,éq. C'est une caractéristique de la réaction à une température donnée : les concentrations initiales ne la changent pas, elles changent seulement l'état final.", "piege": "Croire que K dépend de ce qu'on met au départ : c'est x_f qui en dépend, pas K.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t05", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Pour AH + H₂O = A⁻ + H₃O⁺ avec [AH]₀ = C et un avancement volumique x_éq, la relation K = x_éq²/(C − x_éq) permet de trouver x_éq en :", "options": ["posant x_éq = √(K·C), approximation valable si K est très petit", "posant x_éq = K·C, l'avancement étant proportionnel aux deux", "résolvant x² + K·x − K·C = 0, et en gardant la racine positive", "posant x_éq = C, tout l'acide étant dissocié à l'équilibre"], "bonne_reponse": [2], "explication": "K(C − x) = x² donne x² + Kx − KC = 0. Une seule racine est physiquement acceptable : positive et inférieure à C. L'approximation √(KC) n'est valable que si x ≪ C.", "piege": "Appliquer √(KC) sans vérifier que x ≪ C : c'est une approximation, pas la résolution.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t06", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Dans une pile, l'anode est l'électrode où :", "options": ["se produit la réduction ; c'est le pôle positif", "se produit l'oxydation ; c'est le pôle positif", "arrivent les électrons", "se produit l'oxydation ; c'est le pôle négatif"], "bonne_reponse": [3], "explication": "Anode = oxydation, toujours. Dans une pile, les électrons libérés par l'oxydation sortent par cette électrode : elle est négative. La cathode, siège de la réduction, est positive.", "piege": "Associer anode et pôle + : c'est vrai en électrolyse, faux dans une pile.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t07", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Une pile met en jeu les couples Ag⁺/Ag et Cu²⁺/Cu, l'argent étant le pôle positif. L'équation de fonctionnement est :", "options": ["2 Ag + Cu²⁺ → 2 Ag⁺ + Cu", "Ag⁺ + Cu → Ag + Cu²⁺", "Ag⁺ + Cu²⁺ → Ag + Cu", "2 Ag⁺ + Cu → 2 Ag + Cu²⁺"], "bonne_reponse": [3], "explication": "Pôle + : réduction Ag⁺ + e⁻ → Ag. Pôle − : oxydation Cu → Cu²⁺ + 2e⁻. On multiplie la première par 2 pour égaler les électrons, puis on additionne.", "piege": "Oublier d'équilibrer les électrons : une demi-équation en échange un, l'autre deux.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t08", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Dans une pile en fonctionnement :", "options": ["les électrons vont du ⊖ au ⊕ dans le pont salin, les ions dans le fil", "les électrons vont du ⊖ au ⊕ dans le circuit extérieur, les anions à l'anode", "les ions circulent dans le fil, les électrons dans le pont salin", "les électrons vont du ⊕ au ⊖ dans le circuit extérieur, les anions à la cathode"], "bonne_reponse": [1], "explication": "Les électrons ne circulent que dans les conducteurs métalliques, du − vers le +. Dans le pont salin et les solutions, ce sont les ions qui assurent le courant : les anions compensent les cations créés à l'anode.", "piege": "Faire passer des électrons dans le pont salin : une solution ne conduit que par ses ions.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "piles-t09", "chapitre": "piles", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Une pile consomme au maximum n = 0,050 mol de zinc, avec 2 électrons échangés par atome. Sa capacité vaut :", "options": ["Q = n·z·F = 0,050 × 2 × 96 500 = 9,7 × 10³ C", "Q = n·z = 0,050 × 2 = 0,10 C", "Q = n·F = 0,050 × 96 500 = 4,8 × 10³ C", "Q = z·F = 2 × 96 500 = 1,9 × 10⁵ C"], "bonne_reponse": [0], "explication": "Q = n(e⁻)·F = n·z·F : quantité de matière du réactif limitant, fois le nombre d'électrons échangés par mole, fois le faraday. La durée de vie à intensité I vaut Δt = Q/I.", "piege": "Oublier z : chaque atome de zinc libère DEUX électrons.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  titrages: [
    {
      "ref": "tit-01",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Dans un titrage, la solution <b>titrée</b> est :",
      "options": [
        "celle du bécher, de concentration inconnue",
        "celle qui change de couleur",
        "celle de la burette, de concentration connue",
        "celle du pont salin"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Titré = inconnu, dans l'erlenmeyer. Titrant = connu, dans la burette graduée.",
      "piege": "Confondre titré et titrant — l'erreur qui inverse tout le calcul final.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "tit-02",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "À quoi sert un titrage ?",
      "options": ["à mesurer le pH d'une solution de concentration inconnue", "à déterminer la quantité de matière d'une espèce en solution", "à séparer deux espèces présentes dans une même solution", "à accélérer une réaction lente entre deux espèces dissoutes"],
      "bonne_reponse": [
        1
      ],
      "explication": "On en déduit ensuite une concentration, ou un pourcentage en masse.",
      "piege": "Le confondre avec une simple mesure de pH : le titrage repose sur une réaction chimique.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-03",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Pour un titrage <b>colorimétrique</b>, quel appareil faut-il ?",
      "options": ["un pH-mètre, pour suivre l'évolution du pH au cours du versement", "un conductimètre, pour suivre la conductivité de la solution", "aucun : l'équivalence se repère au changement de couleur", "un spectrophotomètre, pour suivre l'absorbance de la solution"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le volume équivalent se lit alors directement sur la burette graduée.",
      "piege": "Croire qu'un appareil de mesure est toujours nécessaire.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-04",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Quelles propriétés la réaction support doit-elle vérifier ? <b>Plusieurs réponses.</b>",
      "options": [
        "rapide",
        "exothermique",
        "unique",
        "totale"
      ],
      "bonne_reponse": [
        0,
        2,
        3
      ],
      "explication": "Les trois adjectifs sont attendus, chacun avec sa justification.",
      "piege": "N'en citer que deux : le barème compte les trois séparément.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-05",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Pourquoi la réaction support doit-elle être <b>totale</b> ?",
      "options": ["pour que la sonde reste immergée pendant tout le versement", "pour que le titrage se déroule plus vite, la réaction étant rapide", "pour que la solution change nettement de couleur à l'équivalence", "sinon les réactifs ne seraient pas entièrement consommés à l'équivalence"],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est la justification attendue : sans transformation totale, l'équivalence perd son sens.",
      "piege": "Citer l'adjectif sans le justifier — chaque propriété demande sa phrase.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "tit-06",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Pourquoi la réaction support doit-elle être <b>unique</b> ?",
      "options": ["pour éviter une réaction parasite qui consommerait le réactif titrant", "pour que le pH varie nettement au voisinage de l'équivalence", "pour économiser du réactif titrant, qui coûte cher à préparer", "pour que la courbe obtenue soit une droite de part et d'autre"],
      "bonne_reponse": [
        0
      ],
      "explication": "Sinon le volume versé ne correspondrait plus à l'espèce que l'on veut titrer.",
      "piege": "Confondre « unique » et « totale » : ce sont deux exigences différentes.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-07",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La relation à l'équivalence s'écrit :",
      "options": ["n(titré)_i × a = n(titrant)_éq × b", "n(titré)_i/a = n(titrant)_éq/b, avec a et b les coefficients stœchiométriques", "n(titré)_i = n(titrant)_éq, sans les coefficients stœchiométriques", "n(titré)_éq/a = n(titrant)_i/b, avec a et b les coefficients stœchiométriques"],
      "bonne_reponse": [
        1
      ],
      "explication": "Les coefficients viennent de l'équation support : les oublier est l'erreur la plus coûteuse du chapitre.",
      "piege": "Écrire n(A) = n(B) sans vérifier a et b — faux dès que les coefficients diffèrent.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "tit-08",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Qu'appelle-t-on l'équivalence d'un titrage ?",
      "options": ["le moment où le pH de la solution atteint exactement 7,0", "la fin du versement, quand la burette est entièrement vidée", "l'instant où les réactifs sont dans les proportions stœchiométriques", "le moment où la solution change de couleur dans le bécher"],
      "bonne_reponse": [
        2
      ],
      "explication": "Les deux réactifs sont alors entièrement consommés : c'est ce qui permet d'écrire la relation.",
      "piege": "Définir l'équivalence par le changement de couleur, qui n'en est qu'un moyen de repérage.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-09",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "On titre V<sub>A</sub> = 20,0 mL d'acide chlorhydrique par C<sub>B</sub> = 5,0×10⁻² mol·L⁻¹ ; V<sub>éq</sub> = 16,4 mL, a = b = 1. Que vaut C<sub>A</sub> ?",
      "options": [
        "6,1×10⁻² mol·L⁻¹",
        "1,6×10⁻² mol·L⁻¹",
        "8,2×10⁻² mol·L⁻¹",
        "4,1×10⁻² mol·L⁻¹"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C<sub>A</sub> = C<sub>B</sub> × V<sub>éq</sub> / V<sub>A</sub> = 5,0×10⁻² × 16,4/20,0 = 4,1×10⁻² mol·L⁻¹.",
      "piege": "Inverser les volumes : le rapport V<sub>éq</sub>/V<sub>A</sub> est inférieur à 1 ici.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "tit-10",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Faut-il convertir les volumes en litres dans ce calcul ?",
      "options": ["non ici, car les volumes apparaissent en rapport", "non, jamais : les litres se simplifient toujours", "seulement si les concentrations sont en mmol·L⁻¹", "oui, toujours : le système international l'impose"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le rapport V<sub>éq</sub>/V<sub>A</sub> est sans dimension : les millilitres se simplifient. Il faut néanmoins le vérifier.",
      "piege": "Convertir mécaniquement, ou au contraire ne jamais vérifier — les deux font perdre du temps ou des points.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-11",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Pour 5 Fe²⁺ + 1 MnO₄⁻, la relation à l'équivalence s'écrit :",
      "options": [
        "n(Fe²⁺) = n(MnO₄⁻)",
        "n(Fe²⁺)/5 = n(MnO₄⁻)/1",
        "n(Fe²⁺) = 5 × n(MnO₄⁻) × V",
        "n(Fe²⁺) × 5 = n(MnO₄⁻)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Chaque quantité est divisée par son coefficient stœchiométrique.",
      "piege": "Écrire n(A) = n(B) : le résultat serait faux d'un facteur 5.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-12",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre la méthode des tangentes :",
      "options": [
        "repérer son intersection avec la courbe : c'est le point équivalent",
        "descendre à la verticale pour lire V<sub>éq</sub>, et à l'horizontale pour lire pH_éq",
        "tracer la parallèle équidistante de ces deux tangentes",
        "tracer deux tangentes parallèles à la courbe, de part et d'autre du saut de pH"
      ],
      "bonne_reponse": [
        3,
        2,
        0,
        1
      ],
      "explication": "Le correcteur attend de voir les trois droites et les deux traits de lecture.",
      "piege": "Effacer la construction, ou lire le saut de pH à l'œil.",
      "image": "tit_ph.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-13",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Sur la courbe dérivée dpH/dV, l'équivalence correspond :",
      "options": [
        "au premier point",
        "à l'intersection avec l'axe",
        "au maximum de la courbe",
        "au minimum de la courbe"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "La dérivée est maximale là où le pH varie le plus vite, c'est-à-dire à l'équivalence.",
      "piege": "Chercher un point d'annulation : c'est un maximum, pas un zéro.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-14",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Quand faut-il obligatoirement utiliser la méthode des tangentes ?",
      "options": ["pour un titrage conductimétrique, où le saut est net", "jamais, si la dérivée dpH/dV est déjà fournie", "toujours, quel que soit le type de titrage", "quand seule la courbe pH = f(V) est donnée, et qu'on a besoin de pH_éq"],
      "bonne_reponse": [
        3
      ],
      "explication": "Seules les tangentes donnent aussi le pH à l'équivalence, indispensable pour choisir l'indicateur coloré.",
      "piege": "Utiliser la dérivée puis se retrouver sans pH_éq pour la question suivante.",
      "image": "tit_ph.png",
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "tit-15",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Sur une courbe conductimétrique, l'équivalence se repère :",
      "options": ["à la rupture de pente, intersection des deux portions de droite", "au premier point de mesure, avant tout versement de titrant", "au maximum de σ, atteint au voisinage de l'équivalence", "quand σ s'annule, tous les ions ayant alors été consommés"],
      "bonne_reponse": [
        0
      ],
      "explication": "Deux droites de pentes différentes se coupent au volume équivalent.",
      "piege": "Chercher un saut brutal comme en pH-métrie : la courbe conductimétrique est faite de segments de droite.",
      "image": "tit_conducti.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-16",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Un indicateur coloré convient si :",
      "options": [
        "son pKa vaut 7",
        "sa zone de virage <b>contient</b> le pH à l'équivalence",
        "sa couleur est visible",
        "sa zone de virage est proche du pH à l'équivalence"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Il ne suffit pas qu'elle soit proche : elle doit encadrer la valeur.",
      "piege": "Se contenter d'une zone « proche » du pH équivalent — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "tit-17",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Le pH à l'équivalence vaut 8,2. Lequel convient : bleu de bromothymol (6,0 − 7,6) ou phénolphtaléine (8,2 − 10,0) ?",
      "options": [
        "la phénolphtaléine",
        "le bleu de bromothymol",
        "les deux",
        "aucun des deux"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "8,2 appartient à la zone de la phénolphtaléine, pas à celle du bleu de bromothymol.",
      "piege": "Choisir le bleu de bromothymol parce que 7,6 est « presque » 8,2.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-18",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Remets dans l'ordre le choix d'un indicateur coloré :",
      "options": [
        "déterminer le pH à l'équivalence sur la courbe pH = f(V), par la méthode des tangentes",
        "relever la zone de virage de chaque indicateur proposé",
        "conclure sur l'indicateur à utiliser",
        "vérifier laquelle contient le pH à l'équivalence"
      ],
      "bonne_reponse": [
        0,
        1,
        3,
        2
      ],
      "explication": "La première étape est indispensable : sans pH_éq, aucun choix ne peut être justifié.",
      "piege": "Choisir l'indicateur avant d'avoir lu le pH à l'équivalence.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-19",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Pour justifier l'allure d'une courbe conductimétrique, on écrit :",
      "options": ["la loi de Beer-Lambert avant puis après l'équivalence", "la relation à l'équivalence avant puis après le point équivalent", "l'équation de la réaction support avant puis après l'équivalence", "la loi de Kohlrausch avant puis après l'équivalence"],
      "bonne_reponse": [
        3
      ],
      "explication": "On liste tous les ions présents, on suit l'évolution de leur concentration, puis on compare leurs λ si besoin.",
      "piege": "Oublier les ions spectateurs, qui figurent pourtant dans la somme.",
      "image": "tit_conducti.png",
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-20",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "On titre une solution de soude (Na⁺ ; HO⁻) par de l'acide chlorhydrique (H₃O⁺ ; Cl⁻). <b>Données</b> : conductivités molaires ioniques, en mS·m²·mol⁻¹ — λ(HO⁻) = 19,9 ; λ(H₃O⁺) = 35,0 ; λ(Na⁺) = 5,01 ; λ(Cl⁻) = 7,63. Avant l'équivalence, la conductivité :",
      "options": ["diminue, car les ions HO⁻ sont remplacés par des ions Cl⁻ moins conducteurs", "augmente, car les ions Cl⁻ versés s'ajoutent aux ions HO⁻ présents", "reste constante, car les ions Na⁺ ne participent pas à la réaction", "s'annule, car les ions HO⁻ et H₃O⁺ se neutralisent exactement"],
      "bonne_reponse": [
        0
      ],
      "explication": "λ(HO⁻) > λ(Cl⁻) : le remplacement fait baisser σ. Les ions Na⁺ restent spectateurs.",
      "piege": "Conclure sans comparer les conductivités molaires ioniques λ.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-21",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "On titre une solution de soude (Na⁺ ; HO⁻) par de l'acide chlorhydrique (H₃O⁺ ; Cl⁻). <b>Données</b> : conductivités molaires ioniques, en mS·m²·mol⁻¹ — λ(HO⁻) = 19,9 ; λ(H₃O⁺) = 35,0 ; λ(Na⁺) = 5,01 ; λ(Cl⁻) = 7,63. Après l'équivalence, la conductivité :",
      "options": ["dépend de la seule température, les ions n'intervenant plus", "augmente, car les ions H₃O⁺ et Cl⁻ versés s'accumulent en solution", "continue de diminuer, car les ions HO⁻ et Cl⁻ versés s'accumulent", "reste constante, car le nombre total d'ions ne varie plus"],
      "bonne_reponse": [
        1
      ],
      "explication": "Plus rien ne consomme les ions versés : leur concentration croît, et σ avec elle.",
      "piege": "Croire que la courbe continue de descendre : c'est la rupture de pente qui donne V<sub>éq</sub>.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-22",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Quel est l'intérêt de la rupture de pente ?",
      "options": [
        "elle indique la fin de la réaction",
        "elle donne la concentration directement",
        "son abscisse donne le volume équivalent",
        "elle donne le pH à l'équivalence"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est l'intersection des deux portions de droite qui donne V<sub>éq</sub>.",
      "piege": "Chercher le point le plus bas de la courbe : c'est bien l'intersection des deux droites qu'il faut.",
      "image": "tit_conducti.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-23",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Pourquoi ajoute-t-on de l'eau distillée avant un titrage conductimétrique ? <b>Plusieurs réponses.</b>",
      "options": [
        "pour diminuer la quantité de matière titrée",
        "pour accélérer la réaction",
        "pour rendre négligeable l'effet de la dilution sur la courbe",
        "pour immerger totalement la sonde"
      ],
      "bonne_reponse": [
        2,
        3
      ],
      "explication": "Deux raisons, toutes deux attendues. Le volume versé devient petit devant le volume total, et les portions restent des droites.",
      "piege": "Croire que cet ajout modifie la quantité titrée : le résultat du titrage est inchangé.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-24",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "L'ajout d'eau distillée modifie-t-il le résultat du titrage ?",
      "options": ["oui : il augmente le volume équivalent, donc la concentration trouvée", "non : la quantité de matière de l'espèce titrée reste inchangée", "oui : il divise la concentration trouvée par le facteur de dilution", "cela dépend du volume ajouté, au-delà de 10 mL le résultat change"],
      "bonne_reponse": [
        1
      ],
      "explication": "On ajoute du solvant, pas du soluté : n(titré) reste le même, donc V<sub>éq</sub> aussi.",
      "piege": "Croire qu'il faut corriger le résultat d'un facteur de dilution — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-25",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Si la sonde n'est pas totalement immergée, que se passe-t-il ?",
      "options": ["le volume équivalent double, la conductivité étant divisée par deux", "la réaction ne se produit pas, faute de contact entre les réactifs", "la surface des plaques en contact varie, et la mesure est faussée", "rien : la sonde mesure la conductivité quelle que soit l'immersion"],
      "bonne_reponse": [
        2
      ],
      "explication": "La constante de cellule L/S n'est plus constante : la conductivité mesurée n'a plus de sens.",
      "piege": "Négliger ce détail expérimental, souvent demandé en justification.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "tit-26",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Pour remonter de la solution titrée à la solution commerciale, on :",
      "options": [
        "divise par le facteur de dilution F",
        "multiplie par le facteur de dilution F",
        "ajoute F",
        "ne change rien"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La dilution a divisé la concentration par F : on la multiplie donc par F.",
      "piege": "Diviser au lieu de multiplier — l'erreur explicitement listée.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "tit-27",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Le pourcentage en masse s'exprime :",
      "options": [
        "ω = C × M × ρ",
        "ω = C / (M × ρ)",
        "ω = C × M / ρ",
        "ω = ρ / (C × M)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "ω = m(X)/m_solution : en écrivant m(X) = C·V·M et m_solution = ρ·V, le volume se simplifie.",
      "piege": "Inverser le rapport et obtenir un pourcentage supérieur à 100 %.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-28",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Avant de calculer ω = C × M / ρ, quelle conversion s'impose ?",
      "options": [
        "convertir C en mol·m⁻³",
        "convertir M en kg·mol⁻¹",
        "convertir ρ de g·mL⁻¹ en g·L⁻¹",
        "aucune"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "1,10 g·mL⁻¹ = 1100 g·L⁻¹ : sans cette conversion, le résultat est faux d'un facteur mille.",
      "piege": "Utiliser ρ en g·mL⁻¹ — le piège explicitement listé pour cette QT.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "tit-29",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "C_titrée = 4,1×10⁻² mol·L⁻¹, F = 10, M = 36,5 g·mol⁻¹, ρ = 1,10 g·mL⁻¹. Quel est le pourcentage en masse ?",
      "options": [
        "1,4 %",
        "4,1 %",
        "0,14 %",
        "14 %"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "C<sub>com</sub> = 10 × 4,1×10⁻² = 0,41 mol·L⁻¹, puis ω = 0,41 × 36,5 / 1100 = 1,4×10⁻², soit 1,4 %.",
      "piege": "Oublier la conversion de ρ et trouver 14 %.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "tit-30",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Quand l'énoncé fournit l'incertitude-type u(X), on évalue la cohérence par :",
      "options": [
        "l'écart relatif",
        "le z-score",
        "la moyenne",
        "l'écart-type"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "z = |X<sub>exp</sub> − X<sub>réf</sub>| / u(X). On conclut à la cohérence si z &lt; 2.",
      "piege": "Calculer un écart relatif alors que l'incertitude est donnée : le z-score est attendu.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-31",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Sans incertitude fournie, on calcule :",
      "options": ["la différence brute entre la valeur trouvée et celle de référence", "le z-score, quotient de l'écart par l'incertitude sur la mesure", "l'écart relatif, rapporté à la valeur de référence", "la moyenne des deux valeurs, trouvée et de référence"],
      "bonne_reponse": [
        2
      ],
      "explication": "e = |X<sub>exp</sub> − X<sub>réf</sub>| / X<sub>réf</sub>. On conclut généralement à la cohérence si e &lt; 5 %.",
      "piege": "Rapporter l'écart à la valeur mesurée au lieu de la valeur de référence.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-32",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Le fabricant annonce 0,40 mol·L⁻¹ et on mesure 0,41 mol·L⁻¹. Quel est l'écart relatif ?",
      "options": [
        "2,4 %",
        "10 %",
        "0,01 %",
        "2,5 %"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "e = |0,41 − 0,40| / 0,40 = 0,025, soit 2,5 % : inférieur à 5 %, le résultat est cohérent.",
      "piege": "Diviser par 0,41, la valeur mesurée, au lieu de 0,40, la référence.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-33",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Un z-score vaut 3,4. Que conclut-on ?",
      "options": ["le résultat n'est pas cohérent avec la valeur de référence", "l'incertitude est nulle, le z-score étant alors très grand", "le résultat est cohérent avec la valeur de référence", "la mesure est parfaite, le z-score dépassant l'unité"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le critère usuel est z &lt; 2 : au-delà, l'écart n'est pas explicable par la seule incertitude.",
      "piege": "Croire qu'un grand z-score signale une mesure précise.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-34",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelle est l'erreur la plus coûteuse du chapitre ?",
      "options": ["mal lire la burette, et fausser ainsi le volume équivalent", "oublier les coefficients stœchiométriques dans la relation à l'équivalence", "oublier de convertir les volumes en litres avant le calcul", "ne pas agiter la solution, et fausser ainsi la mesure de la sonde"],
      "bonne_reponse": [
        1
      ],
      "explication": "n(titré)/a = n(titrant)/b : les coefficients viennent de l'équation support.",
      "piege": "Écrire n(A) = n(B) par habitude, ce qui n'est vrai que si a = b = 1.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "tit-35",
      "chapitre": "les-titrages",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "À la <b>demi-équivalence</b> d'un titrage pH-métrique, que lit-on ?",
      "options": [
        "la concentration",
        "le pH à l'équivalence",
        "le pKa du couple titré",
        "le volume équivalent"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "En ce point [A⁻] = [AH], donc d'après Henderson pH = pKa : c'est le lien avec le chapitre sur la force d'un acide.",
      "piege": "Confondre équivalence et demi-équivalence : la première donne la concentration, la seconde le pKa.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "titrages-t01", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "La réaction support d'un titrage doit être :", "options": ["exothermique", "réversible, pour atteindre l'équilibre", "lente, pour laisser le temps de mesurer", "totale, rapide et unique"], "bonne_reponse": [3], "explication": "Totale : tout le réactif titré est consommé. Rapide : chaque ajout réagit aussitôt. Unique : rien ne vient perturber le bilan. Sans ces trois propriétés, l'équivalence ne se lit pas.", "piege": "Croire qu'une réaction lente convient : on ne saurait plus quand l'équivalence est atteinte.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "titrages-t02", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "On titre V_A = 20,0 mL d'acide par une base de concentration C_B = 0,10 mol·L⁻¹, l'équivalence étant atteinte pour V_éq = 12,0 mL. La réaction est 1:1. La concentration de l'acide vaut :", "options": ["C_A = C_B·V_A/V_éq = 0,10 × 20,0/12,0 = 0,17 mol·L⁻¹", "C_A·V_A = C_B·V_éq, donc C_A = 0,10 × 12,0/20,0 = 6,0 × 10⁻² mol·L⁻¹", "C_A = C_B = 0,10 mol·L⁻¹, les volumes se simplifiant à l'équivalence", "C_A = C_B·V_éq = 0,10 × 12,0 = 1,2 mol·L⁻¹, sans diviser par V_A"], "bonne_reponse": [1], "explication": "À l'équivalence, les réactifs sont dans les proportions stœchiométriques : n_A = n_B, soit C_A·V_A = C_B·V_éq. On isole C_A.", "piege": "Inverser V_A et V_éq : c'est le volume de la solution TITRÉE qui multiplie C_A.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "titrages-t03", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Sur une courbe pH = f(V) de titrage acide fort–base forte, le volume équivalent se détermine par :", "options": ["le volume où le pH commence à augmenter nettement", "le maximum de la courbe pH = f(V) au saut", "la méthode des tangentes", "le point où pH = 7, quel que soit le titrage"], "bonne_reponse": [2], "explication": "La méthode des tangentes localise le point d'inflexion. Les traits doivent apparaître sur la copie : ce sont eux qui prouvent la construction.", "piege": "Chercher pH = 7 : ce n'est vrai qu'en acide fort–base forte, et ce n'est pas une méthode de construction.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "titrages-t04", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Un titrage a un pH à l'équivalence de 8,7. Parmi les indicateurs, on choisit :", "options": ["l'hélianthine (3,1 – 4,4), dont le virage est le plus visible", "celui dont la zone de virage est la plus large, pour être sûr de la voir", "n'importe lequel : le choix de l'indicateur ne change pas V_éq", "celui dont la zone de virage contient 8,7 : la phénolphtaléine (8,2 – 10,0)"], "bonne_reponse": [3], "explication": "L'indicateur doit changer de couleur au moment de l'équivalence : sa zone de virage doit contenir pH_éq. Sinon le virage se produit trop tôt ou trop tard.", "piege": "Choisir par la couleur ou la largeur de zone : seul le pH à l'équivalence compte.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "titrages-t05", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Lors d'un titrage conductimétrique, la courbe σ = f(V) est formée de deux segments de droite. Le changement de pente à l'équivalence s'explique par :", "options": ["une hausse de température au moment du saut", "un changement des ions présents en solution", "l'arrêt brutal de la réaction support", "la dilution, qui devient alors négligeable"], "bonne_reponse": [1], "explication": "Avant l'équivalence, chaque ajout remplace un ion par un autre de conductivité molaire différente. Après, les ions ajoutés s'accumulent : la pente change. L'ajout d'eau rend la dilution négligeable, d'où des droites.", "piege": "Attribuer la cassure à la dilution : c'est justement l'ajout d'eau qui la rend négligeable et donne des segments droits.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "titrages-t06", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "En titrage conductimétrique, on ajoute un grand volume d'eau distillée à la solution titrée afin de :", "options": ["diluer le réactif titré pour ralentir la réaction", "permettre à la sonde d'être immergée, sans autre effet", "augmenter la conductivité", "rendre la dilution négligeable pendant le titrage, pour que σ varie linéairement"], "bonne_reponse": [3], "explication": "Si le volume total varie peu, les concentrations ne sont modifiées que par la réaction, pas par la dilution : σ devient une fonction affine de V, et l'équivalence se lit à l'intersection de deux droites.", "piege": "Croire que l'eau change les quantités de matière : elle ne change que le volume, donc les concentrations — et c'est ce qu'on veut rendre négligeable.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "titrages-t07", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Un vinaigre a été dilué 10 fois avant titrage. La solution diluée a une concentration de 0,12 mol·L⁻¹. La concentration du vinaigre commercial vaut :", "options": ["C = 0,12 mol·L⁻¹", "C = 0,12 + 10 = 10,12 mol·L⁻¹", "C = 10 × 0,12 = 1,2 mol·L⁻¹", "C = 0,12/10 = 1,2 × 10⁻² mol·L⁻¹"], "bonne_reponse": [2], "explication": "La dilution divise la concentration par le facteur de dilution : C_mère = F × C_fille. Puis on remonte à la masse par litre avec M, et au pourcentage avec la masse volumique.", "piege": "Diviser au lieu de multiplier : la solution mère est plus CONCENTRÉE que la solution diluée.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "titrages-t08", "chapitre": "titrages", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Un titrage donne un pourcentage massique de 6,2 % pour un vinaigre dont l'étiquette annonce 6 %. On peut conclure que :", "options": ["le résultat est cohérent", "le vinaigre est frauduleux", "le titrage est faux", "les deux valeurs diffèrent, aucune conclusion"], "bonne_reponse": [0], "explication": "On calcule l'écart relatif |6,2 − 6|/6 = 3 %. C'est compatible avec l'incertitude d'un titrage — lecture de burette, prélèvement, dilution.", "piege": "Attendre l'égalité exacte : un résultat expérimental est toujours entaché d'incertitude, la cohérence se juge par l'écart relatif.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  analyse: [
    {
      "ref": "ana-01",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Sur un spectre infrarouge, une bande d'absorption apparaît :",
      "options": [
        "comme un creux",
        "comme une droite",
        "comme un pic vers le haut",
        "comme un plateau"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "L'ordonnée est la <b>transmittance</b> en pourcentage : là où la molécule absorbe, la transmittance chute.",
      "piege": "Chercher des pics vers le haut par analogie avec un spectre de masse.",
      "image": "ana_ir.png",
      "tags": [
        "lecture graphique"
      ],
      "actif": true
    },
    {
      "ref": "ana-02",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "En abscisse d'un spectre infrarouge, on porte :",
      "options": [
        "la fréquence en Hz",
        "le nombre d'onde σ = 1/λ en cm⁻¹, gradué de droite à gauche",
        "l'absorbance",
        "la longueur d'onde en nm, graduée de gauche à droite"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L'axe va de 4000 vers 500 cm⁻¹ : c'est la seule échelle du programme graduée à l'envers.",
      "piege": "Lire l'axe de gauche à droite et se tromper de zone spectrale.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-03",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Que représente la zone située en dessous de 1500 cm⁻¹ ?",
      "options": ["les groupes caractéristiques, que l'on identifie un par un", "le bruit de fond de l'appareil, que l'on soustrait au spectre", "l'empreinte digitale de la molécule, que l'on n'interprète pas", "les seules liaisons C=O, que l'on repère à leur finesse"],
      "bonne_reponse": [
        2
      ],
      "explication": "Elle est propre à chaque espèce, mais on n'y lit aucun groupe fonctionnel.",
      "piege": "Chercher un groupe caractéristique sous 1500 cm⁻¹ : la fiche dit explicitement qu'on n'y lit rien.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-04",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Quelle est la phrase type attendue pour exploiter un spectre IR ?",
      "options": ["« la transmittance est faible à x cm⁻¹, donc la liaison est absente »", "« le spectre montre que c'est un alcool, car il descend vers 3300 »", "« le nombre d'onde vaut 1/λ, donc x cm⁻¹ correspond à x nm »", "« j'observe une bande à x cm⁻¹ ; d'après la table, c'est la liaison … »"],
      "bonne_reponse": [
        3
      ],
      "explication": "Décrire la bande, donner sa position, puis citer la table : trois éléments, trois points.",
      "piege": "Conclure directement sans décrire la bande ni citer la table de données.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-05",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "On cherche à distinguer un <b>alcool</b>, un <b>aldéhyde ou une cétone</b> et un <b>acide carboxylique</b>. Quelles deux questions suffisent ?",
      "options": [
        "l'échantillon est-il liquide ? est-il coloré ?",
        "y a-t-il une bande C=O vers 1700 cm⁻¹ ? y a-t-il une bande O—H large ?",
        "quelle est la masse molaire ? quel est le point d'ébullition ?",
        "la molécule est-elle polaire ? contient-elle du carbone ?"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "O—H seule → alcool · C=O seule → aldéhyde ou cétone · les deux → acide carboxylique. D'autres familles portent aussi un C=O — esters, amides — et se distinguent alors sur d'autres bandes.",
      "piege": "Passer en revue toutes les bandes du spectre au lieu de poser ces deux questions.",
      "image": "ana_ir.png",
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "ana-06",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Une bande O—H large vers 3200-3600 cm⁻¹, <b>sans</b> bande C=O, indique :",
      "options": [
        "un aldéhyde",
        "un alcool",
        "un acide carboxylique",
        "une cétone"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "O—H seule sans carbonyle : c'est la signature d'un alcool.",
      "piege": "Conclure à l'acide carboxylique, qui présenterait <b>aussi</b> une bande C=O.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-07",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Une bande C=O vers 1700 cm⁻¹ accompagnée d'une bande O—H très large (2500-3200 cm⁻¹) indique :",
      "options": ["une cétone conjuguée", "un ester aliphatique", "un acide carboxylique", "un alcool secondaire"],
      "bonne_reponse": [
        2
      ],
      "explication": "Les deux bandes ensemble, avec un O—H très large : c'est l'acide carboxylique.",
      "piege": "Voir la bande C=O et conclure trop vite à une cétone, sans regarder le O—H.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-08",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Comment vérifier par IR qu'une oxydation d'alcool a bien eu lieu ?",
      "options": ["en constatant l'élargissement de la bande O—H et le décalage du C—H", "en constatant la disparition de la bande C=O et l'apparition d'une O—H", "en constatant l'apparition d'une bande N—H et la perte du massif C—H", "en constatant la disparition de la bande O—H et l'apparition d'une C=O"],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est la question classique en fin d'exercice de synthèse : le spectre du produit ne porte plus la bande de départ.",
      "piege": "Chercher une nouvelle bande sans vérifier la disparition de l'ancienne.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-09",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "La relation entre conductance et conductivité s'écrit :",
      "options": [
        "σ = G × L/S",
        "σ = G / (L×S)",
        "σ = G × S/L",
        "σ = G + L/S"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "L/S est la <b>constante de cellule</b>, en m⁻¹. G se mesure, σ caractérise la solution.",
      "piege": "Inverser L et S dans la constante de cellule.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "ana-10",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Une cellule de constante L/S = 105 m⁻¹ donne G = 2,4×10⁻³ S. Que vaut la conductivité ?",
      "options": [
        "4,4×10⁴ S·m⁻¹",
        "0,25 S·m⁻¹",
        "2,3×10⁻⁵ S·m⁻¹",
        "2,4×10⁻³ S·m⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "σ = G × L/S = 2,4×10⁻³ × 105 = 0,25 S·m⁻¹.",
      "piege": "Diviser au lieu de multiplier par la constante de cellule.",
      "image": "ana_cellule.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "ana-11",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "La conductance G s'exprime en :",
      "options": [
        "volts",
        "ohms",
        "siemens",
        "siemens par mètre"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "G = 1/R = I/U s'exprime en siemens (S) ; la conductivité σ, elle, est en S·m⁻¹.",
      "piege": "Confondre les unités de G et de σ — l'une caractérise la mesure, l'autre la solution.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-12",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Remets dans l'ordre l'expression de σ en fonction de C pour MgCl₂ :",
      "options": [
        "factoriser par C : σ = C × (λ(Mg²⁺) + 2·λ(Cl⁻))",
        "appliquer Kohlrausch : σ = λ(Mg²⁺)·[Mg²⁺] + λ(Cl⁻)·[Cl⁻]",
        "en déduire [Mg²⁺] = C et [Cl⁻] = 2C",
        "écrire l'équation de dissolution : MgCl₂(s) → Mg²⁺(aq) + 2 Cl⁻(aq)"
      ],
      "bonne_reponse": [
        3,
        2,
        1,
        0
      ],
      "explication": "L'équation de dissolution est indispensable : c'est elle qui donne les concentrations effectives.",
      "piege": "Oublier le coefficient 2 devant l'ion chlorure — une mole de sel en libère deux moles.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-13",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Dans la loi de Kohlrausch, les concentrations s'expriment en :",
      "options": [
        "mol·L⁻¹",
        "g·L⁻¹",
        "mmol·m⁻³",
        "mol·m⁻³"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est le piège d'unité du chapitre. Conversion : 1 mol·m⁻³ = 1×10⁻³ mol·L⁻¹ = 1 mmol·L⁻¹.",
      "piege": "Utiliser des mol·L⁻¹ : le résultat est alors faux d'un facteur mille.",
      "image": null,
      "tags": [
        "unites"
      ],
      "actif": true
    },
    {
      "ref": "ana-14",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "On obtient C = 8,0 mol·m⁻³. Combien cela fait-il en mol·L⁻¹ ?",
      "options": [
        "8,0×10⁻³ mol·L⁻¹",
        "8,0 mol·L⁻¹",
        "8,0×10³ mol·L⁻¹",
        "0,80 mol·L⁻¹"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "On multiplie par 10⁻³ : 8,0 mol·m⁻³ = 8,0×10⁻³ mol·L⁻¹, soit 8,0 mmol·L⁻¹.",
      "piege": "Multiplier par 10³ au lieu de 10⁻³ : le sens de la conversion se contrôle sur l'ordre de grandeur.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-15",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Pour une solution de MgCl₂, la concentration s'isole par :",
      "options": [
        "C = σ × λ(Mg²⁺)",
        "C = σ / (λ(Mg²⁺) + 2·λ(Cl⁻))",
        "C = σ / (λ(Mg²⁺) + λ(Cl⁻))",
        "C = σ × (λ(Mg²⁺) + 2·λ(Cl⁻))"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "On divise la conductivité par la somme pondérée des conductivités molaires ioniques.",
      "piege": "Oublier le facteur 2 devant λ(Cl⁻) au moment d'isoler C.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "ana-16",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Pourquoi dilue-t-on la solution commerciale avant un dosage ?",
      "options": ["parce que le réactif titrant coûte cher et qu'on en économise ainsi", "parce que la couleur devient sinon trop soutenue pour être lue", "parce que Kohlrausch et Beer-Lambert ne valent qu'en solution diluée", "parce que la sonde de mesure ne supporte pas les fortes teneurs"],
      "bonne_reponse": [
        2
      ],
      "explication": "En pratique C &lt; 10⁻² mol·L⁻¹. On choisit de plus le facteur de dilution pour rester dans le domaine de la courbe d'étalonnage.",
      "piege": "Répondre « pour faciliter la mesure » : cela ne rapporte rien, c'est le domaine de validité qui est attendu.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-17",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Le domaine de validité de la loi de Beer-Lambert est :",
      "options": [
        "C &lt; 10⁻² mol·L⁻¹",
        "C > 10⁻² mol·L⁻¹",
        "C &lt; 1 mol·L⁻¹",
        "aucune limite"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Au-delà, la proportionnalité entre absorbance et concentration n'est plus vérifiée.",
      "piege": "Appliquer la loi à une solution commerciale concentrée sans la diluer.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-18",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Comment choisit-on le facteur de dilution ?",
      "options": ["pour que la mesure tombe dans le domaine de la courbe d'étalonnage", "pour que le volume final soit exactement de 100 mL en fiole jaugée", "pour que la valeur lue soit un nombre rond, plus simple à exploiter", "pour qu'il vaille toujours 10, valeur retenue par convention"],
      "bonne_reponse": [
        0
      ],
      "explication": "Sans cela, la lecture serait une extrapolation hors du domaine mesuré.",
      "piege": "Diluer trop et sortir de la courbe par le bas : la lecture est alors tout aussi impossible.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-19",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "La loi de Beer-Lambert s'écrit :",
      "options": [
        "A = C / (ε × ℓ)",
        "A = ε × ℓ × C",
        "A = ε × ℓ / C",
        "A = ε + ℓ + C"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L'absorbance A est <b>sans unité</b> et proportionnelle à la concentration.",
      "piege": "Inverser le rapport, ce qui donnerait une absorbance décroissante avec la concentration.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-20",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 6",
      "enonce": "A = 0,48 dans une cuve de ℓ = 1,0 cm, avec ε = 2,4×10³ L·mol⁻¹·cm⁻¹. Que vaut C ?",
      "options": [
        "5,0×10³ mol·L⁻¹",
        "1,2×10³ mol·L⁻¹",
        "2,0×10⁻⁴ mol·L⁻¹",
        "4,8×10⁻¹ mol·L⁻¹"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C = A/(ε×ℓ) = 0,48/(2,4×10³ × 1,0) = 2,0×10⁻⁴ mol·L⁻¹.",
      "piege": "Multiplier au lieu de diviser : le résultat n'a alors aucun sens physique.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-21",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Après avoir trouvé C = 2,0×10⁻⁴ mol·L⁻¹, que faut-il vérifier ?",
      "options": ["que A > 1, en dessous l'appareil ne mesure plus rien", "que C &lt; 10⁻² mol·L⁻¹, domaine de validité de la loi", "que la cuve mesure bien 1 cm, sinon ε change de valeur", "que la solution est incolore, sinon la loi ne vaut plus"],
      "bonne_reponse": [
        1
      ],
      "explication": "2,0×10⁻⁴ &lt; 10⁻² : la loi s'applique, la réponse est cohérente. Ce contrôle est attendu.",
      "piege": "Rendre le résultat sans vérifier le domaine de validité.",
      "image": null,
      "tags": [
        "controle"
      ],
      "actif": true
    },
    {
      "ref": "ana-22",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Quand ε n'est pas donné, on passe par :",
      "options": ["la droite d'étalonnage, dont le coefficient directeur k = ε × ℓ", "la mesure du pH, dont on déduit ε par la relation ε = 10⁻ᵖᴴ", "la conductimétrie, dont la pente donne directement ε × C", "la masse molaire, qui relie ε à la concentration massique"],
      "bonne_reponse": [
        0
      ],
      "explication": "k joue exactement le même rôle que ε × ℓ dans A = k × C.",
      "piege": "Chercher ε dans les données alors que l'énoncé fournit une courbe d'étalonnage.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-23",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Sur quelle longueur d'onde règle-t-on le spectrophotomètre ?",
      "options": [
        "sur la couleur perçue de la solution",
        "sur λ<sub>max</sub>, l'abscisse du maximum du spectre A = f(λ)",
        "sur 500 nm par convention",
        "sur la longueur d'onde la plus faible"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est là que la mesure est la plus sensible aux variations de concentration.",
      "piege": "Régler sur la couleur perçue : c'est la couleur <b>complémentaire</b> de celle qui est absorbée.",
      "image": "ana_spectre.png",
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "ana-24",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "La couleur perçue d'une solution est :",
      "options": ["toujours le vert, quelle que soit la longueur d'onde λmax", "indépendante de λmax, elle ne dépend que de la concentration", "la couleur complémentaire de celle qu'elle absorbe", "exactement la couleur qu'elle absorbe le plus fortement"],
      "bonne_reponse": [
        2
      ],
      "explication": "Sur le cercle chromatique, c'est la couleur diamétralement opposée à la couleur absorbée.",
      "piege": "Annoncer que la solution est de la couleur qu'elle absorbe.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-25",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Une solution absorbe autour de λ<sub>max</sub> ≈ 650 nm, dans le rouge. De quelle couleur apparaît-elle ?",
      "options": ["rouge orangé", "vert émeraude", "bleu-violet", "jaune citron"],
      "bonne_reponse": [
        2
      ],
      "explication": "Sur le cercle chromatique, la couleur diamétralement opposée au rouge 650 nm est le bleu-violet 480 nm : c'est celle que l'on perçoit.",
      "piege": "Répondre « rouge », la couleur absorbée et non la couleur perçue.",
      "image": "ana_cercle.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-26",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre les étapes d'un dosage par étalonnage :",
      "options": [
        "remonter à la solution commerciale : C<sub>com</sub> = F × C<sub>d</sub>",
        "vérifier que la loi est vérifiée : A = f(C) est une droite passant par l'origine",
        "appliquer la loi à la solution diluée : C<sub>d</sub> = A<sub>d</sub> / k",
        "conclure sur la grandeur demandée : masse, pourcentage en masse…",
        "déterminer le coefficient directeur k à partir de deux points bien lisibles"
      ],
      "bonne_reponse": [
        1,
        4,
        2,
        0,
        3
      ],
      "explication": "Cinq étapes, dont la première est souvent oubliée : on vérifie d'abord que la loi s'applique.",
      "piege": "Sauter la vérification de linéarité et appliquer la loi sans l'avoir justifiée.",
      "image": "ana_etalonnage.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-27",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Pour déterminer k sur la droite d'étalonnage, on utilise :",
      "options": [
        "deux points bien lisibles de la droite tracée",
        "l'origine seulement",
        "le premier et le dernier point de mesure",
        "la moyenne de tous les points"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "k = (A<sub>D</sub> − A<sub>E</sub>)/(C<sub>D</sub> − C<sub>E</sub>) avec deux points de la <b>droite</b>, pas nécessairement des points expérimentaux.",
      "piege": "Utiliser deux points de mesure éloignés de la droite tracée.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-28",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "La solution diluée a C<sub>d</sub> = 2,0×10⁻⁴ mol·L⁻¹ et le facteur de dilution vaut F = 50. Quelle est la concentration commerciale ?",
      "options": [
        "50 mol·L⁻¹",
        "1,0×10⁻² mol·L⁻¹",
        "4,0×10⁻⁶ mol·L⁻¹",
        "2,0×10⁻² mol·L⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C<sub>com</sub> = F × C<sub>d</sub> = 50 × 2,0×10⁻⁴ = 1,0×10⁻² mol·L⁻¹.",
      "piege": "Diviser par le facteur de dilution : la solution commerciale est forcément plus concentrée.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "ana-29",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "L'équation d'état du gaz parfait s'écrit :",
      "options": [
        "P·V = R·T/n",
        "P/V = n·R·T",
        "P·V = n·R·T",
        "P·V·T = n·R"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Avec P en pascals, V en mètres cubes et T en kelvins : trois conversions avant tout calcul.",
      "piege": "Écrire la relation avec des unités usuelles : bar, litre et degré Celsius.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-30",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Avant d'appliquer P·V = n·R·T, quelles conversions faut-il faire ?",
      "options": [
        "P en pascals, V en m³, T en kelvins",
        "seulement le volume",
        "seulement la température",
        "aucune"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Trois conversions systématiques : c'est le piège explicitement listé pour cette QT.",
      "piege": "Oublier la conversion de la température : T = θ + 273.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-31",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "V = 250 mL, P = 1,10×10⁵ Pa, θ = 25 °C, R = 8,314 J·K⁻¹·mol⁻¹. Que vaut n ?",
      "options": [
        "1,1×10⁻² mol",
        "11 mol",
        "1,1×10¹ mol",
        "1,3×10⁻⁴ mol"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "V = 250×10⁻⁶ m³ et T = 298 K, donc n = 1,10×10⁵ × 250×10⁻⁶ / (8,314 × 298) = 1,1×10⁻² mol.",
      "piege": "Garder le volume en millilitres : on trouve alors un résultat mille fois trop grand.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ana-32",
      "chapitre": "mesures-physiques-d-analyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Un élève garde θ = 25 dans la formule au lieu de T = 298 K. Que se passe-t-il ?",
      "options": ["le résultat est faux d'un facteur d'environ 2", "le résultat change de signe et devient négatif", "le résultat est faux d'un facteur d'environ 12", "le résultat est correct, les deux échelles se compensent"],
      "bonne_reponse": [
        2
      ],
      "explication": "298/25 ≈ 12 : la quantité de matière trouvée serait douze fois trop grande.",
      "piege": "Ne pas contrôler l'ordre de grandeur : une erreur de conversion passe alors inaperçue.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {"ref": "analyse-t01", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Sur un spectre infrarouge, une bande large et intense entre 3 200 et 3 600 cm⁻¹ révèle :", "options": ["une liaison C=O, élargie par la conjugaison du carbonyle", "une liaison C–H, élargie par la rotation des méthyles", "une liaison C=C, élargie par la délocalisation des π", "une liaison O–H, élargie par les liaisons hydrogène"], "bonne_reponse": [3], "explication": "O–H : 3 200–3 600 cm⁻¹, bande LARGE à cause des liaisons hydrogène. C=O : 1 700 cm⁻¹, fine et intense. C–H : vers 2 900 cm⁻¹. On lit avec la table des bandes.", "piege": "Confondre avec N–H, dans la même zone mais plus fine, ou avec C–H, plus bas.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t02", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un spectre présente une bande fine et intense vers 1 720 cm⁻¹ et aucune bande large vers 3 300 cm⁻¹. Parmi acide carboxylique, cétone et alcool, l'espèce est :", "options": ["un acide carboxylique : C=O présent", "on ne peut pas trancher", "un alcool : O–H présent", "une cétone : C=O présent, pas de O–H"], "bonne_reponse": [3], "explication": "C=O présent élimine l'alcool. Absence de O–H élimine l'acide, qui en porte un. Reste la cétone. On raisonne par présence ET absence de bandes.", "piege": "S'arrêter à la première bande reconnue : l'acide a aussi un C=O, c'est l'ABSENCE de O–H qui tranche.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t03", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "La conductance G d'une portion de solution entre deux électrodes est reliée à la conductivité σ par :", "options": ["G = σ·L/S, où L est la surface des électrodes et S leur distance", "G = σ/(S·L), où S est la surface des électrodes et L leur distance", "G = σ·S/L, où S est la surface des électrodes et L leur distance", "G = σ, la géométrie de la cellule n'intervenant pas dans le calcul"], "bonne_reponse": [2], "explication": "La conductance dépend de la cellule ; la conductivité ne dépend que de la solution. G = σ·S/L : des électrodes plus grandes ou plus proches conduisent mieux.", "piege": "Inverser S et L : une plus grande surface AUGMENTE la conductance.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t04", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Une solution de chlorure de sodium de concentration C contient Na⁺ et Cl⁻ à la concentration C chacun. Sa conductivité vaut :", "options": ["σ = λ(Na⁺)·C − λ(Cl⁻)·C = (λ(Na⁺) − λ(Cl⁻))·C", "σ = λ(Na⁺)·C × λ(Cl⁻)·C = λ(Na⁺)·λ(Cl⁻)·C²", "σ = λ(Na⁺)·C + λ(Cl⁻)·C = (λ(Na⁺) + λ(Cl⁻))·C", "σ = (λ(Na⁺) + λ(Cl⁻))/C = somme des λ divisée par C"], "bonne_reponse": [2], "explication": "Loi de Kohlrausch : σ = Σ λᵢ·[Xᵢ]. Chaque ion contribue proportionnellement à sa concentration. σ est proportionnelle à C pour les solutions diluées.", "piege": "Oublier un des ions, ou multiplier les conductivités molaires au lieu de les additionner.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t05", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "On dilue une solution avant une mesure de conductivité parce que :", "options": ["la loi de Kohlrausch ne vaut qu'en dessous de 10⁻² mol·L⁻¹", "la sonde de conductivité ne supporte pas les fortes teneurs", "la conductivité mesurée serait sinon trop faible pour être lue", "la solution s'échaufferait sous l'effet du courant appliqué"], "bonne_reponse": [0], "explication": "Au-delà de 10⁻² mol·L⁻¹, les interactions entre ions font que σ n'est plus proportionnelle à C. On dilue pour rester dans le domaine linéaire.", "piege": "Justifier par la sonde ou la température : c'est la LOI qui a un domaine de validité.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t06", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Une solution étalon de concentration 2,0 × 10⁻⁴ mol·L⁻¹ a une absorbance de 0,40. Une solution inconnue a une absorbance de 0,30. Sa concentration vaut :", "options": ["C = 2,0 × 10⁻⁴ × 0,40/0,30 = 2,7 × 10⁻⁴ mol·L⁻¹", "C = 2,0 × 10⁻⁴ × 0,30/0,40 = 1,5 × 10⁻⁴ mol·L⁻¹", "C = 2,0 × 10⁻⁴ + 0,30/0,40 = 2,8 × 10⁻⁴ mol·L⁻¹", "C = 2,0 × 10⁻⁴ × (0,40 − 0,30) = 2,0 × 10⁻⁵ mol·L⁻¹"], "bonne_reponse": [1], "explication": "Loi de Beer-Lambert : A = k·C, k étant le même pour les deux solutions. Donc C_inc/C_ét = A_inc/A_ét.", "piege": "Inverser le rapport : une absorbance plus faible correspond à une concentration plus faible.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t07", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Une solution est bleue. Pour la doser par spectrophotométrie, on règle l'appareil sur :", "options": ["une longueur d'onde quelconque du domaine visible", "une longueur d'onde du domaine orange, vers 600 nm", "une longueur d'onde du domaine bleu, vers 450 nm", "une longueur d'onde où l'absorbance est minimale"], "bonne_reponse": [1], "explication": "La solution est bleue parce qu'elle ABSORBE la couleur complémentaire : l'orange. On travaille au maximum d'absorption, pour la meilleure sensibilité. Le cercle chromatique donne la complémentaire.", "piege": "Régler sur la couleur de la solution : elle la transmet, donc ne l'absorbe pas.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t08", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Un dosage par étalonnage consiste à :", "options": ["mesurer directement la concentration à l'aide d'une sonde dédiée", "faire réagir la solution inconnue avec un réactif titrant approprié", "comparer à l'œil la couleur de l'inconnue à celle d'un témoin", "mesurer une grandeur sur des solutions connues, puis y placer l'inconnue"], "bonne_reponse": [3], "explication": "C'est une méthode non destructive : on ne fait pas réagir l'inconnue. On construit la relation grandeur-concentration avec des étalons, puis on interpole.", "piege": "Le confondre avec un titrage, qui consomme la solution par une réaction.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "analyse-t09", "chapitre": "analyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Une réaction produit du gaz dans une enceinte fermée de volume V, à température T. La quantité de gaz formé se déduit de la variation de pression Δp par :", "options": ["n = Δp/(V·R·T), d'après la loi des gaz parfaits", "n = Δp·R·T/V, d'après la loi des gaz parfaits", "n = Δp·V/(R·T), d'après la loi des gaz parfaits", "n = Δp·V·R·T, d'après la loi des gaz parfaits"], "bonne_reponse": [2], "explication": "p·V = n·R·T. À V et T constants, une variation Δp correspond à Δn = Δp·V/(RT). Attention aux unités : p en Pa, V en m³, T en K.", "piege": "Mélanger les unités : un volume en litres ou une pression en bar donne un résultat faux d'un facteur 10³ ou 10⁵.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  radioactivite: [
    {
      "ref": "rad-01",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La radioactivité est un phénomène : <b>plusieurs réponses.</b>",
      "options": [
        "naturel et spontané",
        "réversible",
        "inéluctable et irréversible",
        "provoqué par un apport d'énergie"
      ],
      "bonne_reponse": [
        0,
        2
      ],
      "explication": "Quatre adjectifs à connaître : naturel, inéluctable, irréversible et spontané. Rien ne peut l'accélérer ni l'arrêter.",
      "piege": "Croire qu'un facteur extérieur — température, pression — peut modifier une désintégration.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-02",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Des <b>isotopes</b> sont des noyaux ayant :",
      "options": [
        "le même Z et des A différents",
        "le même A et des Z différents",
        "la même demi-vie",
        "le même nombre de neutrons"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Même numéro atomique Z, donc même élément, mais des nombres de masse A différents.",
      "piege": "Intervertir A et Z : deux noyaux de même A sont dits isobares, pas isotopes.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-03",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "L'activité d'un échantillon s'exprime en :",
      "options": [
        "secondes⁻¹ par mole",
        "becquerels",
        "sieverts",
        "grays"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "A(t) = −dN/dt = λ·N(t), en becquerels (Bq) : c'est le nombre de désintégrations par seconde.",
      "piege": "Confondre l'activité, en Bq, et la constante radioactive λ, en s⁻¹.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-04",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La désintégration α transforme le noyau selon :",
      "options": [
        "A → A − 4 et Z → Z",
        "A → A et Z → Z + 1",
        "A → A − 4 et Z → Z − 2",
        "A → A − 2 et Z → Z − 4"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le noyau émet un noyau d'hélium <span class=\"noyau\"><sup>4</sup><sub>2</sub></span>He : il perd 4 nucléons dont 2 protons.",
      "piege": "Retenir les variations à l'envers : c'est la particule émise qui les impose.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-05",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La désintégration β⁻ émet :",
      "options": [
        "un noyau d'hélium <span class=\"noyau\"><sup>4</sup><sub>2</sub></span>He",
        "un positon ⁰₊₁e",
        "un photon γ",
        "un électron ⁰₋₁e"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Un neutron du noyau se transforme en proton : Z augmente d'une unité, A ne change pas.",
      "piege": "Confondre β⁻ (électron) et β⁺ (positon) — le piège le plus fréquent du chapitre.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "rad-06",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Lors d'une désexcitation γ :",
      "options": ["A et Z restent inchangés, seul un photon est émis", "le noyau se scinde en deux, seul un photon est émis", "A et Z changent tous les deux, seul un photon est émis", "Z augmente d'une unité, seul un photon est émis"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le noyau excité Y* perd son excédent d'énergie sous forme de photon : sa composition ne change pas.",
      "piege": "Croire que l'émission γ modifie la nature du noyau.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-07",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "L'énoncé donne le noyau père <b>et</b> le noyau fils, et demande la particule émise. Comment procède-t-on ?",
      "options": ["on lit le type de désintégration sur le diagramme (N,Z), puis on conclut", "on écrit les conservations de A et de Z, qui donnent la particule émise", "on cherche le noyau fils dans la classification périodique des éléments", "on calcule la demi-vie, dont la valeur indique le type d'émission"],
      "bonne_reponse": [
        1
      ],
      "explication": "Les deux conservations donnent le couple (A ; Z) de la particule : <span class=\"noyau\"><sup>4</sup><sub>2</sub></span>He, ⁰₋₁e, ⁰₊₁e ou <span class=\"noyau\"><sup>1</sup><sub>0</sub></span>n. C'est le cas où la particule est identifiée <b>à la fin</b>.",
      "piege": "Confondre avec le cas inverse, où l'énoncé donne le père et le type de désintégration, et où c'est le noyau fils qu'on cherche.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "rad-08",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Remets dans l'ordre l'identification d'un noyau fils :",
      "options": [
        "écrire la conservation de A",
        "identifier la particule émise, qui donne le type de désintégration",
        "écrire la conservation de Z",
        "identifier l'élément grâce à Z′ dans la classification périodique"
      ],
      "bonne_reponse": [
        1,
        0,
        2,
        3
      ],
      "explication": "La dernière étape est indispensable : c'est Z′ qui donne le symbole chimique.",
      "piege": "S'arrêter aux valeurs de A′ et Z′ sans nommer le noyau obtenu.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-09",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Le carbone 14 se désintègre selon <span class=\"noyau\"><sup>14</sup><sub>6</sub></span>C → ᴬ′_Z′X + ⁰₋₁e. Quel est le noyau fils ?",
      "options": [
        "<span class=\"noyau\"><sup>14</sup><sub>5</sub></span>B, le bore",
        "<span class=\"noyau\"><sup>14</sup><sub>6</sub></span>C, inchangé",
        "<span class=\"noyau\"><sup>14</sup><sub>7</sub></span>N, l'azote",
        "<span class=\"noyau\"><sup>13</sup><sub>6</sub></span>C, le carbone 13"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "A′ = 14 − 0 = 14 et Z′ = 6 − (−1) = 7 : c'est l'azote 14.",
      "piege": "Soustraire au lieu d'ajouter pour Z : la charge de l'électron étant −1, Z′ augmente.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "rad-10",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "L'uranium 238 (Z = 92) émet une particule α. Quel est le noyau fils ?",
      "options": [
        "<span class=\"noyau\"><sup>236</sup><sub>90</sub></span>Th",
        "<span class=\"noyau\"><sup>234</sup><sub>92</sub></span>U",
        "<span class=\"noyau\"><sup>238</sup><sub>90</sub></span>Th",
        "<span class=\"noyau\"><sup>234</sup><sub>90</sub></span>Th"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "A′ = 238 − 4 = 234 et Z′ = 92 − 2 = 90 : le thorium 234.",
      "piege": "Oublier de retirer les 4 nucléons emportés par la particule α.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-11",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La particule ⁰₊₁e est :",
      "options": [
        "un positon",
        "un photon",
        "un neutron",
        "un électron"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "<span class=\"noyau\"><sup>4</sup><sub>2</sub></span>He noyau d'hélium · ⁰₋₁e électron · ⁰₊₁e positon · <span class=\"noyau\"><sup>1</sup><sub>0</sub></span>n neutron · γ photon.",
      "piege": "Ne regarder que le 0 en haut et confondre électron et positon : c'est le signe de la charge qui les distingue.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-12",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "D'où provient l'électron émis lors d'une désintégration β⁻ ?",
      "options": [
        "du cortège électronique de l'atome",
        "du noyau : un neutron s'y transforme en proton",
        "d'un atome voisin",
        "du rayonnement cosmique"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Il est <b>créé</b> lors de la transformation, il ne préexistait pas.",
      "piege": "Croire qu'il vient du nuage électronique — le piège explicitement cité dans la fiche.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-14",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Un noyau situé <b>au-dessus</b> de la vallée de stabilité :",
      "options": [
        "est émetteur α",
        "a trop de protons, il est émetteur β⁺",
        "a trop de neutrons, il est émetteur β⁻",
        "est stable"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Trop de neutrons : l'un d'eux se transforme en proton, c'est la désintégration β⁻.",
      "piege": "Inverser les deux zones — au-dessus c'est β⁻, en dessous c'est β⁺.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "actif": true
    },
    {
      "ref": "rad-15",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Un noyau de numéro atomique Z > 82 est généralement :",
      "options": [
        "émetteur β⁻",
        "stable",
        "émetteur β⁺",
        "émetteur α"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Les noyaux très lourds se débarrassent de nucléons en émettant un noyau d'hélium.",
      "piege": "Chercher la réponse dans la position verticale : au-delà de Z = 82, c'est la masse qui décide.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-17",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Quelle rédaction est attendue après lecture du diagramme ?",
      "options": ["« le noyau X se situe au-dessus de la vallée : trop de neutrons, émetteur β⁻ »", "« le noyau X se situe en dessous de la vallée : trop de neutrons, émetteur β⁻ »", "« le noyau X se situe au-dessus de la vallée : trop de protons, émetteur β⁺ »", "« le noyau X se situe sur la vallée de stabilité : il n'émet aucune particule »"],
      "bonne_reponse": [
        0
      ],
      "explication": "Position, cause, conclusion : les trois éléments sont notés.",
      "piege": "Annoncer le type de désintégration sans dire où se situe le noyau.",
      "image": "rad_nz.png",
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "rad-18",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Quelle est la méthode en deux temps pour écrire une équation de désintégration ?",
      "options": ["chercher le noyau dans la classification, puis appliquer Soddy", "lire le diagramme pour le type, puis appliquer Soddy pour le noyau fils", "calculer la demi-vie, puis en déduire l'activité du noyau père", "appliquer Soddy pour le noyau fils, puis lire le diagramme pour le type"],
      "bonne_reponse": [
        1
      ],
      "explication": "Le diagramme donne le mode, les lois de Soddy donnent A′ et Z′, la classification donne le symbole.",
      "piege": "Deviner le type de désintégration sans consulter le diagramme fourni.",
      "image": "rad_nz.png",
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-19",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Le strontium 90 (Z = 38) est au-dessus de la vallée. Quelle est son équation de désintégration ?",
      "options": [
        "<span class=\"noyau\"><sup>90</sup><sub>38</sub></span>Sr → <span class=\"noyau\"><sup>90</sup><sub>37</sub></span>Rb + ⁰₊₁e",
        "<span class=\"noyau\"><sup>90</sup><sub>38</sub></span>Sr → <span class=\"noyau\"><sup>86</sup><sub>36</sub></span>Kr + <span class=\"noyau\"><sup>4</sup><sub>2</sub></span>He",
        "<span class=\"noyau\"><sup>90</sup><sub>38</sub></span>Sr → <span class=\"noyau\"><sup>90</sup><sub>39</sub></span>Y + ⁰₋₁e",
        "<span class=\"noyau\"><sup>90</sup><sub>38</sub></span>Sr → <span class=\"noyau\"><sup>90</sup><sub>38</sub></span>Sr + γ"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Émetteur β⁻ : A reste 90, Z passe de 38 à 39, soit l'yttrium.",
      "piege": "Faire diminuer Z : lors d'une β⁻, le numéro atomique <b>augmente</b>.",
      "image": "rad_nz.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-20",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre le passage de l'uranium 238 au plutonium 239 :",
      "options": [
        "<span class=\"noyau\"><sup>239</sup><sub>93</sub></span>Np → <span class=\"noyau\"><sup>239</sup><sub>94</sub></span>Pu + ⁰₋₁e : seconde désintégration β⁻",
        "<span class=\"noyau\"><sup>239</sup><sub>92</sub></span>U → <span class=\"noyau\"><sup>239</sup><sub>93</sub></span>Np + ⁰₋₁e : première désintégration β⁻",
        "<span class=\"noyau\"><sup>238</sup><sub>92</sub></span>U + <span class=\"noyau\"><sup>1</sup><sub>0</sub></span>n → <span class=\"noyau\"><sup>239</sup><sub>92</sub></span>U : capture d'un neutron"
      ],
      "bonne_reponse": [
        2,
        1,
        0
      ],
      "explication": "Une capture, puis deux β⁻ successives : chaque équation est équilibrée en A et en Z.",
      "piege": "Oublier la capture initiale, sans laquelle le nombre de masse ne passerait pas de 238 à 239.",
      "image": "rad_nz.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-21",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Remets dans l'ordre l'établissement de l'équation différentielle de N(t) :",
      "options": [
        "par ailleurs, A(t) = λ × N(t)",
        "soit dN/dt + λ·N = 0",
        "par définition, A(t) = − dN(t)/dt",
        "en égalant : − dN/dt = λ·N"
      ],
      "bonne_reponse": [
        2,
        0,
        3,
        1
      ],
      "explication": "Deux expressions de la même activité, puis on les égale : c'est exactement la démarche de la cinétique d'ordre 1.",
      "piege": "Écrire dN/dt = +λ·N et obtenir une exponentielle croissante, absurde pour une décroissance.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-23",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Pour montrer que N(t) = N₀·e^(−λt) est solution, il faut :",
      "options": ["tracer la courbe et vérifier qu'elle décroît bien vers zéro", "vérifier que N(0) = N₀, ce qui suffit à établir la solution", "calculer la demi-vie, puis vérifier qu'elle vaut bien ln 2/λ", "dériver, reporter dans dN/dt + λ·N, et montrer que le résultat vaut 0"],
      "bonne_reponse": [
        3
      ],
      "explication": "On injecte l'expression et sa dérivée : les deux termes se compensent exactement.",
      "piege": "Se contenter de la condition initiale, qui ne démontre rien sur l'équation.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "rad-24",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Si l'on écrit N(t) = C·e^(−λt), que vaut la constante C ?",
      "options": [
        "N₀, le nombre de noyaux initial",
        "l'activité initiale A₀",
        "λ",
        "0"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "À t = 0, e⁰ = 1 donc N(0) = C. Or N(0) = N₀ : la constante est le nombre initial de noyaux.",
      "piege": "Confondre avec A₀ : l'activité initiale vaut λN₀, pas N₀.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-26",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "La demi-vie radioactive est la durée au bout de laquelle :",
      "options": ["la constante λ est divisée par deux, la décroissance ralentissant", "l'activité s'annule, tous les noyaux s'étant désintégrés", "la moitié des noyaux initialement présents s'est désintégrée", "tous les noyaux se sont désintégrés, l'échantillon étant épuisé"],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est la définition exacte, à écrire telle quelle avant toute démonstration.",
      "piege": "Parler d'annulation de l'activité : une exponentielle ne s'annule jamais.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "rad-27",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre la démonstration de t₁/₂ = ln(2)/λ :",
      "options": [
        "on prend le logarithme : ln(1) − ln(2) = −λ·t₁/₂",
        "on simplifie par N₀ : 1/2 = e^(−λt₁/₂)",
        "on pose N(t₁/₂) = N₀/2 = N₀·e^(−λt₁/₂)",
        "on isole : t₁/₂ = ln(2)/λ"
      ],
      "bonne_reponse": [
        2,
        1,
        0,
        3
      ],
      "explication": "Même démonstration qu'en cinétique d'ordre 1 : la simplification par N₀ montre que t₁/₂ ne dépend pas de la quantité initiale.",
      "piege": "Sauter la simplification et croire que la demi-vie dépend du nombre de noyaux de départ.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-28",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Un radionucléide a λ = 1,21×10⁻⁴ an⁻¹. Que vaut sa demi-vie ?",
      "options": [
        "1,73×10⁴ ans",
        "8,26×10³ ans",
        "5,73×10³ ans",
        "1,21×10⁻⁴ ans"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "t₁/₂ = ln(2)/λ = 0,693/1,21×10⁻⁴ = 5,73×10³ ans : c'est le carbone 14.",
      "piege": "Calculer 1/λ = 8,26×10³ ans, qui est le temps caractéristique, pas la demi-vie.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-29",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Remets dans l'ordre la construction graphique de t₁/₂ :",
      "options": [
        "on lit l'abscisse : c'est t₁/₂",
        "on descend à la verticale jusqu'à l'axe des temps",
        "on trace l'horizontale jusqu'à la courbe",
        "on repère N₀/2 sur l'axe des ordonnées"
      ],
      "bonne_reponse": [
        3,
        2,
        1,
        0
      ],
      "explication": "Trois traits à laisser apparents sur la copie : c'est la construction qui rapporte les points.",
      "piege": "Lire l'abscisse à l'œil sans tracer les traits, ou les effacer ensuite.",
      "image": "rad_decroissance.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-30",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Comment contrôler une lecture de demi-vie ?",
      "options": ["en vérifiant que N s'annule à 2·t₁/₂, puis reste nul ensuite", "en vérifiant qu'il reste N₀/4 à 2·t₁/₂ et N₀/8 à 3·t₁/₂", "en comparant à λ : le produit λ·t₁/₂ doit valoir exactement 1", "aucun contrôle n'est possible : la lecture graphique est unique"],
      "bonne_reponse": [
        1
      ],
      "explication": "Chaque demi-vie divise le nombre de noyaux par deux : le contrôle est immédiat sur le graphe.",
      "piege": "Croire que la courbe atteint zéro : la décroissance est exponentielle.",
      "image": null,
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-31",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Quelle est la version <b>courte</b> pour montrer que A(t) = A₀·e^(−λt) ?",
      "options": ["partir de A(t) = λ·N(t) et y reporter N(t) = N₀·e^(−λt)", "partir de A(t) = −λ·N(t) et y reporter N(t) = N₀·e^(λt)", "intégrer l'équation différentielle dN/dt = −λ·N", "dériver N(t) deux fois, puis simplifier par N₀"],
      "bonne_reponse": [
        0
      ],
      "explication": "A(t) = λN₀·e^(−λt), et λN₀ = A₀ : deux lignes suffisent.",
      "piege": "Se lancer dans la dérivation alors que l'énoncé n'impose pas de partir de −dN/dt.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "rad-33",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 11",
      "enonce": "Remets dans l'ordre la datation par le calcul, à partir de N(t) :",
      "options": [
        "on isole : t = −(1/λ)·ln(N/N₀)",
        "on divise par N₀ : N/N₀ = e^(−λt)",
        "on prend le logarithme népérien : ln(N/N₀) = −λt",
        "on écrit N(t) = N₀·e^(−λt)"
      ],
      "bonne_reponse": [
        3,
        1,
        2,
        0
      ],
      "explication": "Toute datation revient à isoler t dans une exponentielle : on divise, on passe au logarithme, on isole.",
      "piege": "Oublier le signe − en isolant t, et obtenir un âge négatif.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-34",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 11",
      "enonce": "Au bout de combien de temps ne reste-t-il que 1 % des noyaux ?",
      "options": [
        "t = ln(0,01)/λ",
        "t = ln(100)/λ",
        "t = 100/λ",
        "t = λ/ln(100)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "N/N₀ = 1/100 donne −λt = ln(1/100) = −ln(100), donc t = ln(100)/λ.",
      "piege": "Garder ln(0,01), négatif, et obtenir une durée négative.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "rad-35",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 12",
      "enonce": "Un échantillon contient aujourd'hui le quart du carbone 14 initial. Combien de demi-vies se sont écoulées ?",
      "options": [
        "quatre",
        "une",
        "deux",
        "huit"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "N = N₀/4 = N₀/2², donc n = 2. L'âge vaut 2 × t₁/₂.",
      "piege": "Confondre le dénominateur et l'exposant : 1/4 correspond à deux demi-vies, pas quatre.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-36",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 12",
      "enonce": "Avec t₁/₂(¹⁴C) = 5730 ans, quel est l'âge de cet échantillon ?",
      "options": [
        "5 730 ans",
        "22 920 ans",
        "2 865 ans",
        "11 460 ans"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Deux demi-vies : 2 × 5730 = 11 460 ans. Le calcul général donne 1,15×10⁴ ans, les deux concordent.",
      "piege": "N'appliquer qu'une seule demi-vie parce que le rapport est « un quart ».",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-38",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 13",
      "enonce": "Pour qu'un radionucléide convienne à une datation, sa demi-vie doit être :",
      "options": ["du même ordre de grandeur que la durée à mesurer, ou plus grande", "exactement égale à la durée à mesurer, à quelques pour cent près", "très courte devant la durée à mesurer, pour que l'activité ait décru", "sans importance : tout radionucléide convient à toute datation"],
      "bonne_reponse": [
        0
      ],
      "explication": "Si t₁/₂ est trop courte, presque tous les noyaux ont disparu : la mesure devient impossible.",
      "piege": "Choisir un radionucléide à demi-vie très courte en pensant qu'il « réagit plus vite ».",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-39",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 13",
      "enonce": "Le rubidium 87 a t₁/₂ = 49,2×10⁹ ans. Convient-il pour dater une roche de 3×10⁸ ans ?",
      "options": ["non, il faudrait une demi-vie égale à l'âge de la roche", "oui : moins de 1 % des noyaux se sont désintégrés, il en reste assez", "non, sa demi-vie est trop grande par rapport à l'âge de la roche", "oui, sa demi-vie est trop grande par rapport à l'âge de la roche"],
      "bonne_reponse": [
        1
      ],
      "explication": "Il faut en revanche que la proportion de noyaux fils formés reste mesurable.",
      "piege": "Écarter un radionucléide parce que sa demi-vie « dépasse » l'âge à dater.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-40",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 13",
      "enonce": "Un échantillon contient initialement N₀ noyaux et suit la loi N(t) = N₀·e^(−λt). On cherche la date t<sub>f</sub> à laquelle il ne resterait plus que N<sub>min</sub> noyaux. Que vaut t<sub>f</sub> ?",
      "options": [
        "t<sub>f</sub> = λ·ln(N₀/N<sub>min</sub>)",
        "t<sub>f</sub> = (1/λ)·ln(N<sub>min</sub>/N₀)",
        "t<sub>f</sub> = (1/λ)·ln(N₀/N<sub>min</sub>)",
        "t<sub>f</sub> = N₀/(λ·N<sub>min</sub>)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "N<sub>min</sub> = N₀·e^(−λt_f) donne −λt_f = ln(N<sub>min</sub>/N₀), soit t<sub>f</sub> = (1/λ)·ln(N₀/N<sub>min</sub>), qui est positif.",
      "piege": "Garder le rapport dans le mauvais sens et obtenir une durée négative.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rad-42",
      "chapitre": "la-radioactivite",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Un élève trouve un âge négatif dans une datation. Que faut-il en conclure ?",
      "options": ["un signe a été perdu : t = (1/λ)·ln(N/N₀), avec N = N₀", "l'échantillon est trop récent pour cette méthode de datation", "un signe a été perdu : t = −(1/λ)·ln(N/N₀), avec N > N₀", "un signe a été perdu : t = −(1/λ)·ln(N/N₀), avec N &lt; N₀"],
      "bonne_reponse": [
        3
      ],
      "explication": "Comme N &lt; N₀, le logarithme est négatif : c'est le signe − devant qui rend le résultat positif.",
      "piege": "Rendre un âge négatif sans réagir — un contrôle de vraisemblance suffit à le repérer.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {"ref": "radioactivite-t01", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Le radon ²²²₈₆Rn subit une désintégration α. Le noyau fils est :", "options": ["²²⁶₈₈Ra", "²²²₈₇Fr", "²¹⁸₈₆Rn", "²¹⁸₈₄Po"], "bonne_reponse": [3], "explication": "Lois de Soddy : conservation de A et de Z. La particule α est ⁴₂He : le fils a A = 222 − 4 = 218 et Z = 86 − 2 = 84. C'est le polonium.", "piege": "Ne soustraire que l'un des deux nombres : A ET Z diminuent.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t02", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Lors d'une désintégration β⁻, la particule émise est :", "options": ["un électron ⁰₋₁e", "un noyau d'hélium ⁴₂He", "un positon ⁰₊₁e", "un photon γ"], "bonne_reponse": [0], "explication": "β⁻ : n → p + e⁻ (+ antineutrino). Z augmente de 1, A ne change pas. β⁺ émet un positon, α un noyau d'hélium.", "piege": "Confondre β⁻ et β⁺ : le signe indique la charge de la particule émise.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t03", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Sur le diagramme (N, Z), un noyau situé au-dessus de la vallée de stabilité possède trop de neutrons. Il se désintègre par :", "options": ["émission β⁺", "émission β⁻", "émission α", "capture d'un neutron"], "bonne_reponse": [1], "explication": "Trop de neutrons → β⁻ transforme un neutron en proton : N baisse, Z monte, on descend vers la vallée. Trop de protons → β⁺. Noyaux lourds → α.", "piege": "Inverser : β⁻ AUGMENTE Z, c'est ce qu'il faut à un noyau riche en neutrons.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t04", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Le carbone 14, ¹⁴₆C, est émetteur β⁻. Son équation de désintégration est :", "options": ["¹⁴₆C → ¹⁴₅B + ⁰₊₁e", "¹⁴₆C → ¹³₆C + ¹₀n", "¹⁴₆C → ¹⁴₇N + ⁰₋₁e", "¹⁴₆C → ¹⁰₄Be + ⁴₂He"], "bonne_reponse": [2], "explication": "β⁻ : Z passe de 6 à 7, A reste 14. Le fils est l'azote 14. On vérifie : 6 = 7 + (−1) et 14 = 14 + 0.", "piege": "Écrire un fils de même Z : la désintégration β change toujours l'élément.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t05", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "L'uranium ²³⁸₉₂U subit une désintégration α, puis le noyau fils une désintégration β⁻. Après ces deux étapes, le noyau obtenu est :", "options": ["²³⁴₉₂U", "²³⁴₉₀Th", "²³⁸₉₃Np", "²³⁴₉₁Pa"], "bonne_reponse": [3], "explication": "Étape 1 : α, A = 234, Z = 90 (thorium). Étape 2 : β⁻, A = 234, Z = 91 (protactinium). On enchaîne les lois de Soddy étape par étape.", "piege": "S'arrêter à la première étape, ou appliquer les deux désintégrations dans le désordre.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t06", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Le nombre de noyaux qui se désintègrent pendant dt est proportionnel au nombre de noyaux présents : dN = −λ·N·dt. L'équation différentielle est :", "options": ["dN/dt = −λ", "dN/dt = λ·N", "dN/dt = −λ·N", "N = −λ·t"], "bonne_reponse": [2], "explication": "On divise par dt : dN/dt = −λN. Le signe − dit que N décroît ; λ est la constante radioactive, en s⁻¹.", "piege": "Oublier le signe : N diminue, sa dérivée est négative.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t07", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "On vérifie que N(t) = A·e^(−λt) est solution de dN/dt = −λN, puis on détermine A par :", "options": ["la demi-vie t₁/₂ du noyau", "la condition initiale sur le nombre de noyaux", "la valeur de λ mesurée à t = 0", "la limite N(∞) = 0 à l'infini"], "bonne_reponse": [1], "explication": "Dérivée : dN/dt = −λ·A·e^(−λt) = −λN, vérifié. À t = 0, e⁰ = 1 donc A = N₀, le nombre initial de noyaux.", "piege": "Chercher A ailleurs qu'à t = 0 : la constante d'intégration est toujours fixée par la condition initiale.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t08", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "La demi-vie est la durée au bout de laquelle N = N₀/2. De N₀·e^(−λ·t₁/₂) = N₀/2, on tire :", "options": ["t₁/₂ = ln 2/λ", "t₁/₂ = λ·ln 2", "t₁/₂ = 2/λ", "t₁/₂ = 1/(2λ)"], "bonne_reponse": [0], "explication": "On simplifie par N₀, on applique ln : −λ·t₁/₂ = ln(1/2) = −ln 2. D'où t₁/₂ = ln 2/λ ≈ 0,693/λ. Elle ne dépend pas de N₀.", "piege": "Oublier le logarithme, ou le signe dans ln(1/2) = −ln 2.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t09", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Sur la courbe N = f(t), avec N₀ = 8,0 × 10²⁰ noyaux, la demi-vie se lit :", "options": ["à la moitié de la durée totale portée sur le graphe", "au point où la tangente à l'origine coupe l'axe des temps", "à l'abscisse du point d'ordonnée N = 0", "à l'abscisse du point d'ordonnée N₀/2 = 4,0 × 10²⁰"], "bonne_reponse": [3], "explication": "Horizontale à N₀/2, intersection avec la courbe, verticale jusqu'à l'axe des temps. Les traits de construction doivent apparaître.", "piege": "Chercher N = 0 : une exponentielle décroissante ne s'annule jamais.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t10", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "L'activité est définie par A = −dN/dt. Avec N(t) = N₀·e^(−λt), on obtient :", "options": ["A(t) = λ·N₀·e^(−λt) = A₀·e^(−λt), avec A₀ = λ·N₀", "A(t) = N₀·e^(−λt) = A₀·e^(−λt), avec A₀ = N₀", "A(t) = λ·t·N₀·e^(−λt) = A₀·t, avec A₀ = λ·N₀", "A(t) = −λ·N₀·e^(−λt) = A₀·e^(−λt), avec A₀ = −λ·N₀"], "bonne_reponse": [0], "explication": "A = −dN/dt = λN₀e^(−λt) = λN. L'activité suit la même loi que N, avec A₀ = λN₀. Elle se mesure en becquerels.", "piege": "Garder le signe − : A est positive par définition, c'est l'opposé de dN/dt.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t11", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 11", "enonce": "Un échantillon a une activité A = A₀/8. Avec la demi-vie t₁/₂, son âge vaut :", "options": ["t = 3·t₁/₂", "t = 8·t₁/₂", "t = t₁/₂/8", "t = ln 8 × λ"], "bonne_reponse": [0], "explication": "De A = A₀e^(−λt) : t = ln(A₀/A)/λ = ln 8/λ. Avec λ = ln 2/t₁/₂ : t = 3·t₁/₂, car ln 8 = 3·ln 2.", "piege": "Multiplier la demi-vie par le rapport 8 : c'est le LOGARITHME du rapport qui compte.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t12", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 12", "enonce": "Il reste 1/16 des noyaux initiaux. Le nombre de demi-vies écoulées est :", "options": ["4", "16", "8", "2"], "bonne_reponse": [0], "explication": "À chaque demi-vie, N est divisé par 2 : après n demi-vies, N = N₀/2ⁿ. 2⁴ = 16, donc 4 demi-vies.", "piege": "Prendre 16 ou 8 demi-vies : on compte les DIVISIONS PAR 2, pas le rapport.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "radioactivite-t13", "chapitre": "radioactivite", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 13", "enonce": "Le carbone 14 (t₁/₂ = 5 730 ans) convient pour dater des restes organiques de quelques milliers d'années parce que :", "options": ["il est présent dans tous les objets, organiques comme minéraux", "sa demi-vie est du même ordre que les âges à mesurer : l'activité reste mesurable", "sa demi-vie est très courte : l'activité décroît vite et se mesure bien", "sa demi-vie est très longue : l'activité reste forte et se mesure bien"], "bonne_reponse": [1], "explication": "Une demi-vie trop courte : plus rien à mesurer. Trop longue : l'activité n'a pas bougé. Il faut t₁/₂ comparable à l'âge. Pour des roches, on prend l'uranium (milliards d'années).", "piege": "Croire qu'une demi-vie longue est toujours mieux : elle serait inutile pour quelques milliers d'années.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  lunette: [
    {
      "ref": "lun-01",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La vergence d'une lentille s'exprime en dioptries et vaut :",
      "options": [
        "V = 1/f′ avec f′ en mètres",
        "V = f′²",
        "V = 1/f′ avec f′ en centimètres",
        "V = f′"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "V = 1/f′, avec la distance focale <b>en mètres</b> : une lentille de 20 cm de focale a une vergence de 5 δ.",
      "piege": "Utiliser des centimètres et se tromper d'un facteur 100.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-02",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Un grandissement γ négatif signifie que l'image est :",
      "options": [
        "plus grande que l'objet",
        "renversée",
        "droite",
        "plus petite que l'objet"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le signe donne le sens : γ &lt; 0 image renversée, γ > 0 image droite. La valeur absolue donne la taille.",
      "piege": "Confondre le signe, qui donne le sens, et la valeur absolue, qui donne la taille.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-03",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Si |γ| &lt; 1, l'image est :",
      "options": [
        "plus grande que l'objet",
        "virtuelle",
        "plus petite que l'objet",
        "renversée"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "|γ| compare les tailles : inférieur à 1, l'image est réduite.",
      "piege": "Croire qu'un grandissement inférieur à 1 signifie une image renversée : c'est le signe qui dit cela.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-04",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "socle",
      "enonce": "Pourquoi parle-t-on de longueurs <b>algébriques</b> en optique ?",
      "options": ["parce qu'elles sont toujours positives, la distance étant une norme", "parce qu'on les calcule par une équation, et non par une mesure", "parce qu'elles s'expriment en dioptries, unité signée par nature", "parce que leur signe indique la position par rapport à la lentille"],
      "bonne_reponse": [
        3
      ],
      "explication": "Un objet placé avant la lentille a une abscisse négative : oublier ce signe change la nature de l'image.",
      "piege": "Travailler en valeurs absolues et conclure à une image réelle là où elle est virtuelle.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "lun-05",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Le rayon passant par le centre optique O d'une lentille :",
      "options": [
        "n'est pas dévié",
        "émerge parallèlement à l'axe",
        "est renvoyé vers l'objet",
        "passe par le foyer image"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Trois rayons à connaître : parallèle à l'axe → passe par F′ · par O → non dévié · par F → ressort parallèle à l'axe.",
      "piege": "Confondre avec le rayon parallèle à l'axe, qui lui est dévié vers F′.",
      "image": null,
      "tags": [
        "construction"
      ],
      "actif": true
    },
    {
      "ref": "lun-06",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Un rayon incident parallèle à l'axe optique émerge :",
      "options": [
        "en passant par le foyer objet F",
        "en passant par le foyer image F′",
        "parallèlement à l'axe",
        "sans être dévié"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est la définition du foyer image : tous les rayons parallèles à l'axe y convergent.",
      "piege": "Le faire passer par F, le foyer objet — c'est le rayon inverse.",
      "image": null,
      "tags": [
        "construction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-07",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "De quel point doit-on faire partir les rayons pour construire l'image A′B′ ?",
      "options": [
        "du centre optique O",
        "du foyer objet F",
        "de B, le point hors de l'axe",
        "de A, sur l'axe optique"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "On construit B′ à l'intersection des rayons issus de B, puis A′ est son projeté sur l'axe.",
      "piege": "Faire partir les rayons de A : sur l'axe, ils ne donnent aucune intersection exploitable.",
      "image": null,
      "tags": [
        "construction"
      ],
      "actif": true
    },
    {
      "ref": "lun-08",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Combien de rayons faut-il tracer, et pourquoi ?",
      "options": ["quatre, pour que la construction gagne en précision", "deux suffisent, le troisième servant de vérification", "un seul suffit, s'il passe par le centre optique", "les trois sont obligatoires, chacun donnant une information"],
      "bonne_reponse": [
        1
      ],
      "explication": "Deux rayons déterminent l'intersection ; le troisième confirme la construction.",
      "piege": "N'en tracer qu'un : aucune intersection n'est alors définie.",
      "image": null,
      "tags": [
        "construction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-09",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La relation de conjugaison d'une lentille mince s'écrit :",
      "options": [
        "1/OA′ − 1/OA = 1/f′",
        "OA′ − OA = f′",
        "1/OA′ + 1/OA = 1/f′",
        "1/OA′ × 1/OA = 1/f′"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "1/OA′ − 1/OA = 1/f′ : c'est la différence des inverses, pas leur somme.",
      "piege": "Écrire une somme : le résultat sur la position de l'image est alors faux.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "lun-10",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Remets dans l'ordre la détermination complète d'une image :",
      "options": [
        "conclure : réelle si OA′ > 0, renversée si γ &lt; 0, agrandie si |γ| > 1",
        "appliquer la relation de conjugaison pour trouver la position OA′",
        "en déduire la taille A′B′ = γ × AB",
        "calculer le grandissement γ = OA′/OA"
      ],
      "bonne_reponse": [
        1,
        3,
        2,
        0
      ],
      "explication": "Trois grandeurs, puis la conclusion sur les caractéristiques : c'est la conclusion qui est notée.",
      "piege": "S'arrêter au calcul sans donner les caractéristiques demandées.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-11",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "On demande « les caractéristiques de l'image ». Que faut-il donner ?",
      "options": [
        "seulement le grandissement en valeur absolue",
        "réelle ou virtuelle, droite ou renversée, agrandie ou réduite",
        "seulement sa position",
        "seulement sa taille"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Trois caractéristiques, toutes déduites du signe de OA′ et du signe et de la valeur de γ.",
      "piege": "Donner |γ| sans son signe : on perd l'information sur le sens de l'image.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-12",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre la démonstration : l'image d'un objet à l'infini se forme dans le plan focal image.",
      "options": [
        "donc OA′ = f′ : l'image se forme dans le plan focal image",
        "l'objet est à l'infini, donc OA → ∞ et 1/OA → 0",
        "on part de la relation de conjugaison 1/OA′ − 1/OA = 1/f′",
        "il reste 1/OA′ = 1/f′"
      ],
      "bonne_reponse": [
        2,
        1,
        3,
        0
      ],
      "explication": "C'est ce résultat qui justifie toute la construction dans la lunette.",
      "piege": "Affirmer le résultat sans le démontrer — la question dit « montrer que ».",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-13",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Un objet situé à l'infini donne une image :",
      "options": [
        "dans le plan focal objet",
        "au centre optique",
        "dans le plan focal image",
        "à l'infini"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "1/OA → 0 dans la relation de conjugaison : il reste OA′ = f′.",
      "piege": "Confondre plan focal image et plan focal objet.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-14",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Une lunette est <b>afocale</b> lorsque :",
      "options": [
        "F₁ est confondu avec F′₂",
        "f′₁ = f′₂",
        "F′₁ est confondu avec F₂",
        "les deux lentilles sont accolées"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le foyer <b>image</b> de l'objectif coïncide avec le foyer <b>objet</b> de l'oculaire : F′₁ = F₂.",
      "piege": "Confondre foyer objet et foyer image — c'est l'erreur la plus fréquente du chapitre.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "lun-15",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "L'intérêt d'une lunette afocale est que :",
      "options": ["l'œil observe une image à l'infini et n'accommode pas", "elle est plus courte, les deux foyers étant confondus", "elle ne renverse pas l'image, contrairement aux autres", "elle grossit davantage, l'image étant renvoyée à l'infini"],
      "bonne_reponse": [
        0
      ],
      "explication": "Objet à l'infini → image à l'infini : l'observation est nette et sans fatigue.",
      "piege": "Justifier par le grossissement, qui ne dépend pas du caractère afocal.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-16",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Un objectif de focale f′₁ = 90 cm et un oculaire de f′₂ = 3,0 cm forment une lunette afocale. Quelle est sa longueur ?",
      "options": [
        "270 cm",
        "93 cm",
        "30 cm",
        "87 cm"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "L = O₁O₂ = f′₁ + f′₂ = 90 + 3,0 = 93 cm.",
      "piege": "Soustraire les deux focales, ou les multiplier comme pour le grossissement.",
      "image": "lun_afocale.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-17",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre le tracé des rayons dans une lunette afocale :",
      "options": [
        "construire le plan focal image de L₁, plan vertical passant par F′₁",
        "tracer le rayon passant par O₁, qui n'est pas dévié",
        "tracer la droite (B₁O₂), qui donne la direction de sortie",
        "faire converger tous les rayons parallèles en B₁, sur le rayon non dévié",
        "faire ressortir les rayons parallèles à (B₁O₂), sous l'angle θ′"
      ],
      "bonne_reponse": [
        1,
        0,
        3,
        2,
        4
      ],
      "explication": "Cinq étapes, dans cet ordre : c'est le schéma le plus demandé du chapitre.",
      "piege": "Placer B₁ ailleurs que sur le rayon non dévié : toute la suite du tracé est alors fausse.",
      "image": "lun_afocale.png",
      "tags": [
        "construction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-18",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Où se placent les centres optiques O₁ et O₂ sur le schéma ?",
      "options": ["au milieu de la lunette, à mi-distance des deux lentilles", "aux extrémités de la lunette, sur son enveloppe extérieure", "à l'intersection de chaque lentille avec l'axe optique", "au foyer de chaque lentille, sur l'axe optique commun"],
      "bonne_reponse": [
        2
      ],
      "explication": "Point de rigueur attendu, avec un second : chaque trait est un rayon lumineux, donc fléché.",
      "piege": "Les placer approximativement : la construction perd sa cohérence géométrique.",
      "image": "lun_afocale.png",
      "tags": [
        "construction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-19",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Le grossissement d'une lunette est défini par :",
      "options": [
        "G = θ/θ′",
        "G = A₁B₁/f′_obj",
        "G = f′_oc/f′_obj",
        "G = θ′/θ"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Rapport de l'angle sous lequel on voit l'image à travers la lunette sur celui à l'œil nu.",
      "piege": "Inverser le rapport : le grossissement serait alors inférieur à 1.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-20",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Le grossissement d'une lunette afocale vaut :",
      "options": [
        "G = f′_obj / f′_oc",
        "G = f′_oc / f′_obj",
        "G = f′_obj + f′_oc",
        "G = f′_obj × f′_oc"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Pour grossir, il faut un objectif de <b>grande</b> focale et un oculaire de <b>courte</b> focale.",
      "piege": "Inverser le rapport : l'objectif a toujours la grande focale.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "lun-21",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Quelle hypothèse doit obligatoirement être citée dans la démonstration de G = f′_obj/f′_oc ?",
      "options": ["que l'objet est réel, sans quoi l'image ne se formerait pas", "l'approximation des petits angles, qui donne tan θ ≈ θ", "que l'image intermédiaire est renversée par l'objectif", "que les lentilles sont minces devant leur distance focale"],
      "bonne_reponse": [
        1
      ],
      "explication": "Sans elle, on ne peut pas remplacer les tangentes par les angles dans le rapport.",
      "piege": "Oublier de la citer : c'est une erreur explicitement listée dans la fiche.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "actif": true
    },
    {
      "ref": "lun-22",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 6",
      "enonce": "Une lunette a f′_obj = 90 cm et f′_oc = 3,0 cm. Quel est son grossissement ?",
      "options": [
        "93",
        "0,033",
        "30",
        "270"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "G = 90/3,0 = 30 : l'objet paraît trente fois plus grand qu'à l'œil nu.",
      "piege": "Inverser le quotient et trouver 0,033, ce qui reviendrait à réduire l'image.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "lun-23",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "L'angle sous lequel on voit un objet de diamètre d à la distance D vaut :",
      "options": [
        "θ = d/D en degrés",
        "θ = D/d",
        "θ = d × D",
        "θ ≈ d/D en radians"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Dans le triangle rectangle, tan θ = d/D, et l'approximation des petits angles donne θ ≈ d/D — <b>en radians</b>.",
      "piege": "Travailler en degrés : θ = d/D donne toujours un angle en radians.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-24",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Un objet est visible à l'œil nu si :",
      "options": ["θ > ε, où ε est le pouvoir séparateur de l'œil", "d > D, où D est la distance minimale de vision nette", "θ = 0, l'objet étant vu sous un angle nul depuis l'œil", "θ &lt; ε, où ε est le pouvoir séparateur de l'œil"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le pouvoir séparateur ε est le plus petit angle que l'œil sait distinguer.",
      "piege": "Comparer des longueurs au lieu des angles : c'est bien θ que l'on compare à ε.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-25",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Un cratère de d = 2,0 km est observé à D = 3,8×10⁵ km. Quel est l'angle sous lequel on le voit ?",
      "options": [
        "5,3×10⁻³ rad",
        "5,3×10⁻⁶ rad",
        "1,9×10⁵ rad",
        "2,0×10⁻⁶ rad"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "θ ≈ d/D = 2,0 / 3,8×10⁵ = 5,3×10⁻⁶ rad. Les deux distances étant en kilomètres, aucune conversion n'est nécessaire.",
      "piege": "Inverser le quotient, ou convertir l'une des deux distances et pas l'autre.",
      "image": "lun_angle.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "lun-26",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Avec une lunette de grossissement G, sous quel angle voit-on l'objet ?",
      "options": [
        "θ′ = θ + G",
        "θ′ = ε × G",
        "θ′ = G × θ",
        "θ′ = θ / G"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "θ′ = G × θ = θ × f′_obj/f′_oc : c'est cet angle qu'on compare ensuite au pouvoir séparateur.",
      "piege": "Diviser par G : la lunette agrandirait alors l'angle... en le réduisant.",
      "image": "lun_angle.png",
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-27",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre la détermination de l'oculaire à choisir :",
      "options": [
        "on remplace θ par d/D : G<sub>min</sub> = ε × D/d",
        "on identifie avec G = f′_obj/f′_oc",
        "on isole : f′_oc = f′_obj × d/(ε × D)",
        "le grossissement minimal vaut G<sub>min</sub> = ε/θ"
      ],
      "bonne_reponse": [
        3,
        0,
        1,
        2
      ],
      "explication": "C'est la distance focale de l'oculaire qui fixe le choix, l'objectif étant imposé par l'instrument.",
      "piege": "Isoler f′_obj au lieu de f′_oc : c'est pourtant l'oculaire que l'on change.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-28",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Pour savoir si un objet sera visible à travers une lunette donnée, on procède en :",
      "options": ["comparant d à ε, la taille de l'objet au pouvoir séparateur", "calculant la longueur de la lunette, somme des deux focales", "comparant les focales entre elles, la plus grande l'emportant", "exprimant G, isolant θ′ = θ × f′_obj/f′_oc, puis comparant θ′ à ε"],
      "bonne_reponse": [
        3
      ],
      "explication": "Trois temps : exprimer le grossissement, isoler l'angle vu à travers la lunette, comparer au pouvoir séparateur.",
      "piege": "Comparer directement des longueurs : la visibilité se juge sur un angle.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "lun-29",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "θ = 5,3×10⁻⁶ rad et le pouvoir séparateur vaut ε = 3,0×10⁻⁴ rad. Quel grossissement minimal faut-il ?",
      "options": [
        "G<sub>min</sub> = 57",
        "G<sub>min</sub> = 1,6×10⁻⁹",
        "G<sub>min</sub> = 1,8×10⁻²",
        "aucune lunette n'est nécessaire"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "G<sub>min</sub> = ε/θ = 3,0×10⁻⁴ / 5,3×10⁻⁶ = 57 : il faut au moins grossir 57 fois.",
      "piege": "Inverser le quotient et obtenir un grossissement inférieur à 1.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "lun-30",
      "chapitre": "la-lunette-astronomique",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Un grossissement plus élevé demande un oculaire :",
      "options": [
        "identique à l'objectif",
        "de plus courte focale",
        "de vergence négative",
        "de plus grande focale"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "G = f′_obj/f′_oc : diminuer f′_oc augmente le grossissement.",
      "piege": "Choisir un oculaire de grande focale, ce qui réduirait le grossissement.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "lunette-t01", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Pour construire l'image d'un point B hors de l'axe par une lentille convergente, on trace :", "options": ["deux rayons parallèles à l'axe, qui ressortent tous deux par F′", "un seul rayon quelconque, suffisant pour situer l'image de B", "un rayon par le centre optique, non dévié, et un parallèle à l'axe", "un rayon passant par F′ à l'aller, et un autre par le centre optique"], "bonne_reponse": [2], "explication": "Deux rayons particuliers suffisent : par O, non dévié ; parallèle à l'axe, émergeant par F′. Leur intersection est B′. Un troisième, passant par F, ressort parallèle — il sert de vérification.", "piege": "Se contenter d'un rayon : il faut l'intersection de deux pour localiser l'image.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lunette-t02", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un objet est à 30 cm d'une lentille de distance focale f′ = 10 cm. L'image se forme à :", "options": ["1/OA′ = 1/OA − 1/f′ = −1/30 − 1/10 = −4/30, donc OA′ = −7,5 cm", "1/OA′ = 1/OA + 1/f′ = −1/30 + 1/10 = 2/30, donc OA′ = 15 cm : réelle", "1/OA′ = 1/f′ − 1/OA = 1/10 + 1/30 = 4/30, donc OA′ = 7,5 cm : réelle", "1/OA′ = 1/OA + 1/f′ = 1/30 + 1/10 = 4/30, donc OA′ = −15 cm : virtuelle"], "bonne_reponse": [1], "explication": "Relation de conjugaison 1/OA′ − 1/OA = 1/f′ avec OA = −30 cm (objet à gauche). 1/OA′ = 1/10 − 1/30 = 1/15. Image à 15 cm à droite, réelle. Grandissement γ = OA′/OA = −0,5.", "piege": "Oublier le signe de OA : l'objet est à gauche, sa mesure algébrique est négative.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lunette-t03", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Un objet est à l'infini. D'après la relation de conjugaison, l'image se forme :", "options": ["dans le plan focal image, car 1/OA → 0 donc 1/OA′ = 1/f′", "dans le plan focal objet, car 1/OA → 0 donc 1/OA′ = −1/f′", "à l'infini, car 1/OA → 0 donc 1/OA′ → 0 également", "au centre optique, car 1/OA → 0 donc OA′ → 0 également"], "bonne_reponse": [0], "explication": "Objet à l'infini : OA → −∞, donc 1/OA → 0. Il reste 1/OA′ = 1/f′ : l'image est en F′. C'est le cas d'une étoile pour l'objectif.", "piege": "Confondre plan focal objet et image : l'image d'un objet à l'infini est en F′, pas en F.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lunette-t04", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Une lunette est afocale lorsque :", "options": ["les deux lentilles ont la même distance focale, donc le même foyer", "l'objectif est plus grand que l'oculaire, ce qui assure le grossissement", "le foyer image de l'objectif est confondu avec le foyer objet de l'oculaire", "le foyer objet de l'objectif est confondu avec le foyer image de l'oculaire"], "bonne_reponse": [2], "explication": "F′₁ = F₂ : l'image intermédiaire, dans le plan focal de l'objectif, est dans le plan focal objet de l'oculaire, qui la renvoie à l'infini. L'œil observe sans accommoder. Longueur : O₁O₂ = f′₁ + f′₂.", "piege": "Croire que « afocale » veut dire sans foyer : les lentilles en ont, c'est l'ensemble qui n'en a pas.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lunette-t05", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Dans une lunette afocale, un faisceau incident parallèle, incliné de θ, ressort de l'oculaire :", "options": ["parallèle, incliné de θ′ > θ, après l'image intermédiaire A₁B₁", "convergent vers un point du plan focal image de l'oculaire", "parallèle, incliné du même angle θ, l'image restant identique", "divergent depuis un point du plan focal objet de l'oculaire"], "bonne_reponse": [0], "explication": "L'objectif forme A₁B₁ en F′₁. L'oculaire, dont F₂ est en ce point, renvoie un faisceau parallèle. Pour tracer : le rayon par O₂ issu de B₁ donne la direction de sortie.", "piege": "Faire converger le faisceau de sortie : l'œil, placé derrière, doit recevoir un faisceau parallèle.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lunette-t06", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "L'image intermédiaire a pour taille A₁B₁. Avec θ ≈ tan θ = A₁B₁/f′₁ et θ′ ≈ tan θ′ = A₁B₁/f′₂, le grossissement vaut :", "options": ["G = θ/θ′ = f′₂/f′₁", "G = θ′/θ = f′₁/f′₂", "G = f′₁ × f′₂", "G = f′₁ + f′₂"], "bonne_reponse": [1], "explication": "A₁B₁ est vu depuis O₁ sous θ et depuis O₂ sous θ′. Le rapport élimine A₁B₁ : G = f′₁/f′₂. Une lunette grossit si l'objectif a une longue focale et l'oculaire une courte.", "piege": "Inverser le rapport : c'est la focale de l'OBJECTIF au numérateur.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lunette-t07", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Un cratère lunaire de diamètre 4,0 km est à 3,8 × 10⁵ km. Avec une limite de résolution de l'œil de 3 × 10⁻⁴ rad, il est :", "options": ["visible à l'œil nu : θ = 4,0/3,8 × 10⁵ = 1,1 × 10⁻⁵ rad > 3 × 10⁻⁴ rad", "indéterminé : θ = 4,0/3,8 × 10⁵ = 1,1 × 10⁻⁵ rad, du même ordre que ε", "visible à l'œil nu : θ = 3,8 × 10⁵/4,0 = 9,5 × 10⁴ rad > 3 × 10⁻⁴ rad", "invisible à l'œil nu : θ = 4,0/3,8 × 10⁵ = 1,1 × 10⁻⁵ rad &lt; 3 × 10⁻⁴ rad"], "bonne_reponse": [3], "explication": "Le diamètre apparent est θ ≈ d/D = 1,1 × 10⁻⁵ rad. Inférieur au pouvoir séparateur de l'œil : on ne le distingue pas. Une lunette de grossissement 30 le rend visible.", "piege": "Juger par la taille réelle : c'est l'ANGLE sous lequel on voit l'objet qui compte.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "lunette-t08", "chapitre": "lunette", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Pour rendre visible ce cratère (θ = 1,1 × 10⁻⁵ rad), avec un objectif de f′₁ = 900 mm, le grossissement minimal et l'oculaire à choisir sont :", "options": ["G_min = 1,1 × 10⁻⁵/3 × 10⁻⁴ ≈ 0,04, donc f′₂ ≤ 900/0,04 ≈ 23 m", "G_min = 3 × 10⁻⁴ × 1,1 × 10⁻⁵ ≈ 3, donc f′₂ ≤ 900/3 ≈ 300 mm", "G_min = 3 × 10⁻⁴/1,1 × 10⁻⁵ ≈ 27, donc f′₂ ≤ 900/27 ≈ 33 mm", "G_min = 3 × 10⁻⁴/1,1 × 10⁻⁵ ≈ 27, donc f′₂ ≥ 900/27 ≈ 33 mm"], "bonne_reponse": [2], "explication": "Il faut θ′ = G·θ ≥ 3 × 10⁻⁴ rad, donc G ≥ 27. Avec G = f′₁/f′₂ : f′₂ ≤ f′₁/G = 33 mm. Un oculaire de 25 mm convient, un de 40 mm non.", "piege": "Inverser l'inégalité sur f′₂ : plus l'oculaire a une focale COURTE, plus le grossissement est grand.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  cinematique: [
    {
      "ref": "cin2-01",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Un <b>référentiel</b> est :",
      "options": ["l'objet de référence par rapport auquel on étudie le mouvement", "la trajectoire suivie par le système au cours du mouvement", "l'objet dont on étudie le mouvement au cours du temps", "le repère d'espace choisi pour repérer la position du système"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le système est l'objet étudié, le référentiel l'objet par rapport auquel on l'étudie. Trois à connaître : terrestre, géocentrique, héliocentrique.",
      "piege": "Confondre système et référentiel : la première étape de tout exercice consiste à définir les deux.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "cin2-02",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Le référentiel <b>géocentrique</b> est adapté à l'étude :",
      "options": [
        "du mouvement des planètes autour du Soleil",
        "du mouvement d'un satellite autour de la Terre",
        "d'une chute au sol",
        "d'une voiture sur une route"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Terrestre pour la surface de la Terre, géocentrique autour du centre de la Terre, héliocentrique autour du Soleil.",
      "piege": "Choisir le référentiel terrestre pour un satellite : sa trajectoire n'y serait pas exploitable.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-03",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La norme du poids vaut :",
      "options": [
        "P = m·g²",
        "P = m/g",
        "P = m·g",
        "P = g/m"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le poids <span class=\"vec\">P</span> est vertical, dirigé vers le centre de la Terre, de norme P = m·g.",
      "piege": "Écrire le vecteur et sa norme avec le même symbole : on écrit <span class=\"vec\">P</span> pour le vecteur et P pour sa norme.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-04",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Remets dans l'ordre la méthode du bilan des forces :",
      "options": [
        "lister toutes les forces qui s'appliquent",
        "définir le système et le référentiel",
        "donner pour chacune direction, sens, point d'application et norme",
        "les représenter à partir du centre de gravité"
      ],
      "bonne_reponse": [
        1,
        0,
        2,
        3
      ],
      "explication": "Quatre caractéristiques par force : c'est ce qui est noté, pas seulement le nom de la force.",
      "piege": "Représenter les forces sans les avoir caractérisées.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-05",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "La réaction normale du support est dirigée :",
      "options": ["dans la direction du mouvement, du système vers le support", "vers le centre de la Terre, comme toute force de contact", "le long du fil, du système vers le point d'attache", "orthogonalement au support, du support vers le système"],
      "bonne_reponse": [
        3
      ],
      "explication": "Sa norme est une inconnue que l'exercice fera déterminer : aucune formule n'est exigible.",
      "piege": "Chercher une formule pour la réaction normale : seule celle du poids est au programme.",
      "image": "cin_forces.png",
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-06",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Une caisse <b>monte</b> le long d'un plan incliné. Dans quel sens est la force de frottement ?",
      "options": ["vers le bas de la pente, opposée au mouvement", "vers le centre de la Terre, comme le poids", "orthogonale au support, comme la réaction normale", "vers le haut de la pente, dans le sens du mouvement"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le frottement a la direction du mouvement et le sens opposé : si la caisse monte, il descend.",
      "piege": "Le placer dans le sens du mouvement, ou inventer une « force du mouvement » qui n'existe pas.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "cin2-07",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Quelle est l'erreur la plus fréquente dans un bilan des forces ?",
      "options": ["oublier de citer le référentiel avant de faire le bilan", "faire figurer une « force du mouvement », qui n'existe pas", "représenter les forces trop longues sur le schéma", "donner la norme du poids au lieu de son expression vectorielle"],
      "bonne_reponse": [
        1
      ],
      "explication": "Un système en mouvement n'est soumis à aucune force du fait de son mouvement : seules comptent les interactions.",
      "piege": "Ajouter une flèche dans le sens du déplacement pour « expliquer » le mouvement.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {
      "ref": "cin2-08",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "L'expression vectorielle de la force gravitationnelle exercée par A sur B s'écrit :",
      "options": ["F⃗_A/B = + G·m_A·m_B/r² · u⃗, avec u⃗ dirigé de A vers B", "F⃗_A/B = − G·m_A·m_B/r · u⃗, avec u⃗ dirigé de A vers B", "F⃗_A/B = − G·m_A·m_B/r² · u⃗, avec u⃗ dirigé de A vers B", "F⃗_A/B = − G·m_A·m_B·r² · u⃗, avec u⃗ dirigé de A vers B"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le signe moins traduit le caractère attractif : la force est dirigée de B vers A, à l'opposé du vecteur unitaire.",
      "piege": "Oublier le signe − : la force gravitationnelle est toujours attractive.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "cin2-09",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Pour la force électrostatique, qu'est-ce qui décide du sens ?",
      "options": [
        "la masse des particules",
        "la distance entre les charges",
        "la constante k",
        "le signe du produit des charges q<sub>A</sub>·q<sub>B</sub>"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Attractive si q<sub>A</sub>·q<sub>B</sub> &lt; 0, répulsive si q<sub>A</sub>·q<sub>B</sub> > 0. C'est la différence avec la gravitation.",
      "piege": "Appliquer systématiquement le signe − comme pour la gravitation.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-10",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Quelle relation lie les deux forces gravitationnelles entre A et B ?",
      "options": [
        "<span class=\"vec\">F</span><sub>A/B</sub> = − <span class=\"vec\">F</span><sub>B/A</sub>",
        "elles sont sans rapport",
        "<span class=\"vec\">F</span><sub>A/B</sub> = <span class=\"vec\">F</span><sub>B/A</sub>",
        "<span class=\"vec\">F</span><sub>A/B</sub> = 2·<span class=\"vec\">F</span><sub>B/A</sub>"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est la troisième loi de Newton : même intensité, sens opposés.",
      "piege": "Croire que le corps le plus massif exerce une force plus grande.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-11",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Que faut-il préciser pour <b>caractériser</b> un mouvement ? <b>Plusieurs réponses.</b>",
      "options": [
        "la masse du système",
        "le référentiel d'étude",
        "la nature de la trajectoire",
        "l'évolution de la vitesse"
      ],
      "bonne_reponse": [
        1,
        2,
        3
      ],
      "explication": "Trois éléments dans la phrase attendue : « le mouvement est rectiligne et uniformément accéléré dans le référentiel terrestre ».",
      "piege": "Oublier de citer le référentiel — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-12",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Sur une chronophotographie, des points de plus en plus <b>resserrés</b> traduisent un mouvement :",
      "options": [
        "rectiligne accéléré",
        "rectiligne décéléré",
        "circulaire",
        "rectiligne uniforme"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Régulièrement espacés → uniforme · de plus en plus écartés → accéléré · de plus en plus resserrés → décéléré.",
      "piege": "Inverser accéléré et décéléré : plus les points sont proches, moins le système avance vite.",
      "image": "cin_chrono.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-13",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Des points régulièrement espacés sur une droite traduisent un mouvement :",
      "options": [
        "circulaire uniforme",
        "parabolique",
        "rectiligne et uniforme",
        "rectiligne et accéléré"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Même trajectoire droite, même distance parcourue à chaque intervalle : la vitesse est constante.",
      "piege": "Conclure sur la trajectoire sans conclure sur la vitesse, ou l'inverse.",
      "image": "cin_chrono.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-14",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "La variante <b>centrée</b> du vecteur vitesse au point M<sub>i</sub> s'écrit :",
      "options": [
        "v<sub>i</sub> = M_(i−1)M<sub>i</sub>/Δt",
        "v<sub>i</sub> = M_(i−1)M_(i+1)/Δt",
        "v<sub>i</sub> = M_iM_(i+1)/Δt",
        "v<sub>i</sub> = M_(i−1)M_(i+1)/(2Δt)"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "On encadre le point : la corde va de M_(i−1) à M_(i+1), donc la durée vaut 2Δt. C'est plus précis si la trajectoire est courbée.",
      "piege": "Utiliser Δt au lieu de 2Δt quand on encadre le point — le piège explicite de cette QT.",
      "image": "cin_vitesse.png",
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "cin2-15",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Remets dans l'ordre le tracé du vecteur vitesse au point M₂ :",
      "options": [
        "mesurer la distance M₁M₃ sur le document, avec l'échelle des longueurs",
        "convertir cette valeur en longueur à tracer, avec l'échelle des vitesses",
        "calculer v₂ = M₁M₃/(2Δt)",
        "tracer le vecteur depuis M₂, colinéaire à la corde M₁M₃ et dans le sens du mouvement"
      ],
      "bonne_reponse": [
        0,
        2,
        1,
        3
      ],
      "explication": "Deux échelles différentes interviennent : celle des longueurs pour mesurer, celle des vitesses pour tracer.",
      "piege": "Tracer le vecteur sans utiliser l'échelle des vitesses.",
      "image": "cin_vitesse.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-16",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Quelles sont les caractéristiques du vecteur vitesse ?",
      "options": ["direction tangente à la trajectoire, sens du mouvement, origine M_i", "direction verticale, sens vers le bas, origine le point M_i", "direction quelconque, sens du mouvement, origine le point M_i", "direction vers le centre, sens du mouvement, origine le point M_i"],
      "bonne_reponse": [
        0
      ],
      "explication": "La vitesse est toujours tangente à la trajectoire : c'est ce qui la distingue de l'accélération.",
      "piege": "La tracer vers l'intérieur de la trajectoire, ce qui est la propriété de l'accélération.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-17",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre le tracé du vecteur accélération au point M₂ :",
      "options": [
        "calculer a₂ = Δv₂/Δt",
        "tracer <span class=\"vec\">a</span><sub>2</sub> depuis M₂, colinéaire et de même sens que <span class=\"vec\">Δv</span>",
        "mesurer sa longueur et la convertir avec l'échelle des vitesses",
        "construire <span class=\"vec\">Δv</span> = <span class=\"vec\">v</span><sub>3</sub> − <span class=\"vec\">v</span><sub>2</sub>, bout à bout depuis M₂"
      ],
      "bonne_reponse": [
        3,
        2,
        0,
        1
      ],
      "explication": "<span class=\"vec\">a</span> est toujours colinéaire à <span class=\"vec\">Δv</span> : c'est la construction de Δv qui fait tout le travail.",
      "piege": "Tracer l'accélération dans le sens de la vitesse plutôt que dans celui de sa variation.",
      "image": "cin_acceleration.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-18",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Comment vérifier qu'un vecteur accélération a été correctement tracé ?",
      "options": [
        "il doit être vertical",
        "il doit pointer vers l'intérieur de la trajectoire",
        "il doit avoir la même longueur que la vitesse",
        "il doit être tangent à la trajectoire"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "S'il pointe vers l'extérieur, c'est que <span class=\"vec\">Δv</span> a été construit à l'envers.",
      "piege": "Ne pas faire cette vérification, qui détecte immédiatement une soustraction inversée.",
      "image": "cin_acceleration.png",
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-19",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Comment obtient-on les coordonnées du vecteur vitesse à partir des équations horaires ?",
      "options": [
        "en dérivant deux fois",
        "en intégrant chaque coordonnée",
        "en dérivant chaque coordonnée une fois",
        "en divisant par le temps"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "v<sub>x</sub> = dx/dt, puis a<sub>x</sub> = dv_x/dt : une dérivation pour la vitesse, deux pour l'accélération.",
      "piege": "Confondre dérivation et intégration : on primitive pour remonter des accélérations aux positions.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-20",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 6",
      "enonce": "Pour x(t) = 2t² − 3t + 1, que vaut v<sub>x</sub>(t) ?",
      "options": [
        "t² − 3t",
        "2t − 3",
        "4t",
        "4t − 3"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "On dérive : la dérivée de 2t² vaut 4t, celle de −3t vaut −3, celle de la constante est nulle.",
      "piege": "Oublier le facteur 2 devant t² en dérivant.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-21",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 6",
      "enonce": "Avec v<sub>x</sub> = 4t − 3, v<sub>y</sub> = 3 et v<sub>z</sub> = 0, que vaut la valeur de l'accélération ?",
      "options": [
        "4 m·s⁻²",
        "3 m·s⁻²",
        "5 m·s⁻²",
        "0 m·s⁻²"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "a<sub>x</sub> = 4, a<sub>y</sub> = 0, a<sub>z</sub> = 0, donc a = √(4² + 0 + 0) = 4 m·s⁻².",
      "piege": "Inclure v<sub>y</sub> = 3 dans le calcul : c'est une vitesse constante, son accélération est nulle.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "cin2-22",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Pour montrer qu'un mouvement est uniformément accéléré, il faut montrer que :",
      "options": ["le vecteur v⃗ est constant : même valeur, même direction, même sens", "le vecteur a⃗ est constant : même valeur, même direction, même sens", "la trajectoire est rectiligne, et le vecteur a⃗ dirigé selon elle", "le vecteur a⃗ est nul : la vitesse croît alors régulièrement"],
      "bonne_reponse": [
        1
      ],
      "explication": "Trois conditions sur le vecteur, pas seulement sur sa valeur numérique.",
      "piege": "Se contenter de dire que la valeur de a ne dépend pas du temps.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "cin2-23",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Sur un graphe v<sub>x</sub> = f(t), qu'est-ce qui prouve que le mouvement est uniformément accéléré ?",
      "options": ["la courbe passe par l'origine : la vitesse initiale est nulle", "la courbe est croissante : la vitesse augmente au cours du temps", "la courbe est une droite : son coefficient directeur a_x est constant", "la courbe est une parabole : la vitesse croît comme le carré de t"],
      "bonne_reponse": [
        2
      ],
      "explication": "a<sub>x</sub> = dv_x/dt : une droite a une pente constante. Si elle décroît, le mouvement est simplement décéléré.",
      "piege": "Conclure « accéléré » du seul fait que la courbe est croissante.",
      "image": "cin_vx.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-24",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "En chute libre, a<sub>x</sub> = 0 et a<sub>y</sub> = −g. Le mouvement est-il uniformément accéléré ?",
      "options": [
        "oui, mais seulement à la verticale",
        "non, l'accélération varie",
        "non, la trajectoire est parabolique",
        "oui : a = g = 9,81 m·s⁻², constante"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Le vecteur <span class=\"vec\">a</span> est constant en valeur, direction et sens — même si la trajectoire est courbe.",
      "piege": "Croire qu'une trajectoire parabolique interdit un mouvement uniformément accéléré.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-25",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Sur une courbe y = f(t), comment lit-on la vitesse à une date donnée ?",
      "options": ["on trace la tangente et on calcule sa pente avec deux points lisibles", "on lit l'ordonnée du point, qui donne directement la vitesse", "on mesure l'aire sous la courbe entre l'origine et ce point", "on divise l'ordonnée du point par la date t correspondante"],
      "bonne_reponse": [
        0
      ],
      "explication": "v = |dy/dt| : c'est une pente, jamais une ordonnée.",
      "piege": "Lire une ordonnée à la place d'une pente — le réflexe à corriger.",
      "image": "cin_tangente.png",
      "tags": [
        "lecture graphique"
      ],
      "actif": true
    },
    {
      "ref": "cin2-26",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "La tangente en t = 6 s passe par A (3 ; 0) et B (8 ; 4200). Que vaut la vitesse ?",
      "options": [
        "525 m·s⁻¹",
        "840 m·s⁻¹",
        "4 200 m·s⁻¹",
        "1 400 m·s⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "v = |(4200 − 0)/(8 − 3)| = 840 m·s⁻¹.",
      "piege": "Prendre l'ordonnée du point B, 4 200, au lieu de la pente.",
      "image": "cin_tangente.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "cin2-27",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Une tangente <b>horizontale</b> à la courbe y = f(t) signifie :",
      "options": [
        "le mouvement est uniforme",
        "la vitesse est maximale",
        "la vitesse est nulle à cet instant",
        "l'accélération est nulle"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Pente nulle, donc vitesse nulle. C'est le cas au départ d'une chute ou au sommet d'une trajectoire.",
      "piege": "Confondre pente nulle et ordonnée nulle.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-28",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Remets dans l'ordre l'établissement des équations horaires, à partir de l'accélération :",
      "options": [
        "on détermine K₂ avec la condition initiale sur la position",
        "v<sub>x</sub> est une primitive de a<sub>x</sub> : v<sub>x</sub>(t) = a·t + K₁",
        "on part de a<sub>x</sub>(t) = dv_x/dt = a, donnée par l'énoncé",
        "x est une primitive de v<sub>x</sub> : x(t) = a·t²/2 + K₂",
        "on détermine K₁ avec la condition initiale sur la vitesse"
      ],
      "bonne_reponse": [
        2,
        1,
        4,
        3,
        0
      ],
      "explication": "Deux primitives, deux constantes, deux jeux de conditions initiales : la structure est toujours la même.",
      "piege": "Oublier les constantes d'intégration, ou les déterminer toutes deux à la fin.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-29",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Un système part de O au repos avec une accélération a constante. Que vaut x(t) ?",
      "options": [
        "x(t) = a·t²/2 + v₀·t",
        "x(t) = a·t² ",
        "x(t) = a·t",
        "x(t) = a·t²/2"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Les deux constantes sont nulles : le système part de l'origine et sans vitesse initiale.",
      "piege": "Garder un terme en v₀·t alors que la vitesse initiale est nulle.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-30",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Pour un mouvement rectiligne <b>uniforme</b> de vitesse v₀, partant de O :",
      "options": [
        "x(t) = v₀·t",
        "x(t) = v₀/t",
        "x(t) = v₀·t²/2",
        "x(t) = v₀"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "v<sub>x</sub> = v₀ constante, donc x est une primitive de v₀ : une seule primitive suffit ici.",
      "piege": "Appliquer la formule du mouvement accéléré alors que l'accélération est nulle.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-31",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Dans la base de Frenet, le vecteur accélération s'écrit :",
      "options": ["a⃗ = (dv/dt)·u⃗_N, la seule composante normale subsistant", "a⃗ = (dv/dt)·u⃗_T + (v²/R)·u⃗_N, avec R le rayon de courbure", "a⃗ = (v²/R)·u⃗_T, la seule composante tangentielle subsistant", "a⃗ = v·u⃗_T + v·u⃗_N, les deux composantes valant la vitesse"],
      "bonne_reponse": [
        1
      ],
      "explication": "<span class=\"vec\">u</span><sub>T</sub> est tangent à la trajectoire, <span class=\"vec\">u</span><sub>N</sub> est dirigé vers le centre.",
      "piege": "Intervertir les deux composantes : le terme en v²/R est toujours porté par la normale.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-32",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Pour un mouvement circulaire <b>uniforme</b>, que devient cette expression ?",
      "options": ["a⃗ = (dv/dt)·u⃗_T : l'accélération est tangentielle", "a⃗ = v·u⃗_N : l'accélération est centripète et vaut v", "a⃗ = (v²/R)·u⃗_N : l'accélération est centripète", "a⃗ = 0⃗ : l'accélération est nulle, la vitesse étant constante"],
      "bonne_reponse": [
        2
      ],
      "explication": "La vitesse étant constante en valeur, dv/dt = 0 et le terme tangentiel disparaît.",
      "piege": "Conclure que l'accélération est nulle parce que la vitesse est constante.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-33",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Pourquoi un mouvement circulaire uniforme est-il malgré tout accéléré ?",
      "options": ["parce que la valeur de la vitesse augmente le long du cercle", "parce que le rayon de courbure varie au cours du mouvement", "il n'est pas accéléré : la valeur de la vitesse reste constante", "parce que la direction du vecteur v⃗ change en permanence"],
      "bonne_reponse": [
        3
      ],
      "explication": "La valeur v²/R est constante, mais la direction du vecteur accélération change à chaque instant.",
      "piege": "Confondre la valeur de la vitesse et le vecteur vitesse : seul le second est constant dans un mouvement uniforme rectiligne.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "cin2-34",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Un élève écrit v = 3 m·s⁻¹ pour le vecteur vitesse. Que faut-il corriger ?",
      "options": ["il fallait dériver le vecteur position avant de conclure", "un vecteur ne s'écrit pas comme un nombre : v⃗ porte une flèche", "l'unité est fausse : une vitesse s'exprime en km·h⁻¹", "rien : la norme du vecteur vitesse vaut bien 3 m·s⁻¹"],
      "bonne_reponse": [
        1
      ],
      "explication": "Chaque symbole de vecteur porte une flèche sur la copie : la distinction est notée.",
      "piege": "Écrire le vecteur et sa norme avec le même symbole.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cin2-35",
      "chapitre": "cinematique-du-point-materiel",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelle grandeur se conserve dans un mouvement rectiligne uniforme ?",
      "options": [
        "le vecteur <span class=\"vec\">a</span>",
        "la position",
        "le vecteur <span class=\"vec\">v</span>",
        "aucune"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Vitesse constante en valeur, direction et sens : l'accélération est alors nulle.",
      "piege": "Répondre que l'accélération se conserve : elle est nulle, ce qui est un cas particulier.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "cinematique-t01", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Une bille est lâchée sans vitesse initiale dans l'air. On néglige les frottements et la poussée d'Archimède. Quelles forces s'exercent sur elle pendant la chute ?", "options": ["Son poids et la force de lancement", "Aucune : elle est en chute libre", "Son poids et la réaction de l'air", "Son poids uniquement"], "bonne_reponse": [3], "explication": "En chute libre, la seule force est le poids. Il n'existe pas de « force de lancement » qui accompagnerait le mobile : une fois lâchée, la bille n'est plus en contact avec la main.", "piege": "Inventer une force qui « pousse » le mobile dans le sens du mouvement — c'est l'erreur la plus fréquente dans un bilan.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t02", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un système de masse m est soumis à son poids. Dans un repère où l'axe (Oz) est vertical et dirigé vers le haut, l'expression vectorielle du poids est :", "options": ["P⃗ = m·g·u⃗_z", "P⃗ = −m·g", "P⃗ = m·g", "P⃗ = −m·g·u⃗_z"], "bonne_reponse": [3], "explication": "Le poids est vertical, dirigé vers le bas : avec (Oz) vers le haut, sa composante est −m·g. Une force est un vecteur : l'expression doit porter un vecteur unitaire.", "piege": "Écrire P = m·g sans vecteur ni signe — ce n'est qu'une norme, pas l'expression vectorielle demandée.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t03", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Sur une chronophotographie prise à intervalles réguliers, les positions successives d'un mobile sont alignées et de plus en plus espacées. Le mouvement est :", "options": ["rectiligne accéléré", "curviligne accéléré", "rectiligne uniforme", "rectiligne ralenti"], "bonne_reponse": [0], "explication": "Positions alignées : trajectoire rectiligne. Espacement croissant à intervalles de temps égaux : la vitesse augmente, le mouvement est accéléré.", "piege": "Caractériser un mouvement demande DEUX mots : la forme de la trajectoire et l'évolution de la vitesse.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t04", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Sur une chronophotographie d'intervalle Δt = 0,10 s, la distance entre les points M₃ et M₄ mesure 2,0 cm sur le document, à l'échelle 1 cm pour 0,50 m. Que vaut la valeur de la vitesse v₃ au point M₃ ?", "options": ["v₃ = M₃M₄ × Δt = 2,0 × 0,50 × 0,10 = 0,10 m·s⁻¹", "v₃ = M₃M₄ / Δt = 2,0 / 0,10 = 20 m·s⁻¹", "v₃ = M₂M₄ / (2Δt) = (2,0 × 0,50) / 0,20 = 5,0 m·s⁻¹", "v₃ = M₃M₄ / Δt = (2,0 × 0,50) / 0,10 = 10 m·s⁻¹"], "bonne_reponse": [3], "explication": "La vitesse au point Mᵢ se calcule avec le déplacement vers le point SUIVANT, sur UN intervalle : vᵢ = MᵢMᵢ₊₁ / Δt. La distance mesurée se convertit d'abord avec l'échelle : 2,0 cm → 1,0 m.", "piege": "Oublier l'échelle du document, ou employer la variante centrée M₂M₄/(2Δt) qui n'est pas la convention retenue.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t05", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Pour tracer le vecteur accélération a⃗₃ au point M₃ d'une chronophotographie, on construit d'abord le vecteur :", "options": ["Δv⃗₃ = v⃗₃ + v⃗₂, somme des deux vitesses", "Δv⃗₃ = v⃗₄ − v⃗₃, en reportant v⃗₃ à l'origine de v⃗₄", "Δv⃗₃ = v⃗₄ − v⃗₂, entre les deux vitesses voisines", "Δv⃗₃ = v⃗₃ − v⃗₂, en reportant v⃗₂ à l'origine de v⃗₃"], "bonne_reponse": [3], "explication": "La variation de vitesse au point Mᵢ est Δv⃗ᵢ = v⃗ᵢ − v⃗ᵢ₋₁ : on soustrait la vitesse PRÉCÉDENTE. Graphiquement, on reporte v⃗ᵢ₋₁ à l'origine de v⃗ᵢ, et Δv⃗ᵢ joint les deux extrémités. Le vecteur accélération a même direction et même sens.", "piege": "Additionner les vitesses, ou soustraire dans le mauvais ordre : le vecteur obtenu pointe alors à l'opposé.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t06", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Les équations horaires d'un mobile sont x(t) = 3t² + 2t et y(t) = 5t. Les coordonnées de son vecteur accélération sont :", "options": ["aₓ = 3 et a_y = 0", "aₓ = 6 et a_y = 0", "aₓ = 6t + 2 et a_y = 5", "aₓ = 6t et a_y = 5"], "bonne_reponse": [1], "explication": "On dérive deux fois : vₓ = 6t + 2 puis aₓ = 6 ; v_y = 5 puis a_y = 0. L'accélération est constante, dirigée selon (Ox).", "piege": "S'arrêter à la première dérivée, qui donne la vitesse et non l'accélération.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t07", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Pour montrer qu'un mouvement est uniformément accéléré, il suffit de montrer que :", "options": ["la valeur de la vitesse augmente régulièrement au cours du temps", "le vecteur a⃗ est constant, en direction, en sens et en valeur", "la trajectoire est rectiligne, et parcourue de plus en plus vite", "la valeur de l'accélération est positive tout au long du trajet"], "bonne_reponse": [1], "explication": "« Uniformément accéléré » signifie que l'accélération est un vecteur CONSTANT. Sur une chronophotographie, on vérifie que les vecteurs Δv⃗ᵢ ont même longueur, même direction et même sens en tout point.", "piege": "Confondre avec « accéléré » : une vitesse qui augmente ne suffit pas, il faut que l'accélération ne varie pas.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t08", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Les coordonnées du vecteur vitesse d'un mobile sont vₓ = 3,0 m·s⁻¹ et v_y = 4,0 m·s⁻¹. La valeur de la vitesse est :", "options": ["v = vₓ + v_y = 3,0 + 4,0 = 7,0 m·s⁻¹", "v = vₓ × v_y = 3,0 × 4,0 = 12 m·s⁻¹", "v = √(vₓ + v_y) = √7,0 = 2,6 m·s⁻¹", "v = √(vₓ² + v_y²) = √(3,0² + 4,0²) = 5,0 m·s⁻¹"], "bonne_reponse": [3], "explication": "La valeur d'un vecteur se calcule à partir de ses coordonnées par le théorème de Pythagore : v = √(vₓ² + v_y²).", "piege": "Additionner les coordonnées : on additionne des vecteurs, jamais leurs valeurs.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t09", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Un mobile a une accélération constante a⃗ de coordonnées (0 ; −g). À t = 0, sa vitesse est v⃗₀ (v₀ ; 0) et il est à l'origine. Ses équations horaires sont :", "options": ["x(t) = v₀ et y(t) = −g·t", "x(t) = v₀·t et y(t) = −½·g·t²", "x(t) = v₀·t et y(t) = −g·t", "x(t) = ½·v₀·t² et y(t) = −g·t"], "bonne_reponse": [1], "explication": "On intègre deux fois. Vitesse : vₓ = v₀, v_y = −g·t. Position : x = v₀·t, y = −½·g·t². Les constantes d'intégration viennent des conditions initiales.", "piege": "Oublier le facteur ½ à la seconde intégration, ou intégrer une seule fois — ce qui donne la vitesse, pas la position.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "cinematique-t10", "chapitre": "cinematique", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "Un mobile décrit un cercle de rayon R = 2,0 m à la vitesse constante v = 4,0 m·s⁻¹. Son accélération est :", "options": ["de valeur a = v/R = 4,0/2,0 = 2,0 m·s⁻², tangente au cercle", "de valeur a = v²/R = 8,0 m·s⁻², dirigée vers l'extérieur", "nulle, puisque la vitesse est constante", "de valeur a = v²/R = 4,0²/2,0 = 8,0 m·s⁻², dirigée vers le centre du cercle"], "bonne_reponse": [3], "explication": "En mouvement circulaire uniforme, la valeur de la vitesse ne change pas, mais sa DIRECTION change sans cesse : l'accélération n'est pas nulle. Elle est centripète, de valeur v²/R.", "piege": "Croire qu'une vitesse constante en valeur implique une accélération nulle — c'est le vecteur vitesse qui compte, et il tourne.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  newton: [
    {
      "ref": "new-01",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "La première loi de Newton énonce que, dans un référentiel galiléen :",
      "options": ["tout système immobile ou en mouvement rectiligne uniforme subit des forces qui se compensent", "tout système accélère proportionnellement à la somme des forces subies", "tout système immobile n'est soumis à aucune force, la somme étant nulle", "les forces sont toujours nulles, quel que soit le mouvement du système"],
      "bonne_reponse": [
        0
      ],
      "explication": "Σ<span class=\"vec\">F</span><sub>ext</sub> = <span class=\"vec\">0</span> ⟺ <span class=\"vec\">v</span> = constante. La réciproque est vraie, et c'est elle qu'on utilise le plus.",
      "piege": "Dire qu'il n'y a pas de force : leur somme vectorielle est nulle, ce qui est différent.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "new-02",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "« Les forces se compensent » signifie :",
      "options": [
        "elles sont toutes égales",
        "leur somme vectorielle est nulle",
        "elles sont toutes nulles",
        "aucune force ne s'exerce"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Un livre posé sur une table subit deux forces non nulles dont la somme est nulle.",
      "piege": "Confondre somme nulle et absence de force — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "new-03",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Un système se déplace en ligne droite à vitesse constante. Que peut-on affirmer ?",
      "options": [
        "son poids est nul",
        "il n'y a aucune force",
        "la somme des forces extérieures est nulle",
        "l'accélération est constante non nulle"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Mouvement rectiligne uniforme ⟺ forces qui se compensent : c'est le sens utilisé en exercice.",
      "piege": "Conclure que l'accélération est constante : elle est nulle.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-04",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La deuxième loi de Newton s'écrit :",
      "options": [
        "Σ<span class=\"vec\">F</span><sub>ext</sub> = <span class=\"vec\">a</span>/m",
        "Σ<span class=\"vec\">F</span><sub>ext</sub> = m/<span class=\"vec\">a</span>",
        "Σ<span class=\"vec\">F</span><sub>ext</sub> = m·<span class=\"vec\">v</span>",
        "Σ<span class=\"vec\">F</span><sub>ext</sub> = m·<span class=\"vec\">a</span>"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "La somme des forces extérieures est proportionnelle à l'accélération, dans un référentiel galiléen.",
      "piege": "Écrire la vitesse au lieu de l'accélération.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "new-05",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Quelles conditions doivent être réunies pour appliquer la deuxième loi ? <b>Plusieurs réponses.</b>",
      "options": [
        "les forces doivent se compenser",
        "le référentiel doit être galiléen",
        "le mouvement doit être rectiligne",
        "la masse doit être constante"
      ],
      "bonne_reponse": [
        1,
        3
      ],
      "explication": "La masse constante exclut par exemple une fusée qui éjecte du carburant.",
      "piege": "Oublier la condition de masse constante — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-06",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Que peut-on dire du vecteur accélération par rapport à la somme des forces ?",
      "options": [
        "il lui est perpendiculaire",
        "il a la même direction et le même sens",
        "il a la même direction, mais le sens opposé",
        "aucun lien"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est une conséquence directe de la proportionnalité, avec m > 0.",
      "piege": "Oublier de citer cette conséquence, souvent demandée dans la question.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-07",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Que devient la deuxième loi si la somme des forces est nulle ?",
      "options": [
        "la vitesse devient nulle",
        "<span class=\"vec\">a</span> = <span class=\"vec\">0</span> : on retrouve la première loi",
        "la loi ne s'applique plus",
        "le système s'arrête"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La première loi est un cas particulier de la seconde : c'est ce lien qu'il faut savoir citer.",
      "piege": "Conclure que le système s'arrête : sa vitesse reste constante, éventuellement non nulle.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-08",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "La troisième loi de Newton s'écrit :",
      "options": [
        "<span class=\"vec\">F</span><sub>A/B</sub> = 2·<span class=\"vec\">F</span><sub>B/A</sub>",
        "<span class=\"vec\">F</span><sub>A/B</sub> = <span class=\"vec\">F</span><sub>B/A</sub>",
        "<span class=\"vec\">F</span><sub>A/B</sub> = − <span class=\"vec\">F</span><sub>B/A</sub>",
        "<span class=\"vec\">F</span><sub>A/B</sub> + <span class=\"vec\">F</span><sub>B/A</sub> = m·<span class=\"vec\">a</span>"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Actions réciproques : même droite d'action, même valeur, sens opposés.",
      "piege": "Oublier le signe −, qui porte toute l'information sur le sens.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "new-09",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Pourquoi ces deux forces ne se compensent-elles jamais ?",
      "options": [
        "parce qu'elles ont des valeurs différentes",
        "parce qu'elles s'appliquent sur deux systèmes différents",
        "parce qu'elles ont des directions différentes",
        "elles se compensent en réalité"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "On ne peut additionner que des forces appliquées au <b>même</b> système.",
      "piege": "Croire que ces deux forces se compensent — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "new-10",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "La Terre attire la Lune. Que peut-on dire de la force exercée par la Lune sur la Terre ?",
      "options": [
        "elle a la même intensité et le sens opposé",
        "elle est plus grande",
        "elle est plus faible, la Lune étant moins massive",
        "elle est nulle"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Les effets diffèrent parce que les masses diffèrent, pas les forces.",
      "piege": "Croire que le corps le plus massif exerce la force la plus grande.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-11",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Remets dans l'ordre les sept étapes d'un exercice de mécanique :",
      "options": [
        "définir le système et sa masse",
        "faire un schéma avec un repère adapté",
        "faire le bilan des forces",
        "isoler l'inconnue et appliquer les valeurs numériques",
        "écrire la loi de Newton sous forme vectorielle",
        "préciser le référentiel, supposé galiléen",
        "projeter la relation sur chaque axe"
      ],
      "bonne_reponse": [
        0,
        5,
        1,
        2,
        4,
        6,
        3
      ],
      "explication": "C'est l'ossature de tout le chapitre, et elle ne change jamais.",
      "piege": "Projeter avant d'avoir écrit la relation vectorielle — le piège explicite de cette QT.",
      "image": "new_pente.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-12",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Sur un plan incliné, quel repère faut-il choisir ?",
      "options": [
        "un repère centré sur le sol",
        "Ox parallèle à la pente et Oy perpendiculaire",
        "un repère horizontal et vertical",
        "le choix n'a pas d'importance"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Dans ce repère, seul le poids se décompose : les deux équations se résolvent immédiatement.",
      "piege": "Prendre un repère horizontal : il faudrait alors projeter les trois forces.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "new-13",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Une voiture immobile sur une pente d'angle α. La projection sur Ox (parallèle à la pente) donne :",
      "options": [
        "− m·g·cos α + f = 0",
        "− m·g·sin α + R = 0",
        "− m·g·sin α + f = 0",
        "m·g + f = 0"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le poids se décompose : sa composante le long de la pente vaut m·g·sin α, dirigée vers le bas.",
      "piege": "Utiliser le cosinus au lieu du sinus : c'est le schéma qui décide, pas l'habitude.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-14",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Une voiture de masse m = 1200 kg reste immobile sur une pente d'angle α = 30°. Que vaut la force de frottement ? <i>Donnée : g = 9,81 m·s⁻².</i>",
      "options": [
        "1,2×10⁴ N",
        "6,0×10² N",
        "1,0×10⁴ N",
        "5,9×10³ N"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "f = m·g·sin α = 1200 × 9,81 × 0,50 = 5,9×10³ N. La réaction normale vaut m·g·cos α = 1,0×10⁴ N.",
      "piege": "Intervertir sinus et cosinus, ce qui échange f et R.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "new-15",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "méthode",
      "enonce": "Remets dans l'ordre le passage de l'écriture vectorielle à l'écriture scalaire :",
      "options": [
        "lire ligne par ligne : chaque ligne est une équation",
        "fixer le sens de chaque axe, et ne plus en changer",
        "vérifier l'homogénéité et le nombre d'équations",
        "choisir un repère adapté : un axe parallèle au mouvement ou à la surface de contact",
        "réécrire la relation vectorielle en remplaçant chaque vecteur par sa colonne"
      ],
      "bonne_reponse": [
        3,
        1,
        4,
        0,
        2
      ],
      "explication": "C'est l'étape qui fait perdre le plus de points, et elle ne demande aucun calcul.",
      "piege": "Se tromper de signe pour une force opposée à l'axe : c'est la source d'erreur numéro un.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-16",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "méthode",
      "enonce": "Quand la coordonnée d'une force sur un axe est-elle <b>négative</b> ?",
      "options": ["quand la force pointe dans le sens contraire de l'axe choisi", "quand l'axe est vertical et orienté vers le haut, comme d'usage", "quand la force est faible devant les autres forces du bilan", "toujours pour le poids, qui est dirigé vers le bas par nature"],
      "bonne_reponse": [
        0
      ],
      "explication": "Positive si la force pointe dans le sens de l'axe, négative sinon. C'est le sens de l'axe qui décide, pas la nature de la force.",
      "piege": "Mettre systématiquement un signe − au poids : avec un axe orienté vers le bas, il est positif.",
      "image": null,
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "new-17",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "méthode",
      "enonce": "Une force perpendiculaire à un axe a pour coordonnée sur cet axe :",
      "options": [
        "sa norme changée de signe",
        "zéro",
        "sa norme",
        "la moitié de sa norme"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est ce qui simplifie la lecture ligne par ligne : chaque colonne comporte des zéros.",
      "piege": "Chercher à projeter une force qui n'a pas de composante sur l'axe.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-18",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "méthode",
      "enonce": "Quelles vérifications faire à la fin d'une projection ?",
      "options": ["que chaque coordonnée de force est positive sur son axe", "que les angles sont exprimés en degrés et non en radians", "que chaque équation est homogène, et qu'il y a autant d'équations que d'inconnues", "aucune : la projection est exacte dès lors que les axes sont fixés"],
      "bonne_reponse": [
        2
      ],
      "explication": "Des newtons de chaque côté, et le compte des équations : deux contrôles rapides.",
      "piege": "Poursuivre le calcul sans vérifier, alors qu'une erreur de signe se détecte ici.",
      "image": null,
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-19",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre l'établissement des équations horaires avec la deuxième loi :",
      "options": [
        "primitiver une fois : coordonnées de la vitesse, avec deux constantes",
        "projeter sur les deux axes",
        "en déduire les coordonnées de l'accélération",
        "système, référentiel, schéma, bilan des forces",
        "primitiver une seconde fois : équations horaires, avec deux nouvelles constantes",
        "écrire la relation vectorielle Σ<span class=\"vec\">F</span> = m·<span class=\"vec\">a</span>",
        "déterminer ces constantes avec les conditions initiales sur la position",
        "déterminer les constantes avec les conditions initiales sur la vitesse"
      ],
      "bonne_reponse": [
        3,
        5,
        1,
        2,
        0,
        7,
        4,
        6
      ],
      "explication": "Deux primitives, deux jeux de constantes, deux jeux de conditions initiales.",
      "piege": "Oublier les constantes d'intégration, ou toutes les déterminer à la fin.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-20",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Un parachutiste subit son poids et un frottement f constant vers le haut. Avec Oy vers le bas, que vaut a<sub>y</sub> ?",
      "options": [
        "a<sub>y</sub> = g + f/m",
        "a<sub>y</sub> = f/m − g",
        "a<sub>y</sub> = g",
        "a<sub>y</sub> = g − f/m"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "La projection donne m·g − f = m·a<sub>y</sub>, d'où a<sub>y</sub> = g − f/m.",
      "piege": "Oublier de diviser f par la masse, ou se tromper de signe pour le frottement.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-21",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Avec v<sub>y</sub>(t) = (g − f/m)·t + K₂ et v<sub>y</sub>(0) = v₀, que vaut K₂ ?",
      "options": [
        "v₀",
        "g",
        "0",
        "−v₀"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "À t = 0, le terme en t s'annule : v<sub>y</sub>(0) = K₂ = v₀.",
      "piege": "Prendre K₂ = 0 par réflexe alors que la vitesse initiale n'est pas nulle.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "new-22",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "À quel moment détermine-t-on les constantes d'intégration ?",
      "options": ["jamais : elles sont toujours nulles si l'origine est bien choisie", "au début de l'exercice, avant même d'écrire la deuxième loi", "après chaque primitivation, avec les conditions initiales correspondantes", "toutes à la fin, une fois les deux primitivations effectuées"],
      "bonne_reponse": [
        2
      ],
      "explication": "Vitesse d'abord, position ensuite : on réécrit aussitôt les coordonnées avec les constantes trouvées.",
      "piege": "Traîner des constantes indéterminées jusqu'à la fin, ce qui multiplie les risques d'erreur.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "new-23",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Qu'est-ce qui distingue la première de la deuxième loi dans l'écriture ?",
      "options": ["le membre de droite : 0⃗ si le mouvement est rectiligne uniforme, m·a⃗ sinon", "le référentiel : galiléen pour la première, quelconque pour la seconde", "le membre de gauche : ΣF⃗ pour la première, F⃗ seule pour la seconde", "rien : les deux lois s'écrivent de la même façon, ΣF⃗ = m·a⃗"],
      "bonne_reponse": [
        0
      ],
      "explication": "Toute la démarche est identique : seule la valeur du second membre change.",
      "piege": "Traiter les deux lois comme deux méthodes différentes.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-24",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Dans quel référentiel les lois de Newton sont-elles valables ?",
      "options": [
        "dans un référentiel accéléré",
        "seulement dans le référentiel terrestre",
        "dans tout référentiel",
        "dans un référentiel galiléen"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est pour cela qu'on écrit « référentiel terrestre supposé galiléen » à l'étape 2.",
      "piege": "Omettre cette précision, qui fait partie des points de méthode.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-25",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "typologie",
      "enonce": "Un système de masse variable — une fusée qui éjecte du carburant — relève-t-il de la deuxième loi telle qu'énoncée ?",
      "options": [
        "non : l'énoncé suppose une masse constante",
        "oui, sans restriction",
        "non, car il n'y a pas de forces",
        "oui, si le référentiel est galiléen"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est la limite explicite de la loi telle qu'elle est au programme.",
      "piege": "Appliquer la relation sans vérifier la constance de la masse.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-26",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Un livre est posé, immobile, sur une table. Combien de forces s'exercent sur lui ?",
      "options": ["deux : le poids et la réaction du support", "trois : le poids, la réaction et la force de contact", "une seule : le poids, la table n'exerçant rien", "aucune : le livre est immobile, donc sans force"],
      "bonne_reponse": [
        0
      ],
      "explication": "Elles se compensent : leur somme est nulle, mais chacune est bien présente.",
      "piege": "Répondre « aucune » parce que le livre ne bouge pas.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "new-27",
      "chapitre": "les-lois-de-newton",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Pourquoi précise-t-on la masse du système dès l'étape 1 ?",
      "options": ["pour calculer le poids seulement, la masse n'intervenant pas ailleurs", "ce n'est pas nécessaire : la masse se simplifie dans la deuxième loi", "parce que la deuxième loi exige une masse constante, qu'il faut identifier", "pour vérifier l'homogénéité des équations obtenues après projection"],
      "bonne_reponse": [
        2
      ],
      "explication": "L'étape 1 pose le système <b>et</b> sa masse : les deux servent ensuite.",
      "piege": "Définir le système sans sa masse, et se retrouver bloqué à l'étape de projection.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "newton-t01", "chapitre": "newton", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Dans un référentiel galiléen, un système soumis à des forces qui se compensent :", "options": ["est immobile ou en mouvement rectiligne uniforme", "ralentit jusqu'à s'arrêter", "est en mouvement uniformément accéléré", "est nécessairement immobile"], "bonne_reponse": [0], "explication": "Première loi : si ΣF⃗ = 0⃗, le vecteur vitesse est constant — nul (repos) ou non (rectiligne uniforme). Et réciproquement.", "piege": "Croire qu'un système sans force résultante s'arrête : sans frottement, il continue tout droit à vitesse constante.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "newton-t02", "chapitre": "newton", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "La deuxième loi de Newton, pour un système de masse m constante, s'écrit :", "options": ["ΣF⃗ = m·g⃗, dans un référentiel galiléen", "ΣF⃗ = m·v⃗, dans un référentiel galiléen", "ΣF⃗ = m·a⃗, dans un référentiel galiléen", "a⃗ = m·ΣF⃗, dans un référentiel galiléen"], "bonne_reponse": [2], "explication": "La somme vectorielle des forces est égale au produit de la masse par le vecteur accélération. C'est une égalité de VECTEURS, valable dans un référentiel galiléen.", "piege": "Écrire m·v au lieu de m·a : c'est l'accélération que produisent les forces, pas la vitesse.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "newton-t03", "chapitre": "newton", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Un livre est posé sur une table. La table exerce sur le livre une réaction R⃗. D'après la troisième loi, le livre exerce sur la table une force :", "options": ["de même direction, de même valeur et de même sens que R⃗", "de même direction, de même valeur et de sens opposé à R⃗", "nulle, puisque le livre est immobile sur la table", "égale à son poids P⃗, en direction, en sens et en valeur"], "bonne_reponse": [1], "explication": "Troisième loi : les forces d'interaction entre deux systèmes sont opposées, F⃗_{A/B} = −F⃗_{B/A}. Ici l'action du livre sur la table est −R⃗.", "piege": "Confondre avec le poids : P⃗ et R⃗ sont deux forces qui s'exercent sur le MÊME système, ce n'est pas une paire action-réaction.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "newton-t04", "chapitre": "newton", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Une caisse de masse m = 20 kg est tirée à vitesse constante sur un sol horizontal par une force horizontale F⃗. Les frottements valent f = 50 N. La valeur de F est :", "options": ["F = 0, car la vitesse est constante", "F = f = 50 N, car les forces se compensent", "F = m·g = 2,0 × 10² N", "F > 50 N, sinon la caisse ne bougerait pas"], "bonne_reponse": [1], "explication": "Vitesse constante : première loi, ΣF⃗ = 0⃗. Horizontalement, F − f = 0, donc F = f = 50 N. Verticalement, P et R se compensent.", "piege": "Croire qu'il faut tirer plus fort que les frottements pour avancer : c'est vrai pour accélérer, pas pour maintenir la vitesse.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "newton-t05", "chapitre": "newton", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Un système de masse m n'est soumis qu'à son poids. Dans un repère où (Oz) est vertical vers le haut, la deuxième loi donne a⃗ = g⃗. Si à t = 0 il est en O avec une vitesse v⃗₀ verticale vers le haut, son équation horaire z(t) est :", "options": ["z(t) = −½·g·t²", "z(t) = −½·g·t² + v₀·t", "z(t) = −g·t + v₀", "z(t) = ½·g·t² + v₀·t"], "bonne_reponse": [1], "explication": "a_z = −g. On intègre : v_z = −g·t + v₀. On intègre encore : z = −½·g·t² + v₀·t + 0. Les constantes viennent des conditions initiales.", "piege": "Oublier le signe de g avec un axe vers le haut, ou oublier v₀·t à la seconde intégration.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  champuniforme: [
    {
      "ref": "cha-01",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Un système est en <b>chute libre</b> lorsqu'il :",
      "options": [
        "n'est soumis qu'à son poids",
        "tombe verticalement",
        "tombe dans le vide",
        "part sans vitesse initiale"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "La deuxième loi donne alors m·<span class=\"vec\">a</span> = m·<span class=\"vec\">g</span>, soit <span class=\"vec\">a</span> = <span class=\"vec\">g</span> : l'accélération ne dépend pas de la masse.",
      "piege": "Croire qu'une chute libre est forcément verticale : une trajectoire parabolique en est une aussi.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "cha-02",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "En chute libre, l'accélération :",
      "options": [
        "dépend de la masse du système",
        "ne dépend pas de la masse",
        "est nulle",
        "dépend de la vitesse initiale"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La masse se simplifie dans m·<span class=\"vec\">a</span> = m·<span class=\"vec\">g</span> : tous les corps tombent de la même façon.",
      "piege": "Croire qu'un corps lourd tombe plus vite : la masse disparaît de l'équation.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-03",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Le champ électrique entre deux plaques vaut :",
      "options": [
        "E = d / U",
        "E = U × d",
        "E = U / d",
        "E = U + d"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "U est la tension entre les plaques, d leur distance. E s'exprime en V·m⁻¹.",
      "piege": "Inverser le rapport : plus les plaques sont proches, plus le champ est intense.",
      "image": "cha_plaques.png",
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-04",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Le vecteur champ électrique <span class=\"vec\">E</span> est toujours dirigé :",
      "options": ["vers le haut, quelle que soit la position des plaques", "vers les charges positives, de la plaque ⊖ vers la plaque ⊕", "dans le sens du mouvement de la particule chargée", "vers les charges négatives, de la plaque ⊕ vers la plaque ⊖"],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est le repère qui permet ensuite de projeter correctement la force électrique.",
      "piege": "Orienter le champ vers la plaque positive.",
      "image": "cha_plaques.png",
      "tags": [
        "condition"
      ],
      "actif": true
    },
    {
      "ref": "cha-05",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Un <b>électron</b> placé dans un champ <span class=\"vec\">E</span> subit une force :",
      "options": [
        "de sens opposé à <span class=\"vec\">E</span>",
        "de même sens que <span class=\"vec\">E</span>",
        "nulle",
        "perpendiculaire à <span class=\"vec\">E</span>"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "<span class=\"vec\">F</span><sub>e</sub> = q·<span class=\"vec\">E</span> avec q = −e : le signe négatif inverse le sens.",
      "piege": "Oublier le signe de la charge : c'est lui qui décide du sens de la déviation.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-06",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Remets dans l'ordre l'établissement des équations horaires d'une chute libre :",
      "options": [
        "2<sup>e</sup> loi : m·<span class=\"vec\">a</span> = m·<span class=\"vec\">g</span>, donc <span class=\"vec\">a</span> = <span class=\"vec\">g</span>",
        "primitiver une fois : coordonnées de la vitesse, constantes déterminées par v(0)",
        "coordonnées de l'accélération, selon le sens choisi pour l'axe",
        "système, référentiel galiléen, bilan des forces : le poids seul",
        "primitiver une seconde fois : équations horaires, constantes déterminées par la position initiale"
      ],
      "bonne_reponse": [
        3,
        0,
        2,
        1,
        4
      ],
      "explication": "La structure est celle de tout exercice de mécanique : la seule difficulté est le signe des coordonnées.",
      "piege": "Primitiver sans écrire d'abord les coordonnées de l'accélération.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-07",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Axe Oz orienté vers le <b>bas</b>, chute libre. Que vaut a<sub>z</sub> ?",
      "options": [
        "a<sub>z</sub> = − g",
        "a<sub>z</sub> = + g",
        "a<sub>z</sub> = g/2",
        "a<sub>z</sub> = 0"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le poids pointe dans le sens de l'axe : la coordonnée est positive.",
      "piege": "Mettre systématiquement un signe − au poids : le signe dépend du sens de l'axe.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-08",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Un point est lâché en O avec v₀ vers le bas (Oz vers le bas). Que vaut z(t) ?",
      "options": [
        "z(t) = v₀·t",
        "z(t) = g·t²/2",
        "z(t) = g·t²/2 + v₀·t",
        "z(t) = − g·t²/2 + v₀·t"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Deux primitives, et les deux constantes sont nulles puisque le point part de l'origine.",
      "piege": "Oublier le terme en v₀·t alors que la vitesse initiale n'est pas nulle.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "cha-09",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Quelle est la <b>seule</b> nouveauté d'une chute parabolique par rapport à une chute verticale ?",
      "options": ["il faut deux référentiels, un par direction du mouvement", "l'accélération change, elle n'est plus égale à g⃗", "la masse intervient, alors qu'elle disparaissait en chute verticale", "il faut projeter la vitesse initiale v₀⃗ sur les deux axes"],
      "bonne_reponse": [
        3
      ],
      "explication": "Le bilan des forces est identique : <span class=\"vec\">a</span> = <span class=\"vec\">g</span>. Seules les conditions initiales changent.",
      "piege": "Croire que la trajectoire courbe implique une accélération variable.",
      "image": "cha_projection.png",
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "cha-10",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Avec α repéré par rapport à la <b>verticale</b>, comment se projette la vitesse initiale ?",
      "options": [
        "v<sub>x</sub>(0) = v₀·sin α et v<sub>z</sub>(0) = v₀·cos α",
        "v<sub>x</sub>(0) = v₀·cos α et v<sub>z</sub>(0) = v₀·sin α",
        "v<sub>x</sub>(0) = v₀/2 et v<sub>z</sub>(0) = v₀/2",
        "v<sub>x</sub>(0) = v₀ et v<sub>z</sub>(0) = 0"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le côté adjacent à l'angle donne le cosinus, le côté opposé le sinus : c'est le schéma qui décide.",
      "piege": "Appliquer sin et cos par habitude sans regarder par rapport à quoi l'angle est repéré.",
      "image": "cha_projection.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-11",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Axe Oz orienté vers le <b>haut</b>, chute parabolique. Que vaut a<sub>z</sub> ?",
      "options": [
        "a<sub>z</sub> = − g/2",
        "a<sub>z</sub> = − g",
        "a<sub>z</sub> = + g",
        "a<sub>z</sub> = 0"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le poids pointe vers le bas, à l'opposé de l'axe : la coordonnée est négative.",
      "piege": "Garder le signe + de la chute verticale de la QT 1, où l'axe était orienté vers le bas.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-12",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Quelle est l'erreur la plus fréquente du chapitre ?",
      "options": ["oublier le référentiel, sans lequel le mouvement n'a pas de sens", "utiliser des degrés là où les radians sont attendus", "se tromper de signe en projetant, faute d'avoir fixé le sens des axes", "oublier la masse, qui intervient pourtant dans la deuxième loi"],
      "bonne_reponse": [
        2
      ],
      "explication": "Un signe inversé au départ fausse toutes les équations horaires. On fixe le sens des axes sur le schéma, et on ne change plus.",
      "piege": "Changer d'orientation en cours d'exercice.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {
      "ref": "cha-13",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre l'établissement de l'équation de la trajectoire z(x) :",
      "options": [
        "substituer cette expression dans l'équation horaire z(t)",
        "simplifier : le temps a disparu, c'est l'équation d'une parabole",
        "partir de l'équation horaire x(t) = v₀·sin α·t",
        "isoler le temps : t = x/(v₀·sin α)"
      ],
      "bonne_reponse": [
        2,
        3,
        0,
        1
      ],
      "explication": "L'unique astuce est l'isolement du temps dans l'équation en x, la plus simple des deux.",
      "piege": "Essayer d'isoler t dans l'équation en z, qui est du second degré.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-14",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Pourquoi isole-t-on le temps dans l'équation en x plutôt qu'en z ?",
      "options": ["parce que x est plus grand que z, donc plus précis à inverser", "cela n'a pas d'importance : les deux équations s'inversent aussi bien", "par convention, l'axe horizontal étant toujours traité en premier", "parce que x(t) est du premier degré en t, donc immédiatement inversible"],
      "bonne_reponse": [
        3
      ],
      "explication": "z(t) contient un terme en t² : l'isolement y serait bien plus lourd.",
      "piege": "Se lancer dans la résolution d'une équation du second degré inutilement.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-15",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "L'équation de la trajectoire z(x) est celle :",
      "options": [
        "d'une parabole",
        "d'un cercle",
        "d'une droite",
        "d'une exponentielle"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le terme en x² vient de la substitution du temps : c'est la signature de la chute libre.",
      "piege": "Confondre l'équation horaire z(t) et l'équation de la trajectoire z(x).",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "cha-16",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "La <b>portée</b> d'une trajectoire est :",
      "options": ["la vitesse atteinte par le projectile au moment où il touche le sol", "l'abscisse du point où le projectile retombe au sol", "l'altitude maximale atteinte par le projectile au sommet", "la durée du vol, entre le lancer et le retour au sol"],
      "bonne_reponse": [
        1
      ],
      "explication": "On cherche x<sub>P</sub> tel que z(x<sub>P</sub>) = 0, avec x<sub>P</sub> ≠ 0.",
      "piege": "Confondre portée et flèche : l'une est horizontale, l'autre verticale.",
      "image": "cha_parabole.png",
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-17",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "En résolvant z(x<sub>P</sub>) = 0, on trouve deux solutions. Que faut-il faire ?",
      "options": ["garder x_P = 0, qui correspond au point de retombée", "garder les deux, la trajectoire coupant le sol deux fois", "écarter x_P = 0, qui correspond au point de départ", "prendre leur moyenne, le projectile retombant à mi-chemin"],
      "bonne_reponse": [
        2
      ],
      "explication": "On factorise par x<sub>P</sub> : la solution nulle est le lancement, l'autre est la portée cherchée.",
      "piege": "Garder la solution nulle et conclure que la portée est nulle.",
      "image": "cha_parabole.png",
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-18",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Que vaut la portée pour une chute parabolique partant de l'origine ?",
      "options": [
        "x<sub>P</sub> = v₀²/g",
        "x<sub>P</sub> = v₀·cos α/g",
        "x<sub>P</sub> = v₀²·cos²α/(2g)",
        "x<sub>P</sub> = 2v₀²·sin α·cos α / g"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Elle s'obtient en résolvant z(x<sub>P</sub>) = 0 puis en simplifiant avec 1/tan α = cos α/sin α.",
      "piege": "Donner l'expression de la flèche, v₀²·cos²α/(2g), à la place de la portée.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-19",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Comment détermine-t-on l'instant t<sub>F</sub> du sommet de la trajectoire ?",
      "options": ["en écrivant que la vitesse verticale s'annule : v_z(t_F) = 0", "en cherchant z maximal directement sur la courbe tracée", "en dérivant deux fois z(t), la dérivée seconde devant s'annuler", "en posant x = 0, le sommet étant à l'aplomb du point de départ"],
      "bonne_reponse": [
        0
      ],
      "explication": "Au sommet, le projectile ne monte plus et ne descend pas encore.",
      "piege": "Chercher à annuler la vitesse totale : seule sa composante verticale s'annule.",
      "image": "cha_parabole.png",
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "cha-20",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Avec v<sub>z</sub>(t) = − g·t + v₀·cos α, que vaut t<sub>F</sub> ?",
      "options": [
        "t<sub>F</sub> = v₀·sin α / g",
        "t<sub>F</sub> = v₀·cos α / g",
        "t<sub>F</sub> = v₀/g",
        "t<sub>F</sub> = g/(v₀·cos α)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "On résout − g·t<sub>F</sub> + v₀·cos α = 0.",
      "piege": "Confondre sinus et cosinus : ici α est repéré par rapport à la verticale.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-21",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Après avoir trouvé t<sub>F</sub>, que demande presque toujours la question ?",
      "options": ["de calculer z(t_F), c'est-à-dire la flèche", "de calculer x(t_F), c'est-à-dire la portée", "de tracer la trajectoire point par point", "rien de plus : t_F est la réponse attendue"],
      "bonne_reponse": [
        0
      ],
      "explication": "Ne pas confondre t<sub>F</sub>, l'instant du sommet, et z(t<sub>F</sub>), l'altitude atteinte : les deux sont demandés, dans cet ordre.",
      "piege": "S'arrêter à l'instant sans calculer l'altitude — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-22",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Que vaut la flèche z(t<sub>F</sub>) ?",
      "options": [
        "v₀·cos α / g",
        "v₀²·sin²α / (2g)",
        "2v₀²·sin α·cos α / g",
        "v₀²·cos²α / (2g)"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "On reporte t<sub>F</sub> dans z(t) et on simplifie : − v₀²cos²α/(2g) + v₀²cos²α/g = v₀²cos²α/(2g).",
      "piege": "Rendre t<sub>F</sub> à la place de l'altitude.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "cha-23",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Pour montrer que le poids est négligeable devant la force électrique, on :",
      "options": ["forme le rapport F_e/P = q·E/(m·g) et montre qu'il dépasse largement 1", "calcule la différence F_e − P = q·E − m·g et montre qu'elle est positive", "compare les masses de la particule et de la plaque chargée", "mesure la déviation observée et la compare à celle d'une chute libre"],
      "bonne_reponse": [
        0
      ],
      "explication": "Pour un électron dans un champ de quelques kV·m⁻¹, ce rapport vaut plusieurs puissances de dix.",
      "piege": "Comparer les deux forces sans former le rapport : c'est le quotient qui est attendu.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-24",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Quelle conséquence tire-t-on de F<sub>e</sub>/P ≫ 1 ?",
      "options": ["la particule ne bouge pas : les deux forces se compensent", "on ne fait pas figurer le poids dans le bilan des forces", "le champ est trop faible : il faut augmenter la tension", "il faut ajouter le poids au bilan, car il devient dominant"],
      "bonne_reponse": [
        1
      ],
      "explication": "Cela simplifie toute la suite de l'exercice : une seule force au bilan.",
      "piege": "Conserver le poids « par sécurité », ce qui alourdit inutilement les équations.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-25",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Pour une particule chargée entre deux plaques, le bilan des forces se réduit à :",
      "options": [
        "le poids seul",
        "la force électrique <span class=\"vec\">F</span><sub>e</sub> = q·<span class=\"vec\">E</span> seule",
        "le poids et la force électrique",
        "aucune force"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le poids est négligeable devant la force électrique, comme montré à la QT 6.",
      "piege": "Garder le poids dans le bilan après avoir montré qu'il est négligeable.",
      "image": "cha_plaques.png",
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-26",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Une particule de charge q entre en O avec v₀ horizontale. Que vaut v<sub>z</sub>(0) ?",
      "options": [
        "− v₀",
        "qE/m",
        "v₀",
        "0"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "La vitesse initiale étant horizontale, sa composante verticale est nulle : v<sub>x</sub>(0) = v₀ et v<sub>z</sub>(0) = 0.",
      "piege": "Attribuer v₀ aux deux composantes.",
      "image": "cha_plaques.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-27",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Pour un électron (q = −e) dans un champ <span class=\"vec\">E</span> dirigé vers le bas, la déviation se fait :",
      "options": ["vers le haut : les deux signes négatifs se compensent", "dans le sens de la vitesse initiale, quel que soit le signe de q", "vers le bas : la force suit le champ, comme pour toute charge", "il n'y a pas de déviation : la charge négative n'est pas déviée"],
      "bonne_reponse": [
        0
      ],
      "explication": "La coordonnée de <span class=\"vec\">E</span> est négative, et la charge aussi : le produit est positif.",
      "piege": "Ne considérer qu'un seul des deux signes.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-28",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Avec a<sub>z</sub> = − qE/m constante et v<sub>z</sub>(0) = 0, que vaut z(t) ?",
      "options": [
        "z(t) = − (qE/m)·t",
        "z(t) = − (qE/2m)·t²",
        "z(t) = − (qE/m)·t²",
        "z(t) = v₀·t"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Deux primitives, avec des constantes nulles puisque la particule entre en O sans vitesse verticale.",
      "piege": "Oublier le facteur 1/2 de la primitive de t.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "cha-29",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Quel réflexe évite la moitié des erreurs du chapitre ?",
      "options": ["toujours orienter Oz vers le haut, quelle que soit la figure", "apprendre par cœur les équations horaires du mouvement", "fixer le sens de chaque axe sur le schéma avant de projeter", "travailler en degrés plutôt qu'en radians pour les angles"],
      "bonne_reponse": [
        2
      ],
      "explication": "Une coordonnée est positive si le vecteur pointe dans le sens de l'axe, négative sinon.",
      "piege": "Recopier les équations d'un exercice précédent sans vérifier l'orientation des axes.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "cha-30",
      "chapitre": "mouvement-dans-un-champ-uniforme",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelle grandeur reste constante tout au long d'une chute libre parabolique ?",
      "options": [
        "la vitesse",
        "la composante v<sub>z</sub>",
        "l'altitude",
        "le vecteur <span class=\"vec\">a</span>"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Le poids est la seule force, en tout point de la trajectoire : l'accélération vaut <span class=\"vec\">g</span> partout.",
      "piege": "Croire que la vitesse est constante parce que l'accélération l'est.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {"ref": "champuniforme-t01", "chapitre": "champuniforme", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Une bille est lâchée sans vitesse initiale depuis la hauteur h, l'axe (Oz) étant vertical vers le haut, origine au sol. Son équation horaire est :", "options": ["z(t) = −½·g·t² + h", "z(t) = h − g·t", "z(t) = ½·g·t² + h", "z(t) = −½·g·t²"], "bonne_reponse": [0], "explication": "a_z = −g, v_z(0) = 0 et z(0) = h. Deux intégrations : v_z = −g·t, puis z = −½·g·t² + h.", "piege": "Oublier la position initiale h, ou le signe de g avec un axe orienté vers le haut.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "champuniforme-t02", "chapitre": "champuniforme", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un projectile est lancé de O avec une vitesse v⃗₀ faisant un angle α avec l'horizontale. Ses équations horaires sont :", "options": ["x(t) = v₀·cos α et z(t) = −g·t + v₀·sin α", "x(t) = v₀·sin α·t et z(t) = −½·g·t² + v₀·cos α·t", "x(t) = ½·v₀·cos α·t² et z(t) = −g·t", "x(t) = v₀·cos α·t et z(t) = −½·g·t² + v₀·sin α·t"], "bonne_reponse": [3], "explication": "a⃗ = g⃗ : a_x = 0, a_z = −g. Vitesse : v_x = v₀·cos α, v_z = −g·t + v₀·sin α. Position : x = v₀·cos α·t, z = −½·g·t² + v₀·sin α·t.", "piege": "Inverser cos et sin : la composante horizontale de v⃗₀ est v₀·cos α, l'angle étant mesuré depuis l'horizontale.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "champuniforme-t03", "chapitre": "champuniforme", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "À partir de x(t) = v₀·cos α·t et z(t) = −½·g·t² + v₀·sin α·t, l'équation de la trajectoire z(x) s'obtient en :", "options": ["additionnant les deux équations, ce qui élimine le temps t", "posant t = 0 dans les deux équations, puis en éliminant t", "dérivant z(t) par rapport à x, ce qui fait disparaître t", "isolant t = x/(v₀·cos α) dans la première, puis en le reportant"], "bonne_reponse": [3], "explication": "On élimine le temps : t = x/(v₀ cos α), d'où z = −g·x²/(2·v₀²·cos²α) + x·tan α. C'est l'équation d'une parabole.", "piege": "Dériver ou additionner : l'équation de la trajectoire est une relation entre x et z SANS le temps.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "champuniforme-t04", "chapitre": "champuniforme", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "La portée d'un projectile lancé du sol est la distance horizontale atteinte quand il retombe au sol. On la trouve en résolvant :", "options": ["x(t) = 0, l'abscisse s'annulant au point de retombée", "z(x) maximal, l'altitude étant extrémale à la retombée", "v_z(t) = 0, la vitesse verticale s'annulant à la retombée", "z(x) = 0 pour x ≠ 0, en écartant le point de départ"], "bonne_reponse": [3], "explication": "Au sol, z = 0. L'équation z(x) = 0 a deux solutions : x = 0 (le départ) et x_p = v₀²·sin(2α)/g (la portée).", "piege": "Confondre avec la flèche, qui correspond au sommet — c'est là que v_z s'annule.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "champuniforme-t05", "chapitre": "champuniforme", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "La flèche est la hauteur maximale atteinte. On la détermine en cherchant l'instant où :", "options": ["v_x(t) = 0, puis en calculant z à cet instant", "z(t) = 0, puis en calculant x à cet instant", "x(t) est maximal, puis en calculant z à cet instant", "v_z(t) = 0, puis en calculant z à cet instant"], "bonne_reponse": [3], "explication": "Au sommet, le projectile ne monte plus : v_z = 0, soit t_s = v₀·sin α/g. La flèche vaut z(t_s) = v₀²·sin²α/(2g).", "piege": "Chercher v_x = 0 : la composante horizontale est constante, elle ne s'annule jamais.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "champuniforme-t06", "chapitre": "champuniforme", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Un électron (m = 9,1 × 10⁻³¹ kg, e = 1,6 × 10⁻¹⁹ C) est dans un champ E = 1,0 × 10⁴ V·m⁻¹. Le rapport F_e/P vaut :", "options": ["F_e/P ≈ 10⁻¹⁴ : la force électrique est négligeable", "F_e/P = e·E/(m·g) = 1,6 × 10⁻¹⁵/8,9 × 10⁻³⁰ ≈ 2 × 10¹⁴ : le poids est négligeable", "On ne peut pas comparer une force électrique et un poids", "F_e/P ≈ 1 : les deux forces sont comparables"], "bonne_reponse": [1], "explication": "F_e = e·E = 1,6 × 10⁻¹⁵ N ; P = m·g ≈ 8,9 × 10⁻³⁰ N. Le rapport dépasse 10¹⁴ : le poids est totalement négligeable.", "piege": "Ne pas conclure numériquement : le rapport doit être calculé, et c'est l'écart de quatorze ordres de grandeur qui justifie de négliger.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "champuniforme-t07", "chapitre": "champuniforme", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Une particule de charge q > 0 et de masse m entre en O avec v⃗₀ selon (Ox), dans un champ E⃗ uniforme selon (Oy). Poids négligé. Ses équations horaires sont :", "options": ["x(t) = v₀·t et y(t) = q·E·t/m", "x(t) = v₀·t et y(t) = −½·g·t²", "x(t) = v₀·t et y(t) = q·E·t²/(2m)", "x(t) = q·E·t²/(2m) et y(t) = v₀·t"], "bonne_reponse": [2], "explication": "Deuxième loi : m·a⃗ = q·E⃗, donc a_x = 0 et a_y = qE/m. Deux intégrations avec v₀ selon (Ox) : x = v₀·t, y = qE·t²/(2m). Même structure qu'une chute, avec qE/m à la place de g.", "piege": "Faire apparaître g : le poids est négligé, seule la force électrique agit.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  kepler: [
    {
      "ref": "kep-01",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "La loi des <b>orbites</b> énonce que :",
      "options": ["la trajectoire d'une planète est une ellipse dont le Soleil est un foyer", "la trajectoire d'une planète est une ellipse parcourue à vitesse constante", "la trajectoire d'une planète est une ellipse dont le Soleil est le centre", "la trajectoire d'une planète est un cercle dont le Soleil est le centre"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le Soleil est à un <b>foyer</b>, jamais au centre. Et l'énoncé se place dans le référentiel héliocentrique.",
      "piege": "Oublier de préciser le référentiel — le piège explicite de cette QT.",
      "image": "kep_orbite.png",
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "kep-02",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "La loi des <b>aires</b> énonce que :",
      "options": [
        "l'aire de l'ellipse est constante",
        "le rayon-vecteur Soleil-planète balaie des aires égales pendant des durées égales",
        "les planètes balaient des angles égaux en des durées égales",
        "les aires sont proportionnelles au temps au carré"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Conséquence immédiate à citer : la planète va plus vite près du Soleil que loin de lui.",
      "piege": "Parler d'angles égaux : ce sont les aires qui le sont, pas les angles.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-03",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "La loi des <b>périodes</b> s'écrit :",
      "options": [
        "T/a = constante",
        "T³/a² = 4π²/(G·M)",
        "T²/a³ = 4π²/(G·M)",
        "T²·a³ = constante"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le rapport ne dépend que de la masse de l'astre central, pas de la planète considérée.",
      "piege": "Intervertir les exposants : le carré est sur la période, le cube sur le demi-grand axe.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "kep-04",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Ces trois lois s'appliquent :",
      "options": [
        "seulement aux orbites circulaires",
        "seulement aux planètes du système solaire",
        "seulement au Soleil",
        "à tout astre en révolution autour d'un autre astre"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Satellite autour d'une planète, planète autour d'une étoile : c'est la généralisation à citer.",
      "piege": "Les restreindre au système solaire alors que les exercices portent souvent sur des satellites.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-05",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Le demi-grand axe d'une orbite elliptique vaut :",
      "options": ["(d_min + d_max)/2, demi-somme des distances au périastre et à l'apoastre", "le rayon du cercle moyen, égal à la distance minimale au Soleil", "la distance moyenne au Soleil, mesurée sur une révolution entière", "d_max − d_min, écart entre les distances à l'apoastre et au périastre"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le grand axe vaut 2a et se décompose en la distance minimale et la distance maximale.",
      "piege": "Prendre a comme une distance moyenne — le piège explicite de cette QT.",
      "image": "kep_orbite.png",
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "kep-06",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Une planète passe à 1,5×10¹¹ m au périastre et 2,1×10¹¹ m à l'apoastre. Que vaut a ?",
      "options": [
        "3,6×10¹¹ m",
        "1,8×10¹¹ m",
        "0,6×10¹¹ m",
        "1,5×10¹¹ m"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "a = (1,5×10¹¹ + 2,1×10¹¹)/2 = 1,8×10¹¹ m.",
      "piege": "Additionner sans diviser par deux : on obtient le grand axe, pas le demi-grand axe.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "kep-07",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Le <b>périastre</b> est le point de l'orbite :",
      "options": [
        "où la vitesse est minimale",
        "le plus éloigné de l'astre central",
        "le plus proche de l'astre central",
        "situé sur le petit axe"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Périastre = plus proche, apoastre = plus loin. C'est au périastre que la vitesse est maximale.",
      "piege": "Intervertir les deux, ce qui inverse aussi la conclusion sur les vitesses.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-08",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre la démonstration que la vitesse est plus faible à l'apoastre :",
      "options": [
        "d'après la loi des aires, les aires balayées pendant ces durées égales sont égales",
        "or près de l'apoastre le rayon-vecteur est plus long : l'arc parcouru doit être plus court",
        "on considère deux arcs parcourus pendant la même durée Δt, l'un près de l'apoastre, l'autre près du périastre",
        "en divisant les deux arcs par la même durée Δt : v<sub>A</sub> &lt; v<sub>P</sub>"
      ],
      "bonne_reponse": [
        2,
        0,
        1,
        3
      ],
      "explication": "Tout repose sur la loi des aires : c'est elle qu'il faut invoquer explicitement.",
      "piege": "Affirmer le résultat sans passer par les aires balayées.",
      "image": "kep_aires.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-09",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Où la vitesse d'une planète est-elle maximale ?",
      "options": [
        "à l'apoastre, loin du Soleil",
        "aux deux extrémités du petit axe",
        "elle est constante",
        "au périastre, près du Soleil"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "La formulation attendue : « la planète va plus vite près du Soleil que loin de lui ».",
      "piege": "Raisonner en pensant qu'elle « accélère en s'éloignant ».",
      "image": "kep_aires.png",
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-10",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Pourquoi l'arc parcouru est-il plus court près de l'apoastre ?",
      "options": ["parce que le rayon-vecteur y est plus long : à aire égale, l'arc est plus court", "parce que la planète y est plus lente : à aire égale, l'arc est plus court", "parce que la durée y est plus grande : à aire égale, l'arc est plus court", "parce que l'orbite y est plus courbée : à aire égale, l'arc est plus court"],
      "bonne_reponse": [
        0
      ],
      "explication": "L'aire balayée est celle d'un secteur : plus le rayon est long, moins il faut d'arc pour la même aire.",
      "piege": "Invoquer la courbure de l'orbite au lieu de la longueur du rayon-vecteur.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "kep-11",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Pour comparer deux astres tournant autour du même astre central, on écrit :",
      "options": [
        "T₁/a₁ = T₂/a₂",
        "T₁²/a₁³ = T₂²/a₂³",
        "T₁²·a₁³ = T₂²·a₂³",
        "T₁ = T₂"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le rapport T²/a³ ne dépend que de l'astre central : il est donc le même pour les deux.",
      "piege": "Comparer directement les périodes sans passer par le rapport.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-12",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "On isole la période de l'astre 1. Que vaut T₁ ?",
      "options": [
        "T₁ = √( a₂³ × T₂² / a₁³ )",
        "T₁ = a₁³ × T₂ / a₂³",
        "T₁ = √( a₁³ × T₂² / a₂³ )",
        "T₁ = T₂ × a₁/a₂"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "On multiplie en croix puis on prend la racine carrée.",
      "piege": "Oublier la racine carrée : le rapport porte sur T², pas sur T.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-13",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Quel contrôle d'unités s'impose dans ce calcul ?",
      "options": ["convertir toutes les grandeurs en unités SI avant tout calcul", "exprimer les deux demi-grands axes dans la même unité, et les périodes aussi", "convertir les périodes en secondes, les axes restant en unités libres", "aucun contrôle : le rapport T²/a³ est sans dimension par construction"],
      "bonne_reponse": [
        1
      ],
      "explication": "Les grandeurs apparaissant en rapport, il suffit qu'elles soient homogènes entre elles.",
      "piege": "Mélanger unités astronomiques et mètres, ou années et secondes.",
      "image": null,
      "tags": [
        "controle"
      ],
      "actif": true
    },
    {
      "ref": "kep-14",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Le graphe T² = f(a³) est :",
      "options": ["une droite passant par l'origine, de coefficient directeur 4π²/(G·M)", "une parabole passant par l'origine, de courbure 4π²/(G·M)", "une exponentielle croissante, de coefficient 4π²/(G·M)", "une droite affine d'ordonnée à l'origine 4π²/(G·M)"],
      "bonne_reponse": [
        0
      ],
      "explication": "T² = k × a³ : fonction linéaire, donc passage par l'origine.",
      "piege": "La confondre avec une fonction affine et chercher une ordonnée à l'origine.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-15",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre l'exploitation du graphe T² = f(a³) pour déterminer la <b>masse de l'astre attracteur</b> :",
      "options": [
        "identifier ce coefficient à 4π²/(G·M)",
        "vérifier que la droite passe par l'origine : T² = k × a³ est une fonction linéaire",
        "isoler la masse : M = 4π²/(G·k)",
        "relever deux points bien lisibles A et B de la droite",
        "calculer le coefficient directeur k = (T²<sub>B</sub> − T²<sub>A</sub>)/(a³<sub>B</sub> − a³<sub>A</sub>)"
      ],
      "bonne_reponse": [
        1,
        3,
        4,
        0,
        2
      ],
      "explication": "Une seule lecture graphique — le coefficient directeur — suffit : c'est son identification à 4π²/(G·M) qui donne la masse.",
      "piege": "Lire une ordonnée à l'origine : la fonction est linéaire, la droite passe par l'origine.",
      "image": "kep_droite.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-16",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Le coefficient directeur vaut k. Comment obtient-on la masse de l'astre central ?",
      "options": [
        "M = k/G",
        "M = 4π²/(G·k)",
        "M = G·k/(4π²)",
        "M = 4π²·k/G"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "On part de k = 4π²/(G·M) et on isole M.",
      "piege": "Inverser le rapport et obtenir une masse absurde.",
      "image": "kep_droite.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-17",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Pour un satellite en orbite, quel référentiel choisit-on ?",
      "options": ["héliocentrique, centré sur le Soleil et supposé galiléen", "terrestre, lié au sol et supposé galiléen sur une orbite", "géocentrique, centré sur la Terre et supposé galiléen", "celui du satellite, dans lequel il est immobile par définition"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le mouvement est étudié autour du centre de la Terre : c'est le référentiel géocentrique.",
      "piege": "Choisir le référentiel terrestre, qui tourne avec la Terre.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-18",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Remets dans l'ordre la démonstration que l'accélération est centripète :",
      "options": [
        "système : le satellite de masse m<sub>s</sub> · référentiel géocentrique galiléen",
        "<span class=\"vec\">a</span> est colinéaire à <span class=\"vec\">u</span><sub>N</sub>, dirigé vers le centre : elle est centripète",
        "2<sup>e</sup> loi de Newton : m<sub>s</sub>·<span class=\"vec\">a</span> = <span class=\"vec\">F</span><sub>T/s</sub>",
        "bilan : la seule force est la force gravitationnelle exercée par la Terre",
        "on simplifie par m<sub>s</sub> : <span class=\"vec\">a</span> = G·M<sub>T</sub>/(R<sub>T</sub>+h)² · <span class=\"vec\">u</span><sub>N</sub>"
      ],
      "bonne_reponse": [
        0,
        3,
        2,
        4,
        1
      ],
      "explication": "La simplification par m<sub>s</sub> montre au passage que l'accélération ne dépend pas de la masse du satellite.",
      "piege": "Oublier de conclure sur la direction : c'est elle qui répond à la question.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-19",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "L'accélération d'un satellite dépend-elle de sa masse ?",
      "options": [
        "seulement en orbite basse",
        "oui, elle lui est proportionnelle",
        "oui, elle lui est inversement proportionnelle",
        "non : la masse se simplifie dans la deuxième loi"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est une conséquence à citer : deux satellites de masses différentes à la même altitude ont la même accélération.",
      "piege": "Croire qu'un satellite plus lourd est plus fortement accéléré.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-20",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Remets dans l'ordre la démonstration que le mouvement est circulaire uniforme :",
      "options": [
        "on écrit l'accélération dans la base de Frenet : <span class=\"vec\">a</span> = (dv/dt)·<span class=\"vec\">u</span><sub>T</sub> + v²/(R<sub>T</sub>+h)·<span class=\"vec\">u</span><sub>N</sub>",
        "or l'accélération trouvée à la QT 6 n'a aucune composante tangentielle",
        "la valeur de la vitesse ne varie pas : le mouvement est circulaire et uniforme",
        "donc dv/dt = 0, c'est-à-dire v = constante"
      ],
      "bonne_reponse": [
        0,
        1,
        3,
        2
      ],
      "explication": "On compare deux expressions de la même accélération : c'est l'absence de terme tangentiel qui conclut.",
      "piege": "Conclure directement sans passer par la base de Frenet.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-21",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "« Uniforme » signifie-t-il « sans accélération » ?",
      "options": ["oui, si l'orbite est circulaire : la vitesse garde alors sa direction", "non : la direction de la vitesse change, l'accélération n'est pas nulle", "oui : une vitesse de valeur constante donne une accélération nulle", "cela dépend de l'altitude : l'accélération s'annule au-delà de 36 000 km"],
      "bonne_reponse": [
        1
      ],
      "explication": "Seule la <b>valeur</b> de la vitesse est constante : le vecteur, lui, tourne.",
      "piege": "Confondre vitesse constante en valeur et vecteur vitesse constant.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "kep-22",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre la détermination de la vitesse d'un satellite :",
      "options": [
        "on prend la racine : v = √( G·M<sub>T</sub>/(R<sub>T</sub>+h) )",
        "on l'égale à l'accélération gravitationnelle : v²/(R<sub>T</sub>+h) = G·M<sub>T</sub>/(R<sub>T</sub>+h)²",
        "on repart de <span class=\"vec\">a</span> = v²/(R<sub>T</sub>+h)·<span class=\"vec\">u</span><sub>N</sub>, avec dv/dt = 0",
        "on simplifie par (R<sub>T</sub>+h)"
      ],
      "bonne_reponse": [
        2,
        1,
        3,
        0
      ],
      "explication": "La vitesse ne dépend que de l'altitude, jamais de la masse du satellite.",
      "piege": "Oublier de simplifier par (R<sub>T</sub>+h) et garder un exposant faux.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-23",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "La vitesse d'un satellite en orbite circulaire vaut :",
      "options": [
        "v = √( G·M<sub>T</sub>/(R<sub>T</sub>+h)² )",
        "v = √( G·M<sub>T</sub>/(R<sub>T</sub>+h) )",
        "v = G·M<sub>T</sub>/(R<sub>T</sub>+h)",
        "v = √( G·M<sub>T</sub>·(R<sub>T</sub>+h) )"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Plus l'altitude est grande, plus la vitesse est faible.",
      "piege": "Garder le carré au dénominateur : il disparaît lors de la simplification.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-24",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "La période de révolution s'écrit :",
      "options": [
        "T = 2π(R<sub>T</sub>+h)·v",
        "T = (R<sub>T</sub>+h)/(2πv)",
        "T = 2π(R<sub>T</sub>+h)/v",
        "T = 2πv/(R<sub>T</sub>+h)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est la durée d'un tour : le périmètre de l'orbite divisé par la vitesse.",
      "piege": "Multiplier par la vitesse au lieu de diviser.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "kep-25",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "En remplaçant v par son expression, que devient la période ?",
      "options": [
        "T = 2π·√( (R<sub>T</sub>+h)/(G·M<sub>T</sub>) )",
        "T = 2π·(R<sub>T</sub>+h)³/(G·M<sub>T</sub>)",
        "T = 2π·√( G·M<sub>T</sub>/(R<sub>T</sub>+h)³ )",
        "T = 2π·√( (R<sub>T</sub>+h)³/(G·M<sub>T</sub>) )"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Le cube apparaît en combinant le périmètre et l'expression de la vitesse.",
      "piege": "Perdre un exposant lors de la substitution.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "kep-26",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Remets dans l'ordre la démonstration de la troisième loi à partir de la période :",
      "options": [
        "on élève au carré : T² = 4π²·(R<sub>T</sub>+h)³/(G·M<sub>T</sub>)",
        "on part de T = 2π·√( (R<sub>T</sub>+h)³/(G·M<sub>T</sub>) )",
        "on divise par (R<sub>T</sub>+h)³ : T²/(R<sub>T</sub>+h)³ = 4π²/(G·M<sub>T</sub>)",
        "le rapport est une constante qui ne dépend que de la masse de l'astre central"
      ],
      "bonne_reponse": [
        1,
        0,
        2,
        3
      ],
      "explication": "C'est la troisième loi de Kepler, retrouvée dans le cas particulier d'une orbite circulaire où a = R<sub>T</sub> + h.",
      "piege": "Oublier de conclure : c'est la phrase finale qui répond à la question posée.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-27",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "Dans le cas d'une orbite circulaire, à quoi correspond le demi-grand axe ?",
      "options": [
        "au rayon de l'orbite, R<sub>T</sub> + h",
        "au rayon terrestre R<sub>T</sub>",
        "au diamètre de l'orbite",
        "à l'altitude h"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le cercle est une ellipse dont les deux foyers sont confondus : le demi-grand axe est le rayon.",
      "piege": "Prendre l'altitude h seule, en oubliant le rayon de la Terre.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-28",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Un satellite géostationnaire a une période de 24 h. Que peut-on en déduire ?",
      "options": ["son altitude, par la troisième loi de Kepler", "sa masse, par la troisième loi de Kepler", "sa vitesse seulement, la troisième loi ne donnant pas le rayon", "rien : la troisième loi relie la période à l'astre, pas au satellite"],
      "bonne_reponse": [
        0
      ],
      "explication": "T²/(R<sub>T</sub>+h)³ = 4π²/(G·M<sub>T</sub>) : connaissant T, on isole R<sub>T</sub> + h.",
      "piege": "Chercher la masse du satellite : elle n'intervient dans aucune de ces relations.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-29",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelle grandeur n'intervient jamais dans les expressions de v et T d'un satellite ?",
      "options": [
        "l'altitude",
        "la masse de la Terre",
        "la masse du satellite",
        "le rayon terrestre"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Elle se simplifie dès la deuxième loi de Newton : c'est la remarque à citer.",
      "piege": "Croire qu'un satellite lourd doit aller plus vite pour rester en orbite.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-30",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "typologie",
      "enonce": "Deux satellites de masses différentes orbitent à la même altitude. Que peut-on dire de leurs vitesses ?",
      "options": [
        "le plus lourd va plus vite",
        "le plus léger va plus vite",
        "elles sont égales",
        "impossible à dire"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "v = √( G·M<sub>T</sub>/(R<sub>T</sub>+h) ) ne dépend que de l'altitude.",
      "piege": "Transposer l'intuition terrestre selon laquelle la masse change le mouvement.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "kep-31",
      "chapitre": "lois-de-kepler-et-satellites",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Quelle est la seule force à faire figurer au bilan pour un satellite ?",
      "options": [
        "la force gravitationnelle exercée par la Terre",
        "le poids et la force gravitationnelle",
        "la force gravitationnelle et une force centrifuge",
        "aucune force"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Il n'y a ni support, ni frottement, ni « force centrifuge » : une seule force.",
      "piege": "Ajouter une force centrifuge, qui n'existe pas dans un référentiel galiléen.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {"ref": "kepler-t01", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "La deuxième loi de Kepler, dite loi des aires, énonce que :", "options": ["les planètes décrivent des ellipses dont le Soleil est le centre", "le segment reliant le Soleil à la planète balaie des aires égales pendant des durées égales", "la vitesse d'une planète est constante sur son orbite", "le carré de la période est proportionnel au cube du demi-grand axe"], "bonne_reponse": [1], "explication": "Première loi : ellipses dont le Soleil occupe un FOYER. Deuxième loi : loi des aires. Troisième loi : T²/a³ = constante.", "piege": "Placer le Soleil au centre de l'ellipse — il est à l'un des foyers, ce qui explique que la distance varie.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t02", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Une comète a un périhélie à 0,60 ua du Soleil et un aphélie à 35,4 ua. Le demi-grand axe de son orbite vaut :", "options": ["a = (0,60 + 35,4)/2 = 18,0 ua", "a = 35,4 ua", "a = 35,4 − 0,60 = 34,8 ua", "a = √(0,60 × 35,4) = 4,6 ua"], "bonne_reponse": [0], "explication": "Le grand axe est la distance périhélie-aphélie, qui passe par le Soleil : 2a = r_p + r_a. Donc a = (r_p + r_a)/2.", "piege": "Prendre l'aphélie seul, ou la différence : le grand axe traverse toute l'ellipse, il additionne les deux distances.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t03", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "D'après la loi des aires, pendant une même durée Δt, le rayon vecteur balaie la même aire au périastre et à l'apoastre. On en déduit :", "options": ["la vitesse ne dépend pas de la distance : l'aire seule est conservée", "l'apoastre étant plus loin, l'arc y est plus long : la vitesse y est plus grande", "le périastre étant plus proche, l'arc y est plus long : la vitesse y est plus grande", "la vitesse est la même en tout point : c'est l'aire qui varie"], "bonne_reponse": [2], "explication": "Aire ≈ ½·r·(v·Δt). À aire égale, un r plus petit impose un v plus grand. La planète accélère en s'approchant, ralentit en s'éloignant.", "piege": "Confondre distance et vitesse : plus loin ne veut pas dire plus vite, c'est l'inverse.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t04", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Mars a un demi-grand axe a = 1,52 ua. Sachant que pour la Terre T = 1,00 an et a = 1,00 ua, la période de Mars vaut :", "options": ["T = 1,52³ = 3,51 an", "T = 1,52 an", "T = √(1,52³) = 1,87 an", "T = 1,52² = 2,31 an"], "bonne_reponse": [2], "explication": "T²/a³ est la même pour toutes les planètes du Soleil : T_M² = a_M³ × (T_T²/a_T³) = 1,52³, donc T_M = √3,51 = 1,87 an.", "piege": "Oublier la racine carrée : la troisième loi porte sur T², pas sur T.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t05", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "On trace T² en fonction de a³ pour les satellites d'une planète : droite de pente k = 4,2 × 10⁻¹³ s²·m⁻³. La masse de la planète vaut :", "options": ["k = 4π²·G/M, donc M = 4π²·k/G ≈ 2,5 × 10⁻¹ kg", "k = G/M, donc M = k/G ≈ 6,3 × 10⁻³ kg", "k = 4π²/(G·M), donc M = 4π²/(G·k) ≈ 1,4 × 10²⁴ kg", "k = 1/(G·M), donc M = G·k ≈ 2,8 × 10⁻²³ kg"], "bonne_reponse": [2], "explication": "T² = (4π²/GM)·a³ : la pente est 4π²/(GM). On isole M = 4π²/(G·k) = 39,5/(6,67 × 10⁻¹¹ × 4,2 × 10⁻¹³).", "piege": "Inverser la fraction : c'est M au dénominateur de la pente, donc M = 4π²/(G·k), pas G·k/4π².", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t06", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Un satellite n'est soumis qu'à l'attraction gravitationnelle F⃗ = −(G·M·m/r²)·u⃗_r, où u⃗_r pointe de la planète vers le satellite. D'après la deuxième loi :", "options": ["a⃗ = (G·M/r²)·u⃗_r : dirigée vers l'extérieur", "a⃗ = F⃗/m = −(G·M/r²)·u⃗_r : dirigée vers le centre de la planète", "a⃗ = 0⃗ car la vitesse est constante", "a⃗ est tangente à la trajectoire"], "bonne_reponse": [1], "explication": "a⃗ = ΣF⃗/m. La force est centripète (signe −), l'accélération l'est donc aussi, de valeur GM/r².", "piege": "Confondre centripète et centrifuge : la force attire le satellite VERS la planète.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t07", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Dans le repère de Frenet, l'accélération d'un satellite en orbite circulaire s'écrit a⃗ = (dv/dt)·u⃗_t + (v²/r)·u⃗_n. Puisque a⃗ est centripète :", "options": ["la vitesse est nulle : le satellite est immobile sur son orbite", "v²/r = 0 : le mouvement est rectiligne, le rayon étant infini", "dv/dt = g : le satellite accélère en tombant vers la Terre", "dv/dt = 0 : la valeur de la vitesse est constante, le mouvement uniforme"], "bonne_reponse": [3], "explication": "a⃗ n'a pas de composante tangentielle : dv/dt = 0, donc v est constante. Circulaire par hypothèse, uniforme par ce résultat.", "piege": "Croire que « uniforme » veut dire accélération nulle : l'accélération centripète est bien là, c'est la valeur de v qui ne change pas.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t08", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "En identifiant les deux expressions de l'accélération centripète, v²/r = G·M/r², on obtient la vitesse d'un satellite en orbite circulaire :", "options": ["v = √(G·M/r), et sa période vaut T = 2π·r/v", "v = G·M/r, et sa période vaut T = 2π·r/v", "v = 2π·r, et sa période vaut T = √(G·M/r)", "v = √(G·M·r), et sa période vaut T = 2π·r/v"], "bonne_reponse": [0], "explication": "v² = GM/r, donc v = √(GM/r). Un tour complet est 2πr parcouru à vitesse v : T = 2πr/v = 2π·√(r³/GM).", "piege": "Oublier la racine : l'identification donne v², il faut extraire v.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "kepler-t09", "chapitre": "kepler", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "À partir de T = 2π·√(r³/(G·M)), on élève au carré et l'on obtient :", "options": ["T/r³ = 2π/(G·M), constante pour tous les satellites d'un même astre", "T²/r = 4π²/(G·M), constante pour tous les satellites d'un même astre", "T²/r³ = 4π²/(G·M), constante pour tous les satellites d'un même astre", "T² = 4π²·r·G·M, constante pour tous les satellites d'un même astre"], "bonne_reponse": [2], "explication": "T² = 4π²·r³/(GM), donc T²/r³ = 4π²/(GM). Cette constante ne dépend que de M : c'est la troisième loi de Kepler retrouvée.", "piege": "Oublier d'élever le 2π au carré, ou le r³ au dénominateur.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  energie: [
    {
      "ref": "ene-01",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "L'énergie mécanique s'écrit :",
      "options": [
        "E<sub>m</sub> = E<sub>c</sub> + E<sub>pp</sub>",
        "E<sub>m</sub> = E<sub>c</sub> × E<sub>pp</sub>",
        "E<sub>m</sub> = E<sub>c</sub> − E<sub>pp</sub>",
        "E<sub>m</sub> = E<sub>pp</sub> − E<sub>c</sub>"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "E<sub>c</sub> = ½·m·v² et E<sub>pp</sub> = m·g·z, les trois en joules.",
      "piege": "Soustraire les deux énergies : l'énergie mécanique en est la somme.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-02",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "L'énergie cinétique vaut :",
      "options": [
        "E<sub>c</sub> = m·v²",
        "E<sub>c</sub> = ½·m·v²",
        "E<sub>c</sub> = ½·m·v",
        "E<sub>c</sub> = m·v"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le facteur ½ et le carré de la vitesse : les deux comptent.",
      "piege": "Oublier le facteur ½, ou le carré.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-04",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Le travail d'une force constante entre A et B vaut :",
      "options": ["W = F⃗ / AB⃗ = F/AB × cos α", "W = F × AB = F × AB × cos α", "W = F⃗ · AB⃗ = F × AB × cos α", "W = F⃗ ∧ AB⃗ = F × AB × sin α"],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est un produit scalaire : α est l'angle entre la force et le déplacement.",
      "piege": "Oublier le cosinus, ou se tromper d'angle — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-05",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Un travail est <b>moteur</b> lorsque :",
      "options": ["la force est verticale : son travail vaut alors m·g·h", "W &lt; 0 : force et déplacement sont de sens contraires", "W = 0 : force et déplacement sont perpendiculaires", "W > 0 : force et déplacement sont de même sens"],
      "bonne_reponse": [
        3
      ],
      "explication": "Moteur si W > 0, résistant si W &lt; 0. On regarde le signe, on ne devine pas.",
      "piege": "Conclure sans calculer le signe.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "ene-06",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Une force est perpendiculaire au déplacement. Que vaut son travail ?",
      "options": ["il est nul, car cos 90° = 0", "il est négatif, car cos 90° = −1", "il est maximal, car cos 0° = 1", "il vaut F × AB, car cos 90° = 1"],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est le cas de la réaction normale sur un plan horizontal : elle ne travaille pas.",
      "piege": "Faire figurer la réaction normale dans un bilan de travaux alors qu'elle est nulle.",
      "image": "ene_travail_force.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-07",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "F = 50 N, AB = 20 m, α = 60°. Que vaut le travail ?",
      "options": [
        "866 J",
        "500 J",
        "25 J",
        "1000 J"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "W = 50 × 20 × cos 60° = 50 × 20 × 0,50 = 500 J. Il est moteur.",
      "piege": "Oublier le cosinus et rendre 1000 J.",
      "image": "ene_travail_force.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "ene-08",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Remets dans l'ordre l'établissement du travail du poids :",
      "options": [
        "on remplace : W = P × AB × (z<sub>A</sub> − z<sub>B</sub>)/AB",
        "W = <span class=\"vec\">P</span> · <span class=\"vec\">AB</span> = P × AB × cos α",
        "dans le triangle rectangle du schéma, cos α = (z<sub>A</sub> − z<sub>B</sub>)/AB",
        "AB se simplifie : W = m·g·(z<sub>A</sub> − z<sub>B</sub>)"
      ],
      "bonne_reponse": [
        1,
        2,
        0,
        3
      ],
      "explication": "La simplification par AB est la clé : c'est elle qui montre que le chemin ne compte pas.",
      "piege": "Poser la formule sans l'établir, alors que la question dit « établir l'expression ».",
      "image": "ene_travail_poids.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-09",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Le travail du poids dépend :",
      "options": ["de la vitesse du système, qui fixe la durée du trajet", "de la masse seulement, l'altitude n'intervenant pas", "de la différence d'altitude seulement, et de la masse", "du chemin suivi entre le point de départ et celui d'arrivée"],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est ce qui en fait une force conservative.",
      "piege": "Croire qu'un chemin plus long dissipe davantage : c'est vrai des frottements, pas du poids.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-10",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Un système <b>descend</b> d'une hauteur h. Que vaut le travail du poids ?",
      "options": [
        "W = m·g·h², moteur",
        "W = − m·g·h, résistant",
        "W = 0",
        "W = + m·g·h, moteur"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "z<sub>A</sub> > z<sub>B</sub> donc W > 0 : le poids accompagne le mouvement.",
      "piege": "Inverser z<sub>A</sub> et z<sub>B</sub> et changer le signe du travail.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-11",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Un système est lancé vers le <b>haut</b> d'une hauteur h. Que vaut le travail du poids ?",
      "options": [
        "W = − m·g·h, résistant",
        "W = + m·g·h, moteur",
        "W = m·g/h",
        "W = 0"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le système monte : le poids s'oppose au mouvement, son travail est résistant.",
      "piege": "Garder le signe positif de la descente.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-12",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Le travail des forces de frottement vaut :",
      "options": [
        "W = + f × AB",
        "W = − f × AB",
        "W = f × AB × cos α, avec α quelconque",
        "W = 0"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La force est de sens opposé au déplacement : α = 180° et cos 180° = −1.",
      "piege": "Oublier le signe moins — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-13",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Le travail des frottements est :",
      "options": [
        "positif si la vitesse est grande",
        "parfois moteur",
        "toujours résistant",
        "nul"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Et il dépend du chemin suivi, par l'intermédiaire de AB : les frottements sont dissipatifs.",
      "piege": "Imaginer un cas où les frottements accompagneraient le mouvement.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "actif": true
    },
    {
      "ref": "ene-14",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Dans un condensateur plan, le travail de la force électrostatique s'écrit :",
      "options": ["W = E·AB/q = U_AB/q, quotient de la tension par la charge", "W = q·E/AB = q·U_AB/AB², la tension divisée par la distance", "W = q/U_AB = q/(E·AB), la charge divisée par la tension", "W = q·E·AB = q·U_AB, la charge multipliée par la tension"],
      "bonne_reponse": [
        3
      ],
      "explication": "On utilise E = U<sub>AB</sub>/AB : l'écriture en q·U<sub>AB</sub> est commode, la tension étant directement mesurable.",
      "piege": "Oublier la substitution E = U/AB, qui simplifie tout le calcul.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-15",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Une force de frottement f = 12 N s'exerce sur un trajet de 25 m. Que vaut son travail ?",
      "options": [
        "− 300 J",
        "300 J",
        "0 J",
        "− 12 J"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "W = − f × AB = − 12 × 25 = − 300 J : 300 J sont dissipés.",
      "piege": "Rendre une valeur positive, ce qui ferait des frottements une source d'énergie.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-16",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Une force est <b>conservative</b> si :",
      "options": ["elle est constante en direction, en sens et en valeur", "son travail ne dépend pas du chemin, mais des seules positions", "elle est verticale, comme le poids ou la force électrostatique", "son travail est toujours positif, quel que soit le déplacement"],
      "bonne_reponse": [
        1
      ],
      "explication": "Le poids en est l'exemple : W = m·g·(z<sub>A</sub> − z<sub>B</sub>) ne fait intervenir que les altitudes.",
      "piege": "Confondre force constante et force conservative.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-17",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Comment justifie-t-on qu'une force est dissipative ?",
      "options": ["en calculant sa norme, plus grande que celle des autres forces", "en mesurant la température, qui s'élève au cours du trajet", "en montrant que l'expression de son travail contient la longueur du trajet", "en disant qu'elle freine le système, donc qu'elle dissipe l'énergie"],
      "bonne_reponse": [
        2
      ],
      "explication": "W = − f·AB : plus le chemin est long, plus l'énergie dissipée est grande.",
      "piege": "Répondre sans justifier par l'expression du travail — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "ene-18",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Quel est l'enjeu de la distinction conservative / dissipative ?",
      "options": ["calculer la masse du système à partir du travail des forces", "déterminer le sens du mouvement à partir du signe du travail", "choisir le référentiel dans lequel écrire le bilan des forces", "savoir si l'énergie mécanique se conserve ou non au cours du trajet"],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est elle qui décide du cas dans lequel on se trouve pour le théorème de l'énergie mécanique.",
      "piege": "Traiter la distinction comme une simple question de vocabulaire.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-19",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Le théorème de l'énergie mécanique s'écrit :",
      "options": [
        "ΔE_m = W(forces non conservatives)",
        "ΔE_m = ΣW(toutes les forces)",
        "ΔE_m = 0 toujours",
        "ΔE_m = W(poids)"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Seules les forces non conservatives font varier l'énergie mécanique.",
      "piege": "Y faire figurer le travail du poids : il est déjà pris en compte dans l'énergie potentielle.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "ene-20",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Quel réflexe avant d'appliquer ce théorème ?",
      "options": ["calculer la vitesse initiale, qui fixe l'énergie cinétique de départ", "regarder si l'énoncé mentionne des frottements le long du trajet", "tracer la trajectoire, dont dépend le travail des forces en jeu", "vérifier la masse, qui doit rester constante tout au long du trajet"],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est cela qui décide : sans frottement ΔE_m = 0, avec frottement ΔE_m = − f·AB &lt; 0.",
      "piege": "Affirmer la conservation alors que l'énoncé mentionne des frottements — le piège explicite.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "ene-21",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Un système subit des frottements sur une distance AB. Que vaut ΔE_m ?",
      "options": ["+ m·g·h, l'énergie mécanique se conserve", "0, l'énergie mécanique se conserve", "− f × AB, l'énergie mécanique diminue", "+ f × AB, l'énergie mécanique augmente"],
      "bonne_reponse": [
        2
      ],
      "explication": "La différence est dissipée sous forme thermique.",
      "piege": "Conclure à la conservation par habitude.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-22",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "En l'absence de force dissipative :",
      "options": ["Em(B) &lt; Em(A) : l'altitude est constante", "Em(B) = Em(A) : l'énergie cinétique est constante", "Em(B) > Em(A) : l'énergie mécanique augmente", "Em(B) = Em(A) : il y a conservation de l'énergie mécanique"],
      "bonne_reponse": [
        3
      ],
      "explication": "E<sub>c</sub> et E<sub>pp</sub> varient, mais leur somme reste constante.",
      "piege": "Croire que chaque énergie se conserve séparément.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-23",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Le théorème de l'énergie cinétique s'écrit :",
      "options": ["ΔE_c = ΣW(forces extérieures)", "ΔE_c = W(poids) seulement", "ΔE_c = 0 dans tous les cas", "ΔE_c = ΔE_pp, les deux variations étant égales"],
      "bonne_reponse": [
        0
      ],
      "explication": "La variation d'énergie cinétique est égale à la somme des travaux de <b>toutes</b> les forces extérieures.",
      "piege": "Oublier une force dans la somme des travaux — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "ene-24",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Remets dans l'ordre l'application du théorème de l'énergie cinétique :",
      "options": [
        "isoler la vitesse cherchée",
        "écrire ½·m·v_B² − ½·m·v_A² = ΣW",
        "calculer le travail de chacune — beaucoup sont nulles, comme la réaction normale",
        "faire le bilan des forces"
      ],
      "bonne_reponse": [
        3,
        2,
        1,
        0
      ],
      "explication": "Les travaux nuls doivent être signalés, pas ignorés : cela montre qu'on n'a rien oublié.",
      "piege": "Sauter le bilan des forces et perdre un travail en route.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-25",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Quand utilise-t-on l'énergie cinétique plutôt que l'énergie mécanique ?",
      "options": ["quand l'altitude varie, l'énergie potentielle intervenant alors", "dès que la question demande une vitesse, avec ou sans frottements", "quand il y a des frottements, l'énergie mécanique ne se conservant plus", "jamais : l'énergie mécanique suffit dans tous les cas de figure"],
      "bonne_reponse": [
        1
      ],
      "explication": "Énergie mécanique pour une altitude, énergie cinétique pour une vitesse : c'est la grandeur cherchée qui décide.",
      "piege": "Choisir le théorème au hasard et se retrouver avec deux inconnues.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "ene-26",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Sur un graphe des énergies, quelle courbe est toujours au-dessus des deux autres ?",
      "options": ["l'énergie cinétique, puisqu'elle croît au cours de la chute", "l'énergie mécanique, puisqu'elle est la somme des deux autres", "l'énergie potentielle, puisqu'elle vaut m·g·h au point le plus haut", "cela dépend du cas : l'ordre des courbes change selon le mouvement"],
      "bonne_reponse": [
        1
      ],
      "explication": "Sans frottement, c'est une droite horizontale ; avec frottements, elle décroît.",
      "piege": "Intervertir E<sub>m</sub> et E<sub>c</sub> — le piège explicite de cette QT.",
      "image": "ene_sans_frottement.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-27",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Au cours d'une chute, l'énergie cinétique :",
      "options": ["s'annule, l'énergie se transformant entièrement en potentielle", "reste constante, car la masse du système ne varie pas", "décroît, car l'altitude du système diminue au cours de la chute", "croît, car la vitesse du système augmente au cours de la chute"],
      "bonne_reponse": [
        3
      ],
      "explication": "E<sub>c</sub> = ½mv² suit la vitesse ; E<sub>pp</sub> = m·g·z suit l'altitude, et décroît donc.",
      "piege": "Confondre les deux : l'une monte pendant que l'autre descend.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-28",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Comment vérifier une identification de courbes ?",
      "options": ["en vérifiant qu'à chaque instant, E_m vaut la somme des deux autres", "en mesurant les aires sous chacune des trois courbes tracées", "en comparant les pentes des trois courbes en un même instant", "en regardant les couleurs, l'énoncé fixant une couleur par énergie"],
      "bonne_reponse": [
        0
      ],
      "explication": "Un point du graphe suffit : c'est le meilleur moyen de confirmer l'identification.",
      "piege": "Rendre l'identification sans ce contrôle, qui prend dix secondes.",
      "image": "ene_sans_frottement.png",
      "tags": [
        "controle"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-29",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Avec frottements, l'allure de la courbe d'énergie mécanique est :",
      "options": [
        "une parabole",
        "une courbe décroissante",
        "une courbe croissante",
        "une droite horizontale"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "ΔE_m = − f·AB &lt; 0 : l'énergie mécanique diminue tout au long du trajet.",
      "piege": "Garder la droite horizontale du cas sans frottement.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-30",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre les six étapes d'un problème d'énergie :",
      "options": [
        "déterminer les travaux",
        "préciser le référentiel",
        "définir le système",
        "faire le bilan des forces",
        "faire un schéma et représenter les forces",
        "appliquer le théorème adapté à la grandeur cherchée"
      ],
      "bonne_reponse": [
        2,
        1,
        3,
        4,
        0,
        5
      ],
      "explication": "Énergie mécanique pour une altitude, énergie cinétique pour une vitesse.",
      "piege": "Choisir le théorème avant d'avoir fait le bilan des forces.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-31",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Une balle est lancée verticalement. Que faut-il préciser pour trouver la hauteur maximale ?",
      "options": [
        "que la masse est connue",
        "que l'altitude initiale est nulle",
        "que la vitesse est nulle au sommet",
        "que le référentiel est galiléen"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est cette phrase qui permet de conclure : elle rapporte le point.",
      "piege": "Écrire le théorème sans annoncer cette condition, et rester bloqué avec deux inconnues.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-32",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Sans frottements, une balle est lancée à v<sub>A</sub>. Quelle hauteur maximale atteint-elle ?",
      "options": [
        "h = m·v_A²/(2g)",
        "h = 2g/v_A²",
        "h = v<sub>A</sub>/(2g)",
        "h = v_A²/(2g)"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "E<sub>m</sub>(B) = E<sub>m</sub>(A) donne m·g·h = ½·m·v_A², et la masse se simplifie.",
      "piege": "Garder la masse dans le résultat alors qu'elle se simplifie.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-33",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Que faut-il signaler à propos du résultat h = v_A²/(2g) ?",
      "options": [
        "qu'il ne dépend pas de la masse",
        "qu'il est approché",
        "qu'il dépend du référentiel",
        "qu'il dépend de la masse"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "La masse s'est simplifiée : deux balles de masses différentes lancées à la même vitesse montent à la même hauteur.",
      "piege": "Passer à côté de cette remarque, souvent demandée en fin de question.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-34",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Quel théorème choisir pour déterminer une <b>altitude</b> sans frottements ?",
      "options": [
        "l'énergie cinétique",
        "la deuxième loi de Newton",
        "l'énergie mécanique",
        "les deux au choix"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le tableau de la fiche : énergie mécanique pour une altitude, énergie cinétique pour une vitesse.",
      "piege": "Utiliser l'énergie cinétique et se retrouver avec le travail du poids à calculer séparément.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "ene-35",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelle force ne travaille jamais sur un plan horizontal ?",
      "options": ["la force motrice, dirigée dans le sens du déplacement", "le poids, dont le travail vaut m·g·h sur tout trajet", "la réaction normale, perpendiculaire au déplacement", "les frottements, opposés au sens du déplacement"],
      "bonne_reponse": [
        2
      ],
      "explication": "cos 90° = 0 : son travail est nul. Il faut le signaler dans le bilan, pas l'omettre.",
      "piege": "L'oublier complètement au lieu d'écrire que son travail est nul.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ene-36",
      "chapitre": "travail-et-energie",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "typologie",
      "enonce": "Un système part de A à 10 m·s⁻¹ et arrive en B à 6 m·s⁻¹, avec m = 2,0 kg. Que vaut ΔE_c ?",
      "options": [
        "+ 64 J",
        "+ 128 J",
        "− 32 J",
        "− 64 J"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "ΔE_c = ½ × 2,0 × (6² − 10²) = 36 − 100 = − 64 J : le système a perdu de l'énergie cinétique.",
      "piege": "Calculer (10² − 6²) et rendre une valeur positive : c'est final moins initial.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {"ref": "energie-t01", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Une force constante F⃗ de valeur 50 N déplace un objet de A à B sur 4,0 m, en faisant un angle de 60° avec le déplacement. Son travail vaut :", "options": ["W = F⃗ · AB⃗ = F·AB·cos 60° = 1,0 × 10² J", "W = F⃗ / AB⃗ = F/AB × cos 60° = 6,3 J", "W = F⃗ ∧ AB⃗ = F·AB·sin 60° = 1,7 × 10² J", "W = F⃗ · AB⃗ = F·AB, sans cos = 2,0 × 10² J"], "bonne_reponse": [0], "explication": "W_AB(F⃗) = F⃗·AB⃗ = F·AB·cos α. Le cosinus de l'angle entre force et déplacement fait toute la différence.", "piege": "Oublier le cosinus, ou prendre le sinus : seule la composante de F⃗ le long du déplacement travaille.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "energie-t02", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un objet de masse m = 2,0 kg descend de 3,0 m d'altitude. Le travail de son poids vaut :", "options": ["W = m·g·(z_B − z_A) = −59 J : résistant", "W = 0 : le poids ne travaille pas ici", "W = m·g = 20 J : moteur", "W = m·g·(z_A − z_B) = +59 J : moteur"], "bonne_reponse": [3], "explication": "W_AB(P⃗) = m·g·(z_A − z_B). En descente, z_A > z_B : le travail est positif, le poids est moteur. Il ne dépend pas du chemin suivi.", "piege": "Se tromper de signe : en descente le poids AIDE le mouvement, son travail est positif.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "energie-t03", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Une force de frottement f⃗ de valeur 20 N, toujours opposée au mouvement, s'exerce sur 5,0 m. Son travail vaut :", "options": ["W = −f·d = −20 × 5,0 = −1,0 × 10² J : résistant", "W = 0 : les frottements ne travaillent pas", "W = +f·d = +1,0 × 10² J", "W = f/d = 4,0 J"], "bonne_reponse": [0], "explication": "f⃗ fait un angle de 180° avec le déplacement : cos 180° = −1, donc W = −f·d. Le travail est négatif, la force est résistante : elle prélève de l'énergie.", "piege": "Oublier le signe : les frottements freinent, leur travail est toujours négatif.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "energie-t04", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Une force est dite conservative lorsque :", "options": ["elle ne varie pas au cours du temps, ni en valeur ni en direction", "elle est verticale, comme le poids ou la poussée d'Archimède", "son travail est toujours positif, quel que soit le trajet suivi", "son travail ne dépend pas du chemin, mais des seuls points de départ et d'arrivée"], "bonne_reponse": [3], "explication": "Le poids et la force électrostatique sont conservatives : leur travail ne dépend que de A et B, et l'on peut leur associer une énergie potentielle. Les frottements ne le sont pas.", "piege": "Confondre « conservative » et « constante » : une force constante peut être dissipative (frottements sur sol plat).", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "energie-t05", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Un objet glisse avec frottements de A à B. Le théorème de l'énergie mécanique s'écrit :", "options": ["ΔE_m = 0, l'énergie mécanique se conserve toujours", "ΔE_m = E_c(B) − E_c(A)", "ΔE_m = W_AB(P⃗), travail du poids", "ΔE_m = E_m(B) − E_m(A) = W_AB(f⃗), travail des forces non conservatives"], "bonne_reponse": [3], "explication": "La variation d'énergie mécanique est égale au travail des forces NON conservatives. Avec frottements, ΔE_m &lt; 0 : de l'énergie est dissipée en chaleur.", "piege": "Croire que E_m se conserve toujours : ce n'est vrai qu'en l'absence de forces dissipatives.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "energie-t06", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Un objet de masse 1,0 kg passe de 2,0 m·s⁻¹ à 6,0 m·s⁻¹ entre A et B. Le travail total des forces qui s'exercent sur lui vaut :", "options": ["ΣW = m·(v_B − v_A) = 4,0 J", "ΣW = ½·m·(v_B − v_A)² = 8,0 J", "ΣW = ΔE_c = ½·m·(v_B² − v_A²) = 16 J", "ΣW = ½·m·v_B² = 18 J"], "bonne_reponse": [2], "explication": "Théorème de l'énergie cinétique : ΔE_c = ΣW_AB. ΔE_c = ½·m·v_B² − ½·m·v_A², c'est la DIFFÉRENCE DES CARRÉS.", "piege": "Élever au carré la différence des vitesses : (v_B − v_A)² n'est pas v_B² − v_A².", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "energie-t07", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Sur un graphe représentant E_c, E_p et E_m d'un objet en chute libre sans frottement en fonction du temps, on reconnaît :", "options": ["E_c constante, E_p et E_m décroissantes, avec E_c + E_p = E_m", "les trois courbes croissantes, avec E_c + E_p = E_m à chaque instant", "E_m décroissante, E_c et E_p croissantes, avec E_c + E_p = E_m", "E_m constante, E_p décroissante, E_c croissante, avec E_c + E_p = E_m"], "bonne_reponse": [3], "explication": "Sans frottement, E_m se conserve : droite horizontale. L'objet descend : E_p baisse, E_c monte d'autant. Les deux courbes sont symétriques par rapport à E_m/2.", "piege": "Confondre les courbes : celle qui monte est E_c, l'objet accélère en tombant.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "energie-t08", "chapitre": "energie", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Un objet est lâché sans vitesse de la hauteur h = 20 m, sans frottement. Sa vitesse au sol s'obtient par :", "options": ["conservation de E_m : ½·m·v = m·g·h, donc v = 2·g·h = 3,9 × 10² m·s⁻¹", "conservation de E_m : ½·m·v² = m·g·h, donc v = √(2·g·h) = 20 m·s⁻¹", "conservation de E_m : ½·m·v² = ½·m·g·h, donc v = √(g·h) = 14 m·s⁻¹", "conservation de E_m : m·v = m·g·h, donc v = g·h = 2,0 × 10² m·s⁻¹"], "bonne_reponse": [1], "explication": "E_m(départ) = m·g·h ; E_m(sol) = ½·m·v². Égalité, la masse s'élimine : v = √(2gh). L'énergie évite d'écrire les équations horaires.", "piege": "Oublier le facteur 2 sous la racine : il vient du ½ de l'énergie cinétique.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  fluides: [
    {
      "ref": "flu-01",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La masse volumique ρ d'un fluide s'exprime en :",
      "options": [
        "kg·m⁻³",
        "kg",
        "kg·m⁻²",
        "m³·kg⁻¹"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "ρ = m/V : une masse divisée par un volume. Pour l'eau, ρ = 1,0×10³ kg·m⁻³.",
      "piege": "Confondre avec la densité, qui est un rapport sans unité.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-02",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Le débit volumique s'exprime en :",
      "options": [
        "m²·s⁻¹",
        "m³·s⁻¹",
        "m³",
        "kg·s⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "D<sub>V</sub> = V/Δt : un volume par unité de temps. C'est aussi S × v, en m² × m·s⁻¹.",
      "piege": "Donner des m³ : c'est l'unité d'un volume, pas d'un débit.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-03",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La relation de Bernoulli s'écrit, entre deux points 1 et 2 :",
      "options": [
        "P₁ + ρ·v₁²/2 = P₂ + ρ·v₂²/2 uniquement",
        "P₁ · ρ·v₁²/2 · ρ·g·z₁ = P₂ · ρ·v₂²/2 · ρ·g·z₂",
        "P₁ + ρ·v₁²/2 + ρ·g·z₁ = P₂ + ρ·v₂²/2 + ρ·g·z₂",
        "P₁ + ρ·v₁ + ρ·g·z₁ = P₂ + ρ·v₂ + ρ·g·z₂"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Trois termes de chaque côté : pression, terme cinétique en v² sur 2, terme de pesanteur en z. Elle vaut le long d'une ligne de courant, dans le référentiel terrestre supposé galiléen.",
      "piege": "Oublier le facteur ½ ou le carré de la vitesse dans le terme cinétique.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-04",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Dans la relation de Bernoulli, la pression P s'exprime en :",
      "options": [
        "newtons",
        "bars",
        "newtons par mètre",
        "pascals"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Chaque terme est homogène à une pression : ρ en kg·m⁻³, v en m·s⁻¹, z en m, P en pascals.",
      "piege": "Travailler en bars sans convertir : 1 bar = 1,0×10⁵ Pa.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-05",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "La poussée d'Archimède exercée sur un corps immergé est :",
      "options": [
        "verticale, vers le haut, appliquée au centre de gravité du volume immergé",
        "dirigée vers le point le plus profond",
        "verticale, vers le bas, appliquée au centre de gravité du corps",
        "horizontale, dans le sens de l'écoulement"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Trois caractéristiques attendues : direction verticale, sens vers le haut, point d'application au centre de gravité du <b>volume immergé</b>.",
      "piege": "Placer le point d'application au centre de gravité du corps : ce n'est le même que si le corps est entièrement immergé et homogène.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "flu-06",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "La norme de la poussée d'Archimède vaut :",
      "options": [
        "F<sub>A</sub> = ρ<sub>fluide</sub> × V<sub>corps</sub> / g",
        "F<sub>A</sub> = ρ<sub>fluide</sub> × V<sub>immergé</sub> × g",
        "F<sub>A</sub> = m × g",
        "F<sub>A</sub> = ρ<sub>corps</sub> × V<sub>corps</sub> × g"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La masse volumique est celle du <b>fluide</b>, et le volume celui de la <b>partie immergée</b>.",
      "piege": "Utiliser la masse volumique du corps, ou son volume total alors qu'il n'est que partiellement immergé — le piège numéro un du chapitre.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "flu-07",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Quelle interprétation l'énoncé attend-il souvent en justification ?",
      "options": [
        "la poussée compense toujours le poids",
        "la poussée est proportionnelle à la profondeur",
        "la poussée est égale au poids du volume de fluide déplacé",
        "la poussée dépend de la forme du corps"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est la phrase qui rapporte le point : F<sub>A</sub> = ρ<sub>fluide</sub>·V<sub>immergé</sub>·g est bien le poids du fluide qu'occuperait le volume immergé.",
      "piege": "Affirmer que la poussée compense le poids : ce n'est vrai qu'à l'équilibre.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "flu-08",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "Un objet de volume V = 2,0×10⁻³ m³ est entièrement immergé dans l'eau. Que vaut la poussée d'Archimède ? <i>Données : ρ<sub>eau</sub> = 1,0×10³ kg·m⁻³ · g = 9,81 N·kg⁻¹.</i>",
      "options": [
        "2,0×10⁻³ N",
        "2,0×10³ N",
        "0,20 N",
        "20 N"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "F<sub>A</sub> = 1,0×10³ × 2,0×10⁻³ × 9,81 = 19,6 N, soit environ 20 N.",
      "piege": "Oublier de multiplier par g, ou se tromper de puissance de dix sur le volume.",
      "image": "flu_archimede.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "flu-09",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Un corps immergé est à l'équilibre lorsque :",
      "options": [
        "<span class=\"vec\">F</span><sub>A</sub> + <span class=\"vec\">P</span> = <span class=\"vec\">0</span>",
        "<span class=\"vec\">F</span><sub>A</sub> − <span class=\"vec\">P</span> = <span class=\"vec\">0</span> avec les deux vers le haut",
        "<span class=\"vec\">F</span><sub>A</sub> = <span class=\"vec\">P</span>",
        "sa masse volumique est nulle"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Les deux forces se compensent : leur somme vectorielle est nulle, donc F<sub>A</sub> = P en norme. Le corps est immobile ou en mouvement rectiligne uniforme.",
      "piege": "Écrire <span class=\"vec\">F</span><sub>A</sub> = <span class=\"vec\">P</span> : deux vecteurs de sens opposés ne sont jamais égaux, c'est leur somme qui est nulle.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-10",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Si la norme de la poussée dépasse celle du poids, le corps :",
      "options": ["tourne sur lui-même, la résultante n'étant pas verticale", "monte, d'un mouvement accéléré vers la surface", "descend et coule, d'un mouvement accéléré vers le fond", "reste immobile, les deux forces finissant par s'équilibrer"],
      "bonne_reponse": [
        1
      ],
      "explication": "La somme des forces n'est plus nulle : le mouvement est accéléré vers le haut. C'est le cas du ballon lâché sous l'eau.",
      "piege": "Conclure à l'immobilité dès que les deux forces sont présentes.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-11",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Pour un corps <b>flottant</b> à l'équilibre :",
      "options": ["le poids est nul, la poussée compensant toute la masse", "la poussée est nulle, le corps ne déplaçant aucun fluide", "seule une partie du volume est immergée, et ajuste la poussée au poids", "le volume total est immergé, et la poussée vaut alors le poids"],
      "bonne_reponse": [
        2
      ],
      "explication": "Le corps s'enfonce jusqu'à ce que le volume immergé rende la poussée égale au poids.",
      "piege": "Prendre le volume total dans le calcul de la poussée pour un corps flottant.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-12",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 2",
      "enonce": "Un objet de masse m = 1,5 kg et de volume V = 2,0×10⁻³ m³ est entièrement immergé dans l'eau. Que fait-il ? <i>Données : ρ<sub>eau</sub> = 1,0×10³ kg·m⁻³ · g = 9,81 N·kg⁻¹.</i>",
      "options": [
        "il coule",
        "il reste au fond sans bouger",
        "il reste immobile",
        "il monte"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "P = 1,5 × 9,81 = 14,7 N et F<sub>A</sub> = 1,0×10³ × 2,0×10⁻³ × 9,81 = 19,6 N. La poussée l'emporte : l'objet monte.",
      "piege": "Comparer les masses volumiques sans conclure sur les forces — c'est la conclusion sur les forces qui est attendue.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-13",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Quelles hypothèses simplificatrices permet-on sur le fluide et sur l'écoulement ? <b>Plusieurs réponses.</b>",
      "options": ["l'écoulement est vertical, donc la pesanteur agit seule", "l'écoulement est permanent et non tourbillonnaire", "le fluide est incompressible : sa masse volumique est constante", "le fluide est parfait, c'est-à-dire non visqueux"],
      "bonne_reponse": [
        1,
        2,
        3
      ],
      "explication": "Quatre hypothèses en tout : deux sur le fluide — parfait et incompressible — et deux sur l'écoulement — permanent et non tourbillonnaire.",
      "piege": "N'en citer qu'une ou deux sur les quatre : chacune compte séparément.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-14",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Un fluide est dit <b>parfait</b> lorsque :",
      "options": ["il est non visqueux : on néglige les frottements internes", "sa masse volumique est constante : on néglige la compression", "son écoulement ne dépend pas du temps : le régime est permanent", "il ne contient aucune impureté : on néglige les particules"],
      "bonne_reponse": [
        0
      ],
      "explication": "Parfait porte sur la viscosité ; incompressible porte sur la masse volumique. Ce sont deux hypothèses distinctes.",
      "piege": "Confondre « parfait » et « incompressible ».",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "flu-15",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Pourquoi l'énoncé demande-t-il de citer ces hypothèses ?",
      "options": ["par tradition : l'énoncé les réclame sans qu'elles servent au calcul", "parce que ce sont elles qui autorisent la conservation du débit et Bernoulli", "parce qu'elles donnent la valeur de ρ, indispensable au calcul final", "parce qu'elles imposent le sens de l'écoulement, de A vers B"],
      "bonne_reponse": [
        1
      ],
      "explication": "Les citer, c'est justifier tout le reste de l'exercice : sans elles, ni la conservation du débit ni Bernoulli ne s'appliquent.",
      "piege": "Les réciter sans faire le lien avec les relations qu'elles autorisent.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "flu-16",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Un écoulement est dit <b>permanent</b> lorsque :",
      "options": ["la vitesse est la même partout, en tout point de l'écoulement", "le fluide ne s'arrête jamais, l'écoulement se poursuivant sans fin", "en un point donné, les grandeurs ne dépendent pas du temps", "les lignes de courant sont des droites, parallèles entre elles"],
      "bonne_reponse": [
        2
      ],
      "explication": "Permanent ne veut pas dire uniforme : la vitesse peut varier d'un point à l'autre, mais pas au cours du temps en un point donné.",
      "piege": "Le confondre avec un écoulement de vitesse uniforme.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-17",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Le débit volumique est défini par :",
      "options": [
        "D<sub>V</sub> = S/v",
        "D<sub>V</sub> = Δt/V",
        "D<sub>V</sub> = V × Δt",
        "D<sub>V</sub> = V/Δt"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est le volume écoulé par unité de temps, en m³·s⁻¹.",
      "piege": "Multiplier par la durée au lieu de diviser.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-18",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Remets dans l'ordre la démonstration de D<sub>V</sub> = S × v :",
      "options": [
        "pendant la durée Δt, le fluide parcourt la distance L = v × Δt",
        "on part de la définition : D<sub>V</sub> = V/Δt",
        "on divise par Δt : D<sub>V</sub> = S × v",
        "le volume qui traverse la section S est celui du cylindre de base S et de hauteur L : V = S × v × Δt"
      ],
      "bonne_reponse": [
        1,
        0,
        3,
        2
      ],
      "explication": "Préciser que L est la distance parcourue <b>pendant Δt</b> est ce qui rend la démonstration valable.",
      "piege": "Poser V = S × L sans dire ce que vaut L : la simplification par Δt devient injustifiée.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-19",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Avant tout calcul de débit, quel réflexe s'impose ?",
      "options": [
        "convertir les sections en m² et les durées en secondes",
        "mesurer la pression",
        "vérifier que le fluide est de l'eau",
        "vérifier que la conduite est horizontale"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Les centimètres carrés, les litres et les minutes sont la source d'erreur habituelle. 1 cm² = 1,0×10⁻⁴ m² · 1 L = 1,0×10⁻³ m³.",
      "piege": "Mener le calcul en unités mixtes et se tromper de plusieurs puissances de dix.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-20",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Une conduite de section S = 2,0 cm² est parcourue par un fluide à la vitesse v = 1,5 m·s⁻¹. Que vaut le débit volumique ?",
      "options": [
        "3,0×10⁻² m³·s⁻¹",
        "3,0×10⁻⁴ m³·s⁻¹",
        "3,0 m³·s⁻¹",
        "0,75×10⁻⁴ m³·s⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "S = 2,0 cm² = 2,0×10⁻⁴ m², donc D<sub>V</sub> = 2,0×10⁻⁴ × 1,5 = 3,0×10⁻⁴ m³·s⁻¹, soit 0,30 L·s⁻¹.",
      "piege": "Oublier de convertir les centimètres carrés : le résultat est alors faux d'un facteur 10⁴.",
      "image": "flu_debit.png",
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-21",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre la démonstration de la conservation du débit :",
      "options": [
        "la conservation de la masse entraîne donc celle du volume",
        "pendant Δt, le volume entrant par S₁ égale le volume sortant par S₂ : S₁·v₁·Δt = S₂·v₂·Δt",
        "on simplifie par Δt : S₁·v₁ = S₂·v₂, c'est-à-dire D<sub>V1</sub> = D<sub>V2</sub>",
        "le fluide est incompressible : sa masse volumique est constante"
      ],
      "bonne_reponse": [
        3,
        0,
        1,
        2
      ],
      "explication": "L'incompressibilité est le point de départ : c'est elle qui permet de passer de la masse au volume.",
      "piege": "Affirmer la conservation du volume sans invoquer l'incompressibilité.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-22",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "La conservation du débit volumique s'écrit :",
      "options": [
        "S₁ + v₁ = S₂ + v₂",
        "v₁/S₁ = v₂/S₂",
        "S₁ × v₁ = S₂ × v₂",
        "S₁/v₁ = S₂/v₂"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le produit de la section par la vitesse se conserve tout au long de l'écoulement.",
      "piege": "Écrire une somme, ou un rapport, au lieu du produit.",
      "image": "flu_conservation.png",
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "flu-23",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Quelle conclusion l'énoncé attend-il en fin de démonstration ?",
      "options": ["que la vitesse est constante le long de la canalisation", "que le fluide est parfait, donc sans frottement interne", "que la pression est constante le long de la canalisation", "que la conservation de la masse donne celle du débit volumique"],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est la phrase de conclusion : elle relie le résultat obtenu au principe physique de départ.",
      "piege": "S'arrêter à l'égalité S₁·v₁ = S₂·v₂ sans énoncer ce qu'elle signifie.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "flu-24",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Pour montrer qu'un rétrécissement accélère le fluide, on part de S<sub>A</sub>·v<sub>A</sub> = S<sub>B</sub>·v<sub>B</sub> et l'on isole :",
      "options": [
        "v<sub>B</sub> = (S<sub>A</sub>/S<sub>B</sub>) × v<sub>A</sub>",
        "v<sub>B</sub> = v<sub>A</sub>",
        "v<sub>B</sub> = S<sub>A</sub> × S<sub>B</sub> × v<sub>A</sub>",
        "v<sub>B</sub> = (S<sub>B</sub>/S<sub>A</sub>) × v<sub>A</sub>"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "On divise les deux membres par S<sub>B</sub> : la vitesse en B s'exprime avec le rapport des sections.",
      "piege": "Inverser le rapport des sections, ce qui conduit à la conclusion opposée.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-25",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "On montre qu'un rétrécissement accélère le fluide en isolant v<sub>B</sub> = (S<sub>A</sub>/S<sub>B</sub>) × v<sub>A</sub>. Qu'est-ce qui rapporte le point ?",
      "options": ["donner la valeur numérique de v_B, seule attendue en conclusion", "écrire explicitement que le rapport S_A/S_B est supérieur à 1", "préciser que l'écoulement est vertical, donc soumis à la pesanteur", "citer la relation de Bernoulli, qui relie vitesse et pression"],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est cette comparaison à 1 qui transforme l'égalité en inégalité, et permet de conclure v<sub>B</sub> > v<sub>A</sub>.",
      "piege": "Conclure que le fluide accélère sans avoir comparé le rapport des sections à 1.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-26",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 6",
      "enonce": "Une conduite passe d'une section S<sub>A</sub> = 6,0 cm² à une section S<sub>B</sub> = 2,0 cm². La vitesse en A vaut v<sub>A</sub> = 0,50 m·s⁻¹. Que vaut v<sub>B</sub> ?",
      "options": [
        "0,50 m·s⁻¹",
        "6,0 m·s⁻¹",
        "1,5 m·s⁻¹",
        "0,17 m·s⁻¹"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "v<sub>B</sub> = (6,0/2,0) × 0,50 = 1,5 m·s⁻¹. Les sections apparaissant en rapport, il est inutile de les convertir.",
      "piege": "Inverser le rapport et trouver une vitesse plus faible dans le rétrécissement.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "flu-27",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Remets dans l'ordre la démonstration de l'effet Venturi :",
      "options": [
        "la canalisation étant horizontale, z<sub>A</sub> = z<sub>B</sub> : les termes de pesanteur se simplifient",
        "or v<sub>B</sub> > v<sub>A</sub> au rétrécissement : la parenthèse est négative",
        "on isole : P<sub>B</sub> = P<sub>A</sub> + ρ·(v<sub>A</sub>² − v<sub>B</sub>²)/2",
        "donc P<sub>B</sub> &lt; P<sub>A</sub> : la pression diminue",
        "on applique la relation de Bernoulli sur la ligne de courant AB"
      ],
      "bonne_reponse": [
        4,
        0,
        2,
        1,
        3
      ],
      "explication": "La simplification des termes de pesanteur est l'étape qui est notée : elle suppose que la conduite est horizontale, ce qu'il faut dire.",
      "piege": "Oublier de justifier la simplification, ou inverser l'inégalité finale.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-28",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Pourquoi les termes de pesanteur se simplifient-ils ?",
      "options": ["parce que g est constante, donc le terme ρ·g·z l'est aussi", "parce que le fluide est parfait, donc sans énergie de pesanteur", "parce que la pression est la même, donc les termes s'annulent", "parce que la canalisation est horizontale, donc z_A = z_B"],
      "bonne_reponse": [
        3
      ],
      "explication": "ρ·g·z<sub>A</sub> = ρ·g·z<sub>B</sub> : les deux termes sont égaux et disparaissent de l'égalité. C'est une hypothèse à énoncer, pas une évidence.",
      "piege": "Simplifier sans dire pourquoi : sur une conduite inclinée, la démonstration change.",
      "image": "flu_venturi.png",
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "flu-29",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "L'effet Venturi énonce qu'au rétrécissement d'une conduite horizontale :",
      "options": [
        "la vitesse augmente et la pression diminue",
        "la vitesse et la pression augmentent toutes deux",
        "la vitesse diminue et la pression augmente",
        "rien ne change"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "La conservation du débit impose l'accélération, et la relation de Bernoulli traduit cette accélération par une chute de pression.",
      "piege": "Croire que la pression augmente là où le fluide va plus vite.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-30",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Dans une conduite horizontale, v<sub>A</sub> = 0,50 m·s⁻¹ et v<sub>B</sub> = 1,5 m·s⁻¹. De combien la pression varie-t-elle entre A et B ? <i>Donnée : ρ = 1,0×10³ kg·m⁻³.</i>",
      "options": [
        "elle ne varie pas",
        "elle diminue de 1,0×10³ Pa",
        "elle diminue de 5,0×10² Pa",
        "elle augmente de 1,0×10³ Pa"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "P<sub>B</sub> − P<sub>A</sub> = ρ·(v<sub>A</sub>² − v<sub>B</sub>²)/2 = 1,0×10³ × (0,25 − 2,25)/2 = −1,0×10³ Pa : la pression chute de 1,0×10³ Pa.",
      "piege": "Oublier le facteur ½, ou se tromper de signe et conclure à une augmentation.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-31",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "L'énoncé demande « le système est-il à l'équilibre ? ». Que doit contenir la réponse ?",
      "options": ["la valeur du volume immergé, dont dépend la poussée d'Archimède", "une comparaison des masses volumiques, celle du corps et du fluide", "une comparaison des deux forces, et la conclusion sur leur somme vectorielle", "la valeur de la poussée seulement, le poids étant connu d'avance"],
      "bonne_reponse": [
        2
      ],
      "explication": "On compare la poussée et le poids, puis on conclut : somme nulle, donc équilibre — ou somme non nulle, donc mouvement accéléré.",
      "piege": "Comparer des masses volumiques sans conclure sur les forces — le piège explicite de cette formulation.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "flu-32",
      "chapitre": "mecanique-des-fluides",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelles sont les deux relations qui structurent tout le chapitre ?",
      "options": [
        "la relation de Bernoulli et la loi de Newton",
        "la conservation de la masse et la loi des gaz parfaits",
        "la poussée d'Archimède et la loi d'Ohm",
        "la conservation du débit et la relation de Bernoulli"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "S₁·v₁ = S₂·v₂ donne la vitesse, Bernoulli donne la pression. Les deux hypothèses de la QT 3 sont ce qui les autorise.",
      "piege": "Chercher une troisième relation : tout le reste en découle.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "fluides-t01", "chapitre": "fluides", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "La poussée d'Archimède exercée par un fluide sur un corps immergé est :", "options": ["verticale, vers le haut, de valeur ρ_fluide·V_immergé·g", "verticale, vers le haut, de valeur m_corps·g", "horizontale, de valeur ρ_fluide·V·g", "verticale, vers le bas, de valeur ρ_corps·V·g"], "bonne_reponse": [0], "explication": "Elle est égale au poids du fluide DÉPLACÉ : Π = ρ_fluide·V_immergé·g, dirigée vers le haut. C'est la masse volumique du fluide qui compte, pas celle du corps.", "piege": "Employer la masse volumique du corps : c'est le fluide déplacé qui pousse.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "fluides-t02", "chapitre": "fluides", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un ballon de volume V = 2,0 m³, de masse totale 1,5 kg, est plongé dans l'air (ρ = 1,2 kg·m⁻³). Il est :", "options": ["en descente : le poids l'emporte", "en ascension : Π = 1,2 × 2,0 × 9,8 = 24 N est supérieure au poids 15 N", "à l'équilibre : les deux forces se compensent", "immobile : la poussée ne s'exerce pas dans l'air"], "bonne_reponse": [1], "explication": "On compare la poussée d'Archimède au poids. Π = 24 N > P = 15 N : la résultante est vers le haut, le ballon monte.", "piege": "Croire que la poussée d'Archimède n'existe que dans l'eau : elle s'exerce dans tout fluide, l'air compris.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "fluides-t03", "chapitre": "fluides", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Les relations de conservation du débit et de Bernoulli supposent un écoulement :", "options": ["turbulent, avec frottements", "d'un fluide incompressible, en régime permanent, sans frottement", "d'un gaz uniquement", "d'un fluide compressible, en régime variable"], "bonne_reponse": [1], "explication": "Fluide incompressible (masse volumique constante), régime permanent (rien ne dépend du temps en un point), écoulement parfait (pas de viscosité). L'eau les vérifie bien, l'air aussi à faible vitesse.", "piege": "Oublier une hypothèse : sans « incompressible », le débit volumique ne se conserve plus.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "fluides-t04", "chapitre": "fluides", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Pendant Δt, le fluide qui traverse une section S avance de la distance v·Δt. Le volume écoulé est S·v·Δt. Le débit volumique vaut donc :", "options": ["D_V = volume × Δt = S·v·Δt², produit du volume par la durée", "D_V = volume/Δt = S·v·Δt/Δt = S·v", "D_V = S/v, quotient de la section par la vitesse", "D_V = v/S, quotient de la vitesse par la section"], "bonne_reponse": [1], "explication": "Le volume qui traverse S pendant Δt est un cylindre de base S et de longueur v·Δt. Divisé par Δt, il reste S·v, en m³·s⁻¹.", "piege": "Garder Δt dans l'expression : le débit est un volume PAR SECONDE, on a divisé par Δt.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "fluides-t05", "chapitre": "fluides", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Dans une canalisation sans fuite, en régime permanent et fluide incompressible, le débit volumique en deux sections S₁ et S₂ vérifie :", "options": ["S₁·v₁ + S₂·v₂ = constante", "S₁·v₁ = S₂·v₂", "v₁ = v₂", "S₁/v₁ = S₂/v₂"], "bonne_reponse": [1], "explication": "Ce qui entre pendant Δt ressort pendant Δt : le volume se conserve, donc D_V est le même partout. S₁·v₁ = S₂·v₂.", "piege": "Croire que la vitesse se conserve : c'est le DÉBIT qui est constant, la vitesse s'adapte à la section.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "fluides-t06", "chapitre": "fluides", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Un tuyau de section S₁ = 4,0 cm² se rétrécit à S₂ = 1,0 cm². L'eau y entre à v₁ = 0,50 m·s⁻¹. Dans le rétrécissement :", "options": ["v₂ = S₂·v₁/S₁ = 1,0 × 0,50/4,0 = 0,125 m·s⁻¹", "v₂ = S₁·v₁/S₂ = 4,0 × 0,50/1,0 = 2,0 m·s⁻¹", "v₂ = S₁/S₂ = 4,0/1,0 = 4,0 m·s⁻¹", "v₂ = v₁ = 0,50 m·s⁻¹, le débit massique se conservant"], "bonne_reponse": [1], "explication": "Conservation du débit : S₁·v₁ = S₂·v₂, donc v₂ = v₁·S₁/S₂. Une section divisée par 4 multiplie la vitesse par 4.", "piege": "Inverser le rapport des sections : la vitesse augmente là où le tuyau se resserre.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "fluides-t07", "chapitre": "fluides", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "D'après la relation de Bernoulli, ½·ρ·v² + ρ·g·z + P = constante. Dans un rétrécissement horizontal, la vitesse augmente. On en déduit :", "options": ["la pression reste constante", "la pression diminue : c'est l'effet Venturi", "la pression augmente, le fluide étant comprimé", "l'altitude augmente"], "bonne_reponse": [1], "explication": "Sur une même horizontale, z est constant. Si ½ρv² augmente, P doit diminuer pour que la somme reste constante. Plus vite = moins de pression.", "piege": "Raisonner « comprimé donc plus de pression » : dans un fluide en écoulement, c'est l'inverse qui se produit.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  rc: [
    {
      "ref": "rc-01",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Un condensateur est formé de :",
      "options": [
        "deux armatures conductrices séparées par un isolant",
        "deux bobines en série",
        "deux résistances en parallèle",
        "un conducteur ohmique et un générateur"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "L'isolant s'appelle le diélectrique. Chargé, le condensateur porte des charges opposées et stocke de l'énergie électrique.",
      "piege": "Le confondre avec une bobine, qui stocke elle aussi de l'énergie mais sous forme magnétique.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-02",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La relation charge-tension d'un condensateur s'écrit :",
      "options": [
        "q = C + u<sub>C</sub>",
        "q = C × u<sub>C</sub>",
        "q = C / u<sub>C</sub>",
        "q = u<sub>C</sub> / C"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "q en coulombs, C en farads, u<sub>C</sub> en volts. C'est la relation de base du chapitre.",
      "piege": "Inverser le produit : la capacité multiplie la tension, elle ne la divise pas.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-03",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La capacité d'un condensateur plan vaut C = ε·S/e. Si on <b>augmente</b> la distance e entre les armatures :",
      "options": [
        "C ne change pas",
        "C augmente",
        "C diminue",
        "C devient nulle"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "e est au dénominateur : plus les armatures sont éloignées, plus la capacité est faible. À l'inverse, une grande surface S donne un grand C.",
      "piege": "Raisonner par proportionnalité directe sans regarder où se trouve e dans la formule.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-04",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La capacité s'exprime en :",
      "options": [
        "ohms",
        "volts",
        "coulombs",
        "farads"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C en farads (F), q en coulombs, u en volts. En pratique on manipule des μF ou des nF.",
      "piege": "Confondre l'unité de la capacité et celle de la charge.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-05",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Le comportement du condensateur s'écrit :",
      "options": [
        "i = C × du_C/dt",
        "i = du_C/dt",
        "i = C × u<sub>C</sub>",
        "i = u<sub>C</sub> / C"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "i = dq/dt avec q = C·u<sub>C</sub>, et C étant constante elle sort de la dérivée : i = C·du_C/dt.",
      "piege": "Sortir u<sub>C</sub> de la dérivée au lieu de C : c'est la capacité qui est constante, pas la tension.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "rc-06",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Remets dans l'ordre l'établissement de la relation i = C·du_C/dt :",
      "options": [
        "on injecte la relation charge-tension : i = d(C·u<sub>C</sub>)/dt",
        "on part de la définition de l'intensité : i = dq/dt",
        "i = C · du_C/dt",
        "la capacité C étant constante, elle sort de la dérivée"
      ],
      "bonne_reponse": [
        1,
        0,
        3,
        2
      ],
      "explication": "C'est la relation clé du chapitre : elle transforme la loi des mailles en équation différentielle.",
      "piege": "Sauter la justification « C est constante » — c'est elle qui autorise à la sortir.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-07",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Pourquoi cette relation est-elle la clé du chapitre ?",
      "options": ["parce qu'elle donne la valeur de τ sans passer par le graphe", "parce qu'elle transforme la loi des mailles en équation différentielle", "parce qu'elle permet de mesurer C sans connaître la tension E", "parce qu'elle donne la charge du condensateur à chaque instant"],
      "bonne_reponse": [
        1
      ],
      "explication": "Sans elle, la loi des mailles reste une équation entre deux tensions : c'est i = C·du_C/dt qui fait apparaître la dérivée.",
      "piege": "Y voir une simple définition sans comprendre son rôle dans la mise en équation.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-08",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Remets dans l'ordre l'établissement de l'équation différentielle de la <b>charge</b> :",
      "options": [
        "on divise par RC : du_C/dt + u<sub>C</sub>/(RC) = E/(RC)",
        "on pose τ = R·C : du_C/dt + u<sub>C</sub>/τ = E/τ",
        "loi des mailles : u<sub>C</sub> + u<sub>R</sub> = E",
        "loi d'Ohm : u<sub>C</sub> + R·i = E",
        "comportement du condensateur : u<sub>C</sub> + R·C·du_C/dt = E"
      ],
      "bonne_reponse": [
        2,
        3,
        4,
        0,
        1
      ],
      "explication": "Trois lois, puis la mise sous forme canonique : c'est cette dernière forme que l'énoncé demande.",
      "piege": "S'arrêter avant la forme canonique : le barème l'exige explicitement.",
      "image": "rc_montage_charge.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-09",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La forme canonique de l'équation différentielle de charge est :",
      "options": [
        "du_C/dt + u<sub>C</sub>·τ = E·τ",
        "u<sub>C</sub> + du_C/dt = E",
        "du_C/dt + u<sub>C</sub>/τ = E/τ",
        "du_C/dt = E/τ"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Coefficient 1 devant la dérivée, le terme en u<sub>C</sub> divisé par τ, et le second membre E/τ.",
      "piege": "Multiplier par τ au lieu de diviser, ou oublier le second membre.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-10",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Dans la loi des mailles, que vaut u<sub>R</sub> ?",
      "options": [
        "u<sub>R</sub> = R × C",
        "u<sub>R</sub> = i/R",
        "u<sub>R</sub> = R/i",
        "u<sub>R</sub> = R × i"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Loi d'Ohm appliquée au conducteur ohmique. On remplace ensuite i par C·du_C/dt.",
      "piege": "Inverser la loi d'Ohm et casser toute la suite de la mise en équation.",
      "image": "rc_montage_charge.png",
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "rc-11",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Pour montrer qu'une expression est solution de l'équation différentielle, il faut :",
      "options": ["la dériver, la reporter à gauche et retrouver le second membre", "vérifier qu'elle vaut 0 à t = 0, ce qui suffit à la valider", "tracer sa courbe et vérifier qu'elle tend vers E à l'infini", "calculer τ, puis vérifier qu'il vaut bien le produit R·C"],
      "bonne_reponse": [
        0
      ],
      "explication": "On injecte l'expression et sa dérivée, puis on montre qu'on retombe sur E/τ.",
      "piege": "Vérifier seulement la condition initiale : elle est nécessaire mais ne démontre rien.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-12",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Quelle est la dérivée de u<sub>C</sub>(t) = E(1 − e^(−t/τ)) ?",
      "options": [
        "−(E/τ)·e^(−t/τ)",
        "(E/τ)·e^(−t/τ)",
        "−E/τ",
        "E·e^(−t/τ)"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La constante E disparaît, et la dérivée de −E·e^(−t/τ) vaut +(E/τ)·e^(−t/τ).",
      "piege": "Se tromper de signe : le double signe négatif donne une dérivée positive, la tension croît.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "rc-13",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "L'énoncé propose u<sub>C</sub>(t) = A·e^(−t/τ) + E. Remets dans l'ordre la démonstration de τ = RC :",
      "options": [
        "1/(RC) − 1/τ = 0, donc τ = R·C",
        "l'égalité devant être vraie pour tout t, et l'exponentielle ne s'annulant jamais, la parenthèse est nulle",
        "on regroupe et on factorise : A·e^(−t/τ) × (1/(RC) − 1/τ) + E/(RC)",
        "on reporte l'expression et sa dérivée dans le membre de gauche",
        "on dérive : du_C/dt = −(A/τ)·e^(−t/τ)"
      ],
      "bonne_reponse": [
        4,
        3,
        2,
        1,
        0
      ],
      "explication": "L'avant-dernière étape est celle qui rapporte le point : il faut dire que l'égalité vaut <b>pour tout t</b> et que l'exponentielle ne s'annule jamais.",
      "piege": "Conclure τ = RC sans justifier pourquoi la parenthèse doit être nulle.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-14",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Pourquoi la parenthèse (1/(RC) − 1/τ) doit-elle être nulle ?",
      "options": ["parce que E est constant, et qu'un terme constant ne peut varier", "parce que A est nul, ce qui annule tout le premier membre", "parce que l'égalité vaut pour tout t et que e^(−t/τ) ne s'annule pas", "parce que t tend vers l'infini, et que l'exponentielle s'annule"],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est la phrase qui rapporte le point : sans elle, la condition τ = RC n'est pas démontrée.",
      "piege": "Passer directement à la conclusion sans énoncer cette justification.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "rc-15",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "L'énoncé donne u<sub>C</sub>(t) = A·e^(−t/τ) + B. Combien de conditions faut-il utiliser ?",
      "options": [
        "trois",
        "une seule, à t = 0",
        "deux : à t = 0 et en régime permanent",
        "aucune, A et B se déduisent de τ"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Deux inconnues, donc deux conditions : u<sub>C</sub>(0) = 0 et u<sub>C</sub>(∞) = E.",
      "piege": "N'utiliser qu'une seule condition — le piège explicitement listé pour cette QT.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-16",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Avec u<sub>C</sub>(t) = A·e^(−t/τ) + B, que valent A et B lors de la charge ?",
      "options": [
        "A = −E et B = E",
        "A = 0 et B = E",
        "A = E et B = −E",
        "A = E et B = 0"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "À t = 0 : A + B = 0. En régime permanent : B = E. Donc A = −E, et u<sub>C</sub>(t) = E(1 − e^(−t/τ)).",
      "piege": "Intervertir A et B : on obtiendrait une tension qui décroît alors qu'elle doit croître.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-17",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "À l'instant t = 0, lors de la charge, la tension aux bornes du condensateur vaut :",
      "options": ["0,63·E, valeur atteinte au bout d'une constante de temps", "0, le condensateur étant initialement déchargé", "E/2, la charge se partageant entre R et le condensateur", "E, la tension du générateur s'appliquant aussitôt"],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est la première condition aux limites : la charge commence à partir d'un condensateur vide.",
      "piege": "Confondre avec la valeur en régime permanent, où u<sub>C</sub> tend vers E.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-18",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Lors de la charge, la tension aux bornes du conducteur ohmique s'écrit :",
      "options": [
        "u<sub>R</sub>(t) = 0",
        "u<sub>R</sub>(t) = E(1 − e^(−t/τ))",
        "u<sub>R</sub>(t) = E·e^(−t/τ)",
        "u<sub>R</sub>(t) = E"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "u<sub>R</sub> = R·C·du_C/dt = τ·du_C/dt. En dérivant u<sub>C</sub>, on obtient E·e^(−t/τ) : u<sub>R</sub> <b>décroît</b> pendant que u<sub>C</sub> croît.",
      "piege": "Oublier que u<sub>R</sub> décroît alors que u<sub>C</sub> croît — les deux courbes sont opposées.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-19",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Comment vérifier rapidement l'expression de u<sub>R</sub> ?",
      "options": ["en mesurant l'intensité, qui doit valoir E/R à tout instant", "en calculant τ, qui doit valoir R·C à tout instant", "en dérivant deux fois, la dérivée seconde devant s'annuler", "en vérifiant que u_C + u_R = E à tout instant"],
      "bonne_reponse": [
        3
      ],
      "explication": "À t = 0 : u<sub>R</sub> = E et u<sub>C</sub> = 0. En régime permanent : u<sub>R</sub> → 0 et u<sub>C</sub> → E. La loi des mailles est vérifiée partout.",
      "piege": "Rendre l'expression sans ce contrôle, alors qu'il prend deux lignes.",
      "image": "rc_charge.png",
      "tags": [
        "controle"
      ],
      "actif": true
    },
    {
      "ref": "rc-20",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "La courbe de u<sub>R</sub> donne directement l'allure de :",
      "options": [
        "l'intensité i",
        "la charge q",
        "la constante de temps τ",
        "la capacité C"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "u<sub>R</sub> = R·i : les deux grandeurs sont proportionnelles. L'intensité est maximale à t = 0 puis décroît vers zéro.",
      "piege": "Chercher l'allure de l'intensité sur la courbe de u<sub>C</sub>, qui est croissante.",
      "image": "rc_charge.png",
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "rc-21",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Lors de la <b>décharge</b>, la loi des mailles s'écrit :",
      "options": [
        "u<sub>C</sub> + u<sub>R</sub> = E",
        "u<sub>C</sub> + u<sub>R</sub> = 0",
        "u<sub>C</sub> = E",
        "u<sub>C</sub> − u<sub>R</sub> = E"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Le générateur n'est plus dans le circuit : le second membre est nul, et l'équation devient du_C/dt + u<sub>C</sub>/τ = 0.",
      "piege": "Garder le second membre E/τ de la charge — le piège explicite de cette QT.",
      "image": "rc_montage_decharge.png",
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-22",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "La solution de l'équation de décharge s'écrit :",
      "options": [
        "u<sub>C</sub>(t) = E",
        "u<sub>C</sub>(t) = E(1 − e^(−t/τ))",
        "u<sub>C</sub>(t) = E·e^(−t/τ)",
        "u<sub>C</sub>(t) = E·e^(t/τ)"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "À t = 0 le condensateur est chargé : u<sub>C</sub>(0) = E, donc la constante vaut E.",
      "piege": "Reprendre la solution de la charge : le contraste est en (1 − e^(−t/τ)) contre e^(−t/τ).",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "rc-23",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Quelle condition initiale utilise-t-on pour la décharge ?",
      "options": ["u_C(0) = 0, le condensateur étant vide au départ", "u_C(∞) = E, le condensateur se chargeant complètement", "i(0) = 0, aucun courant ne circulant à l'instant initial", "u_C(0) = E, le condensateur étant chargé au départ"],
      "bonne_reponse": [
        3
      ],
      "explication": "La décharge part d'un condensateur plein : c'est l'inverse exact de la charge.",
      "piege": "Reprendre u<sub>C</sub>(0) = 0 par automatisme et trouver une solution identiquement nulle.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-24",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Pour lire τ sur une courbe de <b>charge</b>, on reporte :",
      "options": [
        "0,63 E",
        "0,50 E",
        "0,99 E",
        "0,37 E"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "u<sub>C</sub>(τ) = E(1 − e⁻¹) = 0,63 E. On lit ensuite l'abscisse correspondante.",
      "piege": "Utiliser 0,63 E sur une courbe de décharge : c'est 0,37 E qu'il faut. Contrôle : 0,63 + 0,37 = 1.",
      "image": "rc_courbe_charge.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-25",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Pour lire τ sur une courbe de <b>décharge</b>, on reporte :",
      "options": [
        "0,01 E",
        "0,37 E",
        "0,50 E",
        "0,63 E"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "u<sub>C</sub>(τ) = E·e⁻¹ = 0,37 E : c'est la valeur à reporter sur l'axe des ordonnées.",
      "piege": "Confondre les deux valeurs — l'erreur la plus fréquente de cette QT.",
      "image": "rc_courbe_decharge.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-26",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "La seconde méthode de lecture de τ consiste à :",
      "options": ["diviser la durée totale par 5, le régime étant atteint à 5τ", "mesurer la pente moyenne de la courbe entre 0 et sa fin", "tracer la tangente à l'origine et lire son intersection avec l'asymptote", "mesurer la hauteur totale de la courbe, qui vaut E·τ"],
      "bonne_reponse": [
        2
      ],
      "explication": "La tangente à t = 0 coupe l'asymptote du régime permanent à l'abscisse τ.",
      "piege": "Tracer la tangente en un point quelconque : c'est bien à l'origine qu'elle se trace.",
      "image": "rc_courbe_charge.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-27",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "La constante de temps du circuit vaut :",
      "options": [
        "τ = R/C",
        "τ = C/R",
        "τ = 1/(R·C)",
        "τ = R × C"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "τ = R × C, et c'est bien une durée : l'analyse dimensionnelle le confirme.",
      "piege": "Inverser le produit et obtenir une grandeur qui n'est pas une durée.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "rc-28",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre l'analyse dimensionnelle de τ :",
      "options": [
        "[τ] = [R] × [C]",
        "or R = U/I et C = q/U = I·Δt/U",
        "les U et les I se simplifient : [τ] = [Δt] = s",
        "[τ] = (U/I) × (I·Δt/U)"
      ],
      "bonne_reponse": [
        0,
        1,
        3,
        2
      ],
      "explication": "La constante de temps est bien une durée, exprimée en secondes : c'est ce que la question demande de vérifier.",
      "piege": "Affirmer que τ est en secondes sans le démontrer.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-29",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "On lit τ = 22 ms sur le graphe et le circuit comporte C = 4,7 μF. Que vaut R ?",
      "options": [
        "4,7 kΩ",
        "4,7 Ω",
        "1,0×10⁻⁷ Ω",
        "103 Ω"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "R = τ/C = 22×10⁻³ / 4,7×10⁻⁶ = 4,7×10³ Ω, soit 4,7 kΩ.",
      "piege": "Oublier de convertir les préfixes ms et μF — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "rc-30",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Pour vérifier expérimentalement C = ε·S/e, il faut montrer que :",
      "options": [
        "C ne dépend que de ε",
        "C = f(S) est linéaire et C = f(1/e) l'est aussi",
        "C = f(S) et C = f(e) sont linéaires",
        "C = f(S) est affine"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C est proportionnelle à S, et inversement proportionnelle à e : c'est donc C = f(1/e) qui doit être linéaire.",
      "piege": "Tracer C = f(e) et s'étonner de ne pas obtenir une droite.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-31",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "On considère que le régime permanent est atteint au bout de :",
      "options": [
        "10τ",
        "τ",
        "5τ",
        "3τ"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Au bout de 5τ, la tension a atteint 99 % de sa valeur finale : elle n'évolue pratiquement plus.",
      "piege": "Répondre τ, qui correspond seulement à 63 % de la charge.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-32",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Lors de la charge, que vaut u<sub>C</sub> au bout de 5τ ?",
      "options": [
        "0,63 E",
        "0,50 E",
        "E exactement",
        "0,99 E"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "u<sub>C</sub>(5τ) = E(1 − e⁻⁵) = 0,99 E : le condensateur est chargé à 99 %.",
      "piege": "Annoncer E exactement : une exponentielle n'atteint jamais sa limite.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-33",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Que doit contenir la réponse à « quand le régime permanent est-il atteint ? »",
      "options": ["5τ, accompagné du calcul de u_C(5τ) et de la conclusion", "la seule valeur de τ, le régime étant atteint à cet instant", "le tracé de la tangente à l'origine, qui donne la durée", "la seule valeur 5τ, sans qu'un calcul soit nécessaire"],
      "bonne_reponse": [
        0
      ],
      "explication": "Le barème attend le calcul à l'appui : annoncer 5τ sans justifier ne rapporte pas le point.",
      "piege": "Se contenter d'annoncer 5τ — le piège explicitement listé.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "rc-34",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Un élève écrit i = u<sub>C</sub> × dC/dt. Où est l'erreur ?",
      "options": [
        "il fallait diviser par R",
        "il fallait dériver deux fois",
        "c'est C qui est constante : i = C·du_C/dt",
        "il n'y a pas d'erreur"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "La capacité ne varie pas au cours du temps : c'est la tension que l'on dérive.",
      "piege": "Dériver la mauvaise grandeur dans le produit q = C·u<sub>C</sub>.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {
      "ref": "rc-35",
      "chapitre": "le-circuit-rc",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "typologie",
      "enonce": "Quelle est la seule relation dont découle toute la partie calculatoire du chapitre ?",
      "options": ["q = C·u_C, qui relie la charge à la tension", "u = R·i, qui relie la tension à l'intensité", "i = C·du_C/dt, qui relie l'intensité à la tension", "τ = R·C, qui relie la durée aux deux composants"],
      "bonne_reponse": [
        2
      ],
      "explication": "Injectée dans la loi des mailles, elle donne l'équation différentielle — le reste n'est que lecture graphique.",
      "piege": "Citer la loi d'Ohm, qui est générale et ne concerne pas le condensateur.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "rc-t01", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Pour un condensateur de capacité C, la charge q de son armature, la tension u_C et l'intensité i vérifient :", "options": ["q = C/u_C et i = C·u_C, l'intensité suivant la tension", "q = u_C/C et i = q/t, l'intensité étant la charge par le temps", "q = C·u_C et i = dq/dt = C·du_C/dt", "q = C·u_C et i = dq/dt = u_C/(R·C), par la loi d'Ohm"], "bonne_reponse": [2], "explication": "q = C·u_C définit la capacité. L'intensité est le débit de charge : i = dq/dt, donc i = C·du_C/dt. Une tension constante donne un courant nul.", "piege": "Écrire i = q/t : la charge varie, l'intensité est une dérivée, pas un rapport.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t02", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un condensateur C se charge à travers R sous une tension E. La loi des mailles E = u_R + u_C, avec u_R = R·i = R·C·du_C/dt, donne :", "options": ["du_C/dt + u_C = E", "R·C·u_C = E", "R·C·du_C/dt + u_C = E", "du_C/dt = E/R"], "bonne_reponse": [2], "explication": "On remplace u_R par RC·du_C/dt dans la loi des mailles. On pose τ = RC : τ·du_C/dt + u_C = E. Équation du premier ordre à coefficient constant.", "piege": "Oublier le facteur RC devant la dérivée : il vient de u_R = R·i et i = C·du_C/dt.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t03", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Pour vérifier que u_C(t) = A·e^(−t/τ) + B est solution de τ·du_C/dt + u_C = E, on :", "options": ["pose A = E, puis on vérifie que l'équation est satisfaite", "dérive : du_C/dt = −(A/τ)·e^(−t/τ), on remplace, il vient B = E", "intègre l'équation entre 0 et t, ce qui redonne l'expression", "remplace t par 0 : u_C(0) = A + B, ce qui donne A = −E"], "bonne_reponse": [1], "explication": "On dérive, on injecte dans l'équation. Les termes en exponentielle s'annulent, il reste B = E : l'expression est solution à condition que B = E.", "piege": "Croire que vérifier suffit : la vérification IMPOSE aussi une condition sur B.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t04", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Avec u_C(t) = A·e^(−t/τ) + E et un condensateur initialement déchargé, u_C(0) = 0 donne :", "options": ["A = E, et u_C(t) = E(1 + e^(−t/τ))", "A = E/τ", "A = 0", "A + E = 0, donc A = −E, et u_C(t) = E(1 − e^(−t/τ))"], "bonne_reponse": [3], "explication": "À t = 0, e⁰ = 1 : u_C(0) = A + E = 0, donc A = −E. La solution est u_C = E(1 − e^(−t/τ)) : elle part de 0 et tend vers E.", "piege": "Oublier la condition initiale : sans elle, A reste indéterminée.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t05", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Pendant la charge, avec u_C = E(1 − e^(−t/τ)), la tension aux bornes de la résistance vaut :", "options": ["u_R = E − u_C = E·e^(−t/τ) : elle part de E et tend vers 0", "u_R = E·(1 − e^(−t/τ)) : elle part de 0 et tend vers E", "u_R = u_C = E·(1 − e^(−t/τ)) : les deux sont égales", "u_R = E, constante : la résistance supporte toute la tension"], "bonne_reponse": [0], "explication": "Loi des mailles : u_R = E − u_C. À t = 0, tout est sur R (le condensateur est déchargé) ; en régime permanent, u_R = 0, plus de courant.", "piege": "Croire que u_R = u_C : elles sont complémentaires, leur somme vaut E.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t06", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Un condensateur chargé sous E se décharge dans R. La loi des mailles u_R + u_C = 0 donne :", "options": ["R·C·du_C/dt + u_C = E, de solution u_C = E(1 − e^(−t/τ))", "R·C·du_C/dt − u_C = E, de solution u_C = E(e^(t/τ) − 1)", "du_C/dt = 0, de solution u_C = E, constante au cours du temps", "R·C·du_C/dt + u_C = 0, de solution u_C = E·e^(−t/τ)"], "bonne_reponse": [3], "explication": "Plus de générateur : second membre nul. La solution est une exponentielle décroissante, u_C = E·e^(−t/τ), qui part de E et tend vers 0.", "piege": "Garder E au second membre : le générateur n'est plus dans la boucle.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t07", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Sur la courbe de charge u_C = f(t), la constante de temps τ se lit :", "options": ["au point où la courbe change de sens de variation", "à l'abscisse où u_C atteint 63 % de E, ou sous la tangente à l'origine", "à l'abscisse où u_C atteint E, valeur finale de la charge", "à l'abscisse où u_C atteint E/2, moitié de la valeur finale"], "bonne_reponse": [1], "explication": "u_C(τ) = E(1 − e⁻¹) = 0,63·E. Deuxième méthode : la tangente à l'origine coupe l'asymptote en t = τ. En décharge, c'est 37 % de E.", "piege": "Chercher u_C = E : l'exponentielle n'atteint jamais sa limite.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t08", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "On lit τ = 2,0 ms avec R = 1,0 kΩ. La capacité vaut, et l'unité de τ se vérifie par :", "options": ["C = τ·R = 2,0 × 10⁻³ × 1,0 × 10³ = 2,0 F ; τ = R·C est en Ω·F = s", "C = τ/R = 2,0 × 10⁻³ / 1,0 × 10³ = 2,0 × 10⁻⁶ F ; τ = R·C est en Ω·F = s", "C = τ = 2,0 × 10⁻³ F ; la résistance n'intervient pas dans le calcul", "C = R/τ = 1,0 × 10³ / 2,0 × 10⁻³ = 5,0 × 10⁵ F ; τ = R·C est en Ω·F = s"], "bonne_reponse": [1], "explication": "τ = RC, donc C = τ/R, en secondes sur ohms. Analyse dimensionnelle : Ω = V/A, F = C/V = A·s/V ; le produit donne des secondes.", "piege": "Laisser τ en millisecondes ou R en kilo-ohms : tout en unités SI avant de calculer.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "rc-t09", "chapitre": "rc", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "On considère le condensateur chargé lorsque u_C atteint 99 % de E. Cette durée vaut :", "options": ["exactement τ : e^(−1) ≈ 0,37, donc u_C ≈ 0,63·E", "une durée infinie : l'exponentielle ne s'annule jamais tout à fait", "environ 5τ : e^(−5) ≈ 0,007, donc u_C ≈ 0,993·E", "environ 2τ : e^(−2) ≈ 0,14, donc u_C ≈ 0,86·E"], "bonne_reponse": [2], "explication": "À t = 5τ, e⁻⁵ = 0,0067 : la charge est à 99,3 %. C'est le critère usuel de fin du régime transitoire. À 3τ, on n'est qu'à 95 %.", "piege": "Confondre τ et la durée totale : τ n'est que le temps caractéristique, la charge dure environ cinq fois plus.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  synthese: [
    {
      "ref": "syn-01",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Le rendement d'une synthèse s'écrit :",
      "options": [
        "η = n<sub>f</sub> / n<sub>max</sub>",
        "η = n<sub>max</sub> / n<sub>f</sub>",
        "η = n<sub>f</sub> × n<sub>max</sub>",
        "η = n<sub>max</sub> − n<sub>f</sub>"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Quantité réellement obtenue sur quantité maximale attendue : sans unité, toujours inférieur ou égal à 1.",
      "piege": "Inverser le quotient et obtenir un rendement supérieur à 1.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "syn-02",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Comment améliorer le rendement d'une synthèse ? <b>Plusieurs réponses.</b>",
      "options": ["ajouter un catalyseur, qui déplace l'équilibre vers les produits", "augmenter la température, qui déplace l'équilibre vers les produits", "éliminer un produit au fur et à mesure de sa formation", "introduire l'un des réactifs en large excès dans le mélange"],
      "bonne_reponse": [
        2,
        3
      ],
      "explication": "Deux leviers seulement : l'excès déplace la transformation, l'élimination d'un produit empêche le retour.",
      "piege": "Proposer d'augmenter la température : elle agit sur la vitesse, pas sur l'état final.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-03",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Un élève trouve un rendement de 1,3. Que faut-il en conclure ?",
      "options": ["la synthèse est excellente : plus de produit que la théorie n'en prévoit", "le calcul de n_max est faux : un rendement ne dépasse jamais 1", "il faut convertir en pourcentage : le rendement vaut donc 130 %", "la réaction est totale : le rendement dépasse alors l'unité"],
      "bonne_reponse": [
        1
      ],
      "explication": "Le plus souvent, c'est le coefficient stœchiométrique qui a été oublié dans le calcul de n<sub>max</sub>.",
      "piege": "Rendre un rendement supérieur à 1 sans réagir.",
      "image": null,
      "tags": [
        "reperage erreur"
      ],
      "actif": true
    },
    {
      "ref": "syn-04",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Quels sont les rôles du montage à reflux ? <b>Plusieurs réponses.</b>",
      "options": ["identifier le produit formé, par sa température d'ébullition", "purifier le produit, les impuretés restant au fond du ballon", "accélérer la réaction, la température étant un facteur cinétique", "éviter les pertes de matière, les vapeurs se condensant au réfrigérant"],
      "bonne_reponse": [
        2,
        3
      ],
      "explication": "Les deux rôles sont attendus : n'en citer qu'un fait perdre la moitié des points.",
      "piege": "N'en citer qu'un seul — le piège explicitement listé pour cette QT.",
      "image": "syn_reflux.png",
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-05",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Dans un montage à reflux, l'eau du réfrigérant circule :",
      "options": [
        "dans les deux sens",
        "elle ne circule pas",
        "entrée par le bas, sortie par le haut",
        "entrée par le haut, sortie par le bas"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Entrée par le bas pour que le réfrigérant reste toujours plein d'eau.",
      "piege": "Confondre entrée et sortie : le réfrigérant se viderait partiellement.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-06",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "À quoi sert la pierre ponce introduite dans le ballon ?",
      "options": [
        "à absorber l'eau",
        "à catalyser la réaction",
        "à colorer le mélange",
        "à réguler l'ébullition"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Elle évite les à-coups d'ébullition, qui projetteraient le mélange.",
      "piege": "Lui attribuer un rôle chimique : son rôle est uniquement physique.",
      "image": "syn_reflux.png",
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-07",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Remets dans l'ordre les quatre étapes d'une synthèse organique :",
      "options": [
        "transformation chimique",
        "purification",
        "identification",
        "séparation"
      ],
      "bonne_reponse": [
        0,
        3,
        1,
        2
      ],
      "explication": "Reflux ou distillation · filtration ou décantation · recristallisation · CCM, Kofler ou spectre IR.",
      "piege": "Confondre séparation et purification : la première isole, la seconde élimine les impuretés restantes.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-08",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Quelle technique correspond à l'étape de <b>purification</b> ?",
      "options": [
        "la recristallisation",
        "la filtration sous vide",
        "la chromatographie sur couche mince",
        "le montage à reflux"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "La filtration sépare, la recristallisation purifie, la CCM identifie.",
      "piege": "Prendre la filtration pour une purification : elle appartient à l'étape de séparation.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "syn-09",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Le produit obtenu est solide. Quelle technique de séparation utilise-t-on ?",
      "options": [
        "la recristallisation",
        "la filtration sous vide sur Büchner",
        "la décantation en ampoule",
        "la distillation"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "La décantation sert à extraire une espèce d'une phase liquide, la filtration à récupérer un solide.",
      "piege": "Choisir la décantation par réflexe, alors qu'elle suppose deux phases liquides.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-10",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Quelles conditions le solvant d'extraction doit-il vérifier ? <b>Plusieurs réponses.</b>",
      "options": ["il doit être non miscible avec le solvant initial", "il doit être plus dense que l'eau, pour se placer en dessous", "il doit être coloré, pour distinguer les deux phases à l'œil", "l'espèce à extraire doit y être plus soluble que dans le solvant initial"],
      "bonne_reponse": [
        0,
        3
      ],
      "explication": "Les deux conditions sont attendues : sans la non-miscibilité, les phases ne se sépareraient pas.",
      "piege": "Ne citer que la solubilité — le piège explicitement listé.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-11",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Comment savoir quelle phase se trouve en haut de l'ampoule à décanter ?",
      "options": ["on compare les masses volumiques : la moins dense surnage", "on repère la phase colorée : c'est toujours elle qui surnage", "on repère la phase aqueuse : c'est toujours elle qui surnage", "on mesure la température : la plus chaude des deux surnage"],
      "bonne_reponse": [
        0
      ],
      "explication": "Question associée très fréquente : il suffit de comparer les deux masses volumiques données.",
      "piege": "Supposer que la phase organique est toujours au-dessus : cela dépend du solvant.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "syn-12",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Sur une chromatographie sur couche mince, deux taches à la <b>même hauteur</b> signifient :",
      "options": [
        "deux espèces différentes",
        "un mélange",
        "une erreur de dépôt",
        "la même espèce chimique"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est la règle de lecture de base : même hauteur de migration, même espèce.",
      "piege": "Conclure sur la pureté sans regarder le nombre de taches.",
      "image": "syn_ccm.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-13",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Un dépôt qui ne donne qu'<b>une seule</b> tache correspond à :",
      "options": [
        "un corps pur",
        "un mélange de deux espèces",
        "une espèce non identifiable",
        "une erreur d'éluant"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Une seule tache = corps pur. Plusieurs taches = mélange.",
      "piege": "Confondre le nombre de taches et leur hauteur : la hauteur identifie, le nombre renseigne sur la pureté.",
      "image": "syn_ccm.png",
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-14",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Le dépôt A donne deux taches, l'une à la hauteur de B, l'autre à celle de C. Que conclut-on ?",
      "options": [
        "A est identique à B",
        "A est un mélange contenant B et C",
        "A est un corps pur",
        "A ne contient ni B ni C"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Rédaction attendue : « A possède une tache à la même hauteur que B et une autre à la même hauteur que C : A est donc un mélange contenant B et C. »",
      "piege": "Conclure que A est pur parce que ses taches correspondent à des espèces connues.",
      "image": "syn_ccm.png",
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "syn-15",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Le banc Kofler est une plaque chauffante qui présente :",
      "options": ["un éclairage ultraviolet, qui révèle les taches déposées", "un refroidissement progressif, de 250 °C jusqu'à 50 °C", "un gradient de température, de 50 °C à 250 °C", "une température uniforme, réglée à la valeur attendue"],
      "bonne_reponse": [
        2
      ],
      "explication": "On déplace l'échantillon jusqu'à observer sa fusion, et on lit la température sur l'échelle graduée.",
      "piege": "Croire qu'il chauffe uniformément : c'est le gradient qui permet la lecture.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-16",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Remets dans l'ordre l'exploitation d'un banc Kofler :",
      "options": [
        "le déplacer avec le curseur jusqu'à observer la fusion",
        "déposer l'échantillon solide sur la partie la plus froide",
        "lire la température de fusion sur l'échelle graduée",
        "comparer à la valeur tabulée du produit attendu"
      ],
      "bonne_reponse": [
        1,
        0,
        2,
        3
      ],
      "explication": "Une température de fusion nette signe aussi la pureté du produit obtenu.",
      "piege": "Lire la température sans la comparer à la valeur tabulée : c'est la comparaison qui identifie.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-17",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Une réaction où une liaison double disparaît et deux groupes s'ajoutent est :",
      "options": [
        "une élimination",
        "une oxydoréduction",
        "une substitution",
        "une addition"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Deux réactifs, un seul produit : A + B → C, la liaison double devient simple.",
      "piege": "Confondre addition et substitution — dans la substitution, un groupe en remplace un autre.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "syn-18",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Une réaction où une liaison double apparaît et une petite molécule part est :",
      "options": [
        "une élimination",
        "une substitution",
        "une réaction acide-base",
        "une addition"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "A → B + C : on élimine souvent une molécule d'eau, et une liaison double apparaît.",
      "piege": "L'appeler substitution : ici rien ne vient remplacer le groupe parti.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-19",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "Dans AB + C → AC + B, il s'agit d'une :",
      "options": [
        "élimination",
        "substitution",
        "oxydoréduction",
        "addition"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C vient remplacer B dans A, sans changement du nombre de liaisons.",
      "piege": "Compter les réactifs et les produits sans regarder ce qui est remplacé.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-20",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Comment identifie-t-on la catégorie d'une réaction organique ?",
      "options": ["par le rendement obtenu, propre à chaque catégorie de réaction", "par la couleur du mélange, qui change selon la catégorie", "en comparant les formules du réactif et du produit, atome par atome", "par la température de réaction, propre à chaque catégorie"],
      "bonne_reponse": [
        2
      ],
      "explication": "Liaison double disparue → addition · apparue → élimination · groupe remplacé → substitution.",
      "piege": "Deviner d'après le nom du produit sans comparer les structures.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "syn-21",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "Un transfert de proton H⁺ entre deux espèces caractérise :",
      "options": [
        "une substitution",
        "une oxydoréduction",
        "une addition",
        "une réaction acide-base"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Transfert de proton → acide-base · transfert d'électrons → oxydoréduction.",
      "piege": "Confondre les deux transferts : le proton et l'électron ne définissent pas la même catégorie.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "syn-22",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Pourquoi protège-t-on une fonction dans une molécule polyfonctionnelle ?",
      "options": ["parce que le réactif n'est pas chimiosélectif et agirait aussi sur elle", "pour faciliter la CCM, la fonction protégée migrant plus vite", "pour accélérer la réaction, la fonction protégée gênant l'approche", "pour améliorer la pureté, la fonction protégée retenant les impuretés"],
      "bonne_reponse": [
        0
      ],
      "explication": "Un réactif chimiosélectif n'agit que sur une fonction : dans ce cas, aucune protection n'est nécessaire.",
      "piege": "Justifier par le rendement plutôt que par la chimiosélectivité du réactif.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-23",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Remets dans l'ordre les trois étapes d'une protection de fonction :",
      "options": [
        "déprotection, qui restitue la fonction protégée",
        "protection de la fonction à préserver",
        "réaction avec le réactif sur l'autre groupe fonctionnel"
      ],
      "bonne_reponse": [
        1,
        2,
        0
      ],
      "explication": "L'étape de déprotection est celle qu'on oublie : sans elle, la molécule finale n'est pas la bonne.",
      "piege": "Oublier la déprotection en fin d'étape — le piège explicitement listé.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-24",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "NaBH₄ ne réduit que le carbonyle, LiAlH₄ réduit aussi l'ester. Lequel est chimiosélectif ?",
      "options": [
        "LiAlH₄",
        "NaBH₄",
        "les deux",
        "aucun des deux"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "NaBH₄ n'agit que sur une fonction : avec lui, aucune protection n'est nécessaire.",
      "piege": "Choisir le réactif le plus puissant en pensant qu'il est le plus adapté.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-25",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Que doit contenir la réponse à « pourquoi protéger cette fonction ? »",
      "options": ["l'équation de la réaction, seule à justifier le choix de protéger", "le rendement attendu avec et sans protection de la fonction", "nommer les deux groupes, dire lequel serait modifié à tort, conclure", "le nom de la fonction protégée, sans qu'il faille en dire plus"],
      "bonne_reponse": [
        2
      ],
      "explication": "Trois éléments, trois points : c'est la rédaction attendue par le correcteur.",
      "piege": "Répondre « pour la protéger » sans nommer les groupes ni le réactif en cause.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "syn-26",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Remets dans l'ordre le calcul d'un rendement de synthèse :",
      "options": [
        "identifier le réactif limitant par le tableau d'avancement, ce qui donne x<sub>max</sub>",
        "convertir la donnée expérimentale (masse, volume, densité) en quantité de matière n<sub>f</sub>",
        "calculer η = n<sub>f</sub> / n<sub>max</sub>, puis convertir en pourcentage",
        "en déduire n<sub>max</sub>(produit) = coefficient × x<sub>max</sub>"
      ],
      "bonne_reponse": [
        0,
        3,
        1,
        2
      ],
      "explication": "L'étape 2 est celle qu'on saute : le coefficient stœchiométrique du produit intervient.",
      "piege": "Oublier le coefficient dans n<sub>max</sub> — l'erreur la plus fréquente du chapitre.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-27",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "Une masse m de produit est obtenue. Comment en déduit-on n<sub>f</sub> ?",
      "options": [
        "n<sub>f</sub> = m × M",
        "n<sub>f</sub> = M / m",
        "n<sub>f</sub> = m × ρ",
        "n<sub>f</sub> = m / M"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Pour un liquide de densité d : n<sub>f</sub> = d·ρ<sub>eau</sub>·V/M. Pour un gaz : n<sub>f</sub> = V/V<sub>m</sub>.",
      "piege": "Multiplier par la masse molaire au lieu de diviser.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "syn-28",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 9",
      "enonce": "x<sub>max</sub> = 2,0×10⁻² mol, le coefficient du produit vaut 1, et on obtient n<sub>f</sub> = 1,4×10⁻² mol. Quel est le rendement ?",
      "options": [
        "70 %",
        "0,70 %",
        "1,4 %",
        "140 %"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "η = 1,4×10⁻² / 2,0×10⁻² = 0,70, soit 70 %.",
      "piege": "Inverser le quotient et annoncer 140 %, ce qui est impossible.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-29",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Des isomères de constitution ont :",
      "options": ["des formules brutes différentes, mais la même formule développée", "la même formule brute, mais des formules développées différentes", "la même masse volumique, mais des formules brutes différentes", "la même formule développée, mais des formules brutes différentes"],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est la définition : même brute, structures différentes.",
      "piege": "Confondre avec des espèces simplement voisines : la formule brute doit être identique.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-30",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Deux isomères qui diffèrent par la <b>ramification</b> de leur chaîne carbonée sont des isomères :",
      "options": [
        "de position",
        "optiques",
        "de chaîne",
        "de fonction"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Isomères de chaîne, ou de squelette : linéaire d'un côté, ramifiée de l'autre.",
      "piege": "Les appeler isomères de position : la position concerne le groupe caractéristique, pas la chaîne.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-31",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 10",
      "enonce": "Un aldéhyde et une cétone de même formule brute sont des isomères :",
      "options": [
        "identiques",
        "de position",
        "de chaîne",
        "de fonction"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Le groupe caractéristique lui-même diffère : c'est l'isomérie de fonction.",
      "piege": "Les classer en isomères de position, alors que ce n'est pas la place du groupe qui change mais sa nature.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-32",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Le propan-1-ol et le propan-2-ol ont la même formule brute C₃H₈O. De quelle isomérie s'agit-il ?",
      "options": [
        "isomérie de chaîne",
        "isomérie de position",
        "isomérie de fonction",
        "ce ne sont pas des isomères"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Même chaîne, même groupe caractéristique : seule la <b>place</b> du groupe hydroxyle change. C'est une isomérie de position.",
      "piege": "Répondre « de fonction » : le groupe est le même, c'est sa position qui diffère.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-33",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Quelle technique d'identification utilise un spectre infrarouge ?",
      "options": ["la spectroscopie IR, qui identifie les groupes caractéristiques", "la CCM, qui identifie les groupes caractéristiques par migration", "la recristallisation, qui identifie les groupes par leur solubilité", "le banc Kofler, qui identifie les groupes par leur point de fusion"],
      "bonne_reponse": [
        0
      ],
      "explication": "Elle appartient à l'étape 4, l'identification — voir aussi la fiche Mesures physiques d'analyse.",
      "piege": "Confondre les trois techniques d'identification : CCM, Kofler et IR ne donnent pas la même information.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-34",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Quel est le but d'une <b>stratégie</b> de synthèse ?",
      "options": ["synthétiser le plus vite possible, la durée étant le critère décisif", "améliorer les conditions pour obtenir un produit pur, avec bon rendement", "éviter tout chauffage, afin de limiter la dépense d'énergie", "utiliser le moins de réactifs possible, afin de limiter le coût"],
      "bonne_reponse": [
        1
      ],
      "explication": "Deux objectifs conjoints : la pureté du produit et le rendement.",
      "piege": "Réduire la stratégie à la seule vitesse de la réaction.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "syn-35",
      "chapitre": "strategie-de-synthese",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "socle",
      "enonce": "Quand utilise-t-on une distillation fractionnée plutôt qu'un reflux ?",
      "options": ["quand le solvant est l'eau, dont l'ébullition gênerait le reflux", "quand le produit est solide, et ne peut donc pas être distillé", "quand on veut éliminer un produit au fur et à mesure de sa formation", "quand la réaction est lente, et demande un chauffage prolongé"],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est l'un des deux leviers d'amélioration du rendement de la QT 1.",
      "piege": "Voir la distillation comme une simple alternative au reflux, sans son rôle propre.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "synthese-t01", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Le rendement d'une synthèse est défini comme :", "options": ["la pureté du produit obtenu : η = m_pur/m_brut", "le rapport de la quantité obtenue à la quantité maximale : η = n_obtenu/n_max", "la vitesse de la réaction rapportée à sa durée : η = x_f/Δt", "le rapport de la masse de produit à la masse de réactif : η = m_produit/m_réactif"], "bonne_reponse": [1], "explication": "η = n_exp/n_théo, avec n_théo calculé à partir du réactif limitant. Il est toujours inférieur ou égal à 1 — pertes, réaction limitée, réactions parasites.", "piege": "Comparer des masses de produit et de réactif : ce sont les quantités de matière du même produit qu'on rapporte.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t02", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Un montage à reflux permet de :", "options": ["séparer les constituants du mélange par différence d'ébullition", "purifier le produit en retenant les impuretés dans le réfrigérant", "refroidir le milieu réactionnel pour ralentir une réaction violente", "chauffer le milieu sans perte de matière, les vapeurs se condensant"], "bonne_reponse": [3], "explication": "Le chauffage est un facteur cinétique. Le réfrigérant à boules, placé verticalement, condense les vapeurs qui retombent dans le ballon : rien ne s'échappe. Légende : ballon, chauffe-ballon, réfrigérant, entrée et sortie d'eau, support élévateur.", "piege": "Confondre avec la distillation : le réfrigérant est vertical, les vapeurs REVIENNENT dans le ballon.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t03", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Les quatre étapes d'une synthèse organique, dans l'ordre, sont :", "options": ["isolement, transformation, analyse, purification", "transformation, analyse, isolement, purification", "analyse, transformation, purification, isolement", "transformation, isolement, purification, analyse"], "bonne_reponse": [3], "explication": "On fait réagir, on extrait le produit du mélange, on le débarrasse des impuretés, puis on vérifie ce qu'on a obtenu. L'analyse vient en dernier : on caractérise le produit fini.", "piege": "Placer l'analyse en premier : elle contrôle le résultat, elle ne le précède pas.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t04", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Pour extraire une espèce d'une phase aqueuse, on choisit un solvant :", "options": ["de même densité que l'eau, non miscible, et bon solvant de l'espèce", "non miscible à l'eau, mais dans lequel l'espèce est insoluble", "miscible à l'eau, et dans lequel l'espèce est très soluble", "non miscible à l'eau, de densité différente, et bon solvant de l'espèce"], "bonne_reponse": [3], "explication": "Trois critères : non miscible (deux phases), meilleure solubilité de l'espèce (elle migre), densité différente (on sait quelle phase récupérer). On vérifie dans un tableau de solubilités.", "piege": "Choisir un solvant miscible : il n'y aurait plus deux phases à séparer.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t05", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Sur une plaque de CCM, le dépôt du produit brut présente deux taches, dont l'une a le même rapport frontal que le réactif de départ. On conclut que :", "options": ["deux produits différents se sont formés au cours de la réaction", "la réaction n'a pas eu lieu : seul le réactif est présent", "le produit brut contient encore du réactif : la réaction n'est pas totale", "le produit est pur : les deux taches proviennent du même composé"], "bonne_reponse": [2], "explication": "Une tache à même hauteur que la référence est la même espèce. Deux taches = deux espèces : le produit attendu et le réactif restant.", "piege": "Croire qu'une tache commune prouve que la réaction a échoué : l'autre tache est bien le produit.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t06", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Un solide obtenu fond sur le banc Kofler à 121 °C, la valeur tabulée pour le produit attendu étant 122 °C. On conclut que :", "options": ["le produit est impur : la fusion nette signale un mélange", "le produit est pur : la fusion est nette et proche de la valeur tabulée", "le produit est un autre composé : 121 °C ne correspond pas à 122 °C", "on ne peut rien conclure : le banc Kofler ne mesure pas la pureté"], "bonne_reponse": [1], "explication": "Un corps pur fond à température nette. Un mélange fond sur une plage plus large et plus basse. Ici 121 contre 122 : écart compatible avec l'incertitude du banc.", "piege": "Attendre la valeur exacte : la mesure a une incertitude d'environ 1 °C, l'écart est acceptable.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t07", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "La réaction CH₃COOH + CH₃OH → CH₃COOCH₃ + H₂O est :", "options": ["une substitution : un groupe OH de l'acide est remplacé par OCH₃", "une réduction", "une élimination : une petite molécule est éliminée", "une addition : deux molécules s'assemblent sans perte"], "bonne_reponse": [0], "explication": "On compare les structures : dans l'acide, le OH est remplacé par OCH₃. C'est une substitution. L'eau formée vient de l'OH de l'acide et du H de l'alcool.", "piege": "Voir une addition parce que deux réactifs donnent un produit : une petite molécule H₂O part, ce n'est pas une addition.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t08", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Une molécule porte deux fonctions A et B. On veut faire réagir A seulement, mais le réactif attaque aussi B. La stratégie consiste à :", "options": ["protéger B, faire réagir A, puis déprotéger B pour la restituer", "faire réagir A et B ensemble, puis séparer les deux produits obtenus", "chauffer plus fort, la fonction A réagissant alors la première", "utiliser moins de réactif, de sorte que seule A puisse réagir"], "bonne_reponse": [0], "explication": "Protection : B devient temporairement inerte. Réaction sur A seule. Déprotection : on régénère B. C'est le prix de la sélectivité : deux étapes de plus.", "piege": "Croire qu'un réactif « choisit » la fonction : sans protection, il réagit avec toutes celles qu'il peut.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t09", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "On fait réagir 0,100 mol d'acide avec 0,150 mol d'alcool, réaction 1:1. On obtient 0,072 mol d'ester. Le rendement vaut :", "options": ["n_max = n_acide × n_alcool = 0,0150 mol, donc η = 0,072/0,0150 = 4,8", "l'alcool est limitant : n_max = 0,150 mol, donc η = 0,072/0,150 = 48 %", "n_max = n_acide + n_alcool = 0,250 mol, donc η = 0,072/0,250 = 29 %", "l'acide est limitant : n_max = 0,100 mol, donc η = 0,072/0,100 = 72 %"], "bonne_reponse": [3], "explication": "On identifie le réactif limitant — celui en plus petite quantité pour une réaction 1:1 — qui fixe n_max. Puis η = n_obtenu/n_max.", "piege": "Rapporter à l'alcool, en excès : c'est le réactif LIMITANT qui fixe le maximum théorique.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "synthese-t10", "chapitre": "synthese", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "Le butan-1-ol et le butan-2-ol sont des isomères :", "options": ["de fonction : même formule brute, mais des groupes différents", "de position : même chaîne, même fonction, le groupe OH change de place", "de chaîne : même formule brute, mais le squelette carboné diffère", "ils ne sont pas isomères : leurs formules brutes sont différentes"], "bonne_reponse": [1], "explication": "Même formule brute C₄H₁₀O, même chaîne linéaire à quatre carbones, même fonction alcool : seule la position du OH change. Isomérie de position.", "piege": "Confondre avec l'isomérie de chaîne, qui change le squelette — comme butan-1-ol et 2-méthylpropan-1-ol.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  thermo: [
    {
      "ref": "the-01",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Un système <b>fermé</b> échange avec l'extérieur :",
      "options": [
        "de l'énergie, mais pas de matière",
        "de la matière, mais pas d'énergie",
        "ni matière ni énergie",
        "de la matière et de l'énergie"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Isolé : ni l'un ni l'autre, comme une thermos. Ouvert : les deux, comme une tuyère. En Terminale on se limite aux systèmes fermés.",
      "piege": "Confondre fermé et isolé : un récipient étanche laisse passer la chaleur.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "the-02",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Quelles sont les hypothèses du modèle du gaz parfait ? <b>Plusieurs réponses.</b>",
      "options": ["les entités sont toutes immobiles entre deux collisions", "leur taille est négligeable devant la distance qui les sépare", "les entités n'interagissent pas entre elles en dehors des collisions", "les entités ont toutes la même vitesse, fixée par la température"],
      "bonne_reponse": [
        1,
        2
      ],
      "explication": "Entités ponctuelles et sans interaction : ce sont les deux hypothèses à citer.",
      "piege": "Ajouter une hypothèse sur les vitesses, qui n'existe pas dans le modèle.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-03",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Le modèle du gaz parfait cesse de s'appliquer si :",
      "options": ["le volume est grand, les entités étant alors trop dispersées", "la pression dépasse 1 MPa, ou si T approche l'ébullition du gaz réel", "le gaz est monoatomique, ses entités n'ayant alors aucune structure", "la température est basse, mais reste loin de l'ébullition du gaz"],
      "bonne_reponse": [
        1
      ],
      "explication": "Ce sont les deux limites à citer quand l'énoncé demande de justifier l'emploi du modèle.",
      "piege": "Affirmer que le modèle vaut toujours : le barème attend ses limites.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-04",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 1",
      "enonce": "Un système est en <b>équilibre thermodynamique</b> lorsque :",
      "options": ["sa pression vaut 1 bar et sa température est uniforme en tout point", "sa température est nulle, l'agitation ayant entièrement cessé", "ses variables d'état ne varient plus et sont identiques en tout point", "il n'échange plus de matière, mais peut encore échanger de l'énergie"],
      "bonne_reponse": [
        2
      ],
      "explication": "Deux conditions : stabilité dans le temps et uniformité dans l'espace.",
      "piege": "Ne retenir que la stabilité, en oubliant l'uniformité.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-05",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "À l'échelle microscopique, une <b>température</b> plus élevée traduit :",
      "options": ["une distance plus faible entre les entités, donc plus de collisions", "des entités plus lourdes, donc une énergie cinétique plus grande", "des entités plus nombreuses, donc une énergie totale plus grande", "des entités qui se déplacent plus vite, donc plus d'énergie cinétique"],
      "bonne_reponse": [
        3
      ],
      "explication": "Le réflexe du chapitre : toute grandeur macroscopique se justifie par le mouvement ou la disposition des entités.",
      "piege": "Justifier la température par le nombre d'entités : c'est la pression qui en dépend.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "the-06",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "À l'échelle microscopique, la <b>pression</b> augmente lorsque :",
      "options": ["le nombre de collisions par unité de surface et de temps augmente", "la température diminue, les entités frappant alors plus souvent", "la distance entre entités augmente, ce qui accroît leur élan", "les entités sont plus lourdes, ce qui accroît la force des chocs"],
      "bonne_reponse": [
        0
      ],
      "explication": "Et aussi lorsque l'énergie cinétique moyenne des entités est plus grande.",
      "piege": "Confondre pression et masse volumique : la seconde dépend de la masse et de l'espacement.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "the-07",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "La <b>masse volumique</b> augmente lorsque :",
      "options": ["la pression diminue, les entités occupant alors moins de place", "la masse des entités est plus élevée, ou leur distance plus faible", "les entités vont plus vite, ce qui accroît la masse par unité de volume", "la température augmente, ce qui rapproche les entités entre elles"],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est la seule des trois grandeurs qui ne dépend pas du mouvement des entités.",
      "piege": "L'associer à la vitesse des entités, qui traduit la température.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-08",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Pour un système incompressible, la variation d'énergie interne vaut :",
      "options": [
        "ΔU = m·(T<sub>f</sub> − T<sub>i</sub>)",
        "ΔU = c·(T<sub>f</sub> − T<sub>i</sub>)",
        "ΔU = m·c·(T<sub>f</sub> − T<sub>i</sub>)",
        "ΔU = m·c·T<sub>f</sub>"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "ΔU en joules, m en kilogrammes, c en J·kg⁻¹·K⁻¹, et ΔT en kelvins ou en degrés — c'est un écart.",
      "piege": "Oublier la masse, ou utiliser la température finale au lieu de l'écart.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "the-09",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Le premier principe s'écrit :",
      "options": [
        "ΔU = W × Q",
        "ΔU = W − Q",
        "ΔU = Q − W",
        "ΔU = W + Q"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Pour un système incompressible et immobile, W = 0, donc ΔU = Q.",
      "piege": "Mettre un signe − : les deux transferts sont comptés dans le même sens.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-10",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Selon la convention de signe, une énergie <b>cédée</b> par le système est comptée :",
      "options": [
        "négativement",
        "nulle",
        "positivement",
        "en valeur absolue"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Reçue → positive · cédée → négative. C'est ce qui donne son signe à Q dans un refroidissement.",
      "piege": "Rendre un transfert thermique positif pour un système qui refroidit.",
      "image": null,
      "tags": [
        "condition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-11",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 3",
      "enonce": "Une masse m = 0,50 kg d'eau (c = 4 180 J·kg⁻¹·K⁻¹) passe de 20 °C à 80 °C. Que vaut ΔU ?",
      "options": [
        "2,1×10⁵ J",
        "1,3×10⁵ J",
        "1,7×10⁵ J",
        "6,0×10¹ J"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "ΔU = 0,50 × 4 180 × 60 = 1,3×10⁵ J. L'écart de température est le même en °C et en K.",
      "piege": "Convertir les températures en kelvins <b>puis</b> les soustraire : inutile, l'écart est identique.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "the-12",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Le flux thermique s'écrit :",
      "options": [
        "Φ = Q × Δt",
        "Φ = Q + Δt",
        "Φ = Q / Δt",
        "Φ = Δt / Q"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "C'est une puissance thermique, en watts : Q en joules divisé par Δt en secondes.",
      "piege": "Multiplier au lieu de diviser : le flux serait alors une énergie.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-13",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "La résistance thermique d'une paroi plane vaut :",
      "options": [
        "R<sub>th</sub> = e·λ·S",
        "R<sub>th</sub> = λ·S/e",
        "R<sub>th</sub> = S/(λ·e)",
        "R<sub>th</sub> = e/(λ·S)"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Elle s'exprime en K·W⁻¹, et vaut aussi (T₁ − T₂)/Φ.",
      "piege": "Inverser le rapport : une paroi épaisse isole mieux, donc R<sub>th</sub> augmente avec e.",
      "image": null,
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "the-14",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Une paroi isole d'autant mieux qu'elle est :",
      "options": [
        "épaisse et de faible conductivité",
        "épaisse et de grande conductivité",
        "fine et de faible conductivité",
        "fine et de grande conductivité"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "R<sub>th</sub> = e/(λ·S) : e au numérateur, λ au dénominateur.",
      "piege": "Croire qu'un matériau très conducteur isole bien : c'est l'inverse.",
      "image": "the_paroi.png",
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "the-15",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Le transfert thermique se fait toujours spontanément :",
      "options": ["du froid vers le chaud, de façon irréversible", "du chaud vers le froid, de façon irréversible", "du chaud vers le froid, mais seulement par conduction", "dans les deux sens à la fois, de façon réversible"],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est le sens spontané : le rappeler est souvent le premier point de la question.",
      "piege": "Omettre le caractère irréversible, qui fait partie de la réponse attendue.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-16",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "La <b>conduction</b> se produit :",
      "options": [
        "même dans le vide",
        "dans les fluides, avec déplacement d'ensemble de la matière",
        "sans déplacement d'ensemble de la matière, principalement dans les solides",
        "uniquement dans les gaz"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "L'agitation thermique se transmet de proche en proche, sans que la matière se déplace globalement.",
      "piege": "Confondre conduction et convection : c'est le déplacement d'ensemble qui les distingue.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-17",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "Quel mode de transfert se produit <b>même dans le vide</b> ?",
      "options": [
        "le rayonnement",
        "la convection",
        "la conduction",
        "aucun"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "L'absorption ou l'émission de rayonnement modifie l'agitation thermique : aucun support matériel n'est nécessaire.",
      "piege": "Croire qu'un transfert thermique exige toujours de la matière.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-18",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 5",
      "enonce": "La loi de Newton du refroidissement s'écrit :",
      "options": [
        "Φ = h·S·(T<sub>ther</sub> − T(t))",
        "Φ = h/(S·(T<sub>ther</sub> − T(t)))",
        "Φ = h + S + T(t)",
        "Φ = h·S·T(t)"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Elle régit le transfert conducto-convectif, quand conduction et convection sont toutes deux prédominantes.",
      "piege": "Oublier l'écart de température : c'est lui qui annule le flux à l'équilibre.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-19",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Une tasse de café refroidit à l'air libre. De quel transfert s'agit-il ?",
      "options": ["de conduction seule : la chaleur traverse la paroi puis l'air", "conducto-convectif : conduction à travers la paroi, puis convection dans l'air", "de rayonnement seul : la tasse émet un rayonnement infrarouge", "d'aucun transfert : le café perd sa chaleur par simple évaporation"],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est l'exemple type du transfert conducto-convectif, régi par la loi de Newton.",
      "piege": "N'invoquer qu'un seul mode alors que deux sont en jeu.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "the-20",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "La loi de Stefan-Boltzmann s'écrit :",
      "options": [
        "P = σ·S·T",
        "P = σ·S/T⁴",
        "P = σ·S·T⁴",
        "P = σ·T⁴/S"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "La puissance rayonnée varie comme la puissance <b>quatrième</b> de la température, en kelvins.",
      "piege": "Oublier l'exposant 4, ou travailler en degrés Celsius.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-21",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Remets dans l'ordre le bilan radiatif du système Terre-atmosphère :",
      "options": [
        "à l'équilibre thermique, les deux puissances sont égales — la surface S se simplifie",
        "puissance émise : P_émise = (1 − a)·σ·S·T_T⁴",
        "puissance reçue : P_reçue = (1 − A)·p<sub>s</sub>·S, avec A l'albédo",
        "T<sub>T</sub> = [ (1 − A)·p<sub>s</sub> / ((1 − a)·σ) ]^(1/4)",
        "T_T⁴ = (1 − A)·p<sub>s</sub> / ((1 − a)·σ)"
      ],
      "bonne_reponse": [
        2,
        1,
        0,
        4,
        3
      ],
      "explication": "La dernière étape est celle qu'on oublie : il reste à prendre la racine quatrième.",
      "piege": "Rendre T⁴ au lieu de T — le piège explicite de cette QT.",
      "image": "the_bilan.png",
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-22",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Que représente l'albédo A dans ce bilan ?",
      "options": [
        "la fraction de puissance solaire absorbée",
        "la température de surface",
        "la constante de Stefan",
        "la fraction de puissance solaire réfléchie"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "La Terre absorbe donc la fraction (1 − A) de la puissance solaire reçue.",
      "piege": "Utiliser A au lieu de (1 − A) dans l'expression de la puissance reçue.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "the-23",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Remets dans l'ordre l'établissement de l'équation différentielle de T(t) :",
      "options": [
        "on exprime les deux membres : ΔU = m·c·ΔT et Q = Φ·Δt",
        "on divise par m·c et on pose τ = m·c/(h·S) : dT/dt + T(t)/τ = T<sub>ther</sub>/τ",
        "premier principe : ΔU = W + Q = Q, car le système est incompressible",
        "on remplace Φ par la loi de Newton : m·c·ΔT = h·S·(T<sub>ther</sub> − T(t))·Δt",
        "on divise par Δt et on fait tendre Δt vers 0 : le quotient devient la dérivée"
      ],
      "bonne_reponse": [
        2,
        0,
        3,
        4,
        1
      ],
      "explication": "La forme canonique est exactement celle du circuit RC : même équation, même solution.",
      "piege": "S'arrêter avant la forme canonique, ou oublier de poser la constante de temps.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-24",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 7",
      "enonce": "La constante de temps du refroidissement vaut :",
      "options": [
        "τ = m·c/(h·S)",
        "τ = h·S·m/c",
        "τ = m·c·h·S",
        "τ = h·S/(m·c)"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Plus τ est grande, plus le refroidissement est lent.",
      "piege": "Inverser le rapport : une grande masse ralentit le refroidissement, donc augmente τ.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-25",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Pour T(t) = A·e^(−t/τ) + B, que valent les deux constantes ?",
      "options": [
        "A = T<sub>i</sub> et B = T<sub>ther</sub> − T<sub>i</sub>",
        "A = T<sub>i</sub> − T<sub>ther</sub> et B = T<sub>ther</sub>",
        "A = T<sub>ther</sub> et B = T<sub>i</sub>",
        "A = 0 et B = T<sub>i</sub>"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Quand t → ∞, T → B et physiquement T → T<sub>ther</sub>. À t = 0, T(0) = A + B = T<sub>i</sub>.",
      "piege": "N'utiliser qu'une seule des deux limites : il faut les deux pour déterminer A et B.",
      "image": null,
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-26",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "La solution complète s'écrit :",
      "options": [
        "T(t) = (T<sub>ther</sub> − T<sub>i</sub>)·e^(−t/τ) + T<sub>i</sub>",
        "T(t) = T<sub>i</sub>·e^(−t/τ)",
        "T(t) = (T<sub>i</sub> − T<sub>ther</sub>)·e^(−t/τ) + T<sub>ther</sub>",
        "T(t) = T<sub>ther</sub>·(1 − e^(−t/τ))"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Contrôle : à t = 0 on retrouve T<sub>i</sub>, et quand t → ∞ la température tend vers T<sub>ther</sub>.",
      "piege": "Intervertir T<sub>i</sub> et T<sub>ther</sub> : le contrôle aux deux limites le détecte immédiatement.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-27",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 10",
      "enonce": "Remets dans l'ordre la vérification que T(t) est solution :",
      "options": [
        "reporter T(t) et sa dérivée dans le membre de gauche dT/dt + T(t)/τ",
        "constater que les deux termes en e^(−t/τ) se simplifient",
        "dériver l'expression : T<sub>ther</sub> est constante, sa dérivée est nulle",
        "il reste T<sub>ther</sub>/τ, qui est bien le second membre"
      ],
      "bonne_reponse": [
        2,
        0,
        1,
        3
      ],
      "explication": "Exactement la même méthode que pour le circuit RC.",
      "piege": "Vérifier seulement la valeur à t = 0 : cela ne démontre rien sur l'équation.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-29",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Comment détermine-t-on τ graphiquement sur une courbe de refroidissement ?",
      "options": ["en traçant la tangente à l'origine : elle coupe l'asymptote à l'abscisse τ", "en divisant l'écart initial par deux, puis en lisant l'abscisse obtenue", "en lisant la température finale, atteinte au bout d'une durée τ", "en mesurant la durée totale du refroidissement, qui vaut exactement τ"],
      "bonne_reponse": [
        0
      ],
      "explication": "Seconde méthode : calculer T(τ) = (T<sub>i</sub> − T<sub>ther</sub>)·e⁻¹ + T<sub>ther</sub> et reporter la valeur sur la courbe.",
      "piege": "Chercher un point à mi-hauteur : à t = τ, l'écart ne vaut plus que 37 % de l'écart initial.",
      "image": null,
      "tags": [
        "lecture graphique"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-30",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 9",
      "enonce": "À l'instant t = τ, l'écart T(t) − T<sub>ther</sub> vaut :",
      "options": [
        "50 % de l'écart initial",
        "37 % de l'écart initial",
        "10 % de l'écart initial",
        "63 % de l'écart initial"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "e⁻¹ ≈ 0,37 : c'est la même valeur que pour la décharge d'un condensateur.",
      "piege": "Utiliser 63 %, qui correspond à la charge d'un condensateur, pas à un refroidissement.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-31",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Comment isole-t-on la date t à laquelle le système atteint une température donnée ?",
      "options": ["t = τ · (T(t) − T_ther)/(T_i − T_ther)", "t = τ · ln[ (T_i − T_ther)/(T(t) − T_ther) ]", "t = −τ · ln[ (T(t) − T_ther)/(T_i − T_ther) ]", "t = τ / ln[ (T(t) − T_ther)/(T_i − T_ther) ]"],
      "bonne_reponse": [
        2
      ],
      "explication": "On isole l'exponentielle, puis on passe au logarithme népérien : même démarche qu'en radioactivité.",
      "piege": "Oublier le signe − devant τ et obtenir une durée négative.",
      "image": "the_solution.png",
      "tags": [
        "formule"
      ],
      "actif": true
    },
    {
      "ref": "the-32",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 9",
      "enonce": "Que signifie une grande constante de temps τ ?",
      "options": [
        "la température finale est plus élevée",
        "le refroidissement est rapide",
        "le système est isolé",
        "le refroidissement est lent"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "τ = m·c/(h·S) : une grande masse ou une faible surface d'échange ralentissent le refroidissement.",
      "piege": "Associer une grande valeur de τ à un phénomène rapide.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-33",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Quel chapitre repose exactement sur la même équation différentielle ?",
      "options": [
        "la cinétique chimique",
        "le circuit RC",
        "la radioactivité",
        "les trois"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Équation du premier ordre à coefficients constants : même forme canonique, même solution exponentielle, même lecture de τ.",
      "piege": "Traiter chaque chapitre comme un cas isolé alors que la méthode est identique.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "the-34",
      "chapitre": "thermodynamique-et-transferts-thermiques",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Dans P·V = n·R·T, la température doit être exprimée en :",
      "options": [
        "degrés Fahrenheit",
        "kelvins, avec T = θ + 273",
        "degrés Celsius",
        "kelvins ou degrés indifféremment"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "Contrairement à ΔU = m·c·ΔT, où l'écart est le même dans les deux échelles.",
      "piege": "Laisser θ en degrés Celsius dans l'équation d'état.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "thermo-t01", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Un gaz peut être modélisé par un gaz parfait lorsque :", "options": ["sa pression est faible : les molécules sont éloignées et sans interaction", "sa température est très basse : l'agitation devient alors négligeable", "il est enfermé dans un petit volume : les chocs deviennent réguliers", "il est composé d'une seule espèce : les entités sont alors identiques"], "bonne_reponse": [0], "explication": "Le modèle suppose des molécules ponctuelles sans interaction. C'est vrai quand elles sont loin les unes des autres : faible pression, ou température assez élevée. L'air ambiant convient bien.", "piege": "Croire qu'un gaz comprimé est plus « parfait » : c'est l'inverse, les interactions apparaissent.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t02", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "L'énergie interne U d'un système est :", "options": ["son énergie potentielle de pesanteur, rapportée à son centre de masse", "l'énergie cinétique macroscopique du système, liée à son mouvement d'ensemble", "la somme des énergies cinétiques d'agitation et potentielles d'interaction", "la chaleur qu'il contient, échangeable avec le milieu extérieur"], "bonne_reponse": [0], "explication": "U est l'énergie stockée à l'échelle des molécules. Pour un gaz parfait, seule l'agitation compte : U ne dépend que de T. Ni le mouvement d'ensemble ni l'altitude n'en font partie.", "piege": "Parler de « chaleur contenue » : la chaleur est un transfert, pas une réserve.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t03", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Un système reçoit un travail W = 200 J et cède un transfert thermique de 50 J. Sa variation d'énergie interne vaut :", "options": ["ΔU = W − Q = 200 − 50 = 150 J, le transfert cédé se retranchant", "ΔU = W + Q = 200 + 50 = 250 J, les deux apports s'additionnant", "ΔU = W − Q = 200 − (−50) = 250 J, le transfert cédé étant négatif", "ΔU = W + Q = 200 + (−50) = 150 J, le transfert cédé étant négatif"], "bonne_reponse": [3], "explication": "Premier principe : ΔU = W + Q, avec la convention « reçu positif ». Le système cède 50 J : Q = −50 J.", "piege": "Oublier le signe de Q : un transfert CÉDÉ se compte négativement.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t04", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Un mur de résistance thermique R_th = 0,50 K·W⁻¹ sépare 20 °C de 5 °C. Le flux thermique qui le traverse vaut :", "options": ["Φ = ΔT/R_th = 15/0,50 = 30 W, du chaud vers le froid", "Φ = ΔT = 15 W, la résistance n'intervenant pas dans le flux", "Φ = R_th × ΔT = 0,50 × 15 = 7,5 W, du chaud vers le froid", "Φ = ΔT/R_th = 20/0,50 = 40 W, du chaud vers le froid"], "bonne_reponse": [0], "explication": "Φ = (T_chaud − T_froid)/R_th, comme I = U/R en électricité. Une différence de 15 K — les degrés Celsius et les kelvins ont le même écart.", "piege": "Multiplier au lieu de diviser : une grande résistance thermique LIMITE le flux.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t05", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "Le transfert thermique qui ne nécessite aucun milieu matériel est :", "options": ["la conduction : de proche en proche, sans déplacement de matière", "le rayonnement : c'est ainsi que le Soleil chauffe la Terre à travers le vide", "la convection : par déplacement d'ensemble du fluide chauffé", "la conduction et la convection, qui se passent toutes deux de milieu"], "bonne_reponse": [1], "explication": "Conduction : de proche en proche dans un solide. Convection : par déplacement de matière dans un fluide. Rayonnement : par ondes électromagnétiques, y compris dans le vide.", "piege": "Attribuer le chauffage solaire à la convection : il n'y a pas d'air entre le Soleil et la Terre.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t06", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Sans effet de serre, la température moyenne de la Terre serait d'environ −18 °C. Elle est de 15 °C parce que :", "options": ["le sol absorbe tout le rayonnement solaire, et n'en réémet aucune part", "l'atmosphère produit de la chaleur par les réactions qui s'y déroulent", "l'atmosphère réfléchit le rayonnement solaire, qu'elle renvoie vers le sol", "l'atmosphère absorbe l'infrarouge émis par le sol et en renvoie vers lui"], "bonne_reponse": [3], "explication": "Le sol, chauffé, émet dans l'infrarouge. Les gaz à effet de serre absorbent cet IR et rayonnent dans toutes les directions, dont vers le bas. Le sol reçoit plus qu'avec le seul Soleil.", "piege": "Croire que l'atmosphère « piège » la chaleur comme un couvercle : elle ré-émet, elle ne bloque pas.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t07", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Un corps de capacité thermique C, à la température T, échange avec l'extérieur à T_ext par un flux Φ = (T − T_ext)/R_th. Le premier principe C·dT/dt = −Φ donne :", "options": ["dT/dt = +(T − T_ext)/(R_th·C), soit dT/dt − T/τ = −T_ext/τ avec τ = R_th·C", "C·dT/dt = T_ext, soit dT/dt = T_ext/C, sans intervention de R_th", "dT/dt = −T/(R_th·C), soit dT/dt + T/τ = 0 avec τ = R_th·C", "dT/dt = −(T − T_ext)/(R_th·C), soit dT/dt + T/τ = T_ext/τ avec τ = R_th·C"], "bonne_reponse": [3], "explication": "Le corps perd de l'énergie si T > T_ext : dU/dt = −Φ. En développant : dT/dt = −(T − T_ext)/(R_thC). On pose τ = R_thC, homogène à un temps.", "piege": "Oublier T_ext : le corps ne tend pas vers 0 K mais vers la température extérieure.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t08", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "La solution est T(t) = A·e^(−t/τ) + B. Avec T(0) = T_i et T(∞) = T_ext, on obtient :", "options": ["A = T_i (condition initiale) et B = T_ext (limite à l'infini)", "B = T_ext (limite à l'infini) et A = T_i − T_ext (condition initiale)", "A = T_ext (limite à l'infini) et B = T_i (condition initiale)", "A = B = T_i, les deux constantes valant la température initiale"], "bonne_reponse": [1], "explication": "Quand t → ∞, l'exponentielle s'annule : B = T_ext. À t = 0 : A + B = T_i, donc A = T_i − T_ext. D'où T(t) = (T_i − T_ext)e^(−t/τ) + T_ext.", "piege": "Prendre A = T_i : la condition initiale porte sur A + B, pas sur A seule.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t09", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 9", "enonce": "Une tasse de café passe de 80 °C vers 20 °C. Sur la courbe, τ se lit à l'instant où l'écart T − T_ext a été divisé par e, soit T = 20 + 60/2,72 ≈ 42 °C. Si τ = 10 min, le café atteint 35 °C à :", "options": ["t = τ = 10 min, le refroidissement s'achevant au bout d'une constante", "t = τ·ln((T_i − T_ext)/(T − T_ext)) = 10 × ln(60/15) = 10 × ln 4 ≈ 14 min", "t = 2τ = 20 min, l'écart étant divisé par deux à chaque constante", "t = τ·(80 − 35)/(80 − 20) = 10 × 45/60 = 7,5 min"], "bonne_reponse": [1], "explication": "De T − T_ext = (T_i − T_ext)e^(−t/τ) : t = τ·ln((T_i − T_ext)/(T − T_ext)). Avec les écarts 60 et 15 : ln 4 ≈ 1,39, t ≈ 14 min.", "piege": "Raisonner en proportion linéaire : le refroidissement est exponentiel, pas uniforme.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "thermo-t10", "chapitre": "thermo", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 10", "enonce": "Pour vérifier que T(t) = (T_i − T_ther)·e^(−t/τ) + T_ther est solution de dT/dt + T/τ = T_ther/τ, on calcule dT/dt + T/τ et l'on trouve :", "options": ["0 : les deux termes en exponentielle s'annulent, et il ne reste rien", "T_i/τ : le terme constant subsiste seul, égal à la valeur initiale", "(T_i − T_ther)/τ : l'écart initial subsiste, divisé par la constante", "−(T_i − T_ther)e^(−t/τ)/τ + (T_i − T_ther)e^(−t/τ)/τ + T_ther/τ = T_ther/τ"], "bonne_reponse": [3], "explication": "La dérivée de l'exponentielle donne un terme en −1/τ ; le terme T/τ en donne un en +1/τ. Ils s'annulent, il reste T_ther/τ : c'est bien le second membre.", "piege": "Oublier le terme constant T_ther dans T/τ : c'est lui qui fournit le second membre.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
  electrolyse: [
    {
      "ref": "ele-01",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Dans une transformation <b>forcée</b>, le quotient de réaction :",
      "options": [
        "s'éloigne de K(T)",
        "se rapproche de K(T)",
        "reste égal à K(T)",
        "devient nul"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est exactement l'inverse de l'évolution spontanée : on apporte de l'énergie pour y parvenir.",
      "piege": "Confondre avec l'évolution spontanée, où Q<sub>r</sub> tend toujours vers K(T).",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "ele-02",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La constante de Faraday vaut :",
      "options": [
        "96,5 C·mol⁻¹",
        "9,65×10⁴ C·mol⁻¹",
        "1,60×10⁻¹⁹ C",
        "6,02×10²³ mol⁻¹"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "F = N<sub>A</sub> × e : c'est la charge portée par une mole d'électrons.",
      "piege": "Confondre F avec le nombre d'Avogadro ou la charge élémentaire.",
      "image": null,
      "tags": [
        "unites"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-03",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "La quantité d'électricité s'écrit :",
      "options": ["Q = n(e⁻)/F = I × Δt", "Q = I/Δt = n(e⁻) × F", "Q = I × Δt = n(e⁻) × F", "Q = F/I = n(e⁻)/Δt"],
      "bonne_reponse": [
        2
      ],
      "explication": "Deux expressions de la même charge : Q = x<sub>eq</sub> × N × F, avec N le nombre d'électrons échangés.",
      "piege": "Diviser par Δt : la quantité d'électricité est une charge, en coulombs.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-04",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Remets dans l'ordre la démonstration qu'une transformation est forcée :",
      "options": [
        "conclure : le système évolue dans le sens inverse du sens spontané",
        "comparer Q<sub>r</sub>,i à K(T) pour savoir dans quel sens la réaction aurait lieu spontanément",
        "exprimer et calculer Q<sub>r</sub>,i à partir des concentrations initiales",
        "comparer avec ce qu'on observe expérimentalement"
      ],
      "bonne_reponse": [
        2,
        1,
        3,
        0
      ],
      "explication": "L'étape 3 est indispensable : c'est la contradiction avec l'observation qui prouve le caractère forcé.",
      "piege": "Conclure sans comparer au sens spontané — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-05",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 1",
      "enonce": "On calcule Q<sub>r</sub>,i = 2,0 alors que K(T) = 5×10⁻³⁴. Spontanément, la réaction se ferait :",
      "options": [
        "pas du tout",
        "dans le sens direct",
        "dans les deux sens",
        "dans le sens indirect"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Q<sub>r</sub>,i > K(T) : le quotient doit diminuer, donc évolution spontanée dans le sens indirect.",
      "piege": "Comparer les valeurs sans regarder les puissances de dix.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "ele-06",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 1",
      "enonce": "Que doit contenir la conclusion sur le caractère forcé ?",
      "options": ["la comparaison Q_r,i / K(T), le sens spontané attendu, et la contradiction", "la seule valeur de Q_r,i, dont le signe donne le sens de l'évolution", "la seule valeur de K(T), qui suffit à établir le sens spontané", "l'équation de la réaction, et le nombre d'électrons échangés"],
      "bonne_reponse": [
        0
      ],
      "explication": "Trois éléments : sans la contradiction avec l'expérience, rien n'est démontré.",
      "piege": "Se contenter du calcul de Q<sub>r</sub>,i sans conclure.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "actif": true
    },
    {
      "ref": "ele-07",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "Dans une électrolyse, l'anode est reliée :",
      "options": [
        "à rien",
        "à la borne ⊕ du générateur",
        "à la borne ⊖ du générateur",
        "au pont salin"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "C'est la différence avec la pile : la règle Anode → Oxydation reste vraie, mais la polarité change.",
      "piege": "Transposer la polarité de la pile, où l'anode est le pôle ⊖.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "ele-08",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 2",
      "enonce": "À la cathode d'un électrolyseur, il se produit :",
      "options": ["une réduction des cations, souvent avec un dépôt métallique", "une oxydation des cations, souvent avec un dépôt métallique", "une oxydation des anions, souvent avec un dégagement gazeux", "une réduction des anions, souvent avec un dégagement gazeux"],
      "bonne_reponse": [
        0
      ],
      "explication": "Cathode → Réduction, comme dans la pile. Les cations y sont réduits.",
      "piege": "Inverser anode et cathode : la règle des réactions ne change pas, seule la polarité diffère.",
      "image": "ele_montage.png",
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-09",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Quelle est la différence entre une pile et un électrolyseur pour l'anode ?",
      "options": ["il n'y en a pas : l'anode est le pôle ⊖ dans les deux dispositifs", "l'anode change de réaction : oxydation en pile, réduction en électrolyse", "l'anode se consomme en électrolyse, alors qu'elle reste intacte en pile", "dans la pile l'anode est le pôle ⊖, en électrolyse elle est reliée au ⊕"],
      "bonne_reponse": [
        3
      ],
      "explication": "Anode → Oxydation dans les deux cas : c'est la polarité qui s'inverse, pas la nature de la réaction.",
      "piege": "Croire que l'oxydation change d'électrode : elle reste toujours à l'anode.",
      "image": "ele_montage.png",
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-10",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_multiple",
      "difficulte": "methode",
      "source_qt": "QT 2",
      "enonce": "Que fournit l'énoncé pour identifier les électrodes ? <b>Plusieurs réponses.</b>",
      "options": ["le sens du courant indiqué par un ampèremètre", "le branchement au générateur, pôle par pôle", "la nature du dépôt ou du gaz observé", "la couleur de l'électrolyte, propre à chaque ion"],
      "bonne_reponse": [
        0,
        1,
        2
      ],
      "explication": "L'une de ces trois informations suffit à trancher.",
      "piege": "Chercher une donnée absente au lieu d'exploiter celle qui est fournie.",
      "image": "ele_montage.png",
      "tags": [
        "methode"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-11",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Dans le circuit extérieur d'une électrolyse, les électrons se déplacent :",
      "options": [
        "de la borne ⊖ vers la borne ⊕ du générateur",
        "dans le même sens que le courant",
        "de la borne ⊕ vers la borne ⊖",
        "dans l'électrolyte"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Le courant, lui, circule du ⊕ vers le ⊖ : les deux sens sont opposés.",
      "piege": "Donner au courant le sens des électrons — le piège explicite de cette QT.",
      "image": null,
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-12",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 3",
      "enonce": "Dans l'électrolyte, les cations se déplacent vers :",
      "options": [
        "la cathode",
        "l'anode",
        "le générateur",
        "aucune électrode"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "Cations → cathode, anions → anode : même règle que dans une pile.",
      "piege": "Appliquer aux ions le sens de déplacement des électrons.",
      "image": "ele_montage.png",
      "tags": [
        "propriete"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-13",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 3",
      "enonce": "Comment retenir le sens de déplacement des ions ?",
      "options": [
        "les ions ne se déplacent pas",
        "les ions vont vers le générateur",
        "cations → cathode, anions → anode",
        "les ions suivent les électrons"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le moyen mnémotechnique est identique à celui de la pile : la première lettre correspond.",
      "piege": "Chercher une règle différente de celle de la pile : elle est la même.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "ele-14",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 4",
      "enonce": "Une électrolyse dure 10 minutes sous I = 0,60 A. Quelle quantité d'électricité a circulé ?",
      "options": [
        "0,60 C",
        "6,0 C",
        "3,6×10³ C",
        "360 C"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "Q = I × Δt = 0,60 × 600 = 360 C. Attention à convertir les minutes en secondes.",
      "piege": "Laisser Δt en minutes et se tromper d'un facteur 60.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-15",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 4",
      "enonce": "Comment isole-t-on la durée d'une électrolyse ?",
      "options": ["Δt = Q/I = n(e⁻)·F/I", "Δt = Q·I = n(e⁻)·F·I", "Δt = I/Q = I/(n(e⁻)·F)", "Δt = Q/F = n(e⁻)·I/F"],
      "bonne_reponse": [
        0
      ],
      "explication": "Δt sort en secondes : penser à convertir en heures si l'énoncé le demande.",
      "piege": "Rendre un résultat en secondes quand l'énoncé attend des heures.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-16",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 4",
      "enonce": "Dans Q = x<sub>eq</sub> × N × F, que représente N ?",
      "options": ["le nombre d'Avogadro, qui convertit les moles en entités", "le nombre d'électrons échangés dans les demi-équations", "le nombre d'électrodes plongées dans l'électrolyte", "le nombre de charges portées par chaque ion en solution"],
      "bonne_reponse": [
        1
      ],
      "explication": "Il se lit directement sur la demi-équation : deux pour Zn²⁺ + 2 e⁻ → Zn.",
      "piege": "Confondre N et le nombre d'Avogadro N<sub>A</sub>, qui intervient dans F = N<sub>A</sub> × e.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "ele-17",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Remets dans l'ordre le calcul de la masse déposée à une électrode :",
      "options": [
        "remplacer n(e⁻) par Q/F = I·Δt/F",
        "écrire la demi-équation de l'électrode concernée",
        "convertir en masse : m = n × M",
        "en déduire le lien entre n(produit) et n(e⁻)"
      ],
      "bonne_reponse": [
        1,
        3,
        0,
        2
      ],
      "explication": "La demi-équation donne le coefficient : deux électrons pour un atome de zinc.",
      "piege": "Oublier ce coefficient et trouver une masse deux fois trop grande.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-18",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Pour Zn²⁺ + 2 e⁻ → Zn, avec I = 0,60 A pendant 10 min, quelle quantité de zinc se dépose ? <i>Donnée : F = 9,65×10⁴ C·mol⁻¹.</i>",
      "options": [
        "0,60 mol",
        "3,7×10⁻³ mol",
        "1,9×10⁻³ mol",
        "9,3×10⁻⁴ mol"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "n(Zn) = I·Δt/(2F) = 0,60 × 600 / (2 × 9,65×10⁴) = 1,9×10⁻³ mol.",
      "piege": "Oublier le facteur 2 du dénominateur et doubler le résultat.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-19",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 5",
      "enonce": "Avec M(Zn) = 65,4 g·mol⁻¹, quelle masse de zinc s'est déposée ?",
      "options": [
        "12 g",
        "0,012 g",
        "1,2 g",
        "0,12 g"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "m = n × M = 1,9×10⁻³ × 65,4 = 0,12 g.",
      "piege": "Se tromper d'un facteur dix en négligeant la puissance de dix de n.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "actif": true
    },
    {
      "ref": "ele-20",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 5",
      "enonce": "Quelle électrode gagne de la masse au cours d'une électrolyse ?",
      "options": ["celle sur laquelle se dépose un solide, généralement la cathode", "celle sur laquelle se dépose un solide, généralement l'anode", "les deux également, le dépôt se partageant entre elles", "aucune : la masse totale des électrodes reste constante"],
      "bonne_reponse": [
        0
      ],
      "explication": "Δm = m<sub>f</sub> − m<sub>i</sub> = m(produit formé). Les cations réduits s'y déposent sous forme métallique.",
      "piege": "Choisir l'anode, où se produit au contraire une oxydation, souvent gazeuse.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-21",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 6",
      "enonce": "Comment identifie-t-on le gaz formé à une électrode ?",
      "options": ["en le pesant, sa masse molaire donnant sa nature", "en écrivant l'équation de fonctionnement, le gaz étant côté produits", "à sa seule couleur, chaque gaz ayant la sienne", "en mesurant sa masse volumique, propre à chaque gaz"],
      "bonne_reponse": [
        1
      ],
      "explication": "Puis on applique le test correspondant : tison incandescent ou détonation.",
      "piege": "Deviner le gaz sans écrire l'équation de fonctionnement.",
      "image": null,
      "tags": [
        "methode"
      ],
      "actif": true
    },
    {
      "ref": "ele-22",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Quel gaz ravive la flamme d'un tison incandescent ?",
      "options": [
        "le dihydrogène",
        "le diazote",
        "le dioxygène",
        "le dichlore"
      ],
      "bonne_reponse": [
        2
      ],
      "explication": "Le dihydrogène, lui, produit une détonation à l'approche d'une flamme.",
      "piege": "Inverser les deux tests : ce sont les deux plus classiques du programme.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-23",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 6",
      "enonce": "Comment reconnaît-on le dichlore Cl₂ ?",
      "options": ["il est incolore et inodore, et éteint une flamme", "il ravive un tison, comme tout gaz oxydant", "à sa détonation à la flamme, avec un bruit sec", "à sa couleur jaune-vert et à sa décoloration de l'indigo"],
      "bonne_reponse": [
        3
      ],
      "explication": "C'est le cas de l'électrolyse d'une solution de chlorure d'étain.",
      "piege": "Lui appliquer le test du tison, réservé au dioxygène.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-24",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "ordre",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Remets dans l'ordre le calcul du rendement d'un électrolyseur :",
      "options": [
        "calculer la quantité théorique : n_théorique = I·Δt/(coeff × F)",
        "calculer η = n<sub>exp</sub> / n_théorique",
        "établir l'équation de fonctionnement à partir des deux demi-équations",
        "convertir la donnée expérimentale en quantité de matière : n<sub>exp</sub> = m/M ou V/V<sub>m</sub>"
      ],
      "bonne_reponse": [
        2,
        0,
        3,
        1
      ],
      "explication": "Le rendement est sans unité et toujours inférieur à 1.",
      "piege": "Oublier le coefficient de la demi-équation dans la quantité théorique.",
      "image": null,
      "tags": [
        "demonstration"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-25",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 7",
      "enonce": "La quantité théorique vaut 1,9×10⁻³ mol et on récupère 1,6×10⁻³ mol. Quel est le rendement ?",
      "options": [
        "84 %",
        "1,2 %",
        "0,30 %",
        "119 %"
      ],
      "bonne_reponse": [
        0
      ],
      "explication": "η = 1,6×10⁻³ / 1,9×10⁻³ = 0,84, soit 84 %.",
      "piege": "Inverser le quotient et annoncer 119 %, ce qui est impossible.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-26",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 7",
      "enonce": "Pour un produit gazeux, comment obtient-on la quantité expérimentale ?",
      "options": ["n = V × V_m, avec V_m le volume molaire", "n = V / V_m, avec V_m le volume molaire", "n = m × M, avec M la masse molaire", "n = ρ × V, avec ρ la masse volumique"],
      "bonne_reponse": [
        1
      ],
      "explication": "Masse pour un solide, volume pour un gaz : c'est la donnée de l'énoncé qui décide.",
      "piege": "Appliquer m/M à un volume gazeux.",
      "image": null,
      "tags": [
        "formule"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-27",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Quel est le rôle du générateur dans une électrolyse ?",
      "options": ["séparer les électrodes, en imposant une distance fixe", "accélérer la réaction spontanée, en apportant de la chaleur", "forcer la réaction dans le sens inverse du sens spontané", "chauffer l'électrolyte, en dissipant sa puissance dedans"],
      "bonne_reponse": [
        2
      ],
      "explication": "Sans cet apport d'énergie, le système évoluerait dans l'autre sens.",
      "piege": "Le comparer à un catalyseur, qui n'agit que sur la vitesse.",
      "image": null,
      "tags": [
        "definition"
      ],
      "actif": true
    },
    {
      "ref": "ele-28",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "QT 8",
      "enonce": "Un accumulateur est un dispositif qui :",
      "options": ["produit du courant en permanence, sans jamais s'épuiser", "ne peut être utilisé qu'une fois, la réaction étant irréversible", "fonctionne sans électrolyte, les électrodes suffisant au transfert", "stocke de l'énergie sous forme chimique et se recharge"],
      "bonne_reponse": [
        3
      ],
      "explication": "En décharge il fonctionne comme une pile ; en charge, il subit une transformation forcée.",
      "piege": "Le confondre avec une pile ordinaire, non rechargeable.",
      "image": null,
      "tags": [
        "definition"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-29",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "QT 8",
      "enonce": "Qu'est-ce qui permet à un accumulateur d'être rechargé ?",
      "options": ["la réversibilité des deux transformations, spontanée puis forcée", "son électrolyte liquide, qui se renouvelle à chaque charge", "sa faible résistance interne, qui limite les pertes en charge", "sa grande capacité, qui autorise plusieurs cycles successifs"],
      "bonne_reponse": [
        0
      ],
      "explication": "C'est la phrase attendue : les deux transformations sont inverses l'une de l'autre.",
      "piege": "Justifier par une propriété matérielle plutôt que par la réversibilité.",
      "image": null,
      "tags": [
        "redaction"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-30",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "application",
      "source_qt": "QT 8",
      "enonce": "Pendant la <b>charge</b> d'un accumulateur, la transformation est :",
      "options": [
        "spontanée",
        "forcée",
        "identique à la décharge",
        "impossible"
      ],
      "bonne_reponse": [
        1
      ],
      "explication": "On lui apporte de l'énergie électrique : c'est l'inverse exact de la décharge.",
      "piege": "Croire que la charge et la décharge suivent le même sens d'évolution.",
      "image": null,
      "tags": [
        "calcul"
      ],
      "diagnostic": false,
      "actif": true
    },
    {
      "ref": "ele-31",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "methode",
      "source_qt": "typologie",
      "enonce": "Quelle règle reste identique entre pile et électrolyse ?",
      "options": ["la polarité des électrodes : ⊖ à l'anode, ⊕ à la cathode", "le sens du courant, qui va toujours du ⊕ vers le ⊖ dehors", "Anode → Oxydation, Cathode → Réduction, et cations → cathode", "Anode → Réduction, Cathode → Oxydation, et anions → cathode"],
      "bonne_reponse": [
        2
      ],
      "explication": "Seule la polarité change : dans la pile l'anode est le ⊖, en électrolyse elle est reliée au ⊕.",
      "piege": "Tout réapprendre alors qu'une seule chose diffère.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "actif": true
    },
    {
      "ref": "ele-32",
      "chapitre": "transformations-forcees-et-electrolyse",
      "niveau": "terminale",
      "type_question": "choix_simple",
      "difficulte": "cours",
      "source_qt": "socle",
      "enonce": "Quelle grandeur permet de relier la chimie et l'électricité dans ce chapitre ?",
      "options": [
        "le quotient de réaction Q<sub>r</sub>",
        "la constante d'équilibre K(T)",
        "la masse molaire",
        "la constante de Faraday F"
      ],
      "bonne_reponse": [
        3
      ],
      "explication": "F = 9,65×10⁴ C·mol⁻¹ convertit une quantité de matière d'électrons en charge électrique.",
      "piege": "Chercher le lien dans une grandeur purement chimique.",
      "image": null,
      "tags": [
        "raisonnement"
      ],
      "diagnostic": false,
      "actif": true
    },
    {"ref": "electrolyse-t01", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 1", "enonce": "Une transformation est forcée lorsque :", "options": ["elle est totale, tout l'avancement maximal étant atteint", "elle libère de l'énergie, que le générateur récupère ensuite", "le système évolue à l'inverse du sens spontané, par apport d'énergie", "elle est très rapide, le générateur accélérant la cinétique"], "bonne_reponse": [2], "explication": "On compare Q_r à K : si le système évolue dans le sens où Q_r s'éloigne de K, c'est forcé. Un générateur fournit l'énergie nécessaire.", "piege": "Confondre forcée et rapide ou totale : le critère est le sens d'évolution par rapport au sens spontané.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "electrolyse-t02", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 2", "enonce": "Dans un électrolyseur, l'anode est reliée :", "options": ["à aucun pôle : c'est l'électrode neutre", "au pôle + du générateur ; il s'y produit une réduction", "au pôle − du générateur ; il s'y produit une réduction", "au pôle + du générateur ; il s'y produit une oxydation"], "bonne_reponse": [3], "explication": "Anode = oxydation, toujours. Le générateur y pompe les électrons : elle est reliée à son pôle +. La cathode, reliée au −, reçoit les électrons pour la réduction.", "piege": "Reprendre la polarité de la pile : en électrolyse, l'anode est POSITIVE.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "electrolyse-t03", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 3", "enonce": "Dans un électrolyseur en fonctionnement, les anions de la solution se déplacent :", "options": ["ils ne se déplacent pas, seuls les électrons circulant", "vers la cathode, où ils peuvent être réduits", "vers l'anode, où ils peuvent être oxydés", "dans le fil électrique, jusqu'au générateur"], "bonne_reponse": [2], "explication": "Les anions, négatifs, sont attirés par l'anode positive. Les cations vont vers la cathode. Dans les fils, seuls les électrons circulent, du + vers le − du générateur… vu du circuit extérieur, du − du générateur vers la cathode.", "piege": "Inverser anions et cations : les anions vont à l'ANode, les cations à la CAThode — le mot le dit.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "electrolyse-t04", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 4", "enonce": "Un électrolyseur fonctionne sous I = 2,0 A pendant 30 min. La quantité d'électricité transférée vaut :", "options": ["Q = I·Δt = 2,0 × 30 = 60 C", "Q = I/Δt = 1,1 × 10⁻³ C", "Q = Δt/I = 9,0 × 10² C", "Q = I·Δt = 2,0 × 1 800 = 3,6 × 10³ C"], "bonne_reponse": [3], "explication": "Q = I·Δt, avec Δt en SECONDES : 30 min = 1 800 s. On en tire n(e⁻) = Q/F.", "piege": "Laisser la durée en minutes : le coulomb est un ampère-seconde.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "electrolyse-t05", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 5", "enonce": "À la cathode, Cu²⁺ + 2e⁻ → Cu. Avec n(e⁻) = 0,040 mol, la masse de cuivre déposée (M = 63,5 g·mol⁻¹) vaut :", "options": ["m = n(e⁻)·M/F = 2,6 × 10⁻⁵ g", "n(Cu) = n(e⁻) = 0,040 mol, donc m = 2,5 g", "n(Cu) = 2·n(e⁻) = 0,080 mol, donc m = 5,1 g", "n(Cu) = n(e⁻)/2 = 0,020 mol, donc m = 0,020 × 63,5 = 1,3 g"], "bonne_reponse": [3], "explication": "La demi-équation dit qu'il faut 2 électrons par atome de cuivre : n(Cu) = n(e⁻)/2. Puis m = n·M.", "piege": "Oublier le rapport stœchiométrique : c'est la demi-équation qui donne le lien entre électrons et produit.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "electrolyse-t06", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 6", "enonce": "Lors de l'électrolyse de l'eau, il se forme à la cathode un gaz qui :", "options": ["est le dioxygène O₂, produit par oxydation : 2 H₂O → O₂ + 4 H⁺ + 4e⁻", "est le dihydrogène H₂, produit par réduction : 2 H₂O + 2e⁻ → H₂ + 2 HO⁻", "est le dioxygène O₂, produit par réduction : O₂ + 4e⁻ → 2 O²⁻", "est le dichlore Cl₂, produit par oxydation : 2 Cl⁻ → Cl₂ + 2e⁻"], "bonne_reponse": [1], "explication": "À la cathode, réduction : l'eau capte des électrons et libère H₂. À l'anode, oxydation : O₂. Le volume de H₂ est double de celui de O₂.", "piege": "Attribuer O₂ à la cathode : la réduction produit le gaz de l'élément le plus réduit, l'hydrogène.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "electrolyse-t07", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 7", "enonce": "Un électrolyseur consomme une énergie électrique E_élec = 5,0 × 10⁵ J et produit du dihydrogène dont l'énergie chimique stockée vaut E_chim = 3,5 × 10⁵ J. Son rendement vaut :", "options": ["η = E_chim/E_élec = 3,5/5,0 = 0,70, soit 70 %", "η = E_élec/E_chim = 1,4", "η = E_élec − E_chim = 1,5 × 10⁵ J", "η = E_chim × E_élec"], "bonne_reponse": [0], "explication": "Rendement = énergie utile / énergie fournie. Ici l'énergie utile est celle stockée dans le produit ; le reste est perdu en chaleur.", "piege": "Inverser le rapport : un rendement est toujours inférieur à 1.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true},
    {"ref": "electrolyse-t08", "chapitre": "electrolyse", "niveau": "terminale", "type_question": "choix_simple", "difficulte": "cours", "source_qt": "QT 8", "enonce": "Un accumulateur est un système qui :", "options": ["fonctionne en pile à la décharge et en électrolyseur à la charge", "ne fonctionne qu'en pile, la charge se faisant par ajout de réactif", "ne fonctionne qu'en électrolyseur, le courant venant du dehors", "produit de l'électricité sans réaction chimique, par simple contact"], "bonne_reponse": [0], "explication": "Décharge : transformation spontanée, l'accumulateur fournit du courant. Charge : un générateur impose la transformation inverse, forcée, qui régénère les réactifs.", "piege": "Croire que la charge « remplit » l'accumulateur d'électrons : elle inverse une réaction chimique.", "image": null, "tags": ["positionnement"], "diagnostic": true, "actif": true}
  ],
};

export const TITRES_QT = {
  "cinetique": {
    "QT 1": "Établir l'équation différentielle vérifiée par [R]",
    "QT 2": "Vérifier qu'une expression est solution de cette équation",
    "QT 3": "Déterminer une constante d'intégration",
    "QT 4": "Déterminer graphiquement une vitesse de consommation",
    "QT 5": "Déterminer graphiquement une vitesse de formation",
    "QT 6": "Justifier graphiquement l'évolution de la vitesse",
    "QT 7": "Déterminer et définir t½ graphiquement",
    "QT 8": "Montrer que t½ = ln(2)/k",
    "QT 9": "Déterminer k à partir d'un graphe",
    "QT 10": "Identifier un intermédiaire réactionnel",
    "QT 11": "Identifier le catalyseur d'un mécanisme",
    "QT 12": "Représenter les flèches courbes d'une étape",
    "QT 13": "Déterminer une espèce manquante A",
    "socle": "Transformations, facteurs cinétiques, définitions",
    "vitesse de formation": "Le cas d'un produit : la vitesse de formation",
    "mécanismes": "Actes élémentaires, intermédiaires, flèches courbes",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "son": {
    "QT 1": "Définir une onde progressive et une onde sonore",
    "QT 2": "Déterminer une célérité ou un retard",
    "QT 3": "Déterminer graphiquement la période T et la fréquence f",
    "QT 4": "Déterminer graphiquement la longueur d'onde λ",
    "QT 5": "Relier λ, T, f et v",
    "QT 6": "Calculer l'intensité sonore à x mètres de la source",
    "QT 7": "Calculer le niveau sonore L(x)",
    "QT 8": "Montrer que I = I₀ × 10^(L/10)",
    "QT 9": "Calculer une atténuation",
    "QT 10": "Montrer que doubler la distance atténue de 6 dB",
    "QT 11": "Déterminer le niveau sonore de x sources identiques",
    "socle": "L'onde sonore, intensité et niveau sonore"
  },
  "doppler": {
    "QT 1": "Définir l'effet Doppler",
    "QT 2": "Caractériser une onde par sa double périodicité",
    "QT 3": "Montrer que λ_R = λ_E(c + v)/c lorsque la source s'éloigne",
    "QT 4": "Montrer que λ_R = λ_E(c − v)/c lorsque la source se rapproche",
    "QT 5": "Montrer que λ_R = λ_E(1 ∓ v/c)",
    "QT 6": "Montrer que v = c(1 − λ_R/λ_E)",
    "QT 7": "Déterminer la vitesse de la source à partir de f_A et f_É",
    "QT 8": "Déterminer le signe du décalage Δf et le sens du mouvement",
    "QT 9": "Interpréter un décalage spectral et calculer une vitesse radiale",
    "socle": "Caractéristiques d'une onde : λ, T, f et c"
  },
  "diffraction": {
    "QT 1": "Vérifier si le phénomène de diffraction se produit",
    "QT 2": "Montrer que L = 2λD/a",
    "QT 3": "Déterminer L sur le graphe I = f(x)",
    "QT 4": "Exploiter L = 2λD/a numériquement",
    "QT 5": "Exploiter la droite L = f(1/a)",
    "QT 6": "Déterminer λ à partir du graphe θ = f(1/a)",
    "QT 7": "Dire comment évolue L quand a varie",
    "QT 8": "Énoncer les conditions d'obtention d'interférences",
    "QT 9": "Montrer que l'interfrange vaut i = λD/b",
    "QT 10": "Mesurer l'interfrange sur une figure d'interférences",
    "QT 11": "Déterminer i sur le graphe I = f(x)",
    "QT 12": "Déterminer la nature d'une frange",
    "QT 13": "Montrer que la frange centrale est brillante",
    "socle": "Diffraction : définition et condition d'obtention"
  },
  "lumiere": {
    "QT 1": "Calculer l'énergie d'un photon et situer son domaine spectral",
    "QT 2": "Déterminer la longueur d'onde associée à une transition",
    "QT 3": "Distinguer les trois interactions lumière-matière",
    "QT 4": "Déterminer si l'effet photoélectrique se produit",
    "QT 5": "Calculer la vitesse d'éjection d'un électron",
    "QT 6": "Expliquer l'effet photovoltaïque",
    "QT 7": "Calculer le rendement d'une cellule",
    "socle": "Le photon, son énergie et la quantification"
  },
  "lunette": {
    "QT 1": "Construire l'image donnée par une lentille convergente",
    "QT 2": "Exploiter la relation de conjugaison et le grandissement",
    "QT 3": "Montrer que l'image d'un objet à l'infini se forme dans le plan focal image",
    "QT 4": "Justifier qu'une lunette est afocale et donner sa longueur",
    "QT 5": "Construire la marche des rayons dans une lunette afocale",
    "QT 6": "Montrer que le grossissement vaut G = f′_obj/f′_oc",
    "QT 7": "Déterminer l'angle sous lequel on voit un objet, et dire s'il est visible",
    "QT 8": "Choisir l'oculaire ou calculer le grossissement minimal",
    "socle": "Lentille convergente : vocabulaire et relations"
  },
  "acidebase": {
    "QT 1": "Définir un acide et une base selon Brønsted",
    "QT 2": "Écrire la demi-équation d'un couple acide/base",
    "QT 3": "Écrire l'équation d'une réaction acide-base",
    "QT 4": "Justifier le caractère acide ou basique d'une espèce",
    "QT 5": "Citer les couples de l'eau et justifier son caractère amphotère",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "forceacide": {
    "QT 1": "Écrire l'autoprotolyse de l'eau et exprimer Ke",
    "QT 2": "Décider si un acide est fort ou faible",
    "QT 3": "Retrouver la relation d'Henderson",
    "QT 4": "Déterminer le pH à partir de la concentration en ion hydroxyde",
    "QT 5": "Montrer que le pH d'une solution acide est inférieur à 7",
    "QT 6": "Déterminer [H₃O⁺] à partir de Ka et de C",
    "QT 7": "Montrer que [A⁻]/[AH] = 10^(pH − pKa)",
    "QT 8": "Montrer que [AH]/C × 100 = 100/(1 + 10^(pH − pKa))",
    "QT 9": "Exprimer Ka en fonction du taux d'avancement τ",
    "QT 10": "Exploiter un diagramme de prédominance ou de distribution",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "analyse": {
    "QT 1": "Lire un spectre infrarouge",
    "QT 2": "Identifier une espèce à partir de son spectre infrarouge",
    "QT 3": "Relier conductance et conductivité",
    "QT 4": "Exprimer σ en fonction de la concentration C",
    "QT 5": "Justifier le domaine de validité et la dilution préalable",
    "QT 6": "Exploiter la loi de Beer-Lambert",
    "QT 7": "Choisir la longueur d'onde de travail et justifier une couleur",
    "QT 8": "Réaliser un dosage par étalonnage",
    "QT 9": "Exploiter une mesure de pression"
  },
  "rc": {
    "QT 1": "Relier charge, tension et intensité",
    "QT 2": "Établir l'équation différentielle vérifiée par u_C lors de la charge",
    "QT 3": "Montrer qu'une expression est solution de l'équation différentielle",
    "QT 4": "Déterminer les constantes de la solution",
    "QT 5": "Déterminer la tension aux bornes du conducteur ohmique",
    "QT 6": "Établir l'équation différentielle et la solution lors de la décharge",
    "QT 7": "Déterminer τ graphiquement",
    "QT 8": "Déterminer R ou C, et vérifier l'unité de τ",
    "QT 9": "Déterminer la durée du régime transitoire",
    "socle": "Le condensateur et ses relations",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "radioactivite": {
    "QT 1": "Identifier le noyau fils par les lois de Soddy",
    "QT 2": "Nommer la particule émise",
    "QT 3": "Prévoir le mode de désintégration à partir du diagramme (N,Z)",
    "QT 4": "Écrire l'équation de désintégration d'un noyau du diagramme",
    "QT 5": "Écrire une suite de réactions nucléaires",
    "QT 6": "Établir l'équation différentielle vérifiée par N(t)",
    "QT 7": "Montrer que N(t) = N₀·e^(−λt) est solution et déterminer la constante",
    "QT 8": "Montrer que t₁/₂ = ln(2)/λ",
    "QT 9": "Déterminer graphiquement la demi-vie",
    "QT 10": "Montrer que A(t) = A₀·e^(−λt)",
    "QT 11": "Dater un échantillon par le calcul",
    "QT 12": "Estimer un âge en comptant les demi-vies",
    "QT 13": "Justifier qu'un radionucléide est adapté à une datation",
    "socle": "Les quatre types de radioactivité, isotopes et activité",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "piles": {
    "QT 1": "Déterminer si une transformation est totale ou limitée",
    "QT 2": "Exprimer le quotient de réaction Q_r",
    "QT 3": "Prévoir le sens d'évolution spontanée",
    "QT 4": "Exprimer la constante d'équilibre K(T)",
    "QT 5": "Déterminer x_eq à partir de K(T)",
    "QT 6": "Identifier l'anode, la cathode et la polarité d'une pile",
    "QT 7": "Écrire les demi-équations et l'équation de fonctionnement",
    "QT 8": "Déterminer le sens de déplacement des porteurs de charge",
    "QT 9": "Déterminer la capacité et la durée de vie d'une pile",
    "socle": "Transformation totale ou limitée, quotient de réaction",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "titrages": {
    "QT 1": "Justifier les propriétés de la réaction support",
    "QT 2": "Établir la relation à l'équivalence et calculer la concentration",
    "QT 3": "Déterminer V_éq en laissant apparaître les traits de construction",
    "QT 4": "Justifier le choix d'un indicateur coloré",
    "QT 5": "Justifier l'allure d'une courbe conductimétrique",
    "QT 6": "Expliquer pourquoi on ajoute de l'eau à la solution titrée",
    "QT 7": "Remonter à la solution commerciale et au pourcentage en masse",
    "QT 8": "Évaluer la cohérence du résultat",
    "socle": "But du titrage, montage et réaction support",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "synthese": {
    "QT 1": "Définir la stratégie de synthèse et le rendement",
    "QT 2": "Justifier l'emploi d'un montage à reflux et le légender",
    "QT 3": "Citer les quatre étapes d'une synthèse organique",
    "QT 4": "Justifier le choix d'un solvant d'extraction",
    "QT 5": "Exploiter une chromatographie sur couche mince",
    "QT 6": "Exploiter un banc Kofler",
    "QT 7": "Identifier la catégorie d'une réaction",
    "QT 8": "Expliquer une protection puis une déprotection de fonction",
    "QT 9": "Déterminer le rendement d'une synthèse",
    "QT 10": "Reconnaître les trois types d'isomérie de constitution",
    "socle": "But, rendement et étapes d'une synthèse",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "thermo": {
    "QT 1": "Décrire un système thermodynamique et justifier le modèle du gaz parfait",
    "QT 2": "Relier les échelles microscopique et macroscopique",
    "QT 3": "Calculer ΔU et appliquer le premier principe",
    "QT 4": "Exploiter le flux thermique et la résistance thermique",
    "QT 5": "Distinguer les trois modes de transfert thermique",
    "QT 6": "Effectuer un bilan radiatif du système Terre-atmosphère",
    "QT 7": "Établir l'équation différentielle vérifiée par T(t)",
    "QT 8": "Déterminer les constantes de la solution T(t) = A·e^(−t/τ) + B",
    "QT 9": "Déterminer τ graphiquement, puis une date t",
    "QT 10": "Montrer que T(t) = (T_i − T_ther)·e^(−t/τ) + T_ther est solution",
    "socle": "Systèmes, gaz parfait et énergie interne",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "electrolyse": {
    "QT 1": "Montrer qu'une transformation est forcée",
    "QT 2": "Indiquer la polarité des électrodes et leur rôle",
    "QT 3": "Déterminer le sens de déplacement des porteurs de charge",
    "QT 4": "Déterminer la quantité d'électricité transférée",
    "QT 5": "Déterminer la quantité de matière et la masse de produit formé",
    "QT 6": "Identifier le gaz formé à une électrode",
    "QT 7": "Déterminer le rendement d'un électrolyseur",
    "QT 8": "Expliquer le rôle du générateur et le principe d'un accumulateur",
    "socle": "Transformation forcée, quantité d'électricité et constante de Faraday",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "cinematique": {
    "QT 1": "Faire le bilan des forces sur un système",
    "QT 2": "Écrire l'expression vectorielle d'une force",
    "QT 3": "Caractériser un mouvement",
    "QT 4": "Déterminer un vecteur vitesse sur une chronophotographie",
    "QT 5": "Tracer un vecteur accélération",
    "QT 6": "Déterminer les coordonnées de la vitesse et de l'accélération",
    "QT 7": "Montrer qu'un mouvement est uniformément accéléré",
    "QT 8": "Déterminer une vitesse graphiquement ou à partir de coordonnées",
    "QT 9": "Établir les équations horaires d'un mouvement",
    "QT 10": "Déterminer l'accélération d'un mouvement circulaire uniforme",
    "socle": "Système, référentiel et forces du programme",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "newton": {
    "QT 1": "Énoncer la première loi de Newton",
    "QT 2": "Énoncer la deuxième loi de Newton",
    "QT 3": "Énoncer la troisième loi de Newton",
    "QT 4": "Déterminer la norme d'une force avec la première loi",
    "QT 5": "Déterminer les équations horaires avec la deuxième loi",
    "méthode": "Passer de l'écriture vectorielle à l'écriture scalaire",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "champuniforme": {
    "QT 1": "Établir les équations horaires d'une chute libre verticale",
    "QT 2": "Établir les équations horaires d'une chute parabolique",
    "QT 3": "Établir l'équation de la trajectoire z(x)",
    "QT 4": "Déterminer la portée",
    "QT 5": "Déterminer la flèche",
    "QT 6": "Montrer que le poids est négligeable devant la force électrique",
    "QT 7": "Établir les équations horaires d'une charge dans un champ électrique",
    "socle": "Chute libre et champ électrique uniforme",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "kepler": {
    "QT 1": "Énoncer les trois lois de Kepler",
    "QT 2": "Déterminer le demi-grand axe d'une orbite",
    "QT 3": "Montrer que la vitesse à l'apoastre est plus faible qu'au périastre",
    "QT 4": "Déterminer la période d'un astre par la 3ᵉ loi",
    "QT 5": "Déterminer la masse de l'astre attracteur à partir de T² = f(a³)",
    "QT 6": "Montrer que l'accélération d'un satellite est centripète",
    "QT 7": "Montrer que le mouvement est circulaire uniforme",
    "QT 8": "Déterminer la vitesse et la période de révolution d'un satellite",
    "QT 9": "Retrouver la 3ᵉ loi de Kepler",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "energie": {
    "QT 1": "Calculer le travail d'une force constante",
    "QT 2": "Calculer le travail du poids",
    "QT 3": "Calculer le travail des frottements et de la force électrostatique",
    "QT 4": "Distinguer force conservative et force dissipative",
    "QT 5": "Appliquer le théorème de l'énergie mécanique",
    "QT 6": "Appliquer le théorème de l'énergie cinétique",
    "QT 7": "Identifier les courbes d'évolution des énergies",
    "QT 8": "Résoudre un problème de mécanique par l'énergie",
    "socle": "Travail, énergies et théorèmes",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  },
  "fluides": {
    "QT 1": "Donner les caractéristiques de la poussée d'Archimède",
    "QT 2": "Déterminer si le système étudié est à l'équilibre",
    "QT 3": "Énoncer les hypothèses simplificatrices de l'écoulement",
    "QT 4": "Montrer que le débit volumique vaut D_V = S × v",
    "QT 5": "Montrer que le débit volumique se conserve",
    "QT 6": "Montrer que si la section diminue, la vitesse augmente",
    "QT 7": "Expliquer l'effet Venturi : si la section diminue, la pression diminue",
    "socle": "Masse volumique, débit et relation de Bernoulli",
    "typologie": "Les formulations qui tombent, et le piège de chacune"
  }
};

export const RAPPELS_QT = {
  "cinetique": {
    "QT 1": ["v = − d[R]/dt (définition) et v = k·[R] (ordre 1)", "on égale les deux : d[R]/dt + k·[R] = 0"],
    "QT 2": ["on dérive [R]₀·e⁻ᵏᵗ, on reporte dans l'équation", "on montre que le résultat vaut 0 — la condition initiale ne suffit pas"],
    "QT 3": ["à t = 0, l'exponentielle vaut 1, donc [R](0) = A", "on identifie : A = [R]₀"],
    "QT 4": ["la vitesse est l'opposé du coefficient directeur de la tangente", "on nomme deux points de la TANGENTE, puis on calcule la pente", "v = − pente, puis application numérique et unité en mol·L⁻¹·s⁻¹", "conclusion : les tangentes s'aplatissent, donc la vitesse diminue", "le calcul complet, réactif et produit, est détaillé au paragraphe « vitesse de formation »"],
    "QT 5": ["définition : [R](t½) = [R]₀/2", "trois traits à laisser visibles : repérer [R]₀/2, rejoindre la courbe, lire l'abscisse"],
    "QT 6": ["on pose [R]₀·e⁻ᵏᵗ½ = [R]₀/2, on simplifie par [R]₀", "on prend le logarithme : t½ = ln(2)/k — indépendant de [R]₀"],
    "QT 7": ["v = f([R]) : linéaire, pente = k", "ln([R]) = f(t) : affine, pente = −k, ordonnée ln([R]₀)", "ln([R]/[R]₀) = f(t) : linéaire, pente = −k"],
    "QT 8": ["partir de [R](t½) = [R]₀/2 avec [R] = [R]₀·e^(−kt)", "simplifier par [R]₀, appliquer ln : −k·t½ = −ln 2", "t½ = ln 2/k, indépendant de la concentration initiale"],
    "QT 9": ["tracer ln([R]/[R]₀) en fonction de t : droite de pente −k", "k est l'OPPOSÉ de la pente, toujours positive", "unité : l'inverse de celle du temps, s⁻¹ ou min⁻¹"],
    "QT 10": ["intermédiaire : FORMÉ dans une étape, CONSOMMÉ dans une suivante", "absent du bilan, n'existe qu'en cours de réaction", "à distinguer du catalyseur, qui suit l'ordre inverse"],
    "QT 11": ["catalyseur : CONSOMMÉ dans une étape, RÉGÉNÉRÉ plus loin", "absent du bilan, présent avant et après", "il accélère sans modifier l'état final"],
    "QT 12": ["une flèche courbe suit un DOUBLET d'électrons", "elle part du site donneur — doublet libre ou liaison — vers le site accepteur", "ce n'est pas le sens de la réaction, c'est un déplacement d'électrons"],
    "QT 13": ["compter chaque élément à gauche et à droite", "ce qui manque est l'espèce A — vérifier aussi la charge", "le bilan atomique se vérifie, il ne se devine pas"],
    "mécanismes": ["intermédiaire : formé puis consommé", "catalyseur : consommé puis régénéré", "la flèche courbe va du site donneur vers le site accepteur"],
    "socle": ["v en mol·L⁻¹·s⁻¹, k en s⁻¹ pour l'ordre 1", "facteurs cinétiques : température et concentration initiale", "catalyseur : accélère sans figurer au bilan"],
    "typologie": ["chaque formulation d'énoncé appelle une rédaction précise", "le piège de chacune est listé en fin de fiche"],
    "vitesse de formation": ["<b>Le calcul, en trois lignes, sur un exemple</b> — décomposition de l'eau oxygénée, 2 H₂O₂ → 2 H₂O + O₂, suivie à partir de [H₂O₂]₀ = 0,080 mol·L⁻¹.", "<b>Vitesse de consommation d'un réactif.</b> On trace la tangente à la courbe [H₂O₂] = f(t) à la date voulue, on relève deux points de cette tangente, et l'on calcule sa pente.", "v(H₂O₂) = − d[H₂O₂]/dt = − pente de la tangente", "v(H₂O₂) = − (0 − 0,080) / (83 − 0)", "<b>v(H₂O₂) = 9,6×10⁻⁴ mol·L⁻¹·s⁻¹</b>", "Le signe − rend la vitesse positive : la concentration du réactif décroît, donc la pente est négative.", "<b>Vitesse de formation d'un produit.</b> Même construction sur la courbe [O₂] = f(t), mais la pente est positive : il n'y a pas de signe −.", "v(O₂) = + d[O₂]/dt = pente de la tangente", "<b>Le lien entre les deux, par la stœchiométrie.</b> Pour 2 H₂O₂ → 2 H₂O + O₂, il se forme une mole de O₂ pour deux moles de H₂O₂ consommées.", "v(O₂) = v(H₂O₂) / 2", "v(O₂) = 9,6×10⁻⁴ / 2", "<b>v(O₂) = 4,8×10⁻⁴ mol·L⁻¹·s⁻¹</b>", "Règle générale : pour a A → b B, on a v(A)/a = v(B)/b. Diviser chaque vitesse par son coefficient stœchiométrique donne la même valeur.", "<b>Les trois pièges.</b> Oublier le signe − pour un réactif, ce qui donne une vitesse négative. Oublier le coefficient stœchiométrique, ce qui confond les deux vitesses. Et lire la pente sur la courbe au lieu de la lire sur la tangente."]
  },
  "son": {
    "QT 1": ["onde mécanique : perturbation dans un milieu matériel", "transport d'énergie, sans transport de matière", "longitudinale : propagation parallèle à la perturbation"],
    "QT 2": ["retard τ = durée entre l'émission et la réception", "d = v·τ, ou v = d/τ : bien identifier ce que l'on cherche", "la lumière arrive quasi instantanément, seul le son est retardé"],
    "QT 3": ["mesurer PLUSIEURS périodes puis diviser par leur nombre", "T se lit sur un axe des temps, en secondes", "f = 1/T, en hertz — convertir les millisecondes avant"],
    "QT 4": ["λ se lit sur un axe des POSITIONS, en mètres", "plus petite distance entre deux points dans le même état vibratoire", "mesurer plusieurs longueurs d'onde puis diviser"],
    "QT 5": ["λ = v·T = v/f : distance parcourue pendant une période", "la fréquence est imposée par la source, elle ne change jamais", "changer de milieu change v, donc λ, jamais f"],
    "QT 6": ["l'énergie se répartit sur la sphère de rayon x : S = 4πx²", "I = P/S = P/(4πx²), en W·m⁻²"],
    "QT 7": ["méthode 1 — on part de L = 10·log(I/I₀), puis I = P/(4πx²)", "méthode 2 — si l'atténuation est donnée : L(x) = L₁ − A"],
    "QT 8": ["L = 10·log(I/I₀) ⟺ L/10 = log(I/I₀)", "on prend la puissance de 10, coin maths 10^log(X) = X", "I = I₀ × 10^(L/10)"],
    "QT 9": ["A = L₁ − L₂, toujours une différence de niveaux, en dB", "par absorption : A = L_i − L′ · géométrique : A = L_P − L_L"],
    "QT 10": ["A = 10·log(I_d/I_2d) après factorisation et regroupement", "I_d = P/(4πd²) et I_2d = P/(16πd²) : il reste A = 10·log(4) ≈ 6,0 dB"],
    "QT 11": ["les intensités s'additionnent, jamais les niveaux", "L(x) = 10·log(x) + L(1 source)", "doubler le nombre de sources ajoute 3 dB, le multiplier par dix ajoute 10 dB"],
    "socle": ["I en W·m⁻², L en dB, I₀ = 1,0×10⁻¹² W·m⁻²", "×10 sur l'intensité = +10 dB · ×2 = +3 dB", "repères : 0 · 20 · 60 · 85 · 120 dB"]
  },
  "doppler": {
    "QT 1": [
      "phénomène ondulatoire, mouvement relatif source-récepteur",
      "la fréquence perçue f_R diffère de la fréquence émise f_E"
    ],
    "QT 2": [
      "double périodicité : période temporelle T, période spatiale λ",
      "λ = c × T = c/f",
      "la fréquence est imposée par la source : elle ne change pas de milieu"
    ],
    "QT 3": [
      "on part de f_R = f_E·c/(c + v), on remplace f par c/λ",
      "λ_R = λ_E(c + v)/c > λ_E : la longueur d'onde perçue augmente"
    ],
    "QT 4": [
      "même démarche avec c − v au dénominateur",
      "λ_R = λ_E(c − v)/c &lt; λ_E"
    ],
    "QT 5": [
      "on factorise le numérateur par c, puis on simplifie",
      "rapprochement : λ_R = λ_E(1 − v/c) · éloignement : (1 + v/c)"
    ],
    "QT 6": [
      "on divise par λ_E, on ajoute −1, on multiplie par −1, puis par c",
      "v = c(1 − λ_R/λ_E)"
    ],
    "QT 7": [
      "on écrit f_A = f_E·c/(c − v) et f_É = f_E·c/(c + v)",
      "le rapport f_A/f_É élimine f_E",
      "v = c·(f_A − f_É)/(f_A + f_É)"
    ],
    "QT 8": [
      "Δf > 0 → f_R > f_E → son plus aigu → la source se rapproche",
      "Δf &lt; 0 → la source s'éloigne · Δf = 0 → pas de mouvement relatif"
    ],
    "QT 9": [
      "λ_R > λ_E → décalage vers le rouge → l'astre s'éloigne",
      "v = c(1 − λ_R/λ_E), puis on vérifie que v/c ≪ 1"
    ],
    "socle": [
      "λ = c × T = c/f · f = 1/T",
      "la fréquence est imposée par la source",
      "rapprochement : c − v · éloignement : c + v"
    ]
  },
  "diffraction": {
    "QT 1": ["a ≃ λ ou a ≪ λ · en pratique a ≲ 100 λ pour la lumière", "on calcule le rapport et on écrit la comparaison — jamais à l'œil"],
    "QT 2": ["tan θ = (L/2)/D dans le triangle rectangle", "approximation des petits angles : tan θ ≈ θ", "or θ = λ/a, donc L = 2λD/a"],
    "QT 3": ["convertir nm et μm en mètres avant tout calcul", "L = 2λD/a — ne pas oublier le facteur 2", "pour remonter à a : a = 2λD/L"],
    "QT 4": ["deux ondes de même nature et de même fréquence", "condition discriminante : une source unique, donc des ondes cohérentes", "deux lampes distinctes ne donnent jamais d'interférences"],
    "QT 5": ["i = x_(k+1) − x_k, avec δ = k·λ et δ = b·x_k/D", "x_k = k·λD/b, donc i = λD/b — indépendant de k"],
    "QT 6": ["on mesure le plus grand nombre d'interfranges possible, puis on divise", "justification : l'erreur relative est divisée d'autant"],
    "QT 7": ["on calcule δ = b·x/D, puis on divise par λ", "quotient entier → frange brillante · demi-entier → frange sombre"],
    "QT 8": ["au centre, les deux trajets sont égaux : δ = 0", "on teste les deux hypothèses : k = 0 convient, k = −½ non", "la frange centrale est donc brillante"],
    "QT 9": ["frange brillante : différence de marche δ = k·λ, k entier", "avec δ ≈ b·x/D, les franges brillantes sont en x_k = kλD/b", "deux voisines sont séparées de i = λD/b"],
    "QT 10": ["mesurer PLUSIEURS interfranges puis diviser", "n franges délimitent n − 1 interfranges", "mesurer de centre à centre, sur des franges de même nature"],
    "QT 11": ["sur I = f(x), i est la distance entre deux maxima consécutifs", "ou entre deux minima consécutifs — même valeur", "un maximum à un minimum ne donne que i/2"],
    "QT 12": ["calculer δ/λ : entier → brillante, demi-entier → sombre", "δ = kλ : les ondes arrivent en phase, constructive", "δ = (k + ½)λ : opposition de phase, destructive"],
    "QT 13": ["au centre, à égale distance des fentes, δ = 0", "0 = 0 × λ : c'est un multiple de λ, k = 0", "interférence constructive : la frange centrale est brillante"],
    "socle": ["diffraction : étalement des directions de propagation", "θ = λ/a et L = 2λD/a", "interférences : δ = k·λ brillante · δ = (k + ½)·λ sombre"]
  },
  "lumiere": {
    "QT 1": [
      "E = h·ν = h·c/λ, avec λ EN MÈTRES",
      "1 eV = 1,60×10⁻¹⁹ J",
      "UV &lt; 400 nm · visible 400–800 nm · IR > 800 nm · un photon visible vaut 2 à 3 eV"
    ],
    "QT 2": [
      "h·ν = |E_f − E_i| : le photon n'interagit que si son énergie vaut l'écart exact",
      "calculer |ΔE|, le convertir en joules, puis λ = h·c/|ΔE|",
      "l'entité monte → absorption · elle descend → émission"
    ],
    "QT 3": [
      "lumière-atome : transitions électroniques, UV-visible, spectre de raies",
      "lumière-molécule : vibrations des liaisons, infrarouge, groupes caractéristiques",
      "lumière-métal : extraction d'un électron, effet photoélectrique"
    ],
    "QT 4": [
      "condition en fréquence : ν ≥ ν_S",
      "condition en longueur d'onde : λ ≤ λ_S — l'inégalité S'INVERSE",
      "augmenter l'intensité ne déclenche jamais l'effet sous le seuil"
    ],
    "QT 5": [
      "conservation de l'énergie : h·ν = ½·m·v² + W_ext",
      "½·m·v² = h·(ν − ν_S), puis v = √(2·h·(ν − ν_S)/m)",
      "contrôle : quelques 10⁵ m·s⁻¹, soit moins de 1 % de c"
    ],
    "QT 6": [
      "l'électron passe de la bande de valence à la bande de conduction si h·ν ≥ E_gap",
      "gap très grand → isolant · gap petit → semi-conducteur · bandes confondues → conducteur",
      "un photon moins énergétique traverse sans produire de courant"
    ],
    "QT 7": [
      "P_lumineuse = E × S, avec E l'éclairement en W·m⁻²",
      "η = P_électrique / P_lumineuse, sans unité, toujours inférieur à 1"
    ],
    "socle": [
      "E = h·c/λ gouverne tout le chapitre",
      "convertir les eV en joules et les nm en mètres avant tout calcul",
      "l'énergie est quantifiée : seuls certains écarts sont possibles"
    ]
  },
  "lunette": {
    "QT 1": [
      "trois rayons issus de B : parallèle à l'axe → passe par F′",
      "par le centre optique O → non dévié · par F → ressort parallèle à l'axe",
      "deux rayons suffisent, le troisième vérifie"
    ],
    "QT 2": [
      "relation de conjugaison, en respectant le caractère algébrique des longueurs",
      "γ = OA′/OA = A′B′/AB, puis conclure : réelle, renversée, agrandie"
    ],
    "QT 3": [
      "objet à l'infini : OA → ∞ donc 1/OA → 0",
      "il reste OA′ = f′ : l'image se forme dans le plan focal image"
    ],
    "QT 4": [
      "afocale ⟺ F′₁ = F₂ : foyer image de l'objectif = foyer objet de l'oculaire",
      "objet à l'infini → image à l'infini : l'œil n'accommode pas",
      "longueur : L = O₁O₂ = f′₁ + f′₂"
    ],
    "QT 5": [
      "rayon par O₁ non dévié · plan focal image de L₁ · convergence en B₁",
      "droite (B₁O₂) : direction de sortie · rayons parallèles à (B₁O₂) après l'oculaire",
      "O₁ et O₂ sur l'axe, chaque rayon fléché"
    ],
    "QT 6": [
      "G = θ′/θ par définition",
      "tan θ = A₁B₁/f′_obj et tan θ′ = A₁B₁/f′_oc, petits angles",
      "G = f′_obj / f′_oc : grande focale à l'objectif, courte à l'oculaire"
    ],
    "QT 7": [
      "θ ≈ d/D, EN RADIANS",
      "visible à l'œil nu si θ > ε, le pouvoir séparateur",
      "avec la lunette : θ′ = G × θ, que l'on compare de nouveau à ε"
    ],
    "QT 8": [
      "G_min = ε/θ = ε × D/d",
      "on identifie avec G = f′_obj/f′_oc",
      "f′_oc = f′_obj × d/(ε × D) : c'est l'oculaire que l'on choisit"
    ],
    "socle": [
      "V = 1/f′ en dioptries, avec f′ en mètres",
      "γ &lt; 0 image renversée · |γ| > 1 image agrandie",
      "les longueurs sont algébriques : un signe change la nature de l'image"
    ]
  },
  "acidebase": {
    "QT 1": [
      "acide : espèce capable de CÉDER un ou plusieurs protons H⁺",
      "base : espèce capable de CAPTER un ou plusieurs protons H⁺",
      "le mot qui rapporte le point est « proton », jamais le pH"
    ],
    "QT 2": [
      "AH = A⁻ + H⁺ : c'est elle qui définit le couple",
      "le couple se note toujours dans l'ordre acide / base",
      "la base conjuguée porte une charge négative de plus que l'acide"
    ],
    "QT 3": [
      "identifier les deux couples et écrire leurs demi-équations",
      "retourner celle de la base qui capte le proton, puis sommer",
      "aucun H⁺ dans le bilan · vérifier les éléments et les charges"
    ],
    "QT 4": [
      "acide : liaison polarisée H—O ou H—N, dont la rupture libère H⁺",
      "base : atome O ou N portant des doublets non liants",
      "ne pas confondre les deux critères"
    ],
    "QT 5": [
      "deux couples : H₃O⁺/H₂O (l'eau est base) et H₂O/HO⁻ (l'eau est acide)",
      "appartenant à deux couples, l'eau est amphotère",
      "conséquence à citer : l'autoprotolyse de l'eau"
    ],
    "typologie": [
      "un acide cède un proton, une base le capte",
      "si un H⁺ subsiste dans le bilan, une demi-équation n'a pas été retournée"
    ]
  },
  "forceacide": {
    "QT 1": [
      "2 H₂O ⇌ H₃O⁺ + HO⁻ — l'eau est amphotère",
      "Ke = [H₃O⁺][HO⁻]/(c⁰)², pKe = 14,0 à 25 °C",
      "ne pas oublier c⁰ = 1 mol·L⁻¹, qui rend Ke sans unité"
    ],
    "QT 2": [
      "méthode 1 : τ = c⁰·10⁻ᵖᴴ/C · τ = 1 acide fort, τ &lt; 1 acide faible",
      "méthode 2 : on suppose l'acide fort, pH = −log(C/c⁰), on compare au pH mesuré",
      "un acide fort n'est pas un acide concentré"
    ],
    "QT 3": [
      "partir de Ka, appliquer −log aux deux membres",
      "séparer les deux logarithmes : c'est l'étape notée",
      "pH = pKa + log([A⁻]/[AH])"
    ],
    "QT 4": [
      "passer par le produit ionique : [H₃O⁺] = Ke·c⁰/[HO⁻]",
      "puis appliquer la définition du pH — jamais directement à [HO⁻]"
    ],
    "QT 5": [
      "partir de [H₃O⁺] > [HO⁻], multiplier par [H₃O⁺] : [H₃O⁺]² > Ke",
      "le passage au −log INVERSE le sens de l'inégalité",
      "conclusion : pH &lt; pKe/2 = 7,0"
    ],
    "QT 6": [
      "tableau d'avancement : [A⁻] = [H₃O⁺] et [AH] = C − [H₃O⁺]",
      "on obtient [H₃O⁺]² + Ka·c⁰·[H₃O⁺] − Ka·C·c⁰ = 0",
      "on garde la racine positive, seule à avoir un sens physique"
    ],
    "QT 7": [
      "[A⁻]/[AH] = Ka·c⁰/[H₃O⁺] = 10^(−pKa)/10^(−pH) = 10^(pH − pKa)",
      "attention au sens de l'exposant : pH − pKa"
    ],
    "QT 8": [
      "combiner la QT 7 avec [AH] = C − [A⁻]",
      "[AH](1 + 10^(pH − pKa)) = C, d'où le pourcentage cherché"
    ],
    "QT 9": [
      "x_eq = τ·C·V, donc [A⁻] = [H₃O⁺] = τ·C et [AH] = C(1 − τ)",
      "Ka = C·τ²/((1 − τ)·c⁰) — ne pas oublier le facteur C"
    ],
    "QT 10": [
      "pH &lt; pKa → AH prédomine · pH > pKa → A⁻ prédomine",
      "un acide est d'autant plus fort que son pKa est faible",
      "sur un diagramme de distribution, le pKa se lit à l'INTERSECTION des courbes"
    ],
    "typologie": [
      "τ est compris entre 0 et 1 : au-delà, un quotient a été inversé",
      "solution tampon : [A⁻] = [AH], donc pH = pKa"
    ]
  },
  "analyse": {
    "QT 1": [
      "ordonnée : transmittance en % — une bande est un CREUX",
      "abscisse : nombre d'onde σ = 1/λ en cm⁻¹, gradué de droite à gauche",
      "sous 1500 cm⁻¹ : empreinte digitale, non interprétable"
    ],
    "QT 2": [
      "deux questions : bande C=O vers 1700 ? bande O—H large ?",
      "O—H seule → alcool · C=O seule → aldéhyde ou cétone · les deux → acide carboxylique",
      "suivi de synthèse : disparition du O—H, apparition du C=O"
    ],
    "QT 3": [
      "σ = G × L/S, avec L/S la constante de cellule en m⁻¹",
      "G = 1/R = I/U s'exprime en siemens (S), σ en S·m⁻¹"
    ],
    "QT 4": [
      "écrire l'équation de dissolution pour obtenir les concentrations effectives",
      "loi de Kohlrausch : σ = Σ λᵢ × [Xᵢ], puis factoriser par C",
      "les concentrations sont en mol·m⁻³ : 1 mol·m⁻³ = 10⁻³ mol·L⁻¹"
    ],
    "QT 5": [
      "Kohlrausch et Beer-Lambert ne valent que pour C &lt; 10⁻² mol·L⁻¹",
      "le facteur de dilution est choisi pour rester dans le domaine de la courbe",
      "« pour faciliter la mesure » ne rapporte rien"
    ],
    "QT 6": [
      "A = ε × ℓ × C = k × C, l'absorbance étant sans unité",
      "C = A/(ε×ℓ), puis vérifier que C &lt; 10⁻² mol·L⁻¹",
      "si ε n'est pas donné, on passe par la droite d'étalonnage"
    ],
    "QT 7": [
      "régler le spectrophotomètre sur λ_max, lu sur le spectre A = f(λ)",
      "la couleur perçue est la COMPLÉMENTAIRE de la couleur absorbée"
    ],
    "QT 8": [
      "vérifier que A = f(C) est une droite passant par l'origine",
      "déterminer k, appliquer à la solution diluée : C_d = A_d/k",
      "remonter à la solution commerciale : C_com = F × C_d"
    ],
    "QT 9": [
      "P·V = n·R·T, donc n = P·V/(R·T)",
      "trois conversions systématiques : P en Pa, V en m³, T = θ + 273 en K"
    ]
  },
  "rc": {
    "QT 1": [
      "i = dq/dt avec q = C·u_C, et C est constante",
      "d'où i = C·du_C/dt — la relation clé du chapitre"
    ],
    "QT 2": [
      "loi des mailles : u_C + u_R = E · loi d'Ohm : u_R = R·i",
      "comportement du condensateur : i = C·du_C/dt",
      "forme canonique attendue : du_C/dt + u_C/τ = E/τ, avec τ = RC"
    ],
    "QT 3": [
      "dériver l'expression, la reporter dans le membre de gauche",
      "montrer qu'on retrouve le second membre E/τ",
      "si la forme est A·e^(−t/τ) + E : dire que l'égalité vaut pour tout t et que l'exponentielle ne s'annule jamais"
    ],
    "QT 4": [
      "DEUX conditions aux limites, pas une seule",
      "à t = 0 le condensateur est déchargé : u_C(0) = 0",
      "en régime permanent u_C → E, donc A = −E et B = E"
    ],
    "QT 5": [
      "u_R = R·i = R·C·du_C/dt = τ·du_C/dt",
      "on dérive u_C : u_R(t) = E·e^(−t/τ), qui DÉCROÎT",
      "contrôle : u_C + u_R = E à tout instant"
    ],
    "QT 6": [
      "même démarche, mais le générateur est retiré : u_C + u_R = 0",
      "du_C/dt + u_C/τ = 0, solution u_C(t) = E·e^(−t/τ)",
      "charge : (1 − e^(−t/τ)) · décharge : e^(−t/τ)"
    ],
    "QT 7": [
      "charge : reporter 0,63 E · décharge : reporter 0,37 E",
      "ou tracer la tangente à l'origine et lire son intersection avec l'asymptote",
      "contrôle : 0,63 + 0,37 = 1"
    ],
    "QT 8": [
      "τ = R × C, donc R = τ/C ou C = τ/R",
      "analyse dimensionnelle : [τ] = (U/I) × (I·Δt/U) = s",
      "convertir les préfixes : ms, μF, kΩ"
    ],
    "QT 9": [
      "le régime permanent est atteint au bout de 5τ",
      "charge : u_C(5τ) = 0,99 E · décharge : 0,01 E",
      "annoncer 5τ NE SUFFIT PAS : le calcul est attendu"
    ],
    "socle": [
      "q = C × u_C · i = dq/dt · C = ε·S/e",
      "grand S → grand C · grand e → petit C"
    ],
    "typologie": [
      "toute la partie calculatoire découle de i = C·du_C/dt",
      "charge : second membre E/τ · décharge : second membre nul"
    ]
  },
  "radioactivite": {
    "QT 1": [
      "lois de Soddy : conservation de A ET de Z, écrites séparément",
      "on identifie ensuite l'élément grâce à Z′ dans la classification"
    ],
    "QT 2": [
      "⁴₂He noyau d'hélium · ⁰₋₁e électron · ⁰₊₁e positon · ¹₀n neutron · γ photon",
      "l'électron du β⁻ est créé dans le noyau, il ne vient pas du cortège"
    ],
    "QT 3": [
      "au-dessus de la vallée : trop de neutrons → β⁻",
      "en dessous : trop de protons → β⁺ · Z > 82 → α · dans la vallée : stable",
      "le diagramme est fourni : il suffit de savoir le lire"
    ],
    "QT 4": [
      "① le diagramme donne le type de désintégration",
      "② les lois de Soddy donnent A′ et Z′",
      "③ la classification donne le symbole du noyau fils"
    ],
    "QT 5": [
      "capture d'un neutron, puis désintégrations successives",
      "chaque équation est équilibrée en A et en Z"
    ],
    "QT 6": [
      "A(t) = −dN/dt par définition, et A(t) = λ·N(t)",
      "en égalant : dN/dt + λ·N = 0"
    ],
    "QT 7": [
      "dériver N₀·e^(−λt), reporter, montrer que le résultat vaut 0",
      "la constante se trouve à t = 0 : C = N₀",
      "ne pas noter A cette constante — A désigne déjà l'activité"
    ],
    "QT 8": [
      "définition : durée au bout de laquelle la moitié des noyaux s'est désintégrée",
      "poser N(t₁/₂) = N₀/2, simplifier par N₀, passer au logarithme",
      "t₁/₂ = ln(2)/λ, indépendant du nombre initial de noyaux"
    ],
    "QT 9": [
      "① repérer N₀/2 · ② rejoindre la courbe · ③ lire l'abscisse",
      "traits de construction à laisser apparents",
      "contrôle : N₀/4 à 2·t₁/₂ et N₀/8 à 3·t₁/₂"
    ],
    "QT 10": [
      "version courte : A = λ·N avec N = N₀·e^(−λt), et λN₀ = A₀",
      "l'activité décroît exactement comme N : même λ, même demi-vie"
    ],
    "QT 11": [
      "on divise par la valeur initiale, on passe au logarithme népérien, on isole t",
      "t = −(1/λ)·ln(N/N₀) — attention au signe"
    ],
    "QT 12": [
      "N = N₀/2ⁿ : 1/2 → 1 demi-vie · 1/4 → 2 · 1/8 → 3 · 1/16 → 4",
      "âge = n × t₁/₂ · « il reste 6,25 % » signifie 1/16, donc 4 demi-vies"
    ],
    "QT 13": [
      "la demi-vie doit être du même ordre de grandeur que la durée à dater, ou plus grande",
      "trop courte : il ne reste plus assez de noyaux pour mesurer"
    ],
    "socle": [
      "phénomène naturel, inéluctable, irréversible et spontané",
      "α : A−4, Z−2 · β⁻ : Z+1 · β⁺ : Z−1 · γ : rien ne change",
      "activité A = λ·N, en becquerels"
    ],
    "typologie": [
      "un âge négatif signale un signe perdu dans le logarithme",
      "la demi-vie ne dépend jamais de la taille de l'échantillon"
    ]
  },
  "piles": {
    "QT 1": [
      "hypothèse totale : calculer x_max par le tableau d'avancement",
      "calculer x_eq à partir d'une donnée expérimentale (pH, conductivité…)",
      "τ = x_eq/x_max : τ = 1 totale, τ &lt; 1 limitée"
    ],
    "QT 2": [
      "produits sur réactifs, chacun élevé à son coefficient",
      "l'activité d'un solide ou du solvant vaut 1 : ils n'apparaissent pas",
      "chaque concentration est divisée par c⁰ pour que Q_r soit sans unité"
    ],
    "QT 3": [
      "calculer Q_r,i avec les concentrations initiales",
      "comparer à K(T) : Q_r,i &lt; K → sens direct · Q_r,i > K → sens indirect",
      "Q_r,i = K → le système est déjà à l'équilibre"
    ],
    "QT 4": [
      "K(T) est le quotient de réaction à l'équilibre",
      "elle ne dépend QUE de la température",
      "pour l'hydrolyse d'un acide, K(T) = Ka"
    ],
    "QT 5": [
      "tableau d'avancement, puis report dans K(T)",
      "on obtient une équation du second degré en x_eq",
      "on garde la racine positive : une quantité de matière n'est pas négative"
    ],
    "QT 6": [
      "Anode → Oxydation → pôle ⊖ · Cathode → Réduction → pôle ⊕",
      "l'énoncé donne l'oxydation, le sens du courant, celui des ions, ou un signe affiché",
      "la borne COM doit être reliée au ⊖ pour un affichage positif"
    ],
    "QT 7": [
      "oxydation à l'anode, réduction à la cathode",
      "égaliser le nombre d'électrons, puis sommer",
      "aucun électron ne doit subsister dans l'équation de fonctionnement"
    ],
    "QT 8": [
      "dans le circuit extérieur : les électrons vont de l'anode vers la cathode",
      "le courant circule en sens inverse",
      "dans le pont salin : cations → cathode, anions → anode"
    ],
    "QT 9": [
      "Q = I × Δt et Q = n(e⁻) × F",
      "n(e⁻) se déduit de la demi-équation : N électrons par atome",
      "Δt = Q/I — ne pas oublier le facteur N"
    ],
    "socle": [
      "τ = x_eq/x_max compare l'avancement atteint au maximum",
      "Q_r décrit le système à un instant quelconque, K(T) à l'équilibre"
    ],
    "typologie": [
      "deux comparaisons résument tout : τ contre 1, et Q_r,i contre K(T)"
    ]
  },
  "titrages": {
    "QT 1": [
      "rapide : sinon le volume équivalent serait dépassé avant réaction",
      "totale : sinon la relation stœchiométrique ne s'appliquerait plus",
      "unique : aucune réaction parasite ne doit consommer le titrant"
    ],
    "QT 2": [
      "n(titré)/a = n(titrant)/b — JAMAIS n(A) = n(B) sans vérifier a et b",
      "C_A = a × C_B × V_éq / (b × V_A)",
      "les volumes apparaissant en rapport, la conversion est souvent inutile — mais on vérifie"
    ],
    "QT 3": [
      "tangentes : deux parallèles, la parallèle équidistante, puis les deux traits de lecture",
      "ou courbe dérivée : l'équivalence est au maximum de dpH/dV",
      "les tangentes seules donnent aussi pH_éq · construction à laisser visible"
    ],
    "QT 4": [
      "déterminer pH_éq sur la courbe par la méthode des tangentes",
      "la zone de virage de l'indicateur doit CONTENIR cette valeur",
      "« proche » ne suffit pas"
    ],
    "QT 5": [
      "écrire la loi de Kohlrausch avant puis après l'équivalence",
      "lister tous les ions présents, suivre leur concentration, comparer les λ si besoin",
      "la rupture de pente donne V_éq"
    ],
    "QT 6": [
      "pour immerger totalement la sonde",
      "pour rendre négligeable l'effet de la dilution sur les courbes",
      "cet ajout ne change pas la quantité de matière titrée"
    ],
    "QT 7": [
      "C_com = F × C_titrée — on MULTIPLIE par le facteur de dilution",
      "ω = C × M / ρ, avec ρ converti en g·L⁻¹"
    ],
    "QT 8": [
      "si u(X) est donnée : z-score, cohérent si z &lt; 2",
      "sinon : écart relatif rapporté à la valeur de RÉFÉRENCE, cohérent si e &lt; 5 %"
    ],
    "socle": [
      "titré = inconnu, dans l'erlenmeyer · titrant = connu, dans la burette",
      "la réaction support doit être rapide, totale et unique"
    ],
    "typologie": [
      "l'erreur la plus coûteuse : oublier les coefficients stœchiométriques",
      "à la demi-équivalence d'un titrage pH-métrique, pH = pKa"
    ]
  },
  "synthese": {
    "QT 1": [
      "η = n_f(produit) / n_max(produit), sans unité, toujours ≤ 1",
      "deux leviers : un réactif en excès, ou éliminer un produit au fur et à mesure",
      "la température agit sur la vitesse, pas sur le rendement"
    ],
    "QT 2": [
      "deux rôles : accélérer la réaction ET éviter les pertes de matière",
      "l'eau entre par le bas et sort par le haut du réfrigérant",
      "la pierre ponce régule l'ébullition"
    ],
    "QT 3": [
      "① transformation · ② séparation · ③ purification · ④ identification",
      "reflux ou distillation · filtration ou décantation · recristallisation · CCM, Kofler, IR"
    ],
    "QT 4": [
      "l'espèce doit être plus soluble dans le solvant extracteur",
      "le solvant doit être non miscible avec le solvant initial",
      "phase du haut : la moins dense"
    ],
    "QT 5": [
      "deux taches à la même hauteur = même espèce chimique",
      "une seule tache = corps pur · plusieurs taches = mélange"
    ],
    "QT 6": [
      "gradient de température de 50 à 250 °C, lu sur une échelle graduée",
      "on déplace l'échantillon jusqu'à la fusion, puis on compare à la valeur tabulée",
      "une température de fusion nette signe aussi la pureté"
    ],
    "QT 7": [
      "liaison double disparaît, deux groupes s'ajoutent → addition",
      "liaison double apparaît, une petite molécule part → élimination",
      "un groupe en remplace un autre → substitution"
    ],
    "QT 8": [
      "on protège quand le réactif n'est pas chimiosélectif",
      "trois étapes : protection, réaction, DÉPROTECTION",
      "nommer les deux groupes, dire lequel serait modifié à tort, conclure"
    ],
    "QT 9": [
      "① réactif limitant → x_max · ② n_max = coefficient × x_max",
      "③ convertir la donnée expérimentale en n_f · ④ η = n_f/n_max",
      "ne pas oublier le coefficient stœchiométrique dans n_max"
    ],
    "QT 10": [
      "même formule brute, formules développées différentes",
      "chaîne : la chaîne carbonée diffère · position : le groupe change de place",
      "fonction : le groupe caractéristique lui-même diffère"
    ],
    "socle": [
      "améliorer les conditions pour obtenir un produit pur et un bon rendement"
    ],
    "typologie": [
      "un rendement supérieur à 1 signale une erreur sur n_max"
    ]
  },
  "thermo": {
    "QT 1": [
      "isolé : ni matière ni énergie · fermé : énergie seule · ouvert : les deux",
      "gaz parfait : entités ponctuelles et sans interaction hors collisions",
      "limites : P > 1 MPa, ou T proche de l'ébullition du gaz réel"
    ],
    "QT 2": [
      "température ↔ vitesse des entités, donc énergie cinétique",
      "pression ↔ nombre et énergie des collisions par unité de surface",
      "masse volumique ↔ masse des entités et distance qui les sépare"
    ],
    "QT 3": [
      "ΔU = m·c·(T_f − T_i) pour un système incompressible",
      "premier principe : ΔU = W + Q, et W = 0 ici, donc ΔU = Q",
      "reçue → positive · cédée → négative"
    ],
    "QT 4": [
      "Φ = Q/Δt, en watts",
      "R_th = (T₁ − T₂)/Φ = e/(λ·S), en K·W⁻¹",
      "épaisse et peu conductrice = bien isolante"
    ],
    "QT 5": [
      "conduction : sans déplacement de matière, dans les solides",
      "convection : avec déplacement, dans les fluides · rayonnement : même dans le vide",
      "conducto-convectif : Φ = h·S·(T_ther − T(t))"
    ],
    "QT 6": [
      "P_reçue = (1 − A)·p_s·S · P_émise = (1 − a)·σ·S·T⁴",
      "à l'équilibre les deux sont égales, la surface se simplifie",
      "ne pas oublier la puissance 1/4, et travailler en kelvins"
    ],
    "QT 7": [
      "premier principe, puis loi de Newton du refroidissement",
      "on divise par Δt et on fait tendre vers 0 : le quotient devient la dérivée",
      "forme canonique : dT/dt + T(t)/τ = T_ther/τ, avec τ = m·c/(h·S)"
    ],
    "QT 8": [
      "deux limites : t → ∞ donne B = T_ther, t = 0 donne A = T_i − T_ther",
      "T(t) = (T_i − T_ther)·e^(−t/τ) + T_ther"
    ],
    "QT 9": [
      "tangente à l'origine : elle coupe l'asymptote à l'abscisse τ",
      "à t = τ, l'écart ne vaut plus que 37 % de l'écart initial",
      "t = −τ · ln[ (T(t) − T_ther)/(T_i − T_ther) ]"
    ],
    "QT 10": [
      "dériver, reporter dans le membre de gauche, retrouver T_ther/τ",
      "contrôle : T(0) = T_i et T → T_ther quand t → ∞"
    ],
    "socle": [
      "P·V = n·R·T avec T en kelvins",
      "ΔU = m·c·ΔT — l'écart est le même en °C et en K"
    ],
    "typologie": [
      "même équation différentielle qu'en cinétique, radioactivité et circuit RC"
    ]
  },
  "electrolyse": {
    "QT 1": [
      "calculer Q_r,i, le comparer à K(T) pour connaître le sens spontané",
      "comparer avec ce qu'on observe : le système évolue dans le sens inverse",
      "dans une transformation forcée, Q_r s'ÉLOIGNE de K(T)"
    ],
    "QT 2": [
      "anode reliée au ⊕ du générateur, siège d'une oxydation",
      "cathode reliée au ⊖, siège d'une réduction, souvent un dépôt métallique",
      "c'est la polarité qui change par rapport à la pile, pas la réaction"
    ],
    "QT 3": [
      "dans le circuit : électrons du ⊖ vers le ⊕, courant en sens inverse",
      "dans l'électrolyte : cations → cathode, anions → anode"
    ],
    "QT 4": [
      "Q = I × Δt = n(e⁻) × F = x_eq × N × F",
      "N est le nombre d'électrons de la demi-équation",
      "Δt sort en secondes : convertir si l'énoncé attend des heures"
    ],
    "QT 5": [
      "écrire la demi-équation de l'électrode concernée",
      "n(produit) = n(e⁻)/coefficient, avec n(e⁻) = I·Δt/F",
      "m = n × M · l'électrode qui gagne de la masse est celle du dépôt"
    ],
    "QT 6": [
      "écrire l'équation de fonctionnement et repérer le gaz côté produits",
      "O₂ ravive un tison incandescent · H₂ détone à l'approche d'une flamme",
      "Cl₂ : jaune-vert, décolore l'indigo"
    ],
    "QT 7": [
      "n_théorique = I·Δt/(coefficient × F)",
      "n_exp = m/M pour un solide, V/V_m pour un gaz",
      "η = n_exp / n_théorique, toujours inférieur à 1"
    ],
    "QT 8": [
      "le générateur force la réaction dans le sens inverse du sens spontané",
      "accumulateur : pile en décharge, transformation forcée en charge",
      "c'est la réversibilité des deux transformations qui permet la recharge"
    ],
    "socle": [
      "F = N_A × e = 9,65×10⁴ C·mol⁻¹, la constante de Faraday"
    ],
    "typologie": [
      "Anode → Oxydation et cations → cathode restent vrais : seule la polarité change"
    ]
  },
  "cinematique": {
    "QT 1": [
      "① système et référentiel · ② lister les forces",
      "③ pour chacune : direction, sens, point d'application, norme",
      "④ les représenter depuis le centre de gravité · la « force du mouvement » n'existe pas"
    ],
    "QT 2": [
      "F(A/B) = − G·m_A·m_B/r² · u, avec u dirigé de A vers B",
      "le signe − traduit le caractère attractif de la gravitation",
      "pour la force électrostatique, c'est le signe de q_A·q_B qui décide"
    ],
    "QT 3": [
      "préciser la nature de la trajectoire ET l'évolution de la vitesse",
      "toujours citer le référentiel",
      "points espacés régulièrement → uniforme · écartés → accéléré · resserrés → décéléré"
    ],
    "QT 4": [
      "v_i = M(i−1)M(i+1)/(2Δt) — variante centrée, plus précise si la trajectoire est courbée",
      "direction tangente, sens du mouvement, origine le point M_i",
      "deux échelles : celle des longueurs pour mesurer, celle des vitesses pour tracer"
    ],
    "QT 5": [
      "construire Δv = v(i+1) − v(i), bout à bout depuis le point",
      "mesurer Δv, calculer a = Δv/Δt, tracer a colinéaire à Δv",
      "contrôle : a pointe toujours vers l'INTÉRIEUR de la trajectoire"
    ],
    "QT 6": [
      "v_x = dx/dt : une dérivation · a_x = dv_x/dt : deux dérivations",
      "valeur : a = √(a_x² + a_y² + a_z²)"
    ],
    "QT 7": [
      "montrer que le vecteur a est constant : valeur, direction ET sens",
      "sur le graphe v_x = f(t), une droite signifie une pente constante donc a_x constante",
      "en chute libre a = g : uniformément accéléré, même si la trajectoire est parabolique"
    ],
    "QT 8": [
      "la vitesse est la PENTE de la tangente à x = f(t), jamais une ordonnée",
      "on nomme deux points bien lisibles et on calcule la pente",
      "variante : taux de variation entre deux positions d'un tableau"
    ],
    "QT 9": [
      "primitiver l'accélération, puis la vitesse",
      "deux constantes, déterminées par les conditions initiales — vitesse d'abord, position ensuite"
    ],
    "QT 10": [
      "dans la base de Frenet : a = (dv/dt)·u_T + (v²/R)·u_N",
      "mouvement uniforme → dv/dt = 0, donc a = (v²/R)·u_N, centripète",
      "la direction change en permanence : le mouvement est accéléré"
    ],
    "socle": [
      "système : l'objet étudié · référentiel : l'objet de référence",
      "poids P = m·g, seule norme exigible"
    ],
    "typologie": [
      "chaque symbole de vecteur porte une flèche : v pour le vecteur, v pour sa norme"
    ]
  },
  "newton": {
    "QT 1": [
      "dans un référentiel galiléen, mouvement rectiligne uniforme ou immobile",
      "⟺ les forces se compensent : leur SOMME VECTORIELLE est nulle",
      "la réciproque est vraie, et c'est elle qu'on utilise en exercice"
    ],
    "QT 2": [
      "ΣF(ext) = m·a, dans un référentiel galiléen et à masse CONSTANTE",
      "a a la même direction et le même sens que la somme des forces",
      "si cette somme est nulle, on retrouve la première loi"
    ],
    "QT 3": [
      "F(A/B) = − F(B/A) : même droite d'action, même valeur, sens opposés",
      "elles s'appliquent sur deux systèmes différents : elles ne se compensent jamais"
    ],
    "QT 4": [
      "sept étapes : système, référentiel, schéma, bilan, loi, projection, résolution",
      "sur un plan incliné, Ox suit la pente : seul le poids se décompose",
      "f = m·g·sin α et R = m·g·cos α"
    ],
    "QT 5": [
      "2e loi, projection, coordonnées de a",
      "deux primitives, deux jeux de constantes",
      "conditions initiales sur la vitesse d'abord, puis sur la position"
    ],
    "méthode": [
      "① repère adapté · ② fixer le sens des axes et ne plus en changer",
      "③ remplacer chaque vecteur par sa colonne · ④ lire ligne par ligne",
      "⑤ vérifier l'homogénéité et le nombre d'équations"
    ],
    "typologie": [
      "les deux premières lois ne diffèrent que par le second membre : 0 ou m·a"
    ]
  },
  "champuniforme": {
    "QT 1": [
      "chute libre : le poids est la seule force, donc a = g",
      "coordonnées de a selon le sens de l'axe : + g si Oz est vers le bas",
      "deux primitives, constantes déterminées par les conditions initiales"
    ],
    "QT 2": [
      "même bilan, même a = g : la seule nouveauté est la projection de v₀",
      "le côté adjacent à l'angle donne le cosinus, le côté opposé le sinus",
      "avec Oz vers le haut, a_z = − g"
    ],
    "QT 3": [
      "isoler t dans x(t), qui est du premier degré",
      "substituer dans z(t) : le temps disparaît, on obtient une parabole"
    ],
    "QT 4": [
      "chercher x_P tel que z(x_P) = 0, en écartant la solution x_P = 0",
      "x_P = 2v₀²·sin α·cos α / g"
    ],
    "QT 5": [
      "au sommet, la vitesse VERTICALE s'annule : v_z(t_F) = 0",
      "t_F = v₀·cos α / g, puis la flèche z(t_F) = v₀²·cos²α/(2g)",
      "la question demande presque toujours les deux, dans cet ordre"
    ],
    "QT 6": [
      "former le rapport F_e/P = q·E/(m·g) et montrer qu'il est ≫ 1",
      "conclusion : on ne fait pas figurer le poids dans le bilan des forces"
    ],
    "QT 7": [
      "bilan : la force électrique F_e = q·E seule",
      "attention au signe de la charge ET au sens de E : les deux se combinent",
      "puis deux primitives, comme pour la chute libre"
    ],
    "socle": [
      "E = U/d · le vecteur E va de la plaque ⊕ vers la plaque ⊖",
      "proton et cation : force de même sens que E · électron et anion : sens opposé"
    ],
    "typologie": [
      "fixer le sens des axes sur le schéma avant de projeter, et le garder jusqu'au bout"
    ]
  },
  "kepler": {
    "QT 1": [
      "orbites : ellipse dont un FOYER est le centre du Soleil, référentiel héliocentrique",
      "aires : le rayon-vecteur balaie des aires égales en des durées égales",
      "périodes : T²/a³ = 4π²/(G·M), qui ne dépend que de l'astre central"
    ],
    "QT 2": [
      "a = (d_min + d_max)/2, demi-somme des distances au périastre et à l'apoastre",
      "ce n'est PAS une distance moyenne ni le rayon d'un cercle moyen"
    ],
    "QT 3": [
      "deux arcs parcourus pendant la même durée Δt",
      "loi des aires : les aires balayées sont égales",
      "près de l'apoastre le rayon est plus long, donc l'arc est plus court : v_A &lt; v_P"
    ],
    "QT 4": [
      "T₁²/a₁³ = T₂²/a₂³ pour deux astres autour du même astre central",
      "T₁ = √( a₁³ × T₂²/a₂³ ) — ne pas oublier la racine",
      "les deux demi-grands axes dans la même unité, les deux périodes aussi"
    ],
    "QT 5": [
      "vérifier que la droite passe par l'origine : T² = k × a³ est linéaire",
      "relever deux points bien lisibles et calculer k = (T²_B − T²_A)/(a³_B − a³_A)",
      "identifier k à 4π²/(G·M), puis isoler M = 4π²/(G·k)"
    ],
    "QT 6": [
      "système : le satellite · référentiel géocentrique galiléen",
      "une seule force : l'attraction gravitationnelle terrestre",
      "après simplification par m_s : a = G·M_T/(R_T+h)²·u_N, centripète"
    ],
    "QT 7": [
      "comparer à l'expression de Frenet : a = (dv/dt)·u_T + v²/(R_T+h)·u_N",
      "aucune composante tangentielle, donc dv/dt = 0 et v = constante",
      "uniforme ne veut pas dire sans accélération : la direction change"
    ],
    "QT 8": [
      "égaler v²/(R_T+h) et G·M_T/(R_T+h)², puis simplifier",
      "v = √( G·M_T/(R_T+h) ) — indépendante de la masse du satellite",
      "T = 2π(R_T+h)/v = 2π·√( (R_T+h)³/(G·M_T) )"
    ],
    "QT 9": [
      "élever T au carré, puis diviser par (R_T+h)³",
      "T²/(R_T+h)³ = 4π²/(G·M_T) : c'est la troisième loi, avec a = R_T + h"
    ],
    "typologie": [
      "la masse du satellite n'intervient jamais dans v ni dans T",
      "il n'existe pas de force centrifuge dans un référentiel galiléen"
    ]
  },
  "energie": {
    "QT 1": [
      "W = F · AB = F × AB × cos α, avec α l'angle entre la force et le déplacement",
      "W > 0 moteur · W &lt; 0 résistant — on regarde le signe, on ne devine pas",
      "force perpendiculaire au déplacement → travail NUL"
    ],
    "QT 2": [
      "produit scalaire, puis cos α = (z_A − z_B)/AB : AB se simplifie",
      "W(P) = m·g·(z_A − z_B) : il ne dépend QUE de la différence d'altitude",
      "descente → moteur (+ m·g·h) · montée → résistant (− m·g·h)"
    ],
    "QT 3": [
      "frottements : α = 180°, donc W = − f × AB, toujours résistant",
      "force électrostatique : W = q·E·AB = q·U_AB, en utilisant E = U/AB"
    ],
    "QT 4": [
      "conservative : le travail ne dépend pas du chemin suivi — le poids",
      "dissipative : il en dépend, par la longueur AB — les frottements",
      "justifier par l'EXPRESSION du travail, pas par une impression"
    ],
    "QT 5": [
      "ΔE_m = W(forces non conservatives)",
      "sans frottement : ΔE_m = 0, l'énergie mécanique se conserve",
      "avec frottements : ΔE_m = − f·AB &lt; 0, dissipée en chaleur"
    ],
    "QT 6": [
      "ΔE_c = ΣW(forces extérieures) — TOUTES les forces",
      "½·m·v_B² − ½·m·v_A² = ΣW, puis on isole la vitesse",
      "c'est le théorème à choisir dès qu'on cherche une vitesse"
    ],
    "QT 7": [
      "E_m est toujours au-dessus : c'est la somme des deux autres",
      "E_c suit la vitesse · E_pp suit l'altitude",
      "contrôle : en tout instant, E_m = E_c + E_pp"
    ],
    "QT 8": [
      "six étapes : système, référentiel, bilan, schéma, travaux, théorème adapté",
      "énergie mécanique pour une altitude · énergie cinétique pour une vitesse",
      "au sommet la vitesse est nulle : c'est cette phrase qui permet de conclure"
    ],
    "socle": [
      "E_m = E_c + E_pp, avec E_c = ½·m·v² et E_pp = m·g·z"
    ],
    "typologie": [
      "avant tout calcul, regarder si l'énoncé mentionne des frottements"
    ]
  },
  "fluides": {
    "QT 1": [
      "verticale · vers le haut · appliquée au centre de gravité du VOLUME IMMERGÉ",
      "F_A = ρ_fluide × V_immergé × g — la masse volumique est celle du FLUIDE",
      "interprétation attendue : la poussée égale le poids du volume de fluide déplacé"
    ],
    "QT 2": [
      "équilibre si la somme vectorielle des deux forces est nulle, donc F_A = P",
      "si F_A > P le corps monte · si F_A &lt; P il descend et coule",
      "corps flottant : c'est le volume immergé qui ajuste la poussée au poids"
    ],
    "QT 3": [
      "sur le fluide : parfait (non visqueux) et incompressible (ρ constante)",
      "sur l'écoulement : permanent et non tourbillonnaire",
      "les citer, c'est justifier la conservation du débit et la relation de Bernoulli"
    ],
    "QT 4": [
      "D_V = V/Δt · pendant Δt le fluide parcourt L = v × Δt",
      "V = S × L = S × v × Δt, puis on divise par Δt : D_V = S × v",
      "convertir les cm², les litres et les minutes avant tout calcul"
    ],
    "QT 5": [
      "le fluide est incompressible : la conservation de la masse donne celle du volume",
      "S₁·v₁·Δt = S₂·v₂·Δt, puis on simplifie par Δt",
      "conclusion à citer : la conservation de la masse se traduit par celle du débit"
    ],
    "QT 6": [
      "partir de S_A·v_A = S_B·v_B et isoler v_B = (S_A/S_B) × v_A",
      "dire explicitement que S_A/S_B > 1 — c'est ce qui rapporte le point",
      "donc v_B > v_A : le fluide accélère au rétrécissement"
    ],
    "QT 7": [
      "Bernoulli sur la ligne de courant AB",
      "la conduite étant horizontale, z_A = z_B : les termes de pesanteur se simplifient",
      "P_B = P_A + ρ·(v_A² − v_B²)/2, et v_B > v_A donc P_B &lt; P_A"
    ],
    "socle": [
      "ρ en kg·m⁻³ · D_V en m³·s⁻¹ · P en pascals",
      "Bernoulli : P + ρ·v²/2 + ρ·g·z est le même en tout point d'une ligne de courant"
    ],
    "typologie": [
      "deux relations structurent le chapitre : la conservation du débit et Bernoulli"
    ]
  }
};
