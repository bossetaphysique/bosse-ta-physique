import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { supabaseActif, sessionCourante, surChangementSession, envoyerLienConnexion,
  connexionMotDePasse, reinitialiserMotDePasse } from "./lib/db.js";
import { PiedLegal } from "./lib/legal.jsx";

const CSS_CONNEXION = `
:root{ --bg:#F1F4FE; --surface:#FFF; --ink:#0E1132; --ink-soft:#565E80; --accent:#6C63FF;
  --gold:#E7B24E; --gold-dark:#D9A23C; --line:#E3E8F7;
  --fd:'Poppins',system-ui,sans-serif; --fb:'DM Sans',system-ui,sans-serif; --fm:'IBM Plex Mono',ui-monospace,monospace; }
.cx *{box-sizing:border-box;margin:0;padding:0}
.cx{background:var(--bg);min-height:100vh;min-height:100dvh;font-family:var(--fb);color:var(--ink-soft);
  display:grid;place-items:center;padding:24px;padding-top:calc(24px + env(safe-area-inset-top));
  -webkit-text-size-adjust:100%;color-scheme:light}
.cx .boite{max-width:420px;width:100%}
.cx h1{font-family:var(--fd);font-size:1.7rem;color:var(--ink);letter-spacing:-.02em;line-height:1.15;margin-top:10px}
.cx .eyebrow{font-family:var(--fm);font-size:.66rem;letter-spacing:.2em;text-transform:uppercase;color:#4E7EF3}
.cx .card{background:var(--surface);border:1px solid var(--line);border-radius:18px;box-shadow:0 8px 24px rgba(14,17,50,.05);padding:24px;margin-top:20px}
.cx input{width:100%;font-family:inherit;font-size:16px;color:var(--ink);border:1.5px solid var(--line);border-radius:14px;padding:14px 16px;background:#fff;margin-top:12px}
.cx input:focus{outline:none;border-color:var(--accent)}
.cx button{width:100%;min-height:48px;font-family:var(--fd);font-weight:600;font-size:1rem;background:var(--gold);color:var(--ink);border:0;border-radius:999px;padding:15px;margin-top:14px;cursor:pointer}
.cx button:hover{background:var(--gold-dark)}
.cx button[disabled]{opacity:.5;cursor:not-allowed}
.cx .small{font-size:.87rem}
.cx .muted{opacity:.75}
.cx .logo{display:flex;align-items:center;gap:10px}
.cx .logo svg{width:30px;height:30px}
.cx .logo b{font-family:var(--fd);font-size:1rem;color:var(--ink);line-height:1.05}
.cx .logo b span{display:block;color:var(--accent)}
`;

function Connexion() {
  const [email, setEmail] = useState("");
  const [envoye, setEnvoye] = useState(false);
  const [erreur, setErreur] = useState("");
  const [envoi, setEnvoi] = useState(false);
  const [motDePasse, setMotDePasse] = useState("");
  /* Par défaut on propose le mot de passe : c'est la voie de tous les jours.
     Le lien par courriel reste à un clic, pour la première fois ou l'oubli. */
  const [parLien, setParLien] = useState(false);

  const entrer = async () => {
    if (!email.includes("@")) { setErreur("Adresse email invalide."); return; }
    if (!motDePasse) { setErreur("Saisissez votre mot de passe."); return; }
    setEnvoi(true); setErreur("");
    try { await connexionMotDePasse(email, motDePasse); }
    catch (e) {
      setErreur("Adresse ou mot de passe incorrect. Si c'est votre première "
                + "connexion, demandez un lien par email.");
    }
    finally { setEnvoi(false); }
  };

  const envoyer = async () => {
    if (!email.includes("@")) { setErreur("Adresse email invalide."); return; }
    setEnvoi(true); setErreur("");
    try { await envoyerLienConnexion(email.trim()); setEnvoye(true); }
    catch (e) { setErreur("Envoi impossible : " + (e?.message || "reessayez dans un instant.")); }
    finally { setEnvoi(false); }
  };

  return (
    <div className="cx"><style>{CSS_CONNEXION}</style>
      <div className="boite">
        <div className="logo">
          <svg viewBox="0 0 32 32" fill="none"><path d="M4 19.5L11 26 28 7" stroke="#6C63FF" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" /><circle cx="26.5" cy="5.5" r="3" fill="#E7B24E" /></svg>
          <b>Bosse ta<span>Physique</span></b>
        </div>
        <p className="eyebrow" style={{ marginTop: 22 }}>Espace eleve</p>
        <h1>Connectez-vous.</h1>

        <div className="card">
          {envoye ? (
            <>
              <h1 style={{ fontSize: "1.15rem" }}>Regardez vos emails</h1>
              <p className="small muted" style={{ marginTop: 10 }}>
                Un lien de connexion vient d'etre envoye a {email}. Il est valable une heure.
                Pensez a regarder dans les indesirables.
              </p>
              <button onClick={() => setEnvoye(false)}>Utiliser une autre adresse</button>
            </>
          ) : (
            <>
              {/* Deux voies : le mot de passe pour ceux qui en ont un — la
                  très grande majorité au quotidien — et le lien par courriel
                  pour la première connexion ou en cas d'oubli. */}
              <input
                type="email" placeholder="votre@email.fr" value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !parLien) entrer(); }}
              />
              {!parLien && (
                <input
                  type="password" placeholder="votre mot de passe" value={motDePasse}
                  style={{ marginTop: 10 }}
                  onChange={(e) => setMotDePasse(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") entrer(); }}
                />
              )}
              {erreur && <p className="small" style={{ color: "#E0685F", marginTop: 10 }}>{erreur}</p>}

              {parLien ? (
                <button onClick={envoyer} disabled={envoi}>
                  {envoi ? "Envoi en cours..." : "Recevoir mon lien"}
                </button>
              ) : (
                <button onClick={entrer} disabled={envoi}>
                  {envoi ? "Connexion..." : "Se connecter"}
                </button>
              )}

              <p className="small muted" style={{ marginTop: 14, textAlign: "center" }}>
                <span style={{ cursor: "pointer", textDecoration: "underline" }}
                  onClick={() => { setParLien(!parLien); setErreur(""); }}>
                  {parLien
                    ? "J'ai un mot de passe"
                    : "Première connexion, ou mot de passe oublié ?"}
                </span>
              </p>
              <p className="small muted" style={{ marginTop: 14 }}>
                En vous connectant, vous acceptez les conditions générales de
                vente et la politique de confidentialité, consultables ci-dessous.
                Pour les élèves de moins de 15 ans, l'inscription doit être faite
                avec l'accord d'un parent.
              </p>
            </>
          )}
        </div>
        {/* Les deux textes sont accessibles AVANT toute connexion : c'est une
            obligation, et l'élève doit pouvoir les lire sans compte. */}
        <PiedLegal style={{ marginTop: 18 }} />
      </div>
    </div>
  );
}

function Racine() {
  const [session, setSession] = useState(null);
  const [charge, setCharge] = useState(!supabaseActif);

  useEffect(() => {
    if (!supabaseActif) return;
    sessionCourante().then((s) => { setSession(s); setCharge(true); });
    return surChangementSession((s) => setSession(s));
  }, []);

  if (!charge) return null;
  if (supabaseActif && !session) return <Connexion />;
  return <App />;
}

createRoot(document.getElementById("root")).render(<React.StrictMode><Racine /></React.StrictMode>);
