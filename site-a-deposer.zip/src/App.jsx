import katex from "katex";
import "katex/dist/katex.min.css";
import { useState, useEffect, useMemo, useRef } from "react";
import { SUJETS_BAC } from "./data/sujets-bac.js";
import {
  CHAPITRES, QUESTIONS, VIDEOS, FICHES, THREADS_INIT, JOURS, T, USAGES, BIBLIO_INIT,
  CYCLE_RAPPEL, RESTITUTIONS, DIRECT_JOUR, DIRECT_HEURE, PROGRAMME_DIRECTS, directDeLaSemaine,
  reglesDepuisDiagnostic, partsSemaine, paireRestitution, planifierSemaine,
  composerEvaluation, choisirExercice, progresserNiveau,
  ETAPES_ORAL, JALONS_ORAL, IDEES_ORAL, ideesPourChapitres, classerIdeesOral,
  BANQUES, TITRES_QT, RAPPELS_QT, questionsFlash, diagnosticDepuisBanque, normaliserQuestion,
} from "./lib/planning.js";
import {
  supabaseActif, chargerEtat, sauverEtat, chargerBiblio, ajouterExerciceDb, viderExercicesDb,
  chargerSujets, creerSujet, repondreSujet, envoyerVocalDb, envoyerFichierDb, deconnexion,
  envoyerMessageComplet, marquerCopieCorrigee,
  deposerCopieAnnotee, lienCopieAnnotee, deposerPagesCopie,
  inscrireSeance, cloreSemaine, chargerHistorique, chargerHistoriquesEleves,
  chargerRessources, ajouterRessourceDb, supprimerRessourceDb, supprimerRessourcesDb,
  remplacerRessourceDb,
  ouvrirEntrainementLibre, chargerEntrainementsLibres,
  figerPeriode, chargerPeriodes,
  lireOralOuvert, ecrireOralOuvert,
  monProfil, epinglerSujet as epinglerSujetDb, transformerEnRessource as transformerEnRessourceDb,
  retirerRessource as retirerRessourceDb,
  validerReponse as validerReponseDb, signalerMessage as signalerMessageDb,
  chargerDirects, enregistrerDirect, supprimerDirect, forcerSauvegarde, ecouterDirects,
  demanderAuRobot, lireCredits, crediterEleve,
  poserExerciceDb, majFichiersExerciceDb,
  chargerIdeesOral, ajouterIdeeOral, chargerBanque,
  inviterPersonne, listerInvitations, retirerInvitation, listerEleves,
  changerActivite, mesEnfants, etatDeLEnfant, envoyerLienConnexion, definirMotDePasse,
  chargerEtatsEleves, supprimerSujets, directDeLaClasse, envoyerRelanceDb,
  ecouterPermanence, ecouterEtats, ecouterMonEtat,
  envoyerPointMensuel, pointsMensuelsDe, supprimerEleve, supprimerTousLesEleves,
  reinitialiserEleve,
  listerParents, supprimerParent,
  televerser,
} from "./lib/db.js";
import { PiedLegal } from "./lib/legal.jsx";

/* ============================================================================
   BOSSE TA PHYSIQUE — v3
   Règle d'or : UN SOIR = UNE TÂCHE. Deux seulement en mode contrôle.
   L'élève déclare : ses jours de cours, un nouveau chapitre, un chapitre
   terminé, un contrôle. Tout le reste est automatique.
   ========================================================================== */

/* ────────────────────────────────────────────────────────────────────────────
   LE ROBOT D'AIDE, ÉTEINT.

   La mascotte ne peut rien répondre tant que la mise en service n'est pas
   faite côté Supabase : la fonction relais « robot », la table des crédits et
   la clé de l'interlocuteur. Allumée sans elle, elle s'affiche chez les élèves
   d'Instagram, annonce zéro crédit et renvoie une erreur à la première
   question.

   POUR L'ALLUMER, une fois les neuf étapes de mise en service passées :
   remettre « true » ci-dessous, et redéposer. Rien d'autre à toucher — tout le
   reste du robot est en place.
   ──────────────────────────────────────────────────────────────────────────── */
const ROBOT_ACTIF = false;

const CSS = `
:root{
  --bg:#F1F4FE; --surface:#FFF; --surface-alt:#EDF0FD;
  --ink:#0E1132; --ink-soft:#565E80;
  --accent:#6C63FF; --accent-2:#4E7EF3; --gold:#E7B24E; --gold-dark:#D9A23C;
  --line:#E3E8F7; --green:#2FA97C; --red:#E0685F;
  --fd:'Poppins',system-ui,sans-serif; --fb:'DM Sans',system-ui,sans-serif; --fm:'IBM Plex Mono',ui-monospace,monospace;
}
.b *{box-sizing:border-box;margin:0;padding:0}
.b{background:var(--bg);color:var(--ink-soft);font-family:var(--fb);font-size:16px;line-height:1.6;
  min-height:100vh;min-height:100dvh;-webkit-font-smoothing:antialiased;
  -webkit-text-size-adjust:100%;color-scheme:light;overflow-wrap:break-word}
.b img,.b iframe,.b audio,.b video{max-width:100%}
.b h1,.b h2,.b h3,.b h4{overflow-wrap:anywhere}
/* zone tactile minimale : 44 px, recommandation Apple comme Android */
.b button,.b .chip,.b label.btn{min-height:44px}
.b .btn-sm,.b .chip{min-height:40px}
/* ---- rien ne doit deborder de l'ecran, meme sur un petit telephone ---- */
.b{overflow-x:hidden}
.between{min-width:0}
.between > *{min-width:0}
.between h1,.between h2,.between h3,.between h4{overflow-wrap:anywhere}
.res > div,.tache > div,.jour > div,.bloc > div{min-width:0}
.inp,.composer textarea{min-width:0}
.seg{scrollbar-width:none}
.seg::-webkit-scrollbar{display:none}
.seg button{flex:0 0 auto}
.b h1,.b h2,.b h3,.b h4{font-family:var(--fd);color:var(--ink);line-height:1.2;letter-spacing:-.02em}
.b h1{font-size:1.6rem;font-weight:700}.b h2{font-size:1.18rem;font-weight:700}
.b h3{font-size:1rem;font-weight:600}.b h4{font-size:.92rem;font-weight:600}
.b button{font-family:inherit;font-size:inherit;cursor:pointer;border:0;background:none;color:inherit;text-align:left}
.b :focus-visible{outline:3px solid var(--accent);outline-offset:2px;border-radius:8px}
.small{font-size:.86rem}.muted{opacity:.75}
.eyebrow{font-family:var(--fm);font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;color:var(--accent-2)}
.app{display:grid;grid-template-columns:minmax(0,1fr);min-height:100vh;min-width:0}
.side{display:none}
.main{padding:20px 18px 104px;max-width:860px;width:100%;margin-inline:auto;min-width:0}
.wrapc{max-width:640px;margin-inline:auto;padding:24px 18px 44px}
.topbar{position:sticky;top:0;z-index:30;background:rgba(241,244,254,.93);backdrop-filter:blur(10px);border-bottom:1px solid var(--line);
  padding:11px 18px;padding-top:calc(11px + env(safe-area-inset-top));display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.logo{display:flex;align-items:center;gap:9px}
.logo svg{width:26px;height:26px}
.logo b{font-family:var(--fd);font-size:.92rem;color:var(--ink);line-height:1.05}
.logo b span{display:block;color:var(--accent)}
.spacer{margin-left:auto}

/* ── LA MASCOTTE ────────────────────────────────────────────────────────
   Elle flotte au-dessus de la barre d'onglets, à portée de pouce. Son
   z-index passe devant la barre mais reste sous la liseuse, qui doit
   pouvoir la recouvrir. */
.mascotte{position:fixed;right:16px;bottom:calc(76px + env(safe-area-inset-bottom,0px));
  width:60px;height:60px;border-radius:50%;border:2px solid #FFF;padding:0;
  background:#EDF0FD;box-shadow:0 8px 22px -4px rgba(14,17,50,.34);
  cursor:pointer;z-index:45;display:grid;place-items:center;overflow:hidden;
  transition:transform .16s ease}
.mascotte:hover{transform:scale(1.06)}
.mascotte:active{transform:scale(.96)}
.mascotte:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
.mascotte img{width:100%;height:100%;object-fit:cover;display:block}
.mascotte-x{font-size:1.7rem;line-height:1;color:var(--ink);font-weight:300}


/* LA BULLE D'APPEL, au-dessus de la mascotte. Elle dit qu'on peut demander,
   sans rien réclamer — et disparaît dès le premier clic, pour de bon. */
.appel{position:fixed;right:84px;
  bottom:calc(92px + env(safe-area-inset-bottom,0px));
  z-index:45;background:#FFF;border:1px solid var(--line);
  border-radius:14px;padding:8px 13px;font-size:.82rem;color:var(--ink);
  box-shadow:0 8px 22px -6px rgba(14,17,50,.26);white-space:nowrap;
  animation:appel-vient .4s ease both}
.appel::after{content:"";position:absolute;right:-6px;bottom:14px;
  width:11px;height:11px;background:#FFF;border-right:1px solid var(--line);
  border-bottom:1px solid var(--line);transform:rotate(-45deg)}
@keyframes appel-vient{from{opacity:0;transform:translateX(8px)}
                       to{opacity:1;transform:none}}
/* « display:flex » l'emporterait sur l'attribut « hidden ». */
.bulle[hidden]{display:none}

.bulle{position:fixed;right:16px;left:16px;
  bottom:calc(146px + env(safe-area-inset-bottom,0px));
  max-width:380px;margin-left:auto;z-index:46;background:#FFF;
  border:1px solid var(--line);border-radius:18px;
  box-shadow:0 18px 48px -10px rgba(14,17,50,.3);
  display:flex;flex-direction:column;max-height:min(62vh,440px)}
.bulle-tete{display:flex;justify-content:space-between;align-items:center;
  padding:12px 14px;border-bottom:1px solid var(--line)}
.bulle-fil{flex:1;overflow-y:auto;padding:12px 14px;scrollbar-width:thin}
.bulle-fil::-webkit-scrollbar{width:5px}
.bulle-fil::-webkit-scrollbar-thumb{background:#C9CFE8;border-radius:3px}
.bulle-m{font-size:.88rem;line-height:1.55;margin:0 0 8px;padding:9px 12px;
  border-radius:13px;max-width:88%}
.bulle-m.moi{background:#E8EDFD;color:var(--ink);margin-left:auto;
  border-bottom-right-radius:4px}
.bulle-m.lui{background:#F7F9FF;border:1px solid var(--line);color:var(--ink);
  border-bottom-left-radius:4px}
.bulle-pied{display:flex;gap:8px;padding:10px 12px;border-top:1px solid var(--line)}
/* Les formules : à leur taille dans la phrase, aérées quand elles sont
   seules. Une formule longue défile plutôt que de déborder. */
.f-ligne .katex{font-size:1em}
.f-bloc{display:block;margin:8px 0;text-align:center;overflow-x:auto;
  overflow-y:hidden;padding-bottom:2px}
.f-bloc .katex{font-size:1.06em}
.bulle-m .katex{color:var(--ink)}
.bulle-pied .input{flex:1}
@media (prefers-reduced-motion:reduce){ .mascotte{transition:none}
  .appel{animation:none} }

.tabbar{position:fixed;inset:auto 0 0 0;z-index:40;background:rgba(255,255,255,.97);backdrop-filter:blur(10px);border-top:1px solid var(--line);display:grid;/* Le nombre de colonnes suit le nombre d'onglets : figé à six, le septième
   passait à la ligne et la barre occupait deux étages sur un téléphone. */
grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);padding:8px 1px calc(8px + env(safe-area-inset-bottom))}
.tab{display:grid;justify-items:center;gap:3px;padding:6px 0;font-size:.55rem;letter-spacing:-.01em;color:var(--ink-soft);border-radius:12px;text-align:center}
.tab svg{width:21px;height:21px}
.tab.on{color:var(--accent)}
.badge{position:absolute;transform:translate(11px,-5px);background:var(--gold);color:var(--ink);font-family:var(--fm);font-size:.54rem;padding:1px 5px;border-radius:99px}
.card{background:var(--surface);border:1px solid var(--line);border-radius:18px;box-shadow:0 8px 24px rgba(14,17,50,.05);padding:20px;min-width:0}
.card+.card{margin-top:14px}
.dark{background:var(--ink);border-color:var(--ink);color:#C9CEEA}
.dark h1,.dark h2,.dark h3,.dark h4,.dark b{color:#fff}
.dark .muted{color:#A7AFD0;opacity:1}
.dark .eyebrow{color:#8FA6F7}
.dark .btn-ghost{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.22);color:#fff}
.dark .btn-ghost:hover{border-color:#fff}
.dark .tag{background:rgba(255,255,255,.12);border-color:rgba(255,255,255,.25);color:#fff}
.dark .tag.green{background:rgba(47,169,124,.22);border-color:rgba(47,169,124,.45);color:#8FE3C2}
.dark .tag.gold{background:rgba(231,178,78,.2);border-color:rgba(231,178,78,.45);color:#F2CE8C}
.dark .res,.dark .tache{border-color:rgba(255,255,255,.14)}
/* Boutons de declaration : icone a gauche, libelle, chevron a droite.
   Une seule ligne, meme sur petit ecran. */
.choix{display:flex;align-items:center;gap:13px;width:100%;text-align:left;margin-top:10px;
  padding:13px 15px;border-radius:15px;background:var(--surface);border:1.5px solid var(--line);
  font-family:var(--fd);font-weight:600;font-size:.95rem;line-height:1.25;color:var(--ink);
  cursor:pointer;transition:border-color .15s ease, background .15s ease}
.choix:hover{border-color:#C3CCF7;background:var(--surface-alt)}
.choix.on{background:#F4F3FF;border-color:var(--accent);color:var(--accent)}
.choix .ico{width:36px;height:36px;border-radius:12px;background:#F1F0FF;border:0;
  display:grid;place-items:center;color:var(--accent);flex:0 0 36px}
.choix.on .ico{background:#fff}
.choix .lib{flex:1;min-width:0}
.choix .fin{flex:none;width:22px;height:22px;border-radius:50%;background:var(--surface-alt);
  display:grid;place-items:center;color:var(--ink-soft);font-size:.82rem;line-height:1}
.choix.on .fin{background:rgba(108,99,255,.15);color:var(--accent)}
.dark h1,.dark h2,.dark h3,.dark b{color:#fff}
/* Titre + badge : le titre se comprime, le badge garde sa taille, et si la
   place manque vraiment le badge passe a la ligne au lieu de sortir du cadre. */
.between{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;min-width:0}
.between > *{min-width:0}
.between > .row,.between > .tag,.between > span.tag{flex:0 0 auto}
.between > h1,.between > h2,.between > h3,.between > h4,.between > div:not(.row){flex:1 1 180px}
.tag{max-width:100%}
.row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.stack{display:grid;gap:14px;grid-template-columns:minmax(0,1fr)}
.stack > *{min-width:0}
.grid2{display:grid;gap:14px;grid-template-columns:minmax(0,1fr)}
.grid2 > *{min-width:0}
.tag{font-family:var(--fm);font-size:.61rem;letter-spacing:.12em;text-transform:uppercase;color:var(--accent-2);background:#EBF0FE;border:1px solid #DCE5FD;border-radius:8px;padding:4px 9px;white-space:nowrap}
.tag.gold{color:#7A5A12;background:#FBF1DC;border-color:#F2E1BC}
.tag.green{color:#1E6E52;background:#E4F5EE;border-color:#CBE9DD}
.tag.grey{color:var(--ink-soft);background:#F2F4FB;border-color:var(--line)}
.tag.red{color:#8C332C;background:#FBEBEA;border-color:#F3D6D3}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;font-family:var(--fd);font-weight:600;padding:13px 20px;border-radius:999px;text-align:center;transition:background .15s,transform .1s}
.btn:active{transform:translateY(1px)}
.btn-gold{background:var(--gold);color:var(--ink)}.btn-gold:hover{background:var(--gold-dark)}
.btn-accent{background:var(--accent);color:#fff}.btn-accent:hover{background:#5B52F0}
.btn-ghost{border:1.5px solid var(--line);color:var(--ink);background:var(--surface)}.btn-ghost:hover{border-color:var(--accent)}
.btn-sm{padding:9px 15px;font-size:.86rem}.btn-block{width:100%}
.btn[disabled]{opacity:.45;cursor:not-allowed}
.chip{font-size:.85rem;border:1.5px solid var(--line);background:var(--surface);border-radius:999px;padding:8px 14px;color:var(--ink-soft)}
.chip.on{border-color:var(--accent);color:var(--accent);background:#F4F3FF}
.chips{display:flex;gap:8px;flex-wrap:wrap}
/* Au-delà d'une quinzaine de chapitres, la liste devient un mur : on la borne
   en hauteur et on la fait défiler plutôt que de pousser le reste hors écran. */
/* Notation vectorielle : une VRAIE flèche posée au-dessus du symbole, jamais
   une lettre en gras ni un caractère combinant. On écrit <span class="vec">v</span>. */
/* Notation d'un noyau : le nombre de masse au-dessus du numéro atomique,
   collés au symbole — on écrit <span class="noyau"><sup>14</sup><sub>6</sub></span>C */
.noyau{display:inline-block;vertical-align:-.42em;text-align:right;margin-right:.5px;
  line-height:1;font-style:normal}
.noyau sup,.noyau sub{display:block;position:static;font-size:.64em;line-height:1.06;margin:0;
  top:auto;bottom:auto}

.vec{position:relative;display:inline-block;white-space:nowrap;font-style:italic;padding-top:.08em}
.vec::after{content:"→";position:absolute;left:50%;top:-.66em;transform:translateX(-50%);
  font-size:.62em;font-style:normal;line-height:1;font-weight:400}

.chips.longue{max-height:136px;overflow-y:auto;padding:8px;border:1px solid var(--line);
  border-radius:14px;background:var(--surface-alt);-webkit-overflow-scrolling:touch}
.chips.longue::-webkit-scrollbar{width:4px}
.chips.longue::-webkit-scrollbar-thumb{background:#C3CCF7;border-radius:99px}

/* Indication d'une question à choix multiple. */
.multiple{display:inline-block;margin-top:9px;font-family:var(--fm);font-size:.6rem;
  letter-spacing:.14em;text-transform:uppercase;color:var(--accent);background:#F4F3FF;
  border:1px solid #DCD9FF;border-radius:999px;padding:5px 10px}
.opt.multi .k{border-radius:6px}

/* La figure de la question. */
.figure{display:block;width:100%;height:auto;margin-top:14px;border-radius:14px;
  border:1px solid var(--line);background:#fff}

/* Le renvoi à la fiche : icône et texte sur la MÊME ligne, alignés au centre. */
.renvoi{display:flex;align-items:center;gap:12px;width:100%;text-align:left;margin-top:14px;
  padding:12px 14px;border-radius:14px;background:#F4F3FF;border:1px solid #DCD9FF}
.renvoi.cliquable{cursor:pointer;transition:background .15s ease,border-color .15s ease}
.renvoi.cliquable:hover{background:#EEECFF;border-color:var(--accent)}
.renvoi .ico{width:36px;height:36px;border-radius:12px;background:#fff;border:0;flex:0 0 36px;
  display:grid;place-items:center;color:var(--accent)}
.renvoi .txt{min-width:0;flex:1 1 auto}
.renvoi .ou{display:block;font-family:var(--fm);font-size:.6rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--accent);line-height:1}
.renvoi b{display:block;margin-top:5px;font-family:var(--fd);font-weight:600;font-size:.92rem;
  line-height:1.3;color:var(--ink);overflow-wrap:anywhere}
.renvoi .fin{flex:0 0 auto;color:var(--accent);font-size:1.15rem;line-height:1}

/* Le rappel de la fiche, en feuille qui remonte du bas. */
.voile{position:fixed;inset:0;z-index:60;background:rgba(14,17,50,.42);
  display:flex;align-items:flex-end;justify-content:center}
.feuille{width:100%;max-width:640px;max-height:82vh;overflow-y:auto;background:var(--surface);
  border-radius:24px 24px 0 0;padding:14px 20px calc(24px + env(safe-area-inset-bottom));
  box-shadow:0 -12px 40px rgba(14,17,50,.18)}
.poignee{width:42px;height:4px;border-radius:99px;background:var(--line);margin:0 auto 14px}
ul.rappel{list-style:none;margin-top:10px}
ul.rappel li{position:relative;padding-left:22px;margin-top:10px;font-size:.95rem;
  line-height:1.5;color:var(--ink)}
ul.rappel li::before{content:"";position:absolute;left:4px;top:9px;width:6px;height:6px;
  border-radius:50%;background:var(--accent)}
.bar{height:8px;border-radius:99px;background:#E9EDFB;overflow:hidden}
.bar i{display:block;height:100%;background:var(--accent);transition:width .4s}
.tache{display:flex;gap:12px;align-items:center;padding:14px 0;border-bottom:1px solid var(--line)}
.tache:last-child{border-bottom:0}
.pst{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;flex:none;font-family:var(--fm);font-size:.64rem;background:#EDF0FE;border:1px solid #DFE6FD;color:var(--accent)}
.pst.chaud{background:#E4F5EE;border-color:#CBE9DD;color:#1E6E52}
.pst.rappel{background:#FBF1DC;border-color:#F2E1BC;color:#7A5A12}
.pst.controle{background:#FBEBEA;border-color:#F3D6D3;color:#8C332C}
.pst.restitution{background:#EFEBFE;border-color:#DDD6FB;color:#5B52F0}
.pst.direct{background:#0E1132;border-color:#0E1132;color:#fff}
.jour{border-top:1px solid var(--line);padding:12px 0}
.jour:first-of-type{border-top:0}
.dl{font-family:var(--fm);font-size:.69rem;letter-spacing:.14em;text-transform:uppercase;color:var(--accent-2);width:54px;flex:none}
.jour.off .dl{opacity:.5;color:var(--ink-soft)}
.sub{margin-left:64px;margin-top:8px}
.timer{font-family:var(--fm);font-size:2.5rem;color:var(--ink);line-height:1}
.lock{display:flex;gap:8px;align-items:center;font-size:.85rem;background:var(--surface-alt);border:1px dashed var(--line);border-radius:12px;padding:12px 14px;margin-top:12px}
.opt{display:block;width:100%;border:1.5px solid var(--line);background:var(--surface);border-radius:14px;padding:13px 15px;margin-top:9px}
.opt.sel{border-color:var(--accent);background:#F4F3FF}
.opt.ok{border-color:var(--green);background:#EDF8F4}
.opt.ko{border-color:var(--red);background:#FDF0EF}
.opt .k{font-family:var(--fm);font-size:.7rem;color:var(--accent-2);margin-right:8px}
.seg{display:flex;gap:6px;background:var(--surface-alt);padding:5px;border-radius:14px;margin-bottom:14px;overflow-x:auto}
.seg button{flex:1;white-space:nowrap;padding:9px 12px;border-radius:10px;font-size:.87rem;color:var(--ink-soft);text-align:center}
.seg button.on{background:var(--surface);color:var(--ink);font-weight:500;box-shadow:0 2px 8px rgba(14,17,50,.05)}
.res{display:flex;align-items:center;gap:12px;padding:13px 0;border-bottom:1px solid var(--line)}
.res:last-child{border-bottom:0}
.ico{width:38px;height:38px;border-radius:12px;background:#EDF0FE;border:1px solid #DFE6FD;display:grid;place-items:center;color:var(--accent);flex:none}
.ico svg{width:18px;height:18px}
.msg{max-width:88%;min-width:0;padding:11px 14px;border-radius:14px;font-size:.91rem;margin-top:10px;overflow-wrap:anywhere}
.msg .who{display:block;font-family:var(--fm);font-size:.57rem;letter-spacing:.12em;text-transform:uppercase;opacity:.65;margin-bottom:4px}
.msg-in{background:#F4F6FE;border:1px solid var(--line);border-bottom-left-radius:5px}
.msg-prof{background:var(--accent);color:#fff;border-bottom-left-radius:5px}
.msg-me{background:var(--surface-alt);border:1px solid var(--line);margin-left:auto;border-bottom-right-radius:5px}
/* Badges et actions a l'interieur d'une bulle : ils doivent revenir a la ligne
   au lieu de deborder du cadre. */
.msg .badge-msg{display:inline-flex;align-items:flex-start;gap:6px;max-width:100%;
  white-space:normal;overflow-wrap:anywhere;line-height:1.3;text-align:left;
  font-family:var(--fb);font-size:.78rem;letter-spacing:0;text-transform:none;
  border-radius:10px;padding:7px 10px;margin-top:10px}
.msg .badge-msg.ok{background:#E4F5EE;border:1px solid #CBE9DD;color:#1E6E52}
.msg .badge-msg.ko{background:#FBEBEA;border:1px solid #F3D6D3;color:#8C332C}
.msg-prof .badge-msg.ok,.msg-prof .badge-msg.ko{background:rgba(255,255,255,.18);border-color:rgba(255,255,255,.35);color:#fff}
.msg .commentaire{font-size:.86rem;line-height:1.45;margin-top:6px;overflow-wrap:anywhere}
.msg .actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
.msg .actions button{min-height:36px;padding:7px 12px;font-size:.8rem;border-radius:999px;
  background:rgba(14,17,50,.06);border:1px solid var(--line);color:var(--ink);white-space:nowrap}
.msg .actions button:hover{border-color:var(--accent)}
/* Actions du coach sous un fil : une seule ligne, defilement lateral si besoin */
.barre-actions{display:flex;gap:8px;margin-top:14px;overflow-x:auto;padding-bottom:2px;max-width:100%;min-width:0;
  -webkit-overflow-scrolling:touch;scrollbar-width:none}
.barre-actions::-webkit-scrollbar{display:none}
.barre-actions button{flex:0 0 auto;white-space:nowrap;min-height:40px;padding:9px 16px;
  border-radius:999px;font-family:var(--fd);font-weight:600;font-size:.85rem;
  background:var(--surface-alt);border:1px solid var(--line);color:var(--ink);
  display:inline-flex;align-items:center;gap:7px}
.barre-actions button:hover{border-color:var(--accent);color:var(--accent)}
.barre-actions button.principal{background:var(--accent);border-color:var(--accent);color:#fff}
.barre-actions button.principal:hover{background:#5B52F0;color:#fff}
.composer{display:flex;gap:8px;align-items:flex-end;margin-top:14px}
.composer textarea,.inp{flex:1;font-family:inherit;font-size:16px;color:var(--ink);border:1.5px solid var(--line);border-radius:14px;padding:11px 14px;resize:none;background:var(--surface)}
.composer textarea:focus,.inp:focus{outline:none;border-color:var(--accent)}
/* ---------- telephone etroit : on resserre tout ---------- */
@media(max-width:420px){
  .b{font-size:15.5px}
  .main{padding:16px 14px 104px}
  .card{padding:16px}
  .card+.card{margin-top:12px}
  .b h1{font-size:1.45rem}
  .b h2{font-size:1.08rem}
  .btn{padding:12px 16px;font-size:.95rem}
  .btn-sm{padding:9px 13px;font-size:.83rem}
  .chip{font-size:.8rem;padding:8px 11px}
  .timer{font-size:2.1rem}
  .tab{font-size:.62rem}
  .msg{max-width:94%}
  .dl{width:46px;font-size:.66rem}
  .sub{margin-left:56px}
  .barre-actions button{padding:9px 13px;font-size:.82rem}
}

/* la marque textuelle laisse la place aux boutons dans la barre du haut */
@media(max-width:560px){
  .topbar{gap:8px;padding:10px 14px;padding-top:calc(10px + env(safe-area-inset-top));flex-wrap:nowrap}
  .topbar .logo b{display:none}
  .topbar .btn-sm{padding:8px 12px;font-size:.8rem}
  .topbar .tag{font-size:.58rem;padding:4px 7px}
}

/* ---------- tablette en portrait, grand telephone ---------- */
@media(min-width:600px){
  .b{font-size:17px}
  .main{padding:26px 28px 108px}
  .grid2{grid-template-columns:repeat(2, minmax(0, 1fr))}
  .wrapc{max-width:560px;padding:32px 24px 48px}
  .tab{font-size:.7rem}
  .card{padding:24px}
}

/* ---------- ordinateur et tablette en paysage ---------- */
@media(min-width:900px){
  .app{grid-template-columns:250px minmax(0, 1fr)}
  .side{display:block;border-right:1px solid var(--line);background:var(--surface);padding:20px 14px;position:sticky;top:0;height:100vh}
  .side .nav{display:grid;gap:4px;margin-top:24px}
  .side .nav button{display:flex;align-items:center;gap:11px;padding:11px 13px;border-radius:12px;color:var(--ink-soft);font-size:.92rem;width:100%}
  .side .nav button svg{width:19px;height:19px}
  .side .nav button.on{background:var(--surface-alt);color:var(--accent);font-weight:500}
  .tabbar{display:none}
  .main{padding:28px 32px 60px}
  .topbar .logo{display:none}
  .topbar{padding:14px 32px}
  .grid2{grid-template-columns:repeat(2, minmax(0, 1fr))}
}

/* ---------- grand ecran : on aere sans etirer les lignes ---------- */
@media(min-width:1280px){
  .app{grid-template-columns:280px minmax(0, 1fr)}
  .main{max-width:1000px;padding:36px 44px 60px}
  .b{font-size:17px}
}

/* ---------- telephone en paysage : la barre ne mange plus l'ecran ---------- */
@media(max-height:520px) and (orientation:landscape){
  .tabbar{position:static}
  .main{padding-bottom:24px}
  .timer{font-size:1.9rem}
}

/* ---------- impression : le planning de la semaine sur papier ---------- */
@media print{
  .tabbar,.topbar,.side,.btn{display:none !important}
  .b{background:#fff}
  .card{break-inside:avoid;box-shadow:none}
}
`;

/* ========================= DONNÉES (à brancher sur Base44) ================= */
/* EXERCICES sert de bibliothèque admin : titre, durée, niveau. */

/* ========================= ICÔNES ========================================= */
const I = {
  home: <path d="M4 11l8-7 8 7v9H4z" />,
  cal: <><rect x="3.5" y="5" width="17" height="15" rx="3" /><path d="M8 3v4M16 3v4M3.5 10h17" /></>,
  chat: <path d="M20 12a7 7 0 0 1-7 7H8l-4 3v-4.5A7 7 0 0 1 8 5h5a7 7 0 0 1 7 7z" />,
  book: <><path d="M5 4h10l4 4v12H5z" /><path d="M9 10h6M9 14h4" /></>,
  play: <><circle cx="12" cy="12" r="9" /><path d="M10 8.5l6 3.5-6 3.5z" /></>,
  chart: <><path d="M4 18l5-6 4 3 6.5-8" /><path d="M4 21h16" /></>,
  /* Un fanion : les contrôles, ce sont les échéances qu'on vise. */
  flag: <><path d="M5 21V4" /><path d="M5 4h11l-2 3.5L16 11H5" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4.5 20a7.5 7.5 0 0 1 15 0" /></>,
  lock: <><rect x="5" y="10" width="14" height="10" rx="2.5" /><path d="M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  micro: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></>,
  coche: <><path d="M4 12.5 L9.5 18 L20 6" /></>,
  pdf: <><path d="M6 3h8l4 4v14H6z" /><path d="M10 13h4M10 17h3" /></>,
};
const Icon = ({ d, size = 20 }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width={size} height={size} aria-hidden="true">{d}</svg>
);
const Logo = () => (
  <div className="logo">
    <svg viewBox="0 0 32 32" fill="none"><path d="M4 19.5L11 26 28 7" stroke="#6C63FF" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" /><circle cx="26.5" cy="5.5" r="3" fill="#E7B24E" /></svg>
    <b>Bosse ta<span>Physique</span></b>
  </div>
);
/* ---- Ressources par chapitre : videos Vimeo et fiches PDF, saisies par le coach ---- */
const TYPES_VIDEO = ["Leçon", "Question type", "Résumé"];

/* Le cours de MÉTHODE ne porte sur aucun chapitre : rédaction, gestion du
   temps, lecture d'un énoncé. On lui donne un identifiant à part, reconnu
   partout où un nom de chapitre est affiché. */
const METHODE = "methode";
const NOM_METHODE = "Méthode, tous chapitres";

/* LE SON DES NOTIFICATIONS. Sur mobile, un contexte audio ne peut naître que
   d'un geste de l'utilisateur : créé plus tard, il reste muet. On en garde donc
   un seul, ouvert au premier toucher de l'écran, et réutilisé ensuite. */
let _ctxSon = null;
function contexteSon() {
  try {
    if (!_ctxSon) {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return null;
      _ctxSon = new C();
    }
    return _ctxSon;
  } catch (e) { return null; }
}
if (typeof document !== "undefined") {
  const debloquer = () => {
    const c = contexteSon();
    if (c && c.state === "suspended") c.resume();
  };
  document.addEventListener("touchstart", debloquer, { once: false, passive: true });
  document.addEventListener("click", debloquer, { once: false, passive: true });
}

/* Les directs sont programmes par le coach. Ces quatre-la ne sont qu'un point
   de depart : ils se modifient depuis l'espace coach. */
/* La salle de visioconférence du coach. Une salle permanente vaut mieux qu'un
   lien créé à chaque séance : les élèves retiennent une adresse au lieu d'en
   recevoir une nouvelle chaque semaine, et un lien perdu ne les empêche plus
   d'entrer. */
const SALLE_PAR_DEFAUT = "https://us06web.zoom.us/j/88294392411";

const DIRECTS_INIT = PROGRAMME_DIRECTS.map((d, i) => ({
  id: "d" + (i + 1), semaine: i + 1, jour: DIRECT_JOUR, heure: DIRECT_HEURE,
  duree: 60, titre: d.titre, chapId: d.chapId, lien: "", replayUrl: "",
}));

/* Reponses pre-redigees du coach. Modifiables ici : c'est du texte, rien d'autre.
   Elles s'inserent dans le champ de reponse, ou elles restent modifiables. */
const REPONSES_TYPES = [
  { court: "Bonne piste", texte: "Bonne piste — continue dans cette direction, tu y es presque." },
  { court: "Erreur d'unite", texte: "Attention aux unites : convertis avant d'appliquer la relation, sinon le resultat n'a pas de sens." },
  { court: "Rappel de methode", texte: "Reprends la methode : 1) les donnees de l'enonce, 2) la relation utilisee, 3) l'application numerique avec les unites." },
  { court: "Voir la fiche", texte: "Relis la fiche du chapitre : la relation dont tu as besoin y figure. Reviens vers moi si ca bloque encore." },
  { court: "Envoie ta copie", texte: "Envoie-moi une photo de ta copie, je verrai exactement ou ca bloque." },
  { court: "Calcul seulement", texte: "Ton raisonnement est juste, c'est uniquement une erreur de calcul. Refais l'application numerique." },
  { court: "C'est exact", texte: "C'est exact, bien vu." },
  { court: "On en reparle mercredi", texte: "Bonne question : on la reprend au direct de mercredi, c'est un cas classique." },
];

/* Sujets de bac sélectionnés par le coach sur Labolycée, proposés à l'élève
   le week-end une fois son sujet de synthèse rendu. */

const RESSOURCES_INIT = Object.fromEntries(CHAPITRES.map((c) => [c.id, {
  videos: (VIDEOS[c.id] || []).map((v, i) => ({ id: c.id + "-v" + i, type: v.type, titre: v.titre, duree: v.duree, url: "" })),
  fiches: (FICHES[c.id] || []).map((f, i) => ({ id: c.id + "-f" + i, titre: f.titre, pages: f.pages, url: "" })),
  /* Les fiches EXPRESS, déposées par « resume-son.pdf ». */
  fichesExpress: [],
  /* Les sujets « pour aller plus loin » viennent de la banque Labolycée, comme
     ceux du programme : SUJETS_EXTERNES était vide, et tous les liens de ce
     bloc menaient donc à une adresse inexistante. */
  /* Les épreuves blanches et leurs corrigés sont des PDF déposés par le coach :
     ses propres évaluations, qui priment sur celles composées depuis les lots. */
  epreuves: [],
  corriges: [],
  /* L'entraînement libre : la seconde épreuve, que l'élève fait pour lui. */
  libres: [],
  sujets: (SUJETS_BAC[c.id] || []).map((sj) => ({
    id: sj.id, titre: sj.titre, url: sj.url,
    duree: sj.duree, session: sj.session, points: sj.points,
    consigne: sj.consigne,
  })),
}]));

/* Accepte https://vimeo.com/123456789, /video/123456789, avec ou sans hash. */
function idVimeo(url = "") {
  const m = String(url).match(/vimeo\.com\/(?:video\/)?(\d+)/) || String(url).match(/^(\d{6,})$/);
  return m ? m[1] : null;
}

/* L'adresse de lecture, quelle que soit la plateforme. Seul Vimeo était
   reconnu : une vidéo YouTube — la plupart des capsules de physique en sont —
   affichait « pas encore déposée » alors que le lien était bon. */
function lecteurVideo(url = "") {
  const u = String(url).trim();
  if (!u) return null;

  /* Vimeo, avec son éventuel JETON DE CONFIDENTIALITÉ : une vidéo non
     répertoriée porte une adresse de la forme vimeo.com/1134530387/ed1ef5d63a.
     Sans ce jeton, le lecteur refuse l'affichage et laisse un cadre blanc —
     c'est ce qui se passait, le jeton étant simplement ignoré. */
  const vp = u.match(/vimeo\.com\/(?:video\/)?(\d+)(?:\/([A-Za-z0-9]+))?/);
  if (vp) return "https://player.vimeo.com/video/" + vp[1]
    + (vp[2] ? "?h=" + vp[2] : "");
  const v = idVimeo(u);
  if (v) return "https://player.vimeo.com/video/" + v;

  /* YouTube, sous ses quatre formes : watch?v=, youtu.be/, /embed/, /shorts/ */
  const yt = u.match(/[?&]v=([A-Za-z0-9_-]{11})/)
          || u.match(/youtu\.be\/([A-Za-z0-9_-]{11})/)
          || u.match(/youtube\.com\/embed\/([A-Za-z0-9_-]{11})/)
          || u.match(/youtube\.com\/shorts\/([A-Za-z0-9_-]{11})/);
  if (yt) return "https://www.youtube-nocookie.com/embed/" + yt[1];

  /* Dailymotion */
  const dm = u.match(/dailymotion\.com\/video\/([A-Za-z0-9]+)/)
          || u.match(/dai\.ly\/([A-Za-z0-9]+)/);
  if (dm) return "https://www.dailymotion.com/embed/video/" + dm[1];

  /* Une adresse déjà prête à être intégrée. */
  if (/\/embed\/|player\./.test(u)) return u;
  return null;
}
/* Bouton "Rejoindre" : il ouvre le lien de la visio programme par le coach.
   Sans lien, on le dit clairement plutot que d'afficher un bouton qui ne fait rien. */
function BoutonRejoindre({ lien, taille = "btn-sm" }) {
  if (!lien) return <span className="tag gold">Lien a venir</span>;
  return (
    <a className={"btn btn-gold " + taille} href={lien} target="_blank" rel="noreferrer">Rejoindre</a>
  );
}

const lecteurVimeo = (url) => lecteurVideo(url);

const mmss = (s) => String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");

const ELEVES_DEMO = [
  {
    nom: "Lea M.", chap: "Ondes et signaux", depuis: 2, diff: "moyen", quotaHebdo: 4,
    dernierTravail: 1,                        // il y a n jours
    copie: "a corriger",
    /* 4 semaines d'historique, de la plus ancienne a la semaine en cours */
    histo: [
      { minutes: 128, seances: 4, prevues: 4, restit: 2, restitAttendues: 2, direct: true,  retards: 0 },
      { minutes: 141, seances: 4, prevues: 4, restit: 2, restitAttendues: 2, direct: true,  retards: 0 },
      { minutes: 96,  seances: 3, prevues: 4, restit: 1, restitAttendues: 2, direct: false, retards: 1 },
      { minutes: 112, seances: 4, prevues: 4, restit: 2, restitAttendues: 2, direct: true,  retards: 0 },
    ],
  },
  {
    nom: "Tom B.", chap: "Cinetique et catalyse", depuis: 1, diff: "facile", quotaHebdo: 5,
    dernierTravail: 9,
    copie: "non envoyee",
    histo: [
      { minutes: 88, seances: 3, prevues: 5, restit: 1, restitAttendues: 2, direct: false, retards: 1 },
      { minutes: 62, seances: 2, prevues: 5, restit: 1, restitAttendues: 2, direct: false, retards: 2 },
      { minutes: 34, seances: 1, prevues: 5, restit: 0, restitAttendues: 2, direct: false, retards: 3 },
      { minutes: 0,  seances: 0, prevues: 5, restit: 0, restitAttendues: 2, direct: false, retards: 3 },
    ],
  },
  {
    nom: "Ines R.", chap: "Mouvement et 2e loi de Newton", depuis: 3, diff: "difficile", quotaHebdo: 3,
    dernierTravail: 0,
    copie: "corrigee",
    histo: [
      { minutes: 105, seances: 3, prevues: 3, restit: 2, restitAttendues: 2, direct: true, retards: 0 },
      { minutes: 118, seances: 3, prevues: 3, restit: 2, restitAttendues: 2, direct: true, retards: 0 },
      { minutes: 124, seances: 3, prevues: 3, restit: 2, restitAttendues: 2, direct: true, retards: 0 },
      { minutes: 131, seances: 3, prevues: 3, restit: 2, restitAttendues: 2, direct: true, retards: 0 },
    ],
  },
];

/* Alertes du coach, de la plus grave a la plus benigne. */
function alertesEleve(e) {
  /* Un élève qui vient d'être créé n'a pas encore d'historique mensuel : sans
     ce garde-fou, la ligne suivante plantait et l'espace coach restait blanc. */
  const histo = e.histo || [];
  const s = histo[histo.length - 1]
    || { seances: 0, prevues: 0, minutes: 0, restit: 0, restitAttendues: 0, direct: false };
  const a = [];
  if (e.dernierTravail >= 7) a.push({ niveau: "rouge", motif: "inactif", txt: "Aucun travail depuis " + e.dernierTravail + " jours" });
  /* Les restitutions d'abord, comptées pour ce qu'elles sont : ce sont elles
     qui font tenir le cours dans la durée. */
  const rr = e.restitRetard || 0;
  if (rr >= 2) a.push({ niveau: "rouge", motif: "restitution",
    txt: rr + " restitutions non rendues" + (e.restitPrevues ? " sur " + e.restitPrevues + " prévues" : "") });
  else if (rr === 1) a.push({ niveau: "ambre", motif: "restitution", txt: "1 restitution non rendue" });
  else if (s.retards >= 2) a.push({ niveau: "rouge", motif: "restitution", txt: s.retards + " tâches en retard" });
  else if (s.retards === 1) a.push({ niveau: "ambre", motif: "restitution", txt: "1 tâche en retard" });
  /* Les soirées sautées, et surtout la part qui a été reprise : un élève qui
     saute deux soirs et les rattrape ne demande pas la même attention qu'un
     élève qui en saute deux et n'y revient jamais. */
  /* Les soirées sautées se comptent sur TOUT l'historique connu, pas sur la
     seule semaine en cours : un élève qui saute trois soirs sur deux semaines
     n'en montrait qu'un, et l'alerte disait « toutes rattrapées ». */
  const manques = histo.reduce((n, x) => n + (x.joursManques || 0), 0);
  const repris = histo.reduce((n, x) => n + (x.joursRattrapes || 0), 0);
  if (manques - repris >= 3)
    a.push({ niveau: "rouge", motif: "soirees", txt: (manques - repris) + " soirées sautées, jamais rattrapées" });
  else if (manques - repris > 0)
    a.push({ niveau: "ambre", motif: "soirees", txt: (manques - repris) + " soirée(s) sautée(s) sans rattrapage" });
  else if (repris > 0)
    a.push({ niveau: "vert", txt: repris + " soirée(s) sautée(s), toutes rattrapées" });
  /* Une copie ne peut manquer que si une épreuve blanche était prévue : sans
     contrôle déclaré, l'élève n'avait rien à composer et l'alerte était fausse. */
  if (e.copie === "non envoyee" && e.blanchePrevue)
    a.push({ niveau: "rouge", motif: "copie", txt: "Copie d'évaluation blanche non envoyée" });
  /* Épreuve sautée : rien n'a été composé, donc rien à corriger. Le coach doit
     le voir aussi nettement qu'une copie manquante. */
  if (e.copie === "non faite" && e.blanchePrevue) a.push({ niveau: "rouge", motif: "blanche",
    txt: "Évaluation blanche non faite" });
  /* Une copie qui arrive est une action à mener, pas une information : elle
     doit apparaître dans « à traiter cette semaine », avec son nombre de pages. */
  if (e.copie === "a corriger")
    a.push({ niveau: "ambre", motif: "corriger",
      txt: "Copie reçue" + (e.copiePages ? " · " + e.copiePages + " page(s)" : "") + " · à corriger" });
  if (s.seances < s.prevues) a.push({ niveau: "ambre", motif: "seances", txt: s.seances + " séances sur " + s.prevues + " prévues" });
  /* De même pour le direct : on ne reproche pas une absence à une séance qui
     n'a jamais été programmée. */
  if (!s.direct && e.directPrevu)
    a.push({ niveau: "ambre", motif: "direct", txt: "Absent au direct de la semaine" });
  return a;
}

const totalMois = (e, cle) => (e.histo || []).reduce((n, x) => n + (x[cle] || 0), 0);

/* Brouillon du point mensuel envoye aux familles, ecrit a partir des donnees. */
function pointMensuel(e) {
  const min = totalMois(e, "minutes"), seances = totalMois(e, "seances"), prevues = totalMois(e, "prevues");
  const restit = totalMois(e, "restit"), restitAtt = totalMois(e, "restitAttendues");
  const directs = (e.histo || []).filter((x) => x.direct).length;
  const h = Math.floor(min / 60), m = min % 60;
  /* Le point mensuel suppose quatre semaines d'historique. Un élève récent
     n'en a qu'une : on compare alors ce qu'on a, sans planter. */
  const semaines = e.histo || [];
  const tendance = !semaines.length ? "trop tôt pour le dire"
    : semaines[semaines.length - 1].minutes >= semaines[0].minutes
      ? "en hausse" : "en baisse";
  const phrases = [
    "Sur les quatre dernieres semaines, " + e.nom + " a travaille " + h + " h " + String(m).padStart(2, "0")
      + " sur la plateforme, en " + seances + " seances sur les " + prevues + " prevues.",
    restit >= restitAtt
      ? "Toutes les restitutions feuille blanche ont ete faites (" + restit + "/" + restitAtt + ")."
      : "Restitutions feuille blanche : " + restit + " sur " + restitAtt + " attendues.",
    "Presence au direct hebdomadaire : " + directs + " seance(s) sur 4.",
    "Chapitre en cours : " + e.chap + ", depuis " + e.depuis + " semaine(s).",
    "Volume de travail " + tendance + " sur le mois.",
  ];
  if (e.dernierTravail >= 7) phrases.push("Point de vigilance : plus aucune activite depuis " + e.dernierTravail + " jours. Un echange serait utile.");
  return phrases.join(" ");
}

/* ========================= APP ============================================ */

export default function App() {
  const [phase, setPhase] = useState("onboarding");
  const [onglet, setOnglet] = useState("jour");
  const [accepteCharge, setAccepteCharge] = useState(false);
  /* LE DÉCALAGE ACCUMULÉ PAR « JOUR +1 ». Ce bouton avance l'élève de test,
     mais la position se recalcule depuis la date réelle à chaque chargement :
     l'élève revenait en semaine 1 et paraissait n'avoir rien fait. On enregistre
     donc le nombre de jours ajoutés, et on les rétablit à l'ouverture. Un élève
     ordinaire n'a jamais ce bouton, sa valeur reste à zéro. */
  const [joursAvances, setJoursAvances] = useState(0);
  /* LE JOURNAL DES SÉANCES FAITES. Les tâches sont recalculées à chaque
     déclaration, chaque contrôle, chaque changement de semaine — et malgré tous
     les garde-fous posés, l'historique finissait par fondre. On tient donc une
     liste À PART, jamais recalculée : une ligne par séance terminée, avec sa
     semaine et sa durée. C'est elle que le bilan mensuel du coach lit. */
  const [journalSeances, setJournalSeances] = useState([]);
  /* Le NOMBRE DE TÂCHES PRÉVUES par semaine, figé au moment de quitter la
     semaine. Sans lui, le bilan ne connaissait que les séances faites. */
  const [totauxSemaine, setTotauxSemaine] = useState([]);

  const [controlesPasses, setControlesPasses] = useState([]);


  const [reglages, setReglages] = useState({ joursCours: [1, 4], joursOff: [6], budgetSemaine: 30 });
  /* La durée que l'élève s'était fixée AVANT d'allonger ses soirées pour tenir
     deux chapitres. Sans cette mémoire, l'allongement resterait acquis à vie :
     l'application ne peut pas deviner qu'il était provisoire. */
  const [budgetAvant, setBudgetAvant] = useState(null);
  /* Les exercices servis en travail supplémentaire n'entrent pas dans les tâches
     de la semaine : sans cette liste, le moteur reproposerait indéfiniment le
     même à chaque « un exercice de plus ». */
  const [supplements, setSupplements] = useState([]);
  const [chapitres, setChapitres] = useState([]);
  const [semaine, setSemaine] = useState(1);
  /* Le jour réel de la semaine, pas un jour supposé. L'application partait du
     premier jour de cours déclaré : un élève qui s'inscrivait un jeudi voyait
     son programme commencer un lundi, et ses trois premières soirées étaient
     comptées comme manquées avant même qu'il ait ouvert l'application.
     JavaScript compte le dimanche à 0 ; ici la semaine commence le lundi. */
  const jourReel = () => (new Date().getDay() + 6) % 7;
  const [jour, setJour] = useState(jourReel);
  const [tachesBrutesEtat, setTaches] = useState([]);
  /* ═══════ UN CHAPITRE TERMINÉ NE REVIENT JAMAIS AU PROGRAMME ═══════════
     Sauf en RAPPEL, qui est une séance de questions flash sur un chapitre
     bouclé. Cette règle est posée ICI, à la racine : tout ce qui lit « taches »
     — le programme du soir, l'écran de la semaine, le bilan du coach — la
     respecte sans avoir à la répéter. Les tâches PASSÉES sont conservées :
     elles font l'historique. */
  const taches = useMemo(() => {
    const ouverts = new Set(chapitres.filter((c) => c.statut !== "termine")
      .map((c) => c.id));
    const abs = (t) => ((t.semaine || semaine) - 1) * 7 + (t.jour ?? 0);
    const maintenant = (semaine - 1) * 7 + jour;
    return tachesBrutesEtat.filter((t) => {
      if (!t.chapId || ouverts.has(t.chapId)) return true;   // chapitre ouvert
      /* Le RAPPEL et la SYNTHÈSE portent par nature sur un chapitre bouclé :
         le premier l'entretient en questions flash, la seconde le reprend une
         dernière fois au format bac, la semaine de sa clôture. */
      if (t.type === "rappel") return true;
      if (t.type === "bac" && /synth/i.test(t.motif || "")) return true;
      if (abs(t) < maintenant) return true;                  // le passé reste
      return false;                                          // le reste s'en va
    });
  }, [tachesBrutesEtat, chapitres, semaine, jour]);

  const [controle, setControle] = useState(null);
  /* La banque de DÉMONSTRATION ne sert qu'en mode démonstration : branchée à
     la base, l'application partait avec « Tramway » ou « Atelier mécanique »,
     et le programme du soir était posé avec ces exercices avant même que les
     vrais arrivent — ils ne s'ouvraient donc jamais. */
  const [biblio, setBiblio] = useState(supabaseActif ? {} : BIBLIO_INIT);
  const [ressources, setRessources] = useState(RESSOURCES_INIT);
  const [ideesOral, setIdeesOral] = useState(IDEES_ORAL);
  /* Ce qui vient de la base remplace le chapitre correspondant, sans effacer
     les autres : ajouter un chapitre en back-office ne fait rien disparaître. */
  const [banques, setBanques] = useState(BANQUES);
  const [vus, setVus] = useState([]);          // identifiants d'exercices deja proposes
  const [aRevoir, setARevoir] = useState([]);  // exercices rates ou hesitants, reproposes en bonus
  const [conseilMasque, setConseilMasque] = useState(null);
  const [oral, setOral] = useState({
    semaineEpreuve: null, etape: 1, retenues: [], ideeId: null, chapId: null,
    question: "", ancrage: "", statut: "brouillon", commentaire: "",
    plan: ["", "", ""], prises: [], tirages: [], sechees: [], secondeQuestion: "", oralBlanc: null,
    carnet: [], libre: false, notif: null,
    statutPlan: "brouillon", commentairePlan: "",
  });   // jour ou l'eleve a dit "plus tard"
  const [run, setRun] = useState(null);
  /* Le gestionnaire de retour arrière est posé une fois : il lit la séance et
     l'onglet par des références, jamais par la valeur figée à sa création. */
  const runRef = useRef(null);
  const ongletRef = useRef("jour");
  /* Le changement de niveau doit se voir : sinon l'élève progresse sans le savoir. */
  const [annonce, setAnnonce] = useState(null);
  const [diag, setDiag] = useState(null);
  const [eval_, setEval_] = useState(null);
  const [copies, setCopies] = useState([]);
  /* Les fils de démonstration n'existent qu'en mode aperçu. Dès que la base
     est branchée, la permanence part vide et se remplit des vraies questions. */
  const [threads, setThreads] = useState(supabaseActif ? [] : THREADS_INIT);
  const [declare, setDeclare] = useState(false);
  const [journal, setJournal] = useState([]);
  const [profil, setProfil] = useState(null);
  /* Les fils déjà lus. Ils vivaient jusqu'ici sur l'objet « thread », qui est
     rechargé depuis la base à chaque ouverture : la marque était perdue et la
     pastille se rallumait indéfiniment. Ils sont désormais dans l'état de
     l'élève, qui est enregistré. */
  const [lus, setLus] = useState([]);
  /* L'état des lectures figé à l'entrée dans la permanence : c'est lui qui
     détermine quels messages portent la pastille « nouveau ». */
  const [lusAvant, setLusAvant] = useState(null);
  /* Un élève qui s'inscrit un jeudi n'a que quatre jours de programme pour sa
     première semaine : la juger sur le même pied que les suivantes lui
     donnerait un bilan médiocre alors qu'il n'a rien manqué. On retient donc
     le numéro de sa semaine d'arrivée pour l'exclure des bilans. */
  const [semaineDemarrage, setSemaineDemarrage] = useState(null);
  /* Demande de replanification après la relecture de l'état : elle ne peut pas
     se faire pendant le chargement, les données n'étant pas encore posées. */
  const [aReplanifier, setAReplanifier] = useState(false);
  /* Le lundi de la semaine 1 : c'est LUI qui détermine la date, pas une suite
     d'additions. Posé à la première connexion, il ne bouge plus. */
  const [ancreLe, setAncreLe] = useState(null);
  const [directs, setDirects] = useState(supabaseActif ? [] : DIRECTS_INIT);
  /* L'échec d'enregistrement d'un cours, montré au coach : il était muet, et un
     cours refusé par la base disparaissait au rechargement sans explication. */
  const [avisDirect, setAvisDirect] = useState(null);    // programmes par le coach
  const [inscrits, setInscrits] = useState([]);            // semaines où l'élève est inscrit au direct
  /* Les élèves du coach, pour la barre de la permanence : sans eux, elle ne
     montre que ceux qui ont déjà écrit. */
  /* Le coach arrive sur SES ÉLÈVES, pas sur un programme du soir qui ne le
     concerne pas. On attend de connaître son rôle pour basculer. */
  const rolePose = useRef(false);
  useEffect(() => {
    if (rolePose.current || !profil) return;
    rolePose.current = true;
    if (profil.role === "coach") setOnglet("coach");
  }, [profil]);
  const [mesEleves, setMesEleves] = useState([]);
  useEffect(() => {
    if (!supabaseActif || profil?.role !== "coach") return;
    listerEleves().then(setMesEleves).catch(() => {});
  }, [profil]);

  const [questionsDirect, setQuestionsDirect] = useState([]);

  /* ---- chargement puis sauvegarde automatique de l'etat ---- */
  const [pret, setPret] = useState(!supabaseActif);
  const premierRendu = useRef(true);

  useEffect(() => {
    if (!supabaseActif) return;
    let vivant = true;
    (async () => {
      /* Le profil d'abord : sa date de création sert d'ancre au calendrier. */
      const pr = await monProfil();
      if (vivant && pr) setProfil(pr);

      const e = await chargerEtat();
      /* AUCUN ÉTAT EN BASE : le compte vient d'être remis à zéro, ou c'est une
         première connexion. On repart de l'inscription plutôt que de garder ce
         que l'application a en mémoire — sans quoi un élève remis à zéro
         retrouvait son ancien planning. */
      if (vivant && !e) {
        setReglages({ joursCours: [1, 4], joursOff: [6], budgetSemaine: 30 });
        setChapitres([]); setTaches([]); setCopies([]); setVus([]);
        setSemaine(1); setJour(0); setControle(null); setJournal([]);
        setPhase("onboarding"); setDeclare(false);
        /* La sauvegarde reprend NORMALEMENT : l'élève qui s'inscrit doit voir
           son travail enregistré dès sa première séance. La bloquer évitait une
           ligne vide en base, mais empêchait surtout tout enregistrement pour
           un compte neuf — son planning disparaissait à chaque rechargement. */
        premierRendu.current = false;
        /* LA BANQUE D'ABORD, même pour un compte neuf : l'application se
           déclarait prête sans elle, et le programme construit à la fin du
           test ne trouvait aucun exercice. Il fallait recharger la page pour
           qu'il apparaisse. */
        try {
          const bq = await chargerBiblio();
          if (vivant && bq) setBiblio(bq);
        } catch (err) { /* sans banque, le garde-fou reprendra la main */ }
        setPret(true);
        return;
      }
      if (vivant && e) {
        /* Le choix de 45 min n'existe plus : un élève qui l'avait retenu
           repasse à 30, sans quoi aucune durée n'apparaîtrait sélectionnée. */
        if (e.reglages) setReglages(e.reglages.budgetSemaine === 45
          ? { ...e.reglages, budgetSemaine: 30 } : e.reglages);
        if (e.chapitres) setChapitres(e.chapitres);
        if (e.taches) setTaches(e.taches);
        /* Le calendrier se calcule à partir d'une DATE D'ANCRAGE — le lundi
           de la semaine 1 — et non par additions successives. Avancer d'un
           écart à chaque connexion faisait dériver le calendrier : un jour de
           trop par ouverture, et l'élève se retrouvait jeudi un mardi. Ancrée,
           la date ne peut plus dériver, quel que soit le nombre de connexions. */
        const jourDe = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
        const aujourdhui = jourReel();

        /* L'ancre est le LUNDI DE LA SEMAINE D'INSCRIPTION, déduit de la date
           de création du compte. C'est la seule référence qui ne dépende
           d'aucun état enregistré, donc d'aucune dérive passée : deux comptes
           créés le même jour verront toujours la même semaine.
           Une ancre déjà posée n'est conservée que si elle tombe elle aussi un
           lundi ET donne le jour réel — sinon elle est recalculée. */
        const lundiDe = (d) => {
          const x = new Date(d);
          x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
          x.setHours(0, 0, 0, 0);
          return x;
        };
        const inscription = pr?.cree_le || e.enregistreLe;
        /* Le LUNDI de la semaine d'inscription. Les semaines suivent le
           calendrier réel : un élève inscrit un dimanche est en fin de semaine 1,
           et la semaine 2 commence le lundi. Compter à partir du jour même
           décalait tout le monde et rendait les dates incomparables. */
        const attendue = lundiDe(inscription || new Date());

        /* L'ancre est le JOUR DE L'INSCRIPTION : la semaine 1 commence ce
           jour-là. Elle était calée sur le lundi précédent, ce qui rattachait
           un élève inscrit un vendredi à une semaine ouverte quatre jours
           avant son arrivée. Une ancre enregistrée n'est gardée que si elle
           correspond encore à cette inscription. */
        /* L'ancre enregistrée est CONSERVÉE : la recalculer déplaçait l'élève
           d'une semaine, et les tâches déjà rangées sous l'ancien numéro
           disparaissaient de son programme. On ne la repose que si elle manque,
           ou si elle est postérieure à l'inscription — signe qu'elle est
           fausse. */
        let ancre = e.ancreLe;
        if (ancre && jourDe(new Date(ancre)) > jourDe(attendue)) ancre = null;
        if (!ancre) ancre = attendue.toISOString();
        setAncreLe(ancre);

        /* Le DÉCALAGE DE « JOUR +1 » s'ajoute à la position réelle : sans lui,
           un compte de test avancé de plusieurs jours revenait à la date du
           jour au rechargement, et tout son travail paraissait perdu. */
        const abs = Math.max(0, Math.round(
          (jourDe(new Date()) - jourDe(new Date(ancre))) / 86400000))
          + (e.joursAvances || 0);
        setSemaine(Math.floor(abs / 7) + 1);
        setJour(abs % 7);

        /* Les soirées passées et jamais ouvertes deviennent des soirées
           manquées : sans cela, aucun rattrapage n'était proposé à un élève
           revenu après plusieurs jours d'absence. */
        if (e.taches) {
          const absDe = (t) => (t.semaine - 1) * 7 + t.jour;
          setTaches(e.taches.map((t) => (t.statut === "a_faire" && absDe(t) < abs
            ? { ...t, statut: "manquee" } : t)));
        }

        if (e.controle !== undefined) setControle(e.controle);
        if (e.controlesPasses) setControlesPasses(e.controlesPasses);
        if (e.joursAvances) setJoursAvances(e.joursAvances);
        /* Les exercices À REVOIR : la liste n'était pas enregistrée et se
           vidait à chaque rechargement — un exercice hésité ne revenait donc
           jamais le lendemain. */
        if (e.aRevoir) setARevoir(e.aRevoir);
        /* Le choix « je travaille plus » : non enregistré, la carte « Le compte
           n'y est pas » revenait à chaque rechargement, alors que l'élève avait
           déjà tranché. */
        if (e.accepteCharge) setAccepteCharge(true);
        if (e.supplements) setSupplements(e.supplements);
        if (e.journalSeances) setJournalSeances(e.journalSeances);
        if (e.totauxSemaine) setTotauxSemaine(e.totauxSemaine);
        /* L'historique vient désormais de SES PROPRES TABLES : il complète ce
           que l'état porte encore, le temps que les anciens comptes migrent. */
        /* Le COACH n'a pas d'historique à lui : cette requête chargeait le
           sien — vide — et son résultat écrasait celui de la requête complète.
           On lit le profil LOCAL « pr » : « profil » n'est pas encore renseigné
           à ce stade du chargement, et le garde-fou ne jouait jamais. */
        /* Un « return » ici sortait de TOUTE la fonction de chargement, et
           « setPret » n'était jamais atteint : le coach restait bloqué sur
           « Chargement… ». On saute seulement cette requête. */
        if (pr?.role !== "coach") chargerHistorique().then((h) => {
          if (!vivant || !h) return;
          if (h.seances.length) setJournalSeances((l) => {
            const vus = new Set(l.map((x) => String(x.id)));
            return [...l, ...h.seances.filter((x) => !vus.has(String(x.id)))];
          });
          if (h.semaines.length) setTotauxSemaine((l) => {
            const vus = new Set(l.map((x) => x.semaine));
            return [...l, ...h.semaines.filter((x) => !vus.has(x.semaine))];
          });
        }).catch(() => {});
        if (e.inscrits) setInscrits(e.inscrits);
        if (e.questionsDirect) setQuestionsDirect(e.questionsDirect);
        if (e.copies) setCopies(e.copies);
        if (e.vus) setVus(e.vus);
        if (e.lus) setLus(e.lus);
        if (e.semaineDemarrage != null) setSemaineDemarrage(e.semaineDemarrage);
        if (e.oral) setOral(e.oral);
        if (e.phase) setPhase(e.phase);

        /* Le calendrier a avancé, mais les tâches restaurées sont celles de la
           semaine où l'élève s'est arrêté : la nouvelle semaine était vide, et
           son chapitre en cours disparaissait du planning. On replanifie donc
           dès qu'un jour au moins s'est écoulé — les soirées passées ne sont
           jamais réécrites, seul l'à-venir est recalculé. */
        setAReplanifier(true);
      }
      const b = await chargerBiblio();
      if (vivant && b) setBiblio(b);
      const pd = await chargerPeriodes();
      if (vivant && pd) setPeriodes(pd.map((x) => ({ ...x,
        semaineDebut: x.semaine_debut, semaineFin: x.semaine_fin,
        restitutions: x.restitutions })));
      const el = await chargerEntrainementsLibres();
      if (vivant && el) setLibres(el);
      const rs = await chargerRessources();
      /* On fusionne LISTE PAR LISTE : remplacer le chapitre entier effaçait
         les sujets Labolycée, qui viennent du code et non de la base. */
      if (vivant && rs) setRessources((prec) => {
        const fusion = { ...prec };
        Object.entries(rs).forEach(([cid, chap]) => {
          fusion[cid] = { ...(prec[cid] || {}), ...chap,
            sujets: (prec[cid] || {}).sujets || [] };
        });
        return fusion;
      });
      const dr = await chargerDirects();
      if (vivant && dr) setDirects(dr);
      const io = await chargerIdeesOral();
      if (vivant && io) setIdeesOral([...IDEES_ORAL, ...io]);
      const bq = await chargerBanque();
      if (vivant && bq) setBanques({ ...BANQUES, ...bq });
      const s = await chargerSujets();
      if (vivant && s) setThreads(s);
      else if (vivant && supabaseActif) setThreads([]);
      if (vivant) setPret(true);
    })();
    return () => { vivant = false; };
  }, []);

  /* CE MÉCANISME A ÉTÉ RETIRÉ. Il rechargeait la page dès qu'aucun état n'était
     trouvé en base, pour qu'un élève remis à zéro reparte de l'inscription.
     Mais un élève qui vient de s'inscrire n'a pas encore d'état — sa première
     sauvegarde est différée de quelques secondes : chaque retour sur l'onglet
     rechargeait la page avant qu'elle parte, et son travail n'était jamais
     enregistré. La remise à zéro se constate à la reconnexion, cela suffit. */

  useEffect(() => {
    if (!supabaseActif || !pret) return;
    if (premierRendu.current) { premierRendu.current = false; return; }
    /* L'HISTORIQUE DES CONTRÔLES est enregistré : gardé en mémoire seulement,
       il disparaissait au moindre rechargement, et l'écran DS perdait toute
       trace des devoirs passés. */
    /* Le JOURNAL et les TOTAUX ne sont plus enregistrés dans l'état : ils
       vivent dans leurs propres tables, écrits une fois et jamais réécrits.
       Les garder ici les faisait grossir sans fin et les exposait à être
       effacés par un recalcul. */
    sauverEtat({ reglages, chapitres, taches, semaine, jour, joursAvances, controle, controlesPasses, aRevoir, supplements, accepteCharge, inscrits, questionsDirect, copies, vus, oral, phase, lus, semaineDemarrage,
                 enregistreLe: new Date().toISOString(), ancreLe });
  }, [pret, reglages, chapitres, taches, semaine, jour, joursAvances, aRevoir, accepteCharge, controle, controlesPasses, journalSeances, totauxSemaine, inscrits, questionsDirect, copies, vus, oral, phase, lus, semaineDemarrage]);

  const principaux = chapitres.filter((c) => c.statut !== "termine");
  /* Ce que l'écran de permanence affiche : les fils communs, plus les messages
     privés adressés à la personne connectée. Jamais ceux des autres, et le
     filtre ne dépend PAS du rôle — un compte coach mal configuré ne doit pas
     ouvrir la correspondance privée des élèves.

     ATTENTION : ce filtre est un confort d'affichage, pas une sécurité. La
     confidentialité réelle se joue dans Supabase, par une règle de sécurité au
     niveau des lignes (RLS) qui interdit de LIRE un message privé dont on n'est
     pas le destinataire. Voir README-DEPLOIEMENT.md. */
  const MOI = profil?.nom || "Vous (démo)";
  /* Un fil privé n'est visible que de son destinataire — ou du coach, qui suit
     tout. La comparaison se fait sur l'IDENTIFIANT du profil : le nom
     d'affichage ne suffit pas et changeait d'un écran à l'autre. */
  const threadsVisibles = threads.filter((t) => !t.prive
    || (supabaseActif ? profil?.role === "coach" : true)
    || (t.pourEleveId && t.pourEleveId === profil?.id)
    || t.pourEleve === MOI);
  /* La pastille signale ce qui attend une action de l'élève : un fil dont le
     DERNIER message vient du coach ou d'un camarade, et qu'il n'a pas encore
     ouvert. Compter les fils « en attente » comptait aussi ses propres
     questions, et la pastille ne s'éteignait jamais. */
  /* On retient le DERNIER MESSAGE lu de chaque fil, pas seulement le fait de
     l'avoir ouvert. Marquer un fil comme lu une fois pour toutes éteignait la
     pastille définitivement : un nouveau message du coach sur un fil déjà
     consulté n'était plus jamais signalé. */
  const dernierLu = (id) => {
    const e = lus.find((x) => (typeof x === "object" ? x.id : x) === id);
    return e && typeof e === "object" ? e.msg : (e ? "tout" : null);
  };
  /* L'empreinte d'un fil : elle change à CHAQUE événement — nouveau message,
     réponse validée, erreur signalée, fil résolu. Se fonder sur le seul dernier
     message laissait passer les validations du coach et les signalements, qui
     n'ajoutent rien mais changent tout pour l'élève. */
  const empreinte = (t) => {
    const m = t?.messages || [];
    return [m.length, m[m.length - 1]?.id ?? "", t?.statut ?? "",
            m.filter((x) => x?.valide).length,
            m.filter((x) => x?.signale).length].join("|");
  };

  const aLire = (t) => {
    const msgs = t?.messages || [];
    const dernier = msgs[msgs.length - 1];
    if (!dernier || t.lu) return false;
    const vu = dernierLu(t.id);
    if (vu === "tout") return false;
    if (vu !== null && String(empreinte(t)) === String(vu)) return false;

    /* Le fil a bougé. Mais écrire soi-même ne s'alerte pas : on ne signale que
       si le changement vient d'AILLEURS — un message d'autrui, une réponse
       validée, une erreur signalée, un fil résolu. */
    const parAutrui = dernier.role !== "moi";
    const evenement = msgs.some((m) => m?.valide || m?.signale)
                   || t.statut === "resolu";
    return parAutrui || evenement;
  };
  const enAttente = threadsVisibles.filter(aLire).length;

  /* La permanence en DIRECT : Supabase pousse chaque changement, et les fils se
     rafraîchissent sans qu'on ait à rouvrir l'application. On se désabonne à la
     sortie, sinon les abonnements s'accumulent. */
  useEffect(() => {
    if (!supabaseActif || !pret) return;
    let occupe = false;
    const relire = async () => {
      if (occupe) return;
      occupe = true;
      try { const s = await chargerSujets(); if (s) setThreads(s); }
      finally { occupe = false; }
    };
    return ecouterPermanence(relire);
  }, [pret]);

  /* Ouvrir la permanence vaut lecture : la pastille signale qu'il y a du
     nouveau, pas qu'il reste des fils à ouvrir un par un. Elle s'éteint donc
     dès que l'écran est affiché, côté élève comme côté coach. */
  useEffect(() => {
    if (onglet !== "permanence") return;
    /* On FIGE l'état des lectures à l'entrée dans l'écran. La marque « lu » est
       posée aussitôt, pour éteindre la pastille du menu — mais les pastilles
       « nouveau » des messages doivent, elles, se fonder sur ce que l'élève
       avait vu AVANT d'ouvrir, sinon elles disparaissent dans le même souffle. */
    setLusAvant((prec) => (prec === null ? lus : prec));
    const nouveaux = threadsVisibles.filter(aLire).map((t) => ({
      id: t.id, msg: empreinte(t) }));
    if (!nouveaux.length) return;
    setLus((l) => {
      const garde = l.filter((x) => !nouveaux.some(
        (n) => n.id === (typeof x === "object" ? x.id : x)));
      return [...garde, ...nouveaux];
    });
  }, [onglet, threads]);

  /* En quittant l'écran, on relâche le figeage : la prochaine visite repartira
     de l'état réel des lectures. */
  useEffect(() => {
    if (onglet !== "permanence") setLusAvant(null);
  }, [onglet]);

  /* Une révision, une épreuve blanche ou une reprise n'a de sens que RATTACHÉE
     au contrôle en cours. Dès que le contrôle change de date, disparaît, ou
     qu'elle ne correspond plus au compte à rebours, elle devient un fantôme.
     Comme ces tâches sont marquées « non fait », elles échappaient au ménage
     de la replanification, qui protège justement ce qui reste à rattraper. */
  const tacheDeControle = (t) => ["revision", "blanche", "reprise"].includes(t.type);
  const controleObsolete = (t, ctrl, sem) => {
    if (!tacheDeControle(t) || t.statut === "fait") return false;
    /* Une tâche d'une SEMAINE RÉVOLUE n'est jamais obsolète : elle appartient
       à l'histoire, pas au programme. L'effacer vidait le bilan mensuel — le
       coach voyait « 0/0 » sur des semaines réellement travaillées. */
    if ((t.semaine || sem) < sem) return false;
    if (!ctrl) return true;                                  // plus de contrôle du tout
    const absDS = (ctrl.semaine - 1) * 7 + ctrl.jour;
    const absTache = ((t.semaine || sem) - 1) * 7 + t.jour;
    if (absTache > absDS) return true;                       // posée après l'épreuve
    if (!ctrl.chapitres.includes(t.chapId)) return true;     // porte sur un autre chapitre
    /* le compte à rebours affiché doit correspondre à la date réelle */
    const attendu = absDS - absTache;
    const affiche = /dans (\d+) j/.exec(t.motif || "");
    return Boolean(affiche && Number(affiche[1]) !== attendu);
  };

  /* Ouvrir un fil vaut lecture. */
  /* Vider la permanence : les fils résolus s'accumulent au fil des mois et
     noient les questions en cours. Réservé au coach, et sans toucher aux fils
     encore ouverts ni aux messages privés adressés à un élève. */
  const viderPermanence = async (tout = false) => {
    setThreads((ts) => (tout ? [] : ts.filter((t) => t.statut !== "resolu" || t.prive)));
    if (supabaseActif) {
      await supprimerSujets({ tout });
      const s = await chargerSujets();
      setThreads(s || []);
    }
  };

  const marquerLu = (id) => {
    setThreads((ts) => ts.map((t) => (t.id === id ? { ...t, lu: true } : t)));
    const t = threads.find((x) => x.id === id);
    const msg = t ? empreinte(t) : null;
    setLus((l) => [...l.filter((x) => (typeof x === "object" ? x.id : x) !== id),
                   { id, msg }]);
  };
  /* Filet de sécurité : un chapitre déclaré sans niveau DOIT faire apparaître
     son test, quoi qu'il arrive. Si la replanification n'a pas su le poser —
     soirée pleine, jour de repos, état rechargé depuis la base au mauvais
     moment — on l'ajoute ici. Sans test, le chapitre reste bloqué : le moteur
     ignore le niveau de l'élève et ne peut rien lui servir. */
  /* La SEMAINE compte autant que le jour. Depuis que l'historique est
     conservé, filtrer sur le seul jour rassemblait le mardi de la semaine 1 et
     celui de la semaine 2 : le test diagnostic déjà passé réapparaissait barré,
     et la soirée affichait le double du temps annoncé. */
  /* Les séances HORS PROGRAMME — travaillées depuis Progrès — n'entrent pas
     dans le programme du soir : elles servent uniquement à cocher le geste.
     Le planning de l'élève ne doit jamais changer parce qu'il a travaillé de
     lui-même. */
  const tachesBrutes = taches.filter((t) => t.jour === jour
    && t.semaine === semaine && !t.masquee && !t.horsProgramme);
  const testsManquants = chapitres
    .filter((c) => c.statut === "en_cours" && !c.niveau)
    .filter((c) => !taches.some((t) => t.type === "diagnostic" && t.chapId === c.id
                                    && t.statut !== "fait"))
    .map((c) => ({
      id: "diag-secours-" + c.id, type: "diagnostic", chapId: c.id, jour,
      semaine, duree: 10, statut: "a_faire", obligatoire: true,
      libelle: "Test de positionnement",
      chapNom: CHAPITRES.find((x) => x.id === c.id)?.nom || c.id,
      motif: "Nouveau chapitre · test à passer avant tout travail",
    }));
  const tachesDuJour = [...testsManquants, ...tachesBrutes];
  /* La soiree manquee la plus recente. On rattrape la soiree entiere : une
     feuille blanche sans son exercice d'application n'a pas de sens. */
  /* Une soirée manquée se rattrape même si la semaine a changé : un dimanche
     sauté doit pouvoir être repris le lundi. On raisonne en jours absolus, et
     l'on s'arrête à sept jours — au-delà, le programme a trop avancé. */
  const absJour = (t) => (t.semaine - 1) * 7 + t.jour;
  const absAujourdhui = (semaine - 1) * 7 + jour;
  /* Un DIRECT manqué ne se rattrape pas : c'est un cours en visio à une heure
     donnée, pas un exercice à reprendre. Le compter faisait apparaître « rattrape
     ton retard » le lendemain de chaque direct auquel l'élève n'était pas venu. */
  const manquees = taches.filter((t) => t.statut === "manquee" && !t.masquee
    && t.type !== "direct"
    && absJour(t) < absAujourdhui && absAujourdhui - absJour(t) <= 7);
  const absARattraper = manquees.length ? Math.max(...manquees.map(absJour)) : null;
  const jourARattraper = absARattraper === null ? null : absARattraper % 7;
  const aRattraper = absARattraper === null
    ? null
    : { jour: jourARattraper,
        semaine: Math.floor(absARattraper / 7) + 1,
        anciennete: absAujourdhui - absARattraper,
        taches: manquees.filter((t) => absJour(t) === absARattraper) };

  /* Le carnet de pistes : un bouton depuis un chapitre ou un fil de permanence.
     Il se remplit toute l'annee, et sert de point de depart en janvier. */
  const ajouterAuCarnet = (piste) =>
    setOral((o) => ({
      ...o,
      carnet: o.carnet.some((x) => x.txt === piste.txt)
        ? o.carnet.map((x) => (x.txt === piste.txt ? { ...x, ...piste } : x))
        : [...o.carnet, { id: "p" + Date.now(), semaine, ...piste }],
    }));

  const retirerDuCarnetParTexte = (txt) =>
    setOral((o) => ({ ...o, carnet: o.carnet.filter((x) => x.txt !== txt) }));

  const retirerDuCarnet = (id) =>
    setOral((o) => ({ ...o, carnet: o.carnet.filter((x) => x.id !== id) }));

  /* Un exercice mal reussi revient EN PLUS de la seance du soir, jamais a la
     place : l'eleve le refait s'il le veut. */
  /* Un exercice hésité ou raté se reprend un AUTRE JOUR : le reproposer le soir
     même n'apprend rien — l'élève a la correction sous les yeux — et donnait
     l'impression que l'application tournait en rond. On note donc le jour où il
     a été mis de côté, et on attend le lendemain. */
  /* L'EXERCICE À REVOIR reste proposé même quand la soirée est terminée : il
     n'apparaissait qu'aux côtés d'une tâche encore à faire, et disparaissait
     dès que l'élève avait fini son programme — c'est-à-dire au moment où il
     aurait pu le reprendre. */
  const conseille = (!aRattraper && aRevoir.length && conseilMasque !== jour
    && aRevoir[0].jour !== absAujourdhui) ? aRevoir[0] : null;

  const lancerConseille = () => setRun({
    id: "conseil-" + conseille.exoId, type: "exo", cat: "normal", conseille: true,
    chapId: conseille.chapId, chapNom: conseille.chapNom, libelle: "Exercice conseille : a revoir",
    duree: conseille.duree, difficulte: conseille.niveau, motif: "Vous l'aviez marque " + conseille.resultat,
    exoId: conseille.exoId, exoTitre: conseille.titre, exoNiveau: conseille.niveau,
    statut: "a_faire", resultat: null, jour, semaine,
  });

  const plusTard = () => { setConseilMasque(jour); setARevoir((r) => [...r.slice(1), r[0]]); };

  const passerRattrapage = (soiree) =>
    setTaches((ts) => ts.map((x) => (x.jour === soiree.jour && x.semaine === soiree.semaine
      && x.statut === "manquee" ? { ...x, statut: "abandonnee" } : x)));
  const jourDeCours = reglages.joursCours.includes(jour);

  /* CHAQUE COMPTE A SA PROPRE NUMÉROTATION DE SEMAINES : elle part de sa date
     d'inscription. Un cours programmé « semaine 4 » par le coach tombait donc
     trois semaines plus loin chez un élève arrivé plus tard — et disparaissait
     de sa fenêtre d'affichage. On replace chaque cours à partir de sa DATE,
     dans le calendrier de celui qui regarde. */
  /* LES ÉLÈVES DU LYCÉE reçoivent tout — exercices, fiches, suivi, sujets —
     SAUF les cours en visioconférence et le robot d'aide. Les deux ont un
     coût, et ne leur sont pas vendus. Le groupe vaut « instagram » par
     défaut : les comptes déjà en place ne changent donc en rien. */
  const groupeLycee = supabaseActif && profil?.groupe === "lycee";
  const directsLocaux = useMemo(() => {
    if (groupeLycee) return [];
    const zero = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    return (directs || []).map((d) => {
      if (!d.date || !ancreLe) return d;
      const abs = Math.round((zero(new Date(d.date)) - zero(new Date(ancreLe))) / 86400000);
      if (!Number.isFinite(abs)) return d;
      return { ...d, semaine: Math.floor(abs / 7) + 1, jour: ((abs % 7) + 7) % 7,
               avantInscription: abs < 0 };
    }).filter((d) => !d.avantInscription);
  }, [directs, ancreLe, groupeLycee]);

  /* PLUSIEURS COURS PAR SEMAINE. Un seul était retenu : le coach qui en
     programmait un second sur un autre chapitre effaçait le premier. */
  const directsDeLaSemaine = (sem) => directsLocaux.filter((d) => d.semaine === sem);
  const directProgramme = (sem) => directsDeLaSemaine(sem)[0] || null;
  const directDe = (sem, listeInscrits = inscrits) =>
    directsDeLaSemaine(sem).filter((d) =>
      listeInscrits.includes(cleDirect(d)) || listeInscrits.includes(sem));

  /* ANNULER UN COURS. Il disparaît de la liste du coach, de la base, et du
     programme de chacun : la replanification ne le retrouvera plus, donc la
     séance s'efface d'elle-même chez les élèves inscrits. */
  const annulerDirect = (d) => {
    setDirects((l) => l.filter((x) => !((d.id && x.id === d.id)
      || (x.semaine === d.semaine && x.jour === d.jour))));
    if (supabaseActif) supprimerDirect(d);
    setAReplanifier(true);
  };

  /* Programmer ou modifier le direct d'une semaine : un seul par semaine. */
  const programmerDirect = (d0) => {
    /* On calcule la DATE à partir du calendrier du coach : c'est elle qui
       sera lue par chacun, dans sa propre numérotation. */
    const q = dateDe(ancreLe, d0.semaine, d0.jour);
    const d = { ...d0, date: q
      ? q.getFullYear() + "-" + String(q.getMonth() + 1).padStart(2, "0")
        + "-" + String(q.getDate()).padStart(2, "0")
      : d0.date || null };
    /* On ne remplace QUE le cours du même jour : deux cours la même semaine, sur
       deux jours différents, coexistent désormais. */
    const memeCreneau = (x) => (d.id && x.id === d.id)
      || (x.semaine === d.semaine && x.jour === d.jour);
    const liste = [...directs.filter((x) => !memeCreneau(x)), d]
      .sort((a, b) => (a.semaine - b.semaine) || (a.jour - b.jour));
    setDirects(liste);
    if (supabaseActif) {
      /* On attend la réponse de la base : un cours refusé disparaissait au
         rechargement sans que rien ne le signale. */
      enregistrerDirect(d).then((r) => {
        if (r && r.ok === false) {
          setDirects((l) => l.filter((x) => x !== d));
          setAvisDirect("Ce cours n'a pas pu être enregistré : " + r.message
            + ". Si le message parle d'une contrainte « on conflict », c'est "
            + "l'index (semaine, jour) qui manque en base.");
        } else setAvisDirect(null);
      });
    }
    if (d.semaine === semaine) {
      const neuves = planifierSemaine({
        chapitres, reglages, semaine, controle, depuis: jour,
        existantes: taches.filter((t) => t.semaine === semaine && (t.jour < jour || t.statut !== "a_faire")),
        direct: inscrits.includes(semaine) ? d : null, biblio, vus,
      });
      setTaches((anc) => {
        /* Même règle que la replanification : l'historique des semaines
           antérieures se conserve, sinon le travail accompli disparaît. */
        /* Les semaines RÉVOLUES sont conservées en entier, comme dans la
           replanification : ce qui restait « à faire » devient une soirée
           manquée. Les écarter vidait le bilan mensuel. */
        /* Les tâches à venir d'un chapitre QUI N'EST PLUS OUVERT sont
           écartées ici aussi : ce second chemin de replanification n'avait pas
           le filtre, et les exercices d'un chapitre clos revenaient. */
        const ouvertsIci = new Set(chapitres.filter((c) => c.statut !== "termine")
          .map((c) => c.id));
        const gardees = anc.filter((t) =>
          !(t.chapId && !ouvertsIci.has(t.chapId) && t.statut === "a_faire"
            && ((t.semaine || semaine) > semaine
                || ((t.semaine || semaine) === semaine && t.jour >= jour)))
          && ((t.semaine === semaine
            && (t.jour < jour || t.statut !== "a_faire" || t.rattrapage))
           || t.semaine < semaine)
          && !controleObsolete(t, controle, semaine))
          .map((t) => (t.semaine < semaine && t.statut === "a_faire"
            ? { ...t, statut: "manquee" } : t));
        /* « sem » n'existe pas dans ce bloc : la variable est « semaine ».
           L'erreur passait inaperçue tant qu'on n'entrait pas dans ce chemin,
           où elle jetait une exception et laissait la page blanche. */
        const cles = new Set(gardees.filter((t) => t.semaine === semaine)
        .map((t) => t.jour + "-" + t.type + "-" + t.chapId));
        return [...gardees, ...neuves.filter((t) => !cles.has(t.jour + "-" + t.type + "-" + t.chapId)).map((t) => ({ ...t, semaine }))]
          .sort((a, b) => a.jour - b.jour);
      });
    }
  };

  /* Le temps qu'un chapitre demande par soirée. Cette constante était déclarée
     APRÈS le calcul du budget, qui l'emploie : la page blanchissait au moment
     où l'élève acceptait de travailler plus. */
  const MINUTES_PAR_CHAPITRE = 30;
  /* UN CHAPITRE DONT LE CONTRÔLE EST PASSÉ ne compte plus, même s'il n'est pas
     encore déclaré terminé : le budget restait à soixante minutes alors qu'un
     seul chapitre était réellement au programme. */
  const chapitresActifs = chapitres.filter((c) => {
    if (c.statut === "termine") return false;
    const ct = [controle, ...controlesPasses].find((x) => x
      && (x.chapitres || []).includes(c.id));
    if (!ct) return true;
    return (ct.semaine - 1) * 7 + (ct.jour || 0) >= (semaine - 1) * 7 + jour;
  }).length;
  /* Le budget RELEVÉ : trente minutes par chapitre en cours, plafonné à
     quatre-vingt-dix. Il ne s'applique qu'avec l'accord de l'élève, et
     redescend tout seul dès qu'un chapitre est clos. */
  const budgetRetenu = (() => {
    const base = reglages.budgetSemaine;
    if (!accepteCharge || chapitresActifs < 2) return base;
    return Math.max(base, Math.min(90, chapitresActifs * MINUTES_PAR_CHAPITRE));
  })();
  const reglagesEffectifs = budgetRetenu === reglages.budgetSemaine
    ? reglages : { ...reglages, budgetSemaine: budgetRetenu };

  /* LE BUDGET EST RECALCULÉ ICI, jamais reçu tel quel. Les appelants passaient
     une valeur figée au moment de leur création — la fin du test transmettait
     30 minutes alors que l'élève venait d'accepter d'en faire 60. On repart
     donc des chapitres réellement actifs et du choix enregistré. */
  const budgetPour = (chaps, regl, forceAccord = false) => {
    const base = regl?.budgetSemaine || reglages.budgetSemaine;
    const n = chaps.filter((c) => c.statut !== "termine").length;
    /* « forceAccord » sert au clic même : React n'a pas encore enregistré le
       choix de l'élève, et le budget serait calculé sans lui. */
    if ((!accepteCharge && !forceAccord) || n < 2)
      return { ...(regl || reglages), budgetSemaine: base };
    return { ...(regl || reglages),
      budgetSemaine: Math.max(base, Math.min(90, n * MINUTES_PAR_CHAPITRE)) };
  };

  const replanifier = (chaps = chapitres, ctrl = controle, sem = semaine, depuis = jour, listeInscrits = inscrits, reglRecu = reglagesEffectifs, forceAccord = false) => {
    const regl = budgetPour(chaps, reglRecu, forceAccord);
    /* SANS BANQUE, ON NE PLANIFIE PAS. Les tâches seraient posées sans
       exercice — « la bibliothèque de ce chapitre est épuisée » —, et la
       replanification n'a lieu qu'une fois : le mal serait durable. On
       redemande à replanifier dès que la banque arrive. */
    if (supabaseActif && !Object.keys(biblio).length) {
      setAReplanifier(true);
      return;
    }
    setTaches((anc) => {
      // on garde tout ce qui est passé ou déjà fait : déclarer un chapitre n'efface rien
      /* On garde tout ce qui est passé ou déjà fait dans la semaine courante,
         et TOUT L'HISTORIQUE des semaines antérieures. Ne conserver que les
         soirées manquées effaçait le travail accompli : le coach voyait « 0 »
         sur une semaine réellement travaillée, et le bilan mensuel était vide.
         Seules les tâches encore à faire d'une semaine révolue sont écartées —
         sauf les manquées, qui restent rattrapables. */
      /* Un sujet REPORTÉ revient la semaine suivante, en plus de celui prévu.
         Reporté une seconde fois, il disparaît : on ne traîne pas un sujet
         toute l'année. */
      /* Le sujet reporté est ramené à la semaine courante, ET la copie déjà
         ramenée est conservée telle quelle. Sans ce second cas, la deuxième
         replanification de la semaine ne le reconnaissait plus — il portait
         désormais « a_faire » — et le sujet disparaissait sans laisser de
         trace. C'est ce qui le faisait manquer à l'appel. */
      const reportes = anc
        .filter((t) => t.type === "bac" && (t.reports || 0) > 0 && (t.reports || 0) < 2
          && (t.statut === "reporte" ? t.semaine < sem
                                     : t.semaine === sem && t.statut === "a_faire"))
        .map((t) => ({ ...t, semaine: sem, statut: "a_faire",
                       libelle: "Sujet reporté",
                       motif: "Reporté de la semaine dernière · dernière occasion" }));

      /* L'original d'un sujet reporté est ÉCARTÉ de l'historique : sa copie
         vient d'être créée pour cette semaine, le garder produisait deux
         tâches de même identifiant, et le garde-fou final en supprimait une —
         souvent la bonne. Le sujet reporté ne réapparaissait donc jamais. */
      const idsReportes = new Set(reportes.map((t) => t.id));
      /* LES TÂCHES À VENIR D'UN CHAPITRE CLOS SONT ÉCARTÉES. La clôture ne
         touchait pas aux tâches déjà posées : des exercices d'entraînement
         restaient au programme pour un chapitre dont le contrôle était passé.
         Celles des jours écoulés restent, elles font l'historique. */
      /* ON GARDE LES SEULS CHAPITRES ENCORE OUVERTS. Le filtre s'appuyait sur
         la liste des chapitres TERMINÉS : un chapitre disparu de cette liste —
         c'est le cas d'un chapitre clos depuis longtemps — n'y figurait plus,
         et ses tâches restaient au programme. On raisonne à l'inverse : toute
         tâche à venir qui ne porte pas sur un chapitre ouvert est écartée. */
      const ouvertsIds = new Set(chaps.filter((c) => c.statut !== "termine")
        .map((c) => c.id));
      const gardees = anc.filter((t) =>
        !(t.chapId && !ouvertsIds.has(t.chapId) && t.statut === "a_faire"
          && ((t.semaine || sem) > sem || ((t.semaine || sem) === sem && t.jour >= depuis)))
        && !idsReportes.has(t.id)
        && ((t.semaine === sem && (t.jour < depuis || t.statut !== "a_faire" || t.rattrapage))
            /* Les tâches d'une semaine RÉVOLUE sont toutes conservées : celles
               restées « à faire » deviennent des soirées manquées. Les écarter
               faisait fondre l'historique — le coach voyait « 0/3 » là où
               l'élève avait eu quinze tâches, et le bilan mensuel était faux. */
            || t.semaine < sem)
        && !controleObsolete(t, ctrl, sem));
      // les tâches conservées comptent dans le quota de la semaine
      /* Même règle ici : un sujet reporté ne doit pas être reproposé comme
         sujet de la semaine. */
      /* Ce qui restait « à faire » dans une semaine passée est marqué manqué :
         c'est la vérité de ce qui s'est produit, et le rattrapage s'appuie
         dessus. */
      const gardeesAjour = gardees.map((t) => (t.semaine < sem && t.statut === "a_faire"
        ? { ...t, statut: "manquee" } : t));
      /* Un sujet NON FAIT revient la semaine suivante : c'est voulu. Seuls les
         exercices réellement terminés entrent dans « vus », de sorte qu'un
         sujet laissé de côté soit reproposé plutôt que perdu. */
      const servis = [...vus, ...reportes.map((t) => t.exoId).filter(Boolean)];
      const neuves = planifierSemaine({ chapitres: chaps, reglages: regl, semaine: sem, controle: ctrl, depuis, existantes: gardeesAjour.filter((t) => t.semaine === sem), direct: directDe(sem, listeInscrits), biblio, vus: servis });
      /* La déduplication compte les tâches au lieu de les marquer présentes :
         une soirée porte souvent DEUX exercices du même chapitre, et une clé
         « jour-type-chapitre » unique les faisait s'écraser l'une l'autre. On
         écarte donc autant de nouvelles tâches qu'il en a été conservé, pas
         toutes celles qui portent la même clé. */
      /* L'EXERCICE fait partie de la clé : deux sujets type bac posés le même
         samedi sur le même chapitre avaient la même clé, et le second effaçait
         le premier à chaque replanification — le week-end perdait ses sujets au
         profit d'exercices d'entraînement. */
      const cle = (t) => t.jour + "-" + t.type + "-" + t.chapId + "-" + (t.exoId || "");
      const restant = {};
      gardees.filter((t) => t.semaine === sem)
             .forEach((t) => { restant[cle(t)] = (restant[cle(t)] || 0) + 1; });
      const retenues = neuves.filter((t) => {
        const k = cle(t);
        if (restant[k]) { restant[k] -= 1; return false; }
        return true;
      });
      /* Le sujet reporté passe AVANT celui de la semaine : c'est sa dernière
         occasion, il doit être traité en premier. */
      const fusion = [...gardeesAjour, ...reportes,
                      ...retenues.map((t) => ({ ...t, semaine: sem }))]
        .sort((a, b) => a.jour - b.jour
          || ((b.reports || 0) - (a.reports || 0)));
      /* Dernier garde-fou : aucun identifiant en double dans la liste finale,
         quelles que soient les replanifications successives. Attention au nom :
         « vus » désigne déjà les exercices déjà servis, plus haut. */
      const identifiants = new Set();
      return fusion.map((t) => {
        let id = t.id, k = 1;
        while (identifiants.has(id)) id = t.id + "-" + (k++);
        identifiants.add(id);
        return id === t.id ? t : { ...t, id };
      }).sort((a, b) => a.jour - b.jour);
    });
  };

  /* La replanification demandée à la reprise. Elle attend que l'état soit
     entièrement posé — chapitres, réglages, semaine, jour — faute de quoi elle
     travaillerait sur des données incomplètes. */
  useEffect(() => {
    if (!aReplanifier || !pret) return;
    /* On attend aussi la BANQUE : planifier avant son arrivée posait des
       tâches sans exercice, qui ne s'ouvraient jamais. */
    if (supabaseActif && !Object.keys(biblio).length) return;
    setAReplanifier(false);
    replanifier(chapitres, controle, semaine, jour, inscrits, reglages);
  }, [aReplanifier, pret, semaine, jour, biblio]);


  /* --- déclarations de l'élève --- */
  /* Un chapitre demande environ trente minutes par jour pour être travaillé
     correctement : une restitution et un exercice. En dessous, on ne prépare
     pas, on survole. */
  /* Un contrôle déclaré trop tard : l'épreuve blanche tombe à J-2 et la reprise
     la veille. En deçà de trois jours, la préparation est amputée — l'élève doit
     le savoir, sinon il croira que le programme l'a oublié. */
  /* « Déclaré tard » se juge au moment de la DÉCLARATION, pas aux jours qui
     restent : un contrôle annoncé une semaine à l'avance devenait « déclaré
     trop tard » à mesure que la date approchait, ce qui n'a aucun sens. On
     regarde donc le délai dont l'élève disposait quand il l'a annoncé. */
  const controleTardif = (() => {
    if (!controle) return null;
    const reste = (controle.semaine - 1) * 7 + controle.jour - ((semaine - 1) * 7 + jour);
    if (reste < 0 || reste >= 3) return null;
    const delaiDeclare = controle.declareAbs != null
      ? (controle.semaine - 1) * 7 + controle.jour - controle.declareAbs
      : null;
    /* Annoncé avec au moins quatre jours devant lui : le programme a eu la
       place de s'organiser, l'alerte n'a pas lieu d'être. */
    if (delaiDeclare != null && delaiDeclare >= 4) return null;
    return { reste, jour: controle.jour, duree: controle.duree };
  })();

  /* Toute modification des réglages passe par ici : si l'élève allonge ses
     soirées alors que l'alerte « le compte n'y est pas » est affichée, on note
     d'où il vient. */
  const changerReglages = (r) => {
    if (tropDeChapitres && r.budgetSemaine > reglages.budgetSemaine && budgetAvant === null)
      setBudgetAvant(reglages.budgetSemaine);
    /* S'il redescend de lui-même, la mémoire n'a plus d'objet. */
    if (r.budgetSemaine <= (budgetAvant ?? -1)) setBudgetAvant(null);
    setReglages(r);
  };

  /* Dès qu'il ne reste qu'un chapitre, on rend à l'élève la durée qu'il s'était
     fixée. Le contraire — lui laisser 60 minutes acquises par accident — fausse
     tout son programme et il ne comprend pas pourquoi ses soirées s'allongent. */
  useEffect(() => {
    if (budgetAvant === null) return;
    const actifs = chapitres.filter((c) => c.statut !== "termine").length;
    if (actifs > 1 || reglages.budgetSemaine <= budgetAvant) return;
    const ancien = budgetAvant;
    setBudgetAvant(null);
    setReglages((r) => ({ ...r, budgetSemaine: ancien }));
    setJournal([{ t: "Retour à ton rythme",
      txt: "Tu n'as plus qu'un chapitre en cours : tes soirées reviennent à "
        + ancien + " minutes, la durée que tu t'étais fixée. Tu peux la changer "
        + "à tout moment dans Progrès." }]);
    replanifier(chapitres, controle, semaine, jour, inscrits,
      { ...reglages, budgetSemaine: ancien });
  }, [chapitres, budgetAvant]);

  /* L'élève a-t-il accepté de travailler plus pour mener plusieurs chapitres ?
     Son consentement est mémorisé : sans lui, l'alerte reviendrait chaque soir
     et le budget resterait insuffisant. */
  /* On PASSE LE BUDGET explicitement : « replanifier » sans argument reprenait
     « reglagesEffectifs », calculé avec l'ancienne valeur d'« accepteCharge »
     — React ne l'a pas encore mise à jour. La semaine de la déclaration
     restait donc à 30 minutes, et seule la suivante passait à 60. */
  const accepterCharge = () => {
    setAccepteCharge(true);
    setTimeout(() => replanifier(chapitres, controle, semaine, jour,
                                 inscrits, reglages, true), 0);
  };

  /* Le consentement tombe de lui-même quand il n'y a plus qu'un chapitre. */
  useEffect(() => {
    if (chapitresActifs < 2 && accepteCharge) {
      setAccepteCharge(false);
      /* ET L'ON REPLANIFIE : le consentement tombait mais le programme gardait
         ses soixante minutes, alors qu'il ne reste qu'un chapitre. */
      setAReplanifier(true);
    }
  }, [chapitresActifs]);

  const tropDeChapitres = (() => {
    if (chapitresActifs < 2 || accepteCharge) return null;
    const parChapitre = Math.floor(reglages.budgetSemaine / chapitresActifs);
    return parChapitre < MINUTES_PAR_CHAPITRE
      ? { actifs: chapitresActifs, budget: reglages.budgetSemaine, parChapitre } : null;
  })();

  const declarerChapitre = (chapId) => {
    /* UN CONTRÔLE PASSÉ CLÔT SON CHAPITRE. La clôture n'avait lieu qu'au
       changement de jour : un élève qui déclarait un chapitre le soir même de
       son contrôle se retrouvait avec deux chapitres à mener de front, et
       l'application lui réclamait du temps supplémentaire — alors que le
       premier était terminé. */
    /* La liste CLÔTURÉE sert de base à la suite : « setChapitres » ne prend
       effet qu'au rendu suivant, et le nouveau chapitre était ajouté à la liste
       d'avant — l'ancien y figurait encore comme actif, d'où « le compte n'y
       est pas ». */
    let chapsBase = chapitres;
    if (controle) {
      const absDS = (controle.semaine - 1) * 7 + (controle.jour || 0);
      if (absDS <= (semaine - 1) * 7 + jour) {
        chapsBase = chapitres.map((c) => (controle.chapitres.includes(c.id)
          && c.statut !== "termine"
          ? { ...c, statut: "termine", finSemaine: controle.semaine,
              finJour: controle.jour, syntheseFaite: true, retours: 0,
              derniereRevision: Math.ceil((absDS + 1) / 7) }
          : c));
        setChapitres(chapsBase);
        /* Le contrôle rejoint l'HISTORIQUE avant d'être effacé : sans cela,
           l'écran DS perdait toute trace du devoir passé — et de la copie
           corrigée qui lui était rattachée. */
        setControlesPasses((l) => (l.some((c) => c.semaine === controle.semaine
          && c.jour === controle.jour) ? l : [controle, ...l].slice(0, 12)));
        setControle(null);
      }
    }
    /* Les restitutions se comptent depuis le COURS, pas depuis la déclaration.
       Un élève déclare souvent son chapitre avec un jour de retard : caler J+1
       sur la déclaration ferait glisser tout l'espacement, alors que c'est le
       cours qui a posé la notion en mémoire. On remonte donc au dernier jour de
       cours à cette date ou avant. C'est le seul usage réel des jours de cours
       déclarés dans les réglages. */
    const absAuj = (semaine - 1) * 7 + jour;
    const cours = [...(reglages.joursCours || [])].sort((a, b) => b - a);
    const dernierCours = cours.find((j) => j <= jour);
    const absCours = dernierCours != null
      ? (semaine - 1) * 7 + dernierCours
      /* aucun cours plus tôt cette semaine : on prend le dernier de la
         semaine précédente, sans jamais remonter au-delà de sept jours */
      : cours.length ? (semaine - 2) * 7 + cours[0] : absAuj;

    const next = [...chapsBase, { id: chapId, statut: "en_cours", niveau: null, difficulte: "facile",
      semaineDebut: semaine, jourDeclare: jour,
      absDebut: Math.max(absCours, absAuj - 6), restitutionsFaites: [],
      faits: { flash: 0, exo: 0, bac: 0 },
      retours: 0, derniereRevision: semaine, suite: 0, echecs: 0, depuisPalier: 0 }];
    setChapitres(next); setDeclare(false);
    /* Pas d'avertissement figé dans le journal : la carte « Le compte n'y est
       pas » se recalcule à chaque affichage et disparaît dès que l'élève a
       rallongé ses soirées. Un message gravé, lui, resterait à tort. */
    /* On EMPILE : deux chapitres déclarés le même soir doivent apparaître tous
       les deux, chacun avec son test à passer. */
    setJournal((j) => [...j, { t: "Nouveau chapitre",
      txt: CHAPITRES.find((c) => c.id === chapId).nom
         + " : test de positionnement, à passer maintenant." }]);
    replanifier(next);
  };

  const terminerChapitre = (chapId) => {
    /* La déclaration « terminé » vaut signal de maturité : c'est elle, et non un
       délai en jours, qui déclenche le sujet de synthèse. Il tombe le week-end
       qui suit, même si le chapitre n'a duré que trois jours. */
    const next = chapitres.map((c) => (c.id === chapId
      ? { ...c, statut: "termine", derniereRevision: semaine, retours: 0,
          finSemaine: semaine, finJour: jour, syntheseFaite: false }
      : c));
    setChapitres(next); setDeclare(false);
    setJournal([{ t: "Chapitre terminé",
      txt: CHAPITRES.find((c) => c.id === chapId).nom
         + " : un sujet type bac de synthèse est posé ce week-end, puis le chapitre passe en rappel espacé." }]);
    replanifier(next);
  };

  const declarerControle = (jourDS, semDS, chapIds, duree) => {
    /* Le jour de la DÉCLARATION est conservé : c'est lui qui dit si l'élève a
       prévenu à temps, indépendamment du temps qui reste. */
    const c = { jour: jourDS, semaine: semDS, chapitres: chapIds, duree,
                declareAbs: (semaine - 1) * 7 + jour };
    /* Un contrôle peut porter sur un chapitre jamais déclaré : on l'ajoute, avec
       son test diagnostic, faute de quoi le moteur n'aurait rien à réviser. */
    const manquants = chapIds.filter((id) => !chapitres.some((x) => x.id === id));
    const avecNouveaux = manquants.length
      ? [...chapitres, ...manquants.map((id) => ({ id, statut: "en_cours", niveau: null,
          difficulte: "facile", semaineDebut: semaine, jourDeclare: jour,
          absDebut: (semaine - 1) * 7 + jour, restitutionsFaites: [],
          faits: { flash: 0, exo: 0, bac: 0 }, retours: 0, derniereRevision: semaine,
          suite: 0, echecs: 0, depuisPalier: 0 }))]
      : chapitres;
    if (manquants.length) setChapitres(avecNouveaux);
    setControle(c); setDeclare(false);
    setJournal([{ t: "Contrôle déclaré", txt: "Révisions superposées au programme habituel jusqu'au " + JOURS[jourDS] + ". Évaluation blanche l'avant-veille." }]);
    if (semaineDemarrage == null) setSemaineDemarrage(semaine);
    replanifier(avecNouveaux, c);
  };

  /* --- fin de tâche --- */

  const finirTache = (tache, resultat, extra = {}) => {
    /* La séance est inscrite au journal AVANT tout recalcul : c'est la seule
       trace qui ne dépend d'aucune replanification. */
    if (tache.type !== "direct") {
      /* On retient aussi l'EXERCICE et son TITRE : le journal ne portait que
         l'identifiant de la tâche, et la liste des exercices faits affichait
         « Exercice » sans pouvoir les retrouver. */
      /* ON NOTE SI C'EST UNE REPRISE. Un exercice raté revient le lendemain,
         proposé et non imposé ; le coach voyait alors deux lignes identiques
         sur deux jours, sans rien qui distingue la reprise du premier essai. */
      const ligne = { id: tache.id, semaine: tache.semaine, jour: tache.jour,
                      type: tache.type, chapId: tache.chapId,
                      reprise: !!(tache.conseille || tache.supplement),
                      exoId: tache.exoId || null,
                      exoTitre: tache.exoTitre || null,
                      duree: tache.duree || 0, resultat };
      setJournalSeances((l) => (l.some((x) => String(x.id) === String(tache.id))
        ? l : [...l, ligne]));
      /* ET EN BASE, dans sa propre table : une ligne écrite une fois, que
         nul recalcul ne peut effacer. */
      if (supabaseActif) inscrireSeance(ligne).catch(() => {});
    }
    /* Une feuille blanche terminée renvoie l'élève sur la page du cours : le
       chapitre vient de s'y déverrouiller, et c'est la comparaison avec la
       fiche qui l'instruit. */
    if (extra.versCours) {
      setChapCours(extra.versCours);
      setOnglet("ressources");
    }
    /* Un travail supplémentaire terminé : on barre le message qui l'annonçait,
       pour que l'élève distingue ce qui reste à faire de ce qu'il a réglé. */
    if (tache.supplement) {
      /* Un exercice demandé en plus compte comme vu : il ne doit pas
         réapparaître au programme les jours suivants. */
      if (tache.exoId) setSupplements((l) => [...new Set([...l, tache.exoId])]);
      if (tache.exoId) setVus((v) => [...new Set([...v, tache.exoId])]);
      /* LA SÉANCE ENTRE DANS LES TÂCHES, marquée « hors programme » : sans
         elle, les gestes travaillés en supplément ne se cochaient jamais —
         le calcul ne regarde que les tâches faites. */
      if (tache.exoId) {
        setTaches((ts) => (ts.some((x) => x.id === tache.id) ? ts
          : [...ts, { ...tache, statut: "fait", resultat,
                      semaine, jour, horsProgramme: true }]));
      }
      setJournal((j) => j.map((d) => (d.supplement && !d.fait ? { ...d, fait: true } : d)));
      /* Un supplément ne touche PAS au programme du soir : il s'ajoute à la
         demande de l'élève, il ne le fait pas recalculer. Sans ce retour, la
         soirée était replanifiée et l'élève voyait apparaître des questions
         flash et une feuille blanche qu'il n'avait pas demandées.

         Un exercice hésité ou raté rejoint la liste « à revoir », qui est
         servie les jours SUIVANTS — jamais le soir même. */
      if (tache.exoId && resultat !== "acquis") {
        setARevoir((r) => (r.some((x) => x.exoId === tache.exoId) ? r
          : [...r, { exoId: tache.exoId, chapId: tache.chapId, jour: absAujourdhui }]));
      }
      setRun(null);
      return;
    }
    if (tache.conseille) {
      if (tache.exoId) setVus((v) => [...new Set([...v, tache.exoId])]);
      /* Hésité de nouveau : l'exercice retourne en fin de liste ET porte le jour
         du jour, pour n'être reproposé qu'à partir de demain. Sans cette date,
         il revenait le soir même — l'élève tournait en rond dessus. */
      setARevoir((r) => (resultat === "acquis"
        ? r.filter((x) => x.exoId !== tache.exoId)
        : [...r.slice(1), { ...r[0], jour: absAujourdhui }]));
      setRun(null);
      return;
    }
    setTaches((ts) => {
      /* Une tâche qui était manquée et qui vient d'être faite est un RATTRAPAGE :
         on le marque, le coach doit pouvoir distinguer un élève qui décroche
         d'un élève qui saute un soir puis se reprend. */
      const maj = ts.map((t) => (t.id === tache.id
        ? { ...t, statut: "fait", resultat, ...(t.statut === "manquee" ? { rattrape: true } : {}) }
        : t));
      /* Le sujet de synthèse d'un chapitre terminé ne se pose qu'une fois. */
      if (tache.synthese)
        setChapitres((cs) => cs.map((c) => (c.id === tache.chapId ? { ...c, syntheseFaite: true } : c)));
      return maj.sort((a, b) => a.jour - b.jour);
    });
    if (tache.exoId) setVus((v) => [...new Set([...v, tache.exoId])]);
    if (tache.exoId && ["exo", "bac"].includes(tache.type)) {
      if (resultat === "acquis") {
        setARevoir((r) => r.filter((x) => x.exoId !== tache.exoId));
      } else {
        setARevoir((r) => (r.some((x) => x.exoId === tache.exoId) ? r : [...r, {
          exoId: tache.exoId, chapId: tache.chapId, chapNom: tache.chapNom,
          titre: tache.exoTitre, duree: tache.duree, niveau: tache.exoNiveau, resultat,
          /* Le jour où il a été mis de côté : on ne le repropose pas le soir même. */
          jour: absAujourdhui,
        }]));
      }
    }
    if (tache.type === "restitution") {
      setChapitres((cs) => cs.map((c) => (c.id === tache.chapId
        ? { ...c, restitutionsFaites: [...new Set([...(c.restitutionsFaites || []), tache.offset])] } : c)));
    }
    if (["flash", "exo", "bac"].includes(tache.type)) {
      setChapitres((cs) => cs.map((c) => (c.id === tache.chapId
        ? { ...c, faits: { ...(c.faits || { flash: 0, exo: 0, bac: 0 }), [tache.type]: ((c.faits || {})[tache.type] || 0) + 1 } } : c)));
    }
    /* Le niveau des exercices suit les résultats : deux réussites font monter,
       deux échecs font redescendre, et un palier périodique évite qu'un élève
       reste enfermé au niveau facile. La règle vit dans le moteur, pour être
       testable ; ici on l'applique et on annonce le changement à l'élève. */
    if (tache.type === "exo" || tache.type === "bac") {
      setChapitres((cs) => {
        const suite = cs.map((c) => {
          if (c.id !== tache.chapId) return c;
          /* Plus d'annonce de changement de niveau : il n'y a plus de niveaux.
             Le suivi se fait sur les gestes, dans Progrès. */
          const r = progresserNiveau(c, resultat, !!tache.palier);
          return { ...c, difficulte: r.difficulte, suite: r.suite,
                   echecs: r.echecs, depuisPalier: r.depuisPalier };
        });
        /* PLUS DE REPLANIFICATION en fin d'exercice. Elle servait à changer les
           exercices quand l'élève montait de niveau ; les niveaux ayant disparu,
           elle ne faisait plus que recalculer la soirée en cours — l'élève
           voyait apparaître des tâches après avoir terminé un sujet. Le
           programme de la semaine est posé une fois, il n'a pas à bouger parce
           qu'une séance vient d'être faite. */
        return suite;
      });
    }
    setRun(null);
  };

  /* L'élève redemande du travail après sa séance. On lui sert un exercice de son
     niveau, ou des questions flash. La demande est journalisée : un élève qui en
     redemande est un signal aussi utile pour le coach qu'un exercice raté. */
  /* Un sujet type bac SUPPLÉMENTAIRE, sur un chapitre que l'élève mène en
     parallèle. Ce n'est pas un exercice de plus : il engage une heure ou deux,
     et l'élève choisit lui-même le jour de week-end où le placer. */
  const ajouterSujet = (chapId, jourVoulu) => {
    const c = chapitres.find((x) => x.id === chapId);
    if (!c) return;
    const dejaVus = [...vus, ...taches.filter((t) => t.exoId).map((t) => t.exoId)];
    const sujet = (SUJETS_BAC[chapId] || []).find((x) => !dejaVus.includes(x.id));
    if (!sujet) {
      setJournal((j) => [...j, { t: "Sujets épuisés",
        txt: (CHAPITRES.find((x) => x.id === chapId)?.nom || chapId)
           + " : tous les sujets déposés ont déjà été proposés." }]);
      return;
    }
    setTaches((ts) => [...ts, {
      id: "bac-plus-" + chapId + "-" + Date.now(),
      type: "bac", chapId, jour: jourVoulu, semaine,
      duree: sujet.duree || 60, statut: "a_faire", enPlus: true,
      libelle: "Sujet type bac", chapNom: CHAPITRES.find((x) => x.id === chapId)?.nom || chapId,
      motif: "Sujet demandé en plus · " + (sujet.session || "annales"),
      exoId: sujet.id, exoTitre: sujet.titre, exoNiveau: sujet.niveau,
      consigne: sujet.consigne, url: sujet.url,
      points: sujet.points, session: sujet.session,
      difficulte: c.difficulte,
    }].sort((a, b) => a.jour - b.jour));
  };

  /* Passer le sujet du week-end : il revient la semaine suivante, en plus de
     celui prévu. Passé une seconde fois, il est perdu — on ne traîne pas un
     sujet toute l'année. */
  const passerSujet = (tacheId) => {
    setTaches((ts) => ts.map((t) => (t.id === tacheId
      ? { ...t, statut: "reporte", reports: (t.reports || 0) + 1 } : t)));
  };

  /* Travailler UN GESTE PRÉCIS que le planning n'a pas encore servi. Avec deux
     chapitres menés de front, la couverture complète demande trois semaines au
     lieu de deux : l'élève qui s'inquiète d'un geste peut aller le chercher
     lui-même, sans attendre son tour. Hors programme, comme « j'en veux plus ». */
  const travaillerGeste = (chapId, qt) => {
    const c = chapitres.find((x) => x.id === chapId);
    if (!c) return;
    const dejaVus = [...vus, ...supplements,
                     ...taches.filter((t) => t.exoId).map((t) => t.exoId)];
    /* On cherche d'abord un exercice JAMAIS VU portant ce geste ; à défaut, on
       repropose un déjà fait plutôt que de laisser l'élève sans rien. Le
       filtre exigeait les deux à la fois, et le bouton restait sans effet dès
       que la banque du geste était épuisée. */
    const surLeGeste = (biblio[chapId] || [])
      .filter((e) => e.usage === "entrainement" && (e.qt || []).includes(qt))
      .sort((a, b) => a.duree - b.duree);
    const exo = surLeGeste.find((e) => !dejaVus.includes(e.id)) || surLeGeste[0];
    if (!exo) {
      setJournal((j) => [...j, { t: "Aucun exercice disponible",
        txt: "Ce geste n'a pas d'exercice que tu n'aies déjà fait. Signale-le à ton coach." }]);
      return;
    }
    setSupplements((l) => [...l, exo.id]);
    setVus((v) => [...new Set([...v, exo.id])]);
    /* On RESTE dans Progrès : l'élève y reviendra en fermant l'exercice.
       Basculer sur « soir » — un onglet qui n'existe pas, il s'appelle
       « jour » — le laissait devant une page vide à la fermeture. */
    /* L'identifiant porte l'EXERCICE : « geste-1788… » n'existait dans aucune
       banque, et le geste ne se cochait jamais une fois l'exercice terminé. */
    setRun({ id: "geste-" + exo.id, type: "exo", chapId, duree: exo.duree,
             libelle: "Geste à rattraper", exoId: exo.id, exoTitre: exo.titre,
             difficulte: exo.niveau, chapNom: c.nom || "",
             motif: "Tu as choisi de travailler ce geste", supplement: true });
  };

  /* DEUX EXERCICES SUPPLÉMENTAIRES PAR SOIRÉE au plus. Un chapitre compte
     quinze exercices pour une semaine à une semaine et demie de cours : un
     élève qui en demanderait cinq par soir épuiserait la banque en trois jours,
     et se retrouverait sans rien à travailler avant son contrôle. */
  /* TROIS EXERCICES SUPPLÉMENTAIRES PAR SOIR, quel que soit le nombre de
     chapitres. Avec un seul chapitre, l'élève en reçoit trois du même ; avec
     trois chapitres, un de chaque grâce à l'alternance. La limite était
     calculée par chapitre, ce qui bloquait à un seul quand il n'y en avait
     qu'un — l'élève motivé se retrouvait sans rien. */
  const MAX_SUPPLEMENTS = 3;
  const supplementsDuJour = journal.filter((d) => d.supplement && d.exo).length;
  const chapsActifs = Math.max(1, chapitres.filter((x) => x.statut === "en_cours"
    && x.niveau).length);
  const encore = (quoi) => {
    if (quoi === "exo" && supplementsDuJour >= MAX_SUPPLEMENTS) {
      setJournal((j) => [...j, { t: "Trois exercices en plus, c'est déjà bien",
        txt: "Garde les autres pour les prochaines soirées : chaque chapitre "
           + "n'en compte que quinze, et ils doivent te mener jusqu'au "
           + "contrôle." }]);
      return;
    }
    /* On cherche d'abord un chapitre en cours, puis n'importe quel chapitre déjà
       diagnostiqué : un élève qui vient de terminer son chapitre doit pouvoir
       continuer à s'entraîner dessus. */
    /* ON ALTERNE ENTRE LES CHAPITRES : « find » prenait toujours le premier,
       et l'élève qui en mène deux ne recevait jamais d'exercice supplémentaire
       sur le second. On sert celui qui en a reçu le moins ce soir. */
    const candidats = principaux.filter((x) => x.niveau);
    const dejaCeSoir = (id) => journal.filter((d) => d.supplement
      && String(d.txt || "").startsWith(
        (CHAPITRES.find((y) => y.id === id)?.nom || "") + " :")).length;
    const c = (candidats.length > 1
        ? [...candidats].sort((a, b) => dejaCeSoir(a.id) - dejaCeSoir(b.id))[0]
        : candidats[0])
           || chapitres.find((x) => x.niveau)
           || principaux[0] || chapitres[0];
    if (!c) return;
    /* La carte « travail supplémentaire » n'est inscrite QU'UNE FOIS LA SÉANCE
       OUVERTE : elle l'était dès le clic, et restait affichée même quand
       aucun exercice n'était disponible. */
    if (quoi === "flash") {
      setJournal((j) => [...j, { t: "Travail supplémentaire", supplement: true,
        fait: false, exo: quoi === "exo",
        txt: (CHAPITRES.find((x) => x.id === c.id)?.nom || "") + " : "
           + (quoi === "exo" ? "un exercice de plus, à la demande de l'élève."
                             : "des questions flash, à la demande de l'élève.") }]);
      setRun({ id: "encore-" + Date.now(), type: "flash", chapId: c.id, duree: 10,
               nbQuestions: 7, libelle: "Questions flash", chapNom: c.nom || "",
               motif: "Tu en as redemandé", supplement: true });
      return;
    }
    /* On exclut TOUT ce que l'élève a déjà rencontré : les exercices des
       semaines passées (vus), ceux du jour, et les suppléments déjà demandés.
       Sans « vus », un exercice fait la semaine dernière pouvait revenir. */
    const exo = choisirExercice(biblio, c.id, "entrainement", c.difficulte, 20,
                                [...vus,
                                 ...taches.filter((t) => t.exoId).map((t) => t.exoId),
                                 ...supplements]);
    if (!exo) {
      /* La banque est épuisée. Plutôt que des questions flash, on repropose un
         exercice RATÉ ou HÉSITÉ : c'est le travail le plus utile qui reste, et
         l'élève l'aborde cette fois en sachant où il avait trébuché. */
      const repris = aRevoir[0];
      if (repris) {
        const e = (biblio[repris.chapId] || []).find((x) => x.id === repris.exoId);
        if (e) {
          setJournal((j) => [...j, { t: "Travail supplémentaire", supplement: true,
            fait: false, exo: true,
            txt: (CHAPITRES.find((x) => x.id === repris.chapId)?.nom || "")
               + " : un exercice de plus, à la demande de l'élève." }]);
          setARevoir((r) => [...r.slice(1), r[0]]);
          setRun({ id: "encore-" + Date.now(), type: "exo", chapId: repris.chapId,
                   duree: e.duree, libelle: "Exercice à reprendre",
                   exoId: e.id, exoTitre: e.titre, difficulte: e.niveau,
                   chapNom: CHAPITRES.find((x) => x.id === repris.chapId)?.nom || "",
                   motif: "Tu l'avais " + (repris.resultat === "hesitant" ? "hésité" : "raté")
                        + " : reprends-le maintenant", supplement: true });
          return;
        }
      }
      /* PLUS D'EXERCICE : on le dit, et on n'ouvre RIEN. Servir des questions
         flash à qui demande un exercice ressemblait à une erreur de bouton. */
      setJournal((j) => [...j, { t: "Plus d'exercice à te proposer",
        txt: "Tu as fait tous les exercices de ce chapitre. Reprends-en un que "
           + "tu avais hésité, ou passe aux questions flash si tu veux "
           + "entretenir." }]);
      return;
    }
    setJournal((j) => [...j, { t: "Travail supplémentaire", supplement: true,
      fait: false, exo: true,
      txt: (CHAPITRES.find((x) => x.id === c.id)?.nom || "")
         + " : un exercice de plus, à la demande de l'élève." }]);
    setSupplements((l) => [...l, exo.id]);
    /* Et il rejoint les vus : sinon le moteur le reproposerait au programme
       des jours suivants, alors que l'élève l'a déjà traité. */
    setVus((v) => [...new Set([...v, exo.id])]);
    setRun({ id: "encore-" + Date.now(), type: "exo", chapId: c.id, duree: exo.duree,
             libelle: "Exercice d'entraînement", exoId: exo.id, exoTitre: exo.titre,
             difficulte: exo.niveau, chapNom: c.nom || "", motif: "Tu en as redemandé",
             supplement: true });
  };

  /* ---- Relancer un élève -------------------------------------------------
     Voir un problème sans pouvoir agir dessus ne sert à rien. Chaque alerte du
     suivi porte désormais un bouton qui ouvre un message pré-rédigé, adressé à
     l'élève dans la permanence. Le coach relit, ajuste, envoie. */
  const [relance, setRelance] = useState(null);
  const [relances, setRelances] = useState([]);   // historique, pour le coach
  const [manquements, setManquements] = useState([]);  // épreuves blanches sautées

  const TEXTES_RELANCE = {
    copie: (e) => "Bonjour " + e + ", je n'ai pas reçu ta copie d'évaluation blanche. "
      + "Tu peux la photographier et la déposer depuis l'application ? Sans elle je ne "
      + "peux pas te dire où tu en es.",
    inactif: (e) => "Bonjour " + e + ", je ne t'ai pas vu travailler depuis plusieurs jours. "
      + "Dis-moi ce qui bloque : le temps, un chapitre qui coince, autre chose ? "
      + "On ajustera le programme.",
    restitution: (e) => "Bonjour " + e + ", il te reste des restitutions en retard. "
      + "Ce sont elles qui font tenir le cours dans la durée : reprends-les avant "
      + "d'avancer, même rapidement.",
    seances: (e) => "Bonjour " + e + ", la semaine s'achève et plusieurs séances n'ont pas "
      + "été faites. Si le rythme est trop lourd, on peut revoir ta durée quotidienne.",
    soirees: (e) => "Bonjour " + e + ", tu as sauté des soirées sans les rattraper. "
      + "Ce n'est pas grave une fois, mais dis-moi si c'est le programme qui ne va pas.",
    blanche: (e) => "Bonjour " + e + ", tu n'as pas fait l'évaluation blanche avant ton "
      + "contrôle. C'est le seul moment où l'on voit ce qui tient vraiment sous chronomètre. "
      + "Dis-moi si la durée était le problème, on peut adapter.",
    direct: (e) => "Bonjour " + e + ", tu as manqué le direct de la semaine. "
      + "Le replay est disponible, et je réponds à tes questions en permanence.",
    autre: (e) => "Bonjour " + e + ", ",
  };

  /* L'identifiant de l'élève accompagne son nom : sans lui, la relance ne
     saurait pas à qui s'adresser une fois enregistrée. */
  const ouvrirRelance = (eleve, motif, alerte, eleveId = null) =>
    setRelance({ eleve, eleveId, motif, alerte,
                 texte: (TEXTES_RELANCE[motif] || TEXTES_RELANCE.autre)(eleve) });

  const envoyerRelance = async () => {
    if (!relance || !relance.texte.trim()) return;
    const h = new Date().toTimeString().slice(0, 5);
    /* La relance est ENREGISTRÉE, pas seulement affichée : elle n'existait que
       sur l'écran du coach et n'atteignait jamais l'élève. */
    if (supabaseActif && relance.eleveId) {
      try {
        await envoyerRelanceDb({ eleveId: relance.eleveId,
          chapitre: principaux[0]?.id || CHAPITRES[0].id,
          texte: relance.texte.trim(), motif: relance.motif });
        const s = await chargerSujets();
        if (s) setThreads(s);
        setRelances((rs) => [...rs, { eleve: relance.eleve, motif: relance.motif,
          quand: (semaine - 1) * 7 + jour, semaine, jour }]);
        setRelance(null);
        return;
      } catch (e) { /* on retombe sur l'affichage local */ }
    }
    /* Une relance ne regarde que son destinataire : elle porte son nom et le
       drapeau « privé ». La permanence commune ne l'affichera pas aux autres. */
    setThreads((ts) => [{
      id: Date.now(), chap: principaux[0]?.id || CHAPITRES[0].id,
      titre: "Message de ton coach", statut: "attente",
      prive: true, pourEleve: relance.eleve, motifRelance: relance.motif,
      messages: [{ de: "Nicolas · coach", role: "coach", txt: relance.texte.trim(), h }],
    }, ...ts]);
    /* Côté coach, on garde trace : on ne relance pas deux fois le même jour
       sans le savoir. */
    setRelances((rs) => [...rs, { eleve: relance.eleve, motif: relance.motif,
      quand: (semaine - 1) * 7 + jour, semaine, jour }]);
    setRelance(null);
  };

  /* La correction rendue : elle arrive en message privé, la pastille s'allume,
     et l'élève la retrouve ensuite dans « Mes copies ». */
  const rendreCopie = (copie, corr) => {
    /* La correction est écrite dans l'ÉTAT DE L'ÉLÈVE : sans cela, elle
       n'existait que dans le fil de permanence, et sa copie restait « en
       attente » chez lui — invisible dans son écran DS. */
    /* Sans identifiant d'élève, RIEN NE PART — et sans erreur non plus : la
       correction paraissait rendue alors qu'aucune écriture n'avait été
       tentée. On le signale désormais. */
    if (supabaseActif && !copie.eleveId) {
      setJournal((j) => [...j, { t: "Correction non transmise",
        txt: "Cette copie ne porte pas l'identifiant de son élève. Demandez-lui "
           + "de rendre une nouvelle épreuve blanche." }]);
    }
    if (supabaseActif && copie.eleveId) {
      /* Le PDF part dans le STOCKAGE, et l'état ne porte que son chemin. Le
         mot du coach est écrit DANS TOUS LES CAS : un « return » anticipé
         empêchait la correction d'arriver dès que le dépôt échouait, et
         supprimait aussi le fil de permanence. */
      const pdf = (corr.annotees || []).find((a) => a.fichier);
      const allege = { ...corr, annotees: undefined };
      (pdf
        ? deposerCopieAnnotee(copie.eleveId, pdf.fichier).catch((e) => {
            setJournal((j) => [...j, { t: "Copie annotée non transmise",
              txt: "Le mot est bien parti, mais pas le PDF : " + (e.message || e) }]);
            return null;
          })
        : Promise.resolve(null)
      ).then((chemin) => marquerCopieCorrigee(copie.eleveId, copie.id,
          chemin ? { ...allege, cheminAnnotee: chemin } : allege))
       .catch((e) => setJournal((j) => [...j, { t: "Correction non transmise",
         txt: String(e.message || e) }]));
      /* Un seul appel plus haut : celui-ci écrasait le chemin du PDF avec une
         correction qui n'en portait pas. */
    }
    const h = new Date().toTimeString().slice(0, 5);
    const messages = [];
    /* Les erreurs relevées d'abord : ce sont elles que l'élève doit reprendre. */
    if (corr.pieges && corr.pieges.length)
      messages.push({ de: "Nicolas · coach", role: "coach", h,
        txt: "Ce que j'ai relevé :\n· " + corr.pieges.join("\n· ") });
    if (corr.texte) messages.push({ de: "Nicolas · coach", role: "coach", txt: corr.texte, h });
    (corr.annotees || []).forEach((ph) => messages.push({ de: "Nicolas · coach", role: "coach",
      txt: "", fichier: ph.data, fichierType: ph.type, fichierNom: ph.nom, h }));
    if (corr.vocal) messages.push({ de: "Nicolas · coach", role: "coach", txt: "",
      audio: corr.vocal.url, audioDuree: corr.vocal.duree, h });
    if (!messages.length) return;
    /* La copie corrigée ne va PLUS EN PERMANENCE : elle arrive dans l'écran DS
       de l'élève, à côté de l'épreuve qu'il a composée. En permanence, elle se
       perdait parmi les questions — et encombrait le fil du coach.
       En démonstration, faute de base, on garde le fil : c'est le seul moyen
       de montrer le parcours. */
    /* Le fil de permanence revient QUAND IL Y A DES PAGES ANNOTÉES : elles ne
       peuvent pas transiter par l'état de l'élève, trop lourdes. Le mot et le
       vocal, eux, arrivent bien dans l'écran DS. */
    /* Le fil de permanence n'est plus créé qu'en DÉMONSTRATION. Branché à la
       base, il restait dans la permanence DU COACH — jamais envoyé à l'élève,
       puisqu'il n'était posé qu'en mémoire locale. Le PDF passe désormais par
       le stockage, et la correction par l'état de l'élève : ce fil ne servait
       plus qu'à encombrer. */
    if (!supabaseActif) {
      setThreads((ts) => [{
        id: Date.now(), chap: (copie.exos && copie.exos[0] && copie.exos[0].chapId) || principaux[0]?.id || CHAPITRES[0].id,
        titre: "Ta copie corrigée · semaine " + copie.semaine, statut: "attente",
        prive: true, pourEleve: copie.eleve || "Vous (démo)", correction: true, copieId: copie.id,
        messages,
      }, ...ts]);
    }
  };

  const avancerJour = () => {
    /* Une seance non faite n'est ni deplacee ni dupliquee : elle reste a son jour,
       marquee "non fait", et l'eleve la rattrape avant la seance du jour suivant. */
    setTaches((ts) => ts.map((t) => (t.jour === jour && t.statut === "a_faire" && t.semaine === semaine
      ? { ...t, statut: "manquee" } : t)));

    /* Une épreuve blanche sautée doit rester visible du coach, même après le
       ménage des tâches de contrôle : on la consigne à part, au moment où elle
       est manquée. Sans cela, la preuve disparaîtrait avec la tâche. */
    const blancheSautee = taches.find((t) => t.type === "blanche" && t.jour === jour
      && t.semaine === semaine
      && t.semaine === semaine && t.statut === "a_faire");
    if (blancheSautee)
      setManquements((ms) => [...ms, { type: "blanche", semaine, jour,
        chapId: blancheSautee.chapId, duree: blancheSautee.duree }]);

    const semSuivante = jour >= 6 ? semaine + 1 : semaine;
    const jourSuivant = jour >= 6 ? 0 : jour + 1;
    /* Un contrôle appartient au passé dès que SON JOUR est écoulé, pas à la fin
       de la semaine : sinon le bandeau et les révisions survivaient plusieurs
       jours à une épreuve déjà passée. */
    /* Le contrôle dont la date est dépassée est écarté du programme — mais il
       rejoint d'abord l'HISTORIQUE, sans quoi l'écran DS en perdait toute
       trace au lendemain de l'épreuve, avec la copie corrigée qui s'y
       rattachait. */
    const ctrlPasse = controle
      && (controle.semaine - 1) * 7 + controle.jour < (semSuivante - 1) * 7 + jourSuivant;
    if (ctrlPasse) {
      setControlesPasses((l) => (l.some((c) => c.semaine === controle.semaine
        && c.jour === controle.jour) ? l : [controle, ...l].slice(0, 12)));
    }
    const ctrl = ctrlPasse ? null : controle;

    /* Une révision, une épreuve blanche ou une reprise qui n'a pas été faite
       n'a plus aucun sens une fois le contrôle passé : on ne la propose ni au
       rattrapage, ni au planning des jours suivants. */
    const perime = (t) => !ctrl && controle
      && ["revision", "blanche", "reprise"].includes(t.type) && t.statut !== "fait";

    /* Passer un contrôle sur un chapitre, c'est en avoir fini avec lui : il
       n'a plus à recevoir de séances, il passe en entretien espacé. On ne lui
       pose pas de sujet de synthèse — le contrôle en tenait lieu, et enchaîner
       une épreuve d'une heure au lendemain d'un devoir serait absurde. */
    const cloturerParControle = (liste) => {
      if (ctrl || !controle) return liste;
      const finAbs = (controle.semaine - 1) * 7 + controle.jour;
      return liste.map((c) => (controle.chapitres.includes(c.id) && c.statut !== "termine"
        ? { ...c, statut: "termine", finSemaine: controle.semaine, finJour: controle.jour,
            syntheseFaite: true, retours: 0, derniereRevision: Math.ceil((finAbs + 1) / 7) }
        : c));
    };

    if (jour >= 6) {
      /* LE TOTAL DE LA SEMAINE EST FIGÉ avant de la quitter : le journal ne
         retenait que les séances faites, et le bilan affichait « 2/2 » là où
         l'élève avait eu quinze tâches. On note ici combien il en avait. */
      const prevues = taches.filter((t) => t.semaine === semaine && !t.masquee
        && t.type !== "direct").length;
      if (prevues) {
        setTotauxSemaine((l) => (l.some((x) => x.semaine === semaine) ? l
          : [...l, { semaine, prevues }]));
        if (supabaseActif) cloreSemaine(semaine, prevues).catch(() => {});
      }
      const sem = semSuivante;
      const next = cloturerParControle(chapitres).map((c) => (c.statut === "termine" && taches.some((t) => t.type === "rappel" && t.chapId === c.id)
        ? { ...c, retours: (c.retours || 0) + 1, derniereRevision: semaine } : c));
      setChapitres(next); setSemaine(sem); setJour(0); setControle(ctrl); setJournal([]);
      /* On conserve les soirées manquées de la semaine écoulée : sans elles,
         un dimanche sauté ne pourrait plus être rattrapé le lundi. Elles sont
         purgées au bout de sept jours par la fenêtre de rattrapage. */
      setTaches((anc) => {
        /* Les tâches liées au contrôle traversent la semaine SI le contrôle est
           encore devant : une révision sautée reste utile à rattraper. En
           revanche on efface son compte à rebours, calculé la semaine passée —
           c'est lui, et non la tâche, qui devenait faux. Si le contrôle est
           derrière, la tâche n'a plus d'objet et disparaît. */
        const controleDevant = ctrl
          && (ctrl.semaine - 1) * 7 + ctrl.jour >= (sem - 1) * 7;
        const aRattraper = anc
          .filter((t) => t.statut === "manquee" && t.semaine >= sem - 1 && !perime(t)
            && (!tacheDeControle(t) || controleDevant))
          .map((t) => (tacheDeControle(t) && /dans \d+ j/.test(t.motif || "")
            ? { ...t, motif: "Révision non faite · à rattraper avant le contrôle" } : t));
        /* Le sujet type bac REPORTÉ traverse la semaine : c'est là qu'il
           disparaissait. Ce filtre ne gardait que les soirées manquées, et le
           report — un statut à part — n'y entrait pas. Il revient avec son
           libellé propre, en plus du sujet de la semaine. */
        const reporte = anc
          .filter((t) => t.type === "bac" && t.statut === "reporte"
            && (t.reports || 0) < 2)
          .map((t) => ({ ...t, semaine: sem, statut: "a_faire",
                         libelle: "Sujet reporté",
                         motif: "Reporté de la semaine dernière · dernière occasion" }));
        /* Le sujet reporté compte comme DÉJÀ SERVI : sans cela le moteur
           reposait le même en sujet hebdomadaire, et l'élève se retrouvait
           avec deux fois le même énoncé le même week-end. */
        const dejaServis = [...vus, ...reporte.map((t) => t.exoId).filter(Boolean)];
        const neuves = planifierSemaine({ chapitres: next, reglages: reglagesEffectifs, semaine: sem,
          controle: ctrl, direct: directDe(sem), biblio, vus: dejaServis })
          .map((t) => ({ ...t, semaine: sem }));
        return [...aRattraper, ...reporte, ...neuves];
      });
    } else {
      setJour(jourSuivant);
      /* Le contrôle vient de passer : on efface ses révisions non faites, puis
         on replanifie le reste de la semaine sans lui. */
      if (!ctrl && controle) {
        const apres = cloturerParControle(chapitres);
        const clos = apres.filter((c, i) => c.statut === "termine" && chapitres[i].statut !== "termine");
        setControle(null);
        setChapitres(apres);
        setTaches((anc) => anc.filter((t) => !perime(t)));
        if (clos.length)
          setJournal([{ t: "Contrôle passé",
            txt: clos.map((c) => CHAPITRES.find((x) => x.id === c.id)?.nom).join(" et ")
              + (clos.length > 1 ? " passent" : " passe")
              + " en rappel espacé : le contrôle a eu lieu, le chapitre est derrière toi."
              + " Tu le reverras de loin en loin, sans plus y consacrer tes soirées." }]);
        replanifier(apres, null, semaine, jourSuivant);
      }
    }
  };

  /* L'INSCRIPTION PORTE SUR UN COURS, non sur une semaine entière. Elle était
     enregistrée par numéro de semaine : s'inscrire à celui du mercredi
     inscrivait aussi à celui du samedi. On retient donc le créneau. Les
     anciennes inscriptions, de simples numéros, restent comprises. */
  const cleDirect = (d) => (typeof d === "object" && d !== null)
    ? d.semaine + "-" + (d.jour ?? 2) : d;
  const estInscrit = (d) => {
    if (typeof d !== "object" || d === null) return inscrits.includes(d);
    return inscrits.includes(cleDirect(d)) || inscrits.includes(d.semaine);
  };
  const inscrire = (d) => {
    const cle = cleDirect(d);
    const sem = (typeof d === "object" && d !== null) ? d.semaine : d;
    const dedans = estInscrit(d);
    /* Se désinscrire retire aussi le numéro de semaine hérité — mais celui-ci
       valait pour TOUS les cours de la semaine : on rend donc explicites ceux
       auxquels l'élève reste inscrit, sinon il perdrait les autres du même
       coup. */
    let liste;
    if (dedans) {
      const avaitLaSemaine = inscrits.includes(sem);
      liste = inscrits.filter((x) => x !== cle && x !== sem);
      if (avaitLaSemaine) {
        directsDeLaSemaine(sem)
          .filter((x) => cleDirect(x) !== cle)
          .forEach((x) => { if (!liste.includes(cleDirect(x))) liste.push(cleDirect(x)); });
      }
    } else {
      liste = [...inscrits.filter((x) => x !== cle), cle];
    }
    setInscrits(liste);
    if (sem === semaine) replanifier(chapitres, controle, semaine, jour, liste);
  };

  /* LA QUESTION EST RANGÉE SOUS LA DATE DU COURS, non sous un numéro de
     semaine. Chaque compte a sa propre numérotation — elle part de la date
     d'inscription — si bien que la question d'un élève était classée sous un
     numéro que le coach ne cherchait jamais : aucune ne lui parvenait. */
  const poserQuestionDirect = (sem, txt) => {
    const cours = directsDeLaSemaine(sem)[0] || null;
    setQuestionsDirect((q) => [...q, { id: Date.now(), semaine: sem,
      date: cours?.date || null, txt, statut: "transmise" }]);
  };

  /* Qui dispose des outils du coach : valider une réponse, signaler une erreur,
     épingler un fil, relancer un élève. JAMAIS un élève.

     Sans base de données, l'application tourne en démonstration et ouvre ces
     outils à tout le monde — c'est ce qui permet de la montrer. Un bandeau le
     dit à l'écran, car une version publiée sans base n'est pas sécurisée : ne
     diffusez pas l'adresse avant d'avoir branché Supabase.

     Avec la base, la règle est stricte et échoue du bon côté : tant que le
     profil n'est pas chargé, personne n'est coach. */
  const estCoach = supabaseActif ? profil?.role === "coach" : true;
  const estParent = supabaseActif && profil?.role === "parent";
  const modeDemo = !supabaseActif;
  const [remiseDemo, setRemiseDemo] = useState(false);
  /* Le chapitre à ouvrir dans l'onglet Cours, quand on y arrive depuis une
     feuille blanche plutôt que par le menu. */


  /* Un contrôle dont la date est passée rejoint l'HISTORIQUE : il disparaissait
     purement et simplement, avec la copie corrigée et les gestes travaillés.
     L'élève doit pouvoir revenir sur ce qu'il a rendu. */
  /* Un GARDE-FOU qui ne dépend d'aucun chemin : on retient le dernier contrôle
     vu, et dès qu'il disparaît on le range. Les trois écritures posées dans les
     chemins de clôture ne se déclenchaient pas — le contrôle était déjà nul
     quand elles s'exécutaient, et l'historique restait vide. */
  /* LA CLÔTURE LE JOUR MÊME. Elle n'avait lieu qu'à la déclaration d'un
     chapitre ou au passage de jour : le jour de l'épreuve, sans action de
     l'élève, le chapitre restait ouvert et ses gestes affichés. */
  useEffect(() => {
    if (!controle) return;
    const absDS = (controle.semaine - 1) * 7 + (controle.jour || 0);
    if (absDS > (semaine - 1) * 7 + jour) return;
    setChapitres((cs) => {
      let change = false;
      const suite = cs.map((c) => {
        if (!controle.chapitres.includes(c.id) || c.statut === "termine") return c;
        change = true;
        return { ...c, statut: "termine", finSemaine: controle.semaine,
                 finJour: controle.jour, syntheseFaite: true, retours: 0,
                 derniereRevision: Math.ceil((absDS + 1) / 7) };
      });
      return change ? suite : cs;
    });
  }, [controle, semaine, jour]);

  const dernierControle = useRef(null);
  useEffect(() => {
    if (controle) { dernierControle.current = controle; return; }
    const ct = dernierControle.current;
    if (!ct) return;
    dernierControle.current = null;
    setControlesPasses((l) => (l.some((c) => c.semaine === ct.semaine
      && c.jour === ct.jour) ? l : [ct, ...l].slice(0, 12)));
  }, [controle]);

  const [chapCours, setChapCours] = useState(null);
  /* Les copies corrigées que l'élève n'a pas encore ouvertes. */
  const [copiesVues, setCopiesVues] = useState([]);

  /* La CORRECTION ARRIVE EN DIRECT. Le coach écrit dans l'état de l'élève ;
     sans cette écoute, celui-ci devait fermer et rouvrir l'application pour la
     voir — ce qu'il n'a aucune raison de faire, ne sachant pas qu'elle
     l'attend. On ne reprend QUE LES COPIES : recharger tout l'état écraserait
     le travail en cours de sa soirée. */
/* LES COURS ARRIVENT SANS RECHARGEMENT. Le coach en programme un, l'élève le
     voit aussitôt dans son écran du soir et peut s'y inscrire. */
  useEffect(() => {
    if (!supabaseActif) return undefined;
    return ecouterDirects((liste) => setDirects(liste));
  }, []);

  /* Les références suivent la séance et l'onglet, pour le gestionnaire de
     retour arrière posé une seule fois. */
  useEffect(() => {
    runRef.current = run;
    /* Une entrée d'historique par séance ouverte : c'est elle que le geste de
       retour consomme. */
    if (run && typeof window !== "undefined") window.history.pushState({ btp: 1 }, "");
  }, [run]);
  useEffect(() => { ongletRef.current = onglet; }, [onglet]);

  useEffect(() => {
    if (!supabaseActif || estCoach) return;
    /* AU RETOUR AU PREMIER PLAN, on relit l'état. Sur iPad et iPhone, Safari
       coupe les connexions temps réel quand l'application passe en arrière-plan
       et ne les rétablit pas toujours : l'élève gardait sa copie « en attente »
       indéfiniment, et il n'a aucune raison de vider son cache. */
    const auRetour = () => {
      if (document.visibilityState !== "visible") return;
      chargerEtat().then((e) => {
        if (!e || !e.copies) return;
        setCopies((anc) => {
          const parId = Object.fromEntries(e.copies.map((c) => [c.id, c]));
          let change = false;
          const suite = anc.map((c) => {
            const neuve = parId[c.id];
            if (!neuve) return c;
            const memeCorrection = JSON.stringify(neuve.correction || null)
              === JSON.stringify(c.correction || null);
            if (neuve.statut === c.statut && memeCorrection) return c;
            change = true;
            return { ...c, ...neuve };
          });
          return change ? suite : anc;
        });
      }).catch(() => {});
    };
    /* ── ON N'ÉCRASE PAS LE TRAVAIL DE L'ÉLÈVE QUAND IL PART ───────────────
       L'enregistrement attend 800 ms. Un élève qui appuie sur « retour » juste
       après avoir terminé une séance quittait l'application avant l'écriture,
       et retrouvait sa progression dans l'état d'avant. On écrit donc aussitôt
       dès que la page passe en arrière-plan ou se ferme. */
    const enPartant = () => { if (document.visibilityState === "hidden") forcerSauvegarde(); };

    /* ── LE RETOUR ARRIÈRE FERME LA SÉANCE, IL NE QUITTE PLUS L'APPLICATION ──
       Rien n'était inscrit dans l'historique du navigateur : un élève qui
       revenait en arrière pour fermer un corrigé sortait de l'application. On
       dépose une entrée à chaque ouverture de séance, et le geste de retour la
       consomme au lieu de faire sortir. */
    const surRetour = () => {
      forcerSauvegarde();
      if (runRef.current) { setRun(null); window.history.pushState({ btp: 1 }, ""); }
      else if (ongletRef.current !== "jour") {
        setOnglet("jour"); window.history.pushState({ btp: 1 }, "");
      }
    };
    window.addEventListener("popstate", surRetour);
    document.addEventListener("visibilitychange", enPartant);
    window.addEventListener("pagehide", forcerSauvegarde);

    document.addEventListener("visibilitychange", auRetour);
    const arret = ecouterMonEtat((donnees) => {
      if (!donnees || !donnees.copies) return;
      setCopies((anc) => {
        const parId = Object.fromEntries(donnees.copies.map((c) => [c.id, c]));
        let change = false;
        const suite = anc.map((c) => {
          const neuve = parId[c.id];
          if (!neuve) return c;
          /* On compare la CORRECTION, pas seulement le statut : une copie déjà
             marquée « corrigée » à laquelle le coach ajoute son mot ne changeait
             pas de statut, et la correction n'arrivait jamais. */
          const memeStatut = neuve.statut === c.statut;
          const memeCorrection = JSON.stringify(neuve.correction || null)
            === JSON.stringify(c.correction || null);
          if (memeStatut && memeCorrection) return c;
          change = true;
          return { ...c, ...neuve };
        });
        return change ? suite : anc;
      });
    });
    return () => {
      document.removeEventListener("visibilitychange", enPartant);
      window.removeEventListener("popstate", surRetour);
      window.removeEventListener("pagehide", forcerSauvegarde);
      document.removeEventListener("visibilitychange", auRetour);
      if (arret) arret();
    };
  }, [estCoach]);
  const copiesNonLues = copies.filter((c) =>
    (c.corrigee || c.correction || c.note != null) && !copiesVues.includes(c.id)).length;
  useEffect(() => {
    if (onglet !== "controles" || !copiesNonLues) return;
    setCopiesVues(copies.filter((c) => c.corrigee || c.correction || c.note != null)
      .map((c) => c.id));
  }, [onglet, copiesNonLues]);
  /* Le module GRAND ORAL reste fermé tant que le coach ne l'ouvre pas : il
     n'a pas été éprouvé, et mieux vaut ne rien montrer qu'un module bancal. */
  const [oralOuvert, setOralOuvert] = useState(false);
  useEffect(() => {
    if (!supabaseActif) { setOralOuvert(true); return; }   // démonstration
    lireOralOuvert().then(setOralOuvert).catch(() => {});
  }, []);

  /* Les ressources sont RELUES à chaque ouverture de l'onglet Cours. Chargées
     une seule fois au démarrage, elles restaient figées : une vidéo déposée
     par le coach n'apparaissait qu'au rechargement complet de la page — et sur
     iPad, où l'application reste ouverte des jours, jamais. */
  useEffect(() => {
    /* Relues aussi à l'ouverture d'une ÉPREUVE BLANCHE : chargées seulement à
       l'onglet Cours, un élève qui allait droit à son épreuve ne les avait pas,
       et l'application composait une évaluation depuis les exercices — alors
       que le coach avait déposé la sienne. */
    if (!supabaseActif || (onglet !== "ressources" && !eval_)) return;
    let vivant = true;
    chargerRessources().then((rs) => {
      if (!vivant || !rs) return;
      setRessources((anc) => {
        const suite = { ...anc };
        Object.entries(rs).forEach(([chap, listes]) => {
          suite[chap] = { ...(anc[chap] || {}), ...listes,
            /* Les sujets Labolycée viennent du code, pas de la base : on les
               conserve, sinon ils disparaissent à chaque relecture. */
            sujets: (anc[chap] || {}).sujets || [] };
        });
        return suite;
      });
    }).catch(() => {});
    return () => { vivant = false; };
  }, [onglet, eval_]);

  const validerMessage = async (sujetId, index, messageId) => {
    setThreads((ts) => ts.map((t) => (t.id === sujetId
      ? { ...t, statut: "resolu", messages: t.messages.map((m, i) => (i === index ? { ...m, valide: true } : m)) }
      : t)));
    if (supabaseActif && messageId) {
      await validerReponseDb(messageId, sujetId);
      const s = await chargerSujets();
      setThreads(s || (supabaseActif ? [] : THREADS_INIT));
    }
  };

  const signalerErreur = async (sujetId, index, messageId, commentaire) => {
    setThreads((ts) => ts.map((t) => (t.id === sujetId
      ? { ...t, messages: t.messages.map((m, i) => (i === index ? { ...m, signale: true, signaleCommentaire: commentaire } : m)) }
      : t)));
    if (supabaseActif && messageId) {
      await signalerMessageDb(messageId, commentaire);
      const s = await chargerSujets();
      setThreads(s || (supabaseActif ? [] : THREADS_INIT));
    }
  };

  const epingler = async (id, valeur) => {
    setThreads((t) => t.map((x) => (x.id === id ? { ...x, epingle: valeur } : x)));
    if (supabaseActif) { await epinglerSujetDb(id, valeur); const s = await chargerSujets(); if (s) setThreads(s); }
  };

  const enRessource = async (id, titre, resume) => {
    setThreads((t) => t.map((x) => (x.id === id
      ? { ...x, ressource: true, ressourceTitre: titre, ressourceResume: resume, statut: "resolu" } : x)));
    if (supabaseActif) { await transformerEnRessourceDb(id, titre, resume); const s = await chargerSujets(); if (s) setThreads(s); }
  };

  const retirerDesRessources = async (id) => {
    setThreads((t) => t.map((x) => (x.id === id ? { ...x, ressource: false } : x)));
    if (supabaseActif) { await retirerRessourceDb(id); const s = await chargerSujets(); if (s) setThreads(s); }
  };

  /* Retirer une ressource : une seule, tout un type d'un chapitre, ou le
     chapitre entier. Le coach doit pouvoir défaire ce qu'il a déposé. */
  const retirerRessource = async (chapId, id) => {
    setRessources((r) => ({ ...r, [chapId]: {
      ...r[chapId],
      videos: (r[chapId]?.videos || []).filter((v) => v.id !== id),
      fiches: (r[chapId]?.fiches || []).filter((f) => f.id !== id),
    }}));
    if (supabaseActif) await supprimerRessourceDb(id);
  };

  const viderRessources = async (chapId, type) => {
    setRessources((r) => ({ ...r, [chapId]: {
      ...r[chapId],
      videos: type && type !== "fiches"
        ? (r[chapId]?.videos || []).filter((v) => v.type !== type)
        : (type === "fiches" ? (r[chapId]?.videos || []) : []),
      fiches: type && type !== "fiches" ? (r[chapId]?.fiches || []) : [],
    }}));
    if (supabaseActif) await supprimerRessourcesDb({ chapitre: chapId, type });
  };

  /* L'élève a choisi de faire le second sujet : on en garde la trace pour le
     coach. Aucune copie n'est rendue — c'est l'implication qui est notée. */
  const [libres, setLibres] = useState([]);
  /* Les contrôles déjà passés : le moteur ne garde que celui à venir, mais
     l'élève doit pouvoir revenir sur ce qu'il a fait pour les précédents. */


  /* Les PÉRIODES DE QUATRE SEMAINES déjà closes. Chaque bloc — semaines 1 à 4,
     puis 5 à 8… — est figé dès qu'il s'achève : sans cela, l'historique du
     coach s'arrêtait à quatre semaines et tout le reste était perdu. */
  const [periodes, setPeriodes] = useState([]);
  useEffect(() => {
    const close = Math.floor((semaine - 1) / 4);   // nombre de blocs achevés
    if (close < 1) return;
    if (periodes.some((p) => p.numero === close)) return;
    const debut = (close - 1) * 4 + 1, fin = close * 4;
    /* Le direct n'est pas une séance : il ne compte pas dans le bilan. */
    const lot = taches.filter((t) => (t.semaine || 1) >= debut
      && (t.semaine || 1) <= fin && !t.masquee && t.type !== "direct");
    if (!lot.length) return;
    const faits = lot.filter((t) => t.statut === "fait");
    const bilan = { numero: close, semaineDebut: debut, semaineFin: fin,
      minutes: faits.reduce((a, t) => a + (t.duree || 0), 0),
      seances: faits.length, prevues: lot.length,
      restitutions: faits.filter((t) => t.type === "restitution").length,
      directs: faits.filter((t) => t.type === "direct").length,
      copies: copies.filter((c) => (c.semaine || 1) >= debut
        && (c.semaine || 1) <= fin).length };
    setPeriodes((l) => [bilan, ...l]);
    if (supabaseActif) figerPeriode(bilan).catch(() => {});
  }, [semaine, taches.length]);
  const noterEntrainementLibre = async (chapId, titre) => {
    const local = { id: "loc-" + Date.now(), chapitre: chapId, titre,
                    semaine, commence_le: new Date().toISOString(),
                    eleve_id: profil?.id || null, nom: profil?.nom || null };
    setLibres((l) => [local, ...l]);
    setJournal((j) => [...j, { t: "Entraînement libre lancé",
      txt: "Ce sujet ne se rend pas. Note tes questions : tu les poseras en direct ou en permanence." }]);
    if (supabaseActif) {
      try { await ouvrirEntrainementLibre(chapId, titre, semaine); } catch (e) { /* sans trace */ }
    }
  };

  const ajouterRessource = async (chapId, item) => {
    setRessources((r) => {
      const chap = r[chapId] || { videos: [], fiches: [], sujets: [],
                                  epreuves: [], corriges: [], libres: [] };
      const cle = item.type === "Fiche" ? "fiches"
        : item.type === "Fiche express" ? "fichesExpress"
                : item.type === "Épreuve blanche" ? "epreuves"
                : item.type === "Corrigé épreuve" ? "corriges"
                : item.type === "Entraînement libre" ? "libres"
                : item.type === "Sujet Labolycée" ? "sujets" : "videos";
      /* Un dépôt REMPLACE ce qui existait du même type : redéposer une fiche
         ou une épreuve corrigée ne doit pas laisser l'ancienne à côté. Les
         vidéos font exception — un chapitre en porte plusieurs par catégorie,
         et les sujets Labolycée viennent du code, pas d'un dépôt. */
      const unique = ["fiches", "epreuves", "corriges", "libres"].includes(cle);
      return { ...r, [chapId]: { ...chap,
        [cle]: unique ? [item] : [...(chap[cle] || []), item] } };
    });
    if (supabaseActif) {
      try {
        const unique = ["Fiche", "Fiche express", "Épreuve blanche",
                        "Corrigé épreuve", "Entraînement libre"].includes(item.type);
        if (unique) await remplacerRessourceDb(chapId, item.type);
        await ajouterRessourceDb(chapId, item);
      }
      catch (e) {
        /* On retire la ressource de l'écran : la garder afficherait un dépôt
           réussi alors que rien n'a été enregistré. */
        setRessources((r) => ({ ...r, [chapId]: Object.fromEntries(
          Object.entries(r[chapId] || {}).map(([k, v]) =>
            [k, Array.isArray(v) ? v.filter((x) => x.id !== item.id) : v])) }));
        setJournal((j) => [...j, { t: "Dépôt refusé",
          txt: "La ressource n'a pas pu être enregistrée : " + (e.message || e) }]);
      }
    }
  };

  const envoyerFichier = async (threadId, fichier, chapId) => {
    const h = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    const local = await versDataUrl(fichier);
    const message = { de: "Vous", role: "moi", txt: "", fichier: local, fichierType: fichier.type, fichierNom: fichier.name, h };
    if (threadId) setThreads((t) => t.map((x) => x.id === threadId ? { ...x, statut: "attente", messages: [...x.messages, message] } : x));
    else setThreads((t) => [{ id: Date.now(), chap: chapId, titre: fichier.type.startsWith("image/") ? "Photo de copie" : fichier.name, statut: "attente", messages: [message] }, ...t]);
    if (!supabaseActif) return;
    await envoyerFichierDb(threadId, fichier, chapId);
    const s = await chargerSujets();
    if (s) setThreads(s);
  };

  const envoyerVocal = async (threadId, blob, duree, chapId) => {
    const h = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    const local = await versDataUrl(blob);
    const message = { de: "Vous", role: "moi", txt: "", audio: local, audioDuree: duree, h };
    if (threadId) setThreads((t) => t.map((x) => x.id === threadId ? { ...x, statut: "attente", messages: [...x.messages, message] } : x));
    else setThreads((t) => [{ id: Date.now(), chap: chapId, titre: "Question vocale · " + duree + " s", statut: "attente", messages: [message] }, ...t]);
    if (!supabaseActif) return;
    await envoyerVocalDb(threadId, blob, duree, chapId);
    const s = await chargerSujets();
    if (s) setThreads(s);
  };

  const envoyer = async (threadId, txt, chapId) => {
    const h = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    /* Répondre, c'est avoir lu : la pastille s'éteint pour ce fil. */
    if (threadId) setThreads((t) => t.map((x) => x.id === threadId
      ? { ...x, statut: "attente", lu: true, messages: [...x.messages, { de: "Vous", role: "moi", txt, h }] } : x));
    else setThreads((t) => [{ id: Date.now(), chap: chapId, titre: txt.slice(0, 48), statut: "attente", messages: [{ de: "Vous", role: "moi", txt, h }] }, ...t]);
    if (!supabaseActif) return;
    if (threadId) await repondreSujet(threadId, txt); else await creerSujet(chapId, txt);
    const s = await chargerSujets();
    if (s) setThreads(s);
  };

  /* L'aiguillage par rôle passe AVANT tout le reste. Placé plus bas, un parent
     traversait l'écran d'accueil et se retrouvait dans l'application de
     l'élève — avec les données du compte connecté, pas celles de son enfant. */
  if (supabaseActif && !pret) {
    return (
      <div className="b"><style>{CSS}</style>
        <div className="wrap" style={{ paddingTop: 60, textAlign: "center" }}>
          <p className="small muted">Chargement…</p>
        </div>
      </div>
    );
  }

  /* Un compte connecté SANS profil : cela arrive quand le compte a été créé
     à la main dans Supabase, hors du circuit d'invitation. L'application
     l'affichait alors comme un élève ordinaire, mais rien ne fonctionnait
     vraiment — ni la déclaration de chapitre, ni le suivi. Mieux vaut le dire
     que de laisser l'élève devant une application inerte. */
  if (supabaseActif && pret && !profil) {
    return (
      <div className="b"><style>{CSS}</style>
        <div className="wrap" style={{ maxWidth: 460, paddingTop: 40 }}>
          <p className="sur">Bosse ta Physique</p>
          <h1 style={{ margin: "6px 0 0", fontSize: "1.3rem" }}>Compte incomplet</h1>
          <div className="card" style={{ marginTop: 18 }}>
            <p className="small">
              Votre compte existe mais n'a pas de profil : il a été créé en
              dehors du circuit d'invitation.
            </p>
            <p className="small muted" style={{ marginTop: 10 }}>
              Demandez à votre coach de vous inviter depuis son espace, puis
              reconnectez-vous avec le lien reçu.
            </p>
            <button className="btn btn-ghost btn-block" style={{ marginTop: 14 }}
              onClick={deconnexion}>Se déconnecter</button>
          </div>
        </div>
      </div>
    );
  }

  /* Un accès suspendu par le coach. Le bouton « Suspendre » écrivait bien la
     suspension en base, mais rien ne la lisait : l'élève continuait d'entrer
     comme si de rien n'était. Ses données sont conservées — le coach garde
     accès à son travail, et une réactivation le remet dans l'état exact où il
     s'était arrêté. */
  if (supabaseActif && profil && profil.actif === false) {
    return (
      <div className="b"><style>{CSS}</style>
        <div className="wrap" style={{ maxWidth: 460, paddingTop: 40 }}>
          <p className="sur">Bosse ta Physique</p>
          <h1 style={{ margin: "6px 0 0", fontSize: "1.3rem" }}>Accès suspendu</h1>
          <div className="card" style={{ marginTop: 18 }}>
            <p className="small">
              Votre accès a été suspendu par votre coach.
            </p>
            <p className="small muted" style={{ marginTop: 10 }}>
              Votre travail est conservé : rien n'est effacé. Rapprochez-vous de
              lui pour rétablir l'accès.
            </p>
            <button className="btn btn-ghost btn-block" style={{ marginTop: 14 }}
              onClick={deconnexion}>Se déconnecter</button>
          </div>
        </div>
      </div>
    );
  }

  /* Le mot de passe se choisit avant tout le reste, quel que soit le rôle :
     c'est une étape unique, à la première connexion. */
  if (supabaseActif && profil && !profil.mot_de_passe_pose) {
    return <ChoisirMotDePasse onFait={() => setProfil({ ...profil, mot_de_passe_pose: true })} />;
  }

  if (estParent) {
    return (
      <div className="b"><style>{CSS}</style>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=DM+Sans:opsz,wght@9..40,400;9..40,500&family=IBM+Plex+Mono:wght@500&display=swap" rel="stylesheet" />
        <div className="wrap">
          <div className="between" style={{ marginBottom: 16 }}>
            <div>
              <p className="sur" style={{ margin: 0 }}>Bosse ta Physique</p>
              <h1 style={{ margin: "4px 0 0", fontSize: "1.4rem" }}>Espace parent</h1>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={deconnexion}>Quitter</button>
          </div>
          <EspaceParent />
        </div>
      </div>
    );
  }

  if (phase === "onboarding")
    return <Onboarding {...{ reglages, setReglages }} onFini={() => {
      /* On pose l'ancre : le lundi de cette semaine-ci. Tout le calendrier en
         découlera, sans jamais dériver. */
      const a = jourReel();
      const lundi = new Date();
      lundi.setDate(lundi.getDate() - a);
      lundi.setHours(0, 0, 0, 0);
      setAncreLe(lundi.toISOString());
      setJour(a); setPhase("app"); setDeclare(true);
    }} />;

  /* garde-fou : le direct est un rendez-vous, jamais une seance chronometree */
  if (run && run.type === "direct") setRun(null);
  if (run && run.type === "flash" && (banques[run.chapId] || []).length)
    return <Flash tache={run} vus={vus} banques={banques} ressources={ressources}
      onFini={(resultat, refs) => { setVus((v) => [...new Set([...v, ...refs])]); finirTache(run, resultat); }}
      onQuit={() => setRun(null)} />;
  /* LA VEILLE DU CONTRÔLE : l'élève relit la correction de son épreuve blanche
     et les conseils du coach. Ce soir-là ouvrait un exercice ordinaire, ce qui
     n'a aucun sens — c'est le moment de reprendre ses erreurs, pas d'en
     découvrir de nouvelles. */
  if (run && run.type === "reprise")
    return <Reprise tache={run} copies={copies} onFini={finirTache}
             onQuit={() => setRun(null)} />;
  if (run && run.type !== "direct")
    /* LE ROBOT N'EST PAS PROPOSÉ AUX ÉLÈVES DU LYCÉE. Ils reçoivent tout le
       reste — exercices, fiches, suivi — mais pas l'aide en ligne, qui a un
       coût et qui ne leur est pas vendue. */
    return <Session tache={run} biblio={biblio} vus={vus} ressources={ressources}
      avecRobot={ROBOT_ACTIF && !groupeLycee}
      onFini={finirTache} onQuit={() => setRun(null)} />;

  if (diag) return (
    <Diagnostic chapId={diag} banques={banques} ressources={ressources} onQuit={() => setDiag(null)} onFini={(score, total, qtRatees = [], extra = {}) => {
      /* Le test vient d'ouvrir le cours : si l'élève a cliqué « Voir le cours »,
         on l'y emmène directement. */
      if (extra.versCours) { setChapCours(extra.versCours); setOnglet("ressources"); }
      const r = reglesDepuisDiagnostic(score, total);
      const next = chapitres.map((c) => (c.id === diag
        ? { ...c, ...r, score, total, qtRatees } : c));
      setChapitres(next);
      /* Seul le diagnostic DU chapitre passé est marqué fait : avec deux
         chapitres déclarés le même soir, l'autre reste à faire. */
      /* LE TEST ENTRE AU JOURNAL comme les autres séances : il ne passait pas
         par « finirTache », qui inscrit les séances, et le coach comptait donc
         une séance de moins que l'élève. */
      /* L'inscription au journal se fait À PART : la déclencher depuis
         « setTaches » mêlerait deux mises à jour, et React peut rejouer cette
         fonction — la séance serait inscrite plusieurs fois. */
      (() => {
        const t = taches.find((y) => y.type === "diagnostic" && y.chapId === diag);
        if (!t) return;
        const ligne = { id: t.id, semaine: t.semaine, jour: t.jour,
                        type: t.type, chapId: t.chapId,
                        duree: t.duree || 0, resultat: "fait" };
        setJournalSeances((l) => (l.some((y) => String(y.id) === String(t.id))
          ? l : [...l, ligne]));
        if (supabaseActif) inscrireSeance(ligne).catch(() => {});
      })();
      setTaches((ts) => ts.map((t) => (t.type === "diagnostic" && t.chapId === diag
        ? { ...t, statut: "fait", resultat: "fait" } : t)));
      const nomChap = CHAPITRES.find((x) => x.id === diag)?.nom || "";
      /* On EMPILE : avec deux chapitres déclarés le même soir, le second
         diagnostic ne doit pas effacer le résultat du premier. */
      /* ON DEMANDE LA PLANIFICATION : elle ne se faisait plus qu'au
         rechargement de la page. Le garde-fou « sans banque, on ne planifie
         pas » avait pu refuser un premier essai, et rien ne reprenait la main
         une fois la banque arrivée. */
      setAReplanifier(true);
      setJournal((j) => [...j.filter((e) => !e.t.startsWith("Nouveau chapitre")),
        { t: nomChap + " · test " + score + "/" + total,
          /* Le message parle de GESTES, pas de niveau : c'est ce que le test
             mesure désormais, et c'est ce qui commande les prochains exercices. */
          /* Le détail des gestes est dans le bilan dépliable, juste au-dessus :
             le répéter ici faisait un pavé de sept intitulés à la suite. */
          txt: qtRatees.length === 0
            ? "Tous les gestes sont acquis. Tes exercices vont maintenant les consolider."
            : "Tes premiers exercices iront chercher en priorité les "
              + qtRatees.length + " geste" + (qtRatees.length > 1 ? "s" : "")
              + " à reprendre." }]);
      replanifier(next);
      setDiag(null);
    }} />
  );

  if (eval_) return (
    <EvalBlanche tache={eval_} biblio={biblio} vus={vus} chapitres={chapitres}
      ressources={ressources}
      onEntrainementLibre={noterEntrainementLibre}
      onQuit={() => setEval_(null)}
      onEnvoi={(exos, photos = [], extra = {}) => {
        /* Les CHAPITRES évalués sont portés par la copie : c'est ce qui permet
           à l'écran DS de la rattacher au bon contrôle une fois corrigée. */
        /* Les PAGES partent dans le stockage : gardées dans l'état, elles le
           faisaient refuser par la base. */
        const idCopie = Date.now();
        if (supabaseActif && photos.length) {
          deposerPagesCopie(photos).then((chemins) => {
            if (chemins.length) setCopies((cs) => cs.map((x) => (x.id === idCopie
              ? { ...x, cheminsPages: chemins } : x)));
          }).catch(() => {});
        }
        setCopies((c) => [...c, { id: idCopie, semaine, exos, photos,
          chapitres: extra.chapitres || (eval_ && (eval_.chapitresEval || [eval_.chapId])) || [],
          eleve: profil?.nom || "Vous (démo)", statut: "en_attente" }]);
        setVus((v) => [...new Set([...v, ...exos.map((e) => e.id)])]);
        setTaches((ts) => ts.map((t) => (t.id === eval_.id ? { ...t, statut: "fait", resultat: "envoyee" } : t)));
        setEval_(null);
      }} />
  );

  /* Le COACH n'a pas de programme à suivre : « Ce soir », « Semaine », « DS »
     et « Progrès » sont les écrans d'un élève. Les lui montrer encombrait son
     menu et lui faisait croire qu'il devait s'en occuper. Il garde Cours — sa
     bibliothèque —, la permanence et son espace. */
  /* En démonstration, tout le monde est « coach » pour que les outils soient
     visibles — mais le menu doit rester celui de l'élève, sans quoi le parcours
     complet n'est plus visitable. */
  const nav = (estCoach && supabaseActif) ? [
    { id: "coach", label: "Élèves", ic: I.user },
    { id: "permanence", label: "Perm.", ic: I.chat, badge: enAttente },
    { id: "ressources", label: "Cours", ic: I.book },
    ...(oralOuvert
      ? [{ id: "oral", label: "Oral", ic: I.micro }]
      : []),
  ] : [
    { id: "jour", label: "Ce soir", ic: I.home },
    { id: "semaine", label: "Sem.", ic: I.cal },
    { id: "ressources", label: "Cours", ic: I.book },
    /* LA PERMANENCE EST MASQUÉE CÔTÉ ÉLÈVE : les échanges passent par Discord,
       où les notifications existent. Le code reste en place — la correction des
       copies n'en dépend pas, elle passe par l'état de l'élève et le stockage.
       Remettre la ligne ci-dessous suffit à la rouvrir.
    { id: "permanence", label: "Perm.", ic: I.chat, badge: enAttente }, */
    /* Une pastille quand une copie vient d'être corrigée : l'élève doit savoir
       qu'elle l'attend, sans avoir à ouvrir l'onglet pour vérifier. */
    { id: "controles", label: "DS", ic: I.flag, badge: copiesNonLues },
    { id: "progres", label: "Progrès", ic: I.chart },
    /* L'onglet n'apparaît que si le coach a ouvert le module. */
    ...(oralOuvert || estCoach
      ? [{ id: "oral", label: "Oral", ic: I.micro, badge: oral.notif && !oral.notif.lu ? 1 : 0 }]
      : []),
  ];

  return (
    <div className="b"><style>{CSS}</style>
      {modeDemo && (
        <div style={{ background: "#FBF1DC", borderBottom: "1px solid #F2E1BC",
          padding: "8px 16px", fontSize: ".72rem", color: "#7A5A12", textAlign: "center" }}>
          Mode démonstration · rien n'est enregistré et les outils du coach sont
          ouverts à tous. Branchez Supabase avant de diffuser l'adresse.
          {/* Repartir de zéro sans vider le cache du navigateur : c'est le
              geste qu'on répète vingt fois quand on éprouve un parcours. */}
          <button className="btn btn-ghost btn-sm" style={{ marginLeft: 8, color: "#7A5A12" }}
            onClick={() => setRemiseDemo(true)}>Remettre à zéro</button>
        </div>
      )}
      {remiseDemo && (
        <div className="voile" onClick={() => setRemiseDemo(false)}>
          <div className="feuille" onClick={(e) => e.stopPropagation()}>
            <div className="poignee" />
            <h3>Repartir de zéro ?</h3>
            <p className="small muted" style={{ marginTop: 6 }}>
              Le parcours reprend à l'inscription : chapitres, tâches, copies et
              historique effacés. Les fiches et vidéos déposées restent.
            </p>
            <div className="row" style={{ gap: 8, marginTop: 14 }}>
              <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                onClick={() => setRemiseDemo(false)}>Annuler</button>
              <button className="btn btn-accent btn-sm" style={{ flex: 1 }}
                onClick={() => {
                  /* En mode démonstration, l'état ne vit qu'en mémoire : un
                     rechargement suffit à repartir de l'inscription. */
                  window.location.reload();
                }}>Tout effacer</button>
            </div>
          </div>
        </div>
      )}
      {/* La fenêtre de changement de niveau a disparu avec les niveaux. */}
      {relance && <FenetreRelance relance={relance} setRelance={setRelance} onEnvoyer={envoyerRelance} />}
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=DM+Sans:opsz,wght@9..40,400;9..40,500&family=IBM+Plex+Mono:wght@500&display=swap" rel="stylesheet" />
      <div className="app">
        <aside className="side">
          <Logo />
          <nav className="nav">
            {[...nav, ...(estCoach ? [{ id: "coach", label: "Espace coach", ic: I.user }] : [])].map((n) => (
              <button key={n.id} className={onglet === n.id ? "on" : ""} onClick={() => setOnglet(n.id)}>
                <Icon d={n.ic} /> {n.label}
                {n.badge ? <span className="tag gold" style={{ marginLeft: "auto" }}>{n.badge}</span> : null}
              </button>
            ))}
          </nav>
        </aside>

        <div>
          <div className="topbar">
            <Logo />
            <div className="spacer" />
            <span className="tag grey">
              {(() => { const d = dateDe(ancreLe, semaine, jour);
                return d ? JOURS[jour] + " " + d.getDate() + "/" + (d.getMonth() + 1)
                         : JOURS[jour] + " · S" + semaine; })()}
            </span>
            {/* Avancer le jour fausse tout le suivi : un élève qui appuie dessus
                voit ses séances marquées manquées et son niveau chuter. Le bouton
                est donc réservé au coach et aux comptes de test, qui servent
                justement à parcourir plusieurs semaines pour vérifier. */}
            {(estCoach || profil?.test) && (
              <button className="btn btn-ghost btn-sm" onClick={() => { setJoursAvances((n) => n + 1); avancerJour(); }}>Jour +1</button>
            )}
            {/* REVENIR À LA DATE RÉELLE : le décalage accumulé par « Jour +1 »
                est conservé d'une session à l'autre, et il fallait pouvoir
                l'annuler pour retrouver le calendrier du jour. */}
            {joursAvances > 0 && (
              <button className="btn btn-ghost btn-sm"
                title={"Annuler les " + joursAvances + " jours simulés"}
                onClick={() => {
                  setJoursAvances(0);
                  const anc = ancreLe ? new Date(ancreLe) : null;
                  if (!anc) return;
                  const j = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
                  const abs = Math.max(0, Math.round((j(new Date()) - j(anc)) / 86400000));
                  setSemaine(Math.floor(abs / 7) + 1);
                  setJour(abs % 7);
                }}>Aujourd'hui</button>
            )}
            {estCoach && (
              <button className={"btn btn-sm " + (onglet === "coach" ? "btn-accent" : "btn-ghost")}
                onClick={() => setOnglet(onglet === "coach" ? "jour" : "coach")}>Coach</button>
            )}
            {supabaseActif && <button className="btn btn-ghost btn-sm" onClick={deconnexion}>Quitter</button>}
          </div>

          <main className="main">
            {onglet === "jour" && (
              <CeSoir {...{ jour, semaine, taches: tachesDuJour,
                tachesSemaine: taches.filter((t) => t.semaine === semaine && !t.masquee),
                jourDeCours, chapitres, controle, journal, encore, ajouterSujet, passerSujet, reglages, vus, accepterCharge, ancreLe, supplementsDuJour, MAX_SUPPLEMENTS, ressources, tropDeChapitres, controleTardif,
                setRun, setDiag, setEval_, setOnglet, setDeclare, declare, declarerChapitre, terminerChapitre, declarerControle, reglages, enAttente, principaux,
                inscrits, inscrire, estInscrit, questionsDirect, poserQuestionDirect, directs: directsLocaux, aRattraper, passerRattrapage,
                conseille, lancerConseille, plusTard }} />
            )}
            {/* Le planning n'affiche QUE la semaine en cours : les tâches
                conservées de la semaine passée, encore rattrapables, se
                retrouvaient posées sur la grille de celle-ci, avec leurs
                anciens comptes à rebours. */}
            {onglet === "semaine" && <MaSemaine {...{ taches: taches.filter((t) => !t.masquee && (t.semaine || semaine) === semaine), reglages, jour, semaine, chapitres, principaux, controle, journal, setRun, setDiag, setEval_, directs: directsLocaux,
                inscrits, questionsDirect, poserQuestionDirect, aRattraper, ancreLe }} />}
            {/* TOUS les chapitres, pas seulement ceux en cours : un chapitre
                terminé doit rester consultable, et il l'a déjà déverrouillé. */}
            {onglet === "ressources" && <Ressources {...{ ressources, principaux: chapitres, ajouterAuCarnet: (oralOuvert || estCoach) ? ajouterAuCarnet : null, retirerDuCarnetParTexte, carnet: (oralOuvert || estCoach) ? oral.carnet : [], chapVoulu: chapCours }} />}
            {onglet === "permanence" && <Permanence {...{ threads: threadsVisibles, marquerLu, viderPermanence, lus: lusAvant ?? lus, envoyer, envoyerVocal, envoyerFichier, estCoach, epingler, enRessource, retirerDesRessources, validerMessage, signalerErreur, ajouterAuCarnet: (oralOuvert || estCoach) ? ajouterAuCarnet : null, retirerDuCarnetParTexte, carnet: (oralOuvert || estCoach) ? oral.carnet : [], envoyerTout: envoyerMessageComplet, elevesPermanence: mesEleves }} />}
            {onglet === "oral" && <GrandOral {...{ oral, setOral, chapitres, semaine, idees: ideesOral, retirerDuCarnet, taches }} />}
            {onglet === "controles" && <Controles {...{ controle, controlesPasses,
              chapitres, taches, semaine, vus, ressources, copies, setRun, setEval_,
              travaillerGeste, biblio, ancreLe, jour,
              onEntrainementLibre: noterEntrainementLibre }} />}
            {onglet === "progres" && <Progres {...{ taches: taches.filter((t) => !t.masquee), chapitres, copies, semaine, jour, controle, controlesPasses, reglages, setReglages: changerReglages, replanifier, travaillerGeste, budgetRetenu, chapitresActifs, ancreLe, biblio, vus, supplements, journalSeances, setRun,
              demarrage: semaineDemarrage === semaine }} />}
            {onglet === "coach" && <EspaceCoach {...{ biblio, setBiblio, copies, setCopies, taches, chapitres, semaine, controle, ouvrirRelance, rendreCopie, manquements, relances, absAujourdhuiCoach: (semaine - 1) * 7 + jour, questionsDirect, inscrits, ressources, ajouterRessource, retirerRessource, viderRessources, libres, ancreLe, periodes, profil, oralOuvert, setOralOuvert, directs, programmerDirect, annulerDirect, avisDirect,
                oral, setOral, ideesOral, setIdeesOral, banques }} />}
            {/* Les mentions légales, au bas de chaque écran : elles doivent
                rester joignables d'un seul geste, où que soit l'élève. */}
            <PiedLegal style={{ marginTop: 26, marginBottom: 4 }} />
          </main>
        </div>
      </div>

      <nav className="tabbar">
        {nav.map((n) => (
          <button key={n.id} className={"tab" + (onglet === n.id ? " on" : "")} onClick={() => setOnglet(n.id)}>
            <span style={{ position: "relative" }}>
              <Icon d={n.ic} size={21} />
              {n.badge ? <span className="badge">{n.badge}</span> : null}
            </span>
            {n.label}
          </button>
        ))}
      </nav>
    </div>
  );
}

/* ========================= ONBOARDING ===================================== */

function Onboarding({ reglages, setReglages, onFini }) {
  /* Un jour ne peut pas être à la fois jour de cours et jour sans travail :
     cocher dans une liste le retire de l'autre. */
  const [avertir, setAvertir] = useState(null);
  const t = (cle, v) => {
    const dedans = reglages[cle].includes(v);
    const suite = dedans ? reglages[cle].filter((x) => x !== v) : [...reglages[cle], v].sort();
    /* Au moins un jour de week-end doit rester travaillé : c'est là que se pose
       le sujet de bac, et un sujet de deux heures n'a pas sa place un soir de
       semaine. Chômer samedi ET dimanche est donc refusé. */
    if (cle === "joursOff" && !dedans && v >= 5 && [5, 6].every((x) => suite.includes(x))) {
      setAvertir("Garde au moins un jour de week-end : c'est là que se place ton sujet de bac.");
      return;
    }
    setAvertir(null);
    /* LES DEUX LISTES NE S'EXCLUENT PLUS. Un élève peut avoir cours de
       physique le mardi et ne pas travailler le mardi soir : ce sont deux
       choses différentes, et lui refuser l'une parce qu'il a coché l'autre
       l'empêchait de décrire sa semaine telle qu'elle est. Le moteur ne pose
       rien un jour chômé, la combinaison est donc sans danger. */
    setReglages({ ...reglages, [cle]: suite });
  };
  return (
    <div className="b"><style>{CSS}</style>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=DM+Sans:opsz,wght@9..40,400;9..40,500&family=IBM+Plex+Mono:wght@500&display=swap" rel="stylesheet" />
      <div className="wrapc">
        <Logo />
        <p className="eyebrow" style={{ marginTop: 24 }}>Mise en route</p>
        <h1 style={{ marginTop: 6 }}>Quatre questions, une seule fois.</h1>
        <p className="small muted" style={{ marginTop: 8 }}>Ensuite vous ne choisissez plus rien : chaque soir, une tâche vous attend.</p>

        <div className="card" style={{ marginTop: 18 }}>
          <h3>Vos jours de cours de physique-chimie</h3>
          <div className="chips" style={{ marginTop: 12 }}>
            {JOURS.map((j, k) => <button key={j} className={"chip" + (reglages.joursCours.includes(k) ? " on" : "")} onClick={() => t("joursCours", k)}>{j}</button>)}
          </div>
        </div>
        <div className="card">
          <h3>Vos jours sans travail</h3>
          <div className="chips" style={{ marginTop: 12 }}>
            {JOURS.map((j, k) => <button key={j} className={"chip" + (reglages.joursOff.includes(k) ? " on" : "")} onClick={() => t("joursOff", k)}>{j}</button>)}
          </div>
          {avertir && (
            <p className="small" style={{ marginTop: 8, color: "#7A5A12" }}>{avertir}</p>
          )}
          <div style={{ display: "none" }}>
          </div>
        </div>
        <div className="card">
          <h3>Temps disponible en semaine</h3>
          <div className="chips" style={{ marginTop: 12 }}>
            {/* DEUX DURÉES SEULEMENT. Le choix de 45 min a été retiré : trente
                minutes par soir suffisent, et l'élève qui veut travailler
                davantage prend des exercices supplémentaires — ils s'ajoutent
                à la soirée sans épuiser la banque du chapitre. */}
            {[20, 30].map((b) => <button key={b} className={"chip" + (reglages.budgetSemaine === b ? " on" : "")} onClick={() => setReglages({ ...reglages, budgetSemaine: b })}>{b} min</button>)}
          </div>
          <p className="small muted" style={{ marginTop: 6 }}>
            20 min, c'est le minimum pour tenir le rythme. 30 min est le plus
            courant. Si tu veux en faire plus un soir, tu pourras demander des
            exercices supplémentaires. Tu pourras changer à tout moment.
          </p>
          <div style={{ display: "none" }}>
          </div>
        </div>
        <button className="btn btn-gold btn-block" style={{ marginTop: 18 }} disabled={!reglages.joursCours.length} onClick={onFini}>C'est parti</button>
      </div>
    </div>
  );
}

/* ========================= CE SOIR ======================================== */

function CeSoir({ jour, semaine, taches, tachesSemaine = [], vus = [], accepterCharge, ancreLe, supplementsDuJour = 0, MAX_SUPPLEMENTS = 2, jourDeCours, principaux, chapitres, controle, journal, setRun, setDiag, setEval_, setOnglet, declare, setDeclare, declarerChapitre, terminerChapitre, declarerControle, reglages, enAttente, ajouterSujet, passerSujet, inscrits, estInscrit = () => false, inscrire, questionsDirect, poserQuestionDirect, directs = [], aRattraper = null, passerRattrapage, conseille = null, lancerConseille, plusTard, encore, ressources = {}, tropDeChapitres = null, controleTardif = null }) {
  const [form, setForm] = useState(null);
  /* Le sujet dont le report attend confirmation : un report est irréversible
     pour la semaine, l'élève doit savoir ce qu'il engage. */
  const [aConfirmer, setAConfirmer] = useState(null);
  const [question, setQuestion] = useState("");
  const [semQuestion, setSemQuestion] = useState(null);
  /* CINQ SEMAINES DEVANT, au lieu de deux : un coach qui programme un cours un
     mois à l'avance le voyait disparaître de l'écran de ses élèves, qui ne
     pouvaient donc pas s'y inscrire. */
  const prochains = directs.filter((d) => d.semaine >= semaine && d.semaine <= semaine + 5)
    .sort((a, b) => (a.semaine - b.semaine) || (a.jour - b.jour));
  const [sel, setSel] = useState([]);
  const [jourDS, setJourDS] = useState(null);
  const [semDS, setSemDS] = useState(semaine);
  /* Deux heures, toujours : la durée ne se déclare plus. */
  const dureeDS = 120;
  const dispo = CHAPITRES.filter((c) => !chapitres.find((x) => x.id === c.id));
  const total = taches.filter((t) => t.statut !== "manquee").reduce((a, t) => a + t.duree, 0);

  const lancer = (t) => {
    if (t.type === "diagnostic") return setDiag(t.chapId);
    if (t.type === "blanche") return setEval_(t);
    /* UN RAPPEL est une séance de QUESTIONS FLASH sur un chapitre terminé : il
       ouvrait un exercice d'entraînement, ce qui n'a pas de sens — l'élève
       n'est plus en train d'apprendre ce chapitre, il l'entretient. */
    if (t.type === "rappel") return setRun({ ...t, type: "flash" });
    setRun(t);
  };
  /* une seance manquee se relance normalement : c'est le rattrapage */

  return (
    <div className="stack">
      <div>
        <p className="eyebrow">
          {jourEnClair(ancreLe, semaine, jour) || JOURS[jour] + " · semaine " + semaine}
          {jourDeCours ? " · cours de physique" : ""}
        </p>
        <h1 style={{ marginTop: 6 }}>Ce soir</h1>
      </div>

      {/* Contrôle déclaré trop tard : on dit franchement ce qui manquera, sans
          dramatiser. Mieux vaut un élève averti qu'un élève qui croit que le
          programme l'a oublié. */}
      {/* Les jours sans cours, un accès discret pour saisir une date de contrôle. */}


      {controleTardif && (
        <div className="card" style={{ borderColor: "#F3D6D3", background: "#FDF6F5" }}>
          <span className="eyebrow" style={{ color: "#8C332C" }}>Contrôle déclaré tard</span>
          <h3 style={{ marginTop: 8 }}>
            {controleTardif.reste === 0 ? "Le contrôle est aujourd'hui"
              : controleTardif.reste === 1 ? "Le contrôle est demain"
              : "Le contrôle est après-demain"}
          </h3>
          <p className="small" style={{ marginTop: 6, color: "#8C332C" }}>
            {controleTardif.reste === 0
              ? "Il n'y a plus de préparation possible : ni épreuve blanche, ni reprise des erreurs. Bon courage."
              : controleTardif.reste === 1
              ? "Il reste ce soir pour la reprise des erreurs. L'épreuve blanche, elle, tombait avant-hier : elle ne sera pas posée."
              : "L'épreuve blanche tient encore ce soir, et la reprise demain. Mais les séances de révision des jours précédents sont perdues."}
          </p>
          <p className="small muted" style={{ marginTop: 8 }}>
            Une préparation complète demande au moins trois jours : révisions, puis
            épreuve blanche à J-2, puis reprise la veille. Déclarez vos contrôles
            dès que la date est connue.
          </p>
        </div>
      )}

      {/* Deux chapitres ouverts sur un budget trop court : on le dit tant que
          la situation dure, avec le calcul sous les yeux. Ce n'est pas un
          reproche — c'est une information dont l'élève a besoin pour choisir. */}
      {tropDeChapitres && (
        <div className="card" style={{ borderColor: "#F2E1BC", background: "#FFFDF7" }}>
          <span className="eyebrow" style={{ color: "#7A5A12" }}>Le compte n'y est pas</span>
          <h3 style={{ marginTop: 8 }}>
            {tropDeChapitres.actifs} chapitres pour {tropDeChapitres.budget} min par jour
          </h3>
          <p className="small" style={{ marginTop: 6, color: "#7A5A12" }}>
            Cela fait {tropDeChapitres.parChapitre} min par chapitre. Il en faut une trentaine
            pour en travailler un correctement : une restitution et un exercice.
          </p>
          {/* On dit s'il EXISTE un réglage qui règle le problème. Au-delà de
              trois chapitres, allonger les soirées ne suffit plus : le seul
              remède est d'en terminer un, et il vaut mieux le dire franchement
              que de renvoyer l'élève vers des réglages sans issue. */}
          <p className="small muted" style={{ marginTop: 8 }}>
            Pour les mener tous les {tropDeChapitres.actifs} correctement, il te
            faudrait {Math.min(90, tropDeChapitres.actifs * 30)} min par soir au
            lieu de {tropDeChapitres.budget}. En l'état, ils avancent tous au ralenti.
          </p>
          {/* L'élève décide : soit il accepte des soirées plus longues, soit il
              clôt un chapitre. L'ancien message le renvoyait aux réglages sans
              rien proposer — et à trois chapitres, aucun réglage ne suffisait. */}
          <div className="row" style={{ gap: 8, marginTop: 12 }}>
            <button className="btn btn-accent btn-sm" style={{ flex: 1 }}
              onClick={() => accepterCharge && accepterCharge()}>
              J'accepte de travailler plus
            </button>
            <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
              onClick={() => setOnglet("progres")}>
              Terminer un chapitre
            </button>
          </div>
          {/* Deux chapitres, ce sont aussi deux sujets de synthèse à placer, et
              ils ne tiennent pas dans un seul soir de week-end. */}
          <p className="small muted" style={{ marginTop: 6 }}>
            Ton week-end a été élargi automatiquement : chaque chapitre terminé donne
            droit à un sujet type bac d'une heure, et il faut de la place pour les deux.
          </p>
          <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }}
            onClick={() => setOnglet("progres")}>Ouvrir mes réglages</button>
        </div>
      )}

      {/* les déclarations, seulement les soirs de cours */}
      {/* Un chapitre se déclare après le cours, mais une DATE DE CONTRÔLE
          s'apprend n'importe quand — souvent un jour sans cours. La bloquer
          derrière les jours de cours faisait perdre à l'élève plusieurs jours
          de préparation. */}
      {/* Le panneau était réservé aux jours de cours : un élève qui sortait
          d'un cours un mercredi — remplacement, rattrapage, semaine décalée —
          n'avait aucun moyen de déclarer son chapitre. Il est désormais
          accessible tous les jours, l'intitulé s'adaptant au contexte. */}
      <div className="card">
          <span className="eyebrow">{jourDeCours ? "Après votre cours" : "À tout moment"}</span>
          <h3 style={{ marginTop: 8 }}>Quelque chose a changé ?</h3>
          {/* Déclarer un chapitre ne dépend plus du jour : un cours peut tomber
              n'importe quand, un remplacement, un rattrapage, une semaine
              décalée. Réserver ce bouton aux jours de cours déclarés laissait
              l'élève sans moyen d'entrer son chapitre le soir même. */}
          {/* TROIS CHAPITRES AU PLUS. Au-delà, même en acceptant des soirées
              plus longues, chacun reçoit moins de vingt minutes : l'élève
              survole tout et ne maîtrise rien. On dit pourquoi plutôt que de
              masquer le bouton sans explication. */}
          {(chapitres || []).filter((c) => c.statut === "en_cours").length >= 3 ? (
            <div style={{ padding: "10px 12px", borderRadius: 10,
              background: "#FBF3E4", border: "1px solid #E8DCC0", marginBottom: 8 }}>
              <p className="small" style={{ margin: 0, color: "#7A5A12" }}>
                Tu mènes déjà trois chapitres — c'est le maximum. Termine-en un
                avant d'en ouvrir un autre : au-delà, chacun reçoit trop peu de
                temps pour être maîtrisé.
              </p>
            </div>
          ) : (
            <button className={"choix" + (form === "nouveau" ? " on" : "")}
              onClick={() => setForm(form === "nouveau" ? null : "nouveau")}>
              <span className="ico"><Icon d={I.book} size={18} /></span>
              <span className="lib">J'ai commencé un nouveau chapitre</span>
              <span className="fin">{form === "nouveau" ? "×" : "›"}</span>
            </button>
          )}
          {principaux.some((c) => c.niveau) && (
            <button className={"choix" + (form === "fini" ? " on" : "")}
              onClick={() => setForm(form === "fini" ? null : "fini")}>
              <span className="ico"><Icon d={I.coche} size={18} /></span>
              <span className="lib">Un chapitre est terminé</span>
              <span className="fin">{form === "fini" ? "×" : "›"}</span>
            </button>
          )}
          {/* Un DS ne se déclare qu'APRÈS le test de positionnement : sans lui,
              le moteur ne sait ni quels gestes reprendre ni quels exercices
              servir. Il poserait une épreuve blanche sur du vide. */}
          {(principaux || []).some((c) => c.niveau) ? (
            <button className={"choix" + (form === "ds" ? " on" : "")}
              onClick={() => setForm(form === "ds" ? null : "ds")}>
              <span className="ico"><Icon d={I.cal} size={18} /></span>
              <span className="lib">Un contrôle est prévu</span>
              <span className="fin">{form === "ds" ? "×" : "›"}</span>
            </button>
          ) : (principaux || []).length ? (
            <div style={{ padding: "10px 12px", borderRadius: 10, marginTop: 8,
              background: "#FBF3E4", border: "1px solid #E8DCC0" }}>
              <p className="small" style={{ margin: 0, color: "#7A5A12" }}>
                Passe d'abord ton test de positionnement : c'est lui qui dit
                quels gestes reprendre. Sans lui, ton épreuve blanche et tes
                révisions ne sauraient pas quoi te proposer.
              </p>
            </div>
          ) : null}

          {form === "nouveau" && (
            <div style={{ marginTop: 14 }}>
              <p className="small muted">Le test diagnostic sera proposé ce soir même. C'est lui qui règle la suite.</p>
              <div className="chips" style={{ marginTop: 10 }}>
                {dispo.map((c) => <button key={c.id} className="chip" onClick={() => { declarerChapitre(c.id); setForm(null); }}>{c.court}</button>)}
              </div>
            </div>
          )}

          {form === "fini" && (
            <div style={{ marginTop: 14 }}>
              <p className="small muted">Lequel ? Il repassera en rappel espacé, il ne disparaît pas.</p>
              <div className="chips" style={{ marginTop: 10 }}>
                {principaux.filter((c) => c.niveau).map((c) => (
                  <button key={c.id} className="chip" onClick={() => { terminerChapitre(c.id); setForm(null); }}>
                    {CHAPITRES.find((x) => x.id === c.id).court}
                  </button>
                ))}
              </div>
            </div>
          )}

          {form === "ds" && (
            <div style={{ marginTop: 14 }}>
              <p className="small muted">Quel jour a lieu le controle ?</p>
              <div className="chips" style={{ marginTop: 10 }}>
                {Array.from({ length: 14 }, (_, k) => k + 1).map((k) => {
                  const abs = (semaine - 1) * 7 + jour + k;
                  const jDS = abs % 7, sDS = Math.floor(abs / 7) + 1;
                  /* LES JOURS CHÔMÉS RESTENT PROPOSÉS. Un contrôle a lieu en
                     classe, dans la journée ; le jour chômé ne concerne que
                     le soir. Les masquer empêchait l'élève qui a physique le
                     vendredi, et ne travaille pas le vendredi soir, de
                     déclarer son devoir du vendredi. Le moteur, lui, s'en
                     accommode : l'épreuve blanche et la reprise se placent
                     les soirs travaillés qui précèdent. */
                  const actif = jourDS === jDS && semDS === sDS;
                  return (
                    <button key={k} className={"chip" + (actif ? " on" : "")} onClick={() => { setJourDS(jDS); setSemDS(sDS); }}>
                      {/* La DATE RÉELLE plutôt qu'un « +5j » : l'élève reporte
                          ce qu'il lit sur son cahier de textes, sans calcul. */}
                      {(() => { const d = dateDe(ancreLe, sDS, jDS);
                        return d ? JOURS[jDS] + " " + d.getDate() + "/" + (d.getMonth() + 1)
                                 : JOURS[jDS] + " +" + k + "j"; })()}
                    </button>
                  );
                })}
              </div>

              {/* La durée ne se choisit plus : deux heures pour tout le monde.
                  S'entraîner sur une heure ne prépare pas à tenir la longueur —
                  c'est la fatigue de la seconde heure qui départage. L'épreuve
                  du baccalauréat dure 3 h 30, deux heures en sont une étape. */}
              <p className="small muted" style={{ marginTop: 14 }}>
                Ton épreuve blanche durera <b>2 h</b>, sans interruption.
                Elle est programmée deux jours avant ton contrôle.
              </p>

              {/* Un contrôle porte souvent sur un chapitre qu'on ne travaille
                  plus — terminé, ou jamais déclaré ici. On propose donc TOUS
                  les chapitres, ceux déjà suivis en tête. */}
              <p className="small muted" style={{ marginTop: 14 }}>Chapitres évalués</p>
              <div className="chips" style={{ marginTop: 8 }}>
                {chapitres.map((c) => (
                  <button key={c.id} className={"chip" + (sel.includes(c.id) ? " on" : "")}
                    onClick={() => setSel((x) => x.includes(c.id) ? x.filter((y) => y !== c.id) : [...x, c.id])}>
                    {CHAPITRES.find((x) => x.id === c.id).court}
                  </button>
                ))}
              </div>
              {CHAPITRES.filter((c) => !chapitres.some((x) => x.id === c.id)).length > 0 && (
                <>
                  <p className="small muted" style={{ marginTop: 12 }}>
                    Un chapitre que vous n'avez pas déclaré ici ? Choisissez-le quand même :
                    il sera ajouté, avec son test diagnostic pour calibrer les révisions.
                  </p>
                  <div className="chips" style={{ marginTop: 8 }}>
                    {CHAPITRES.filter((c) => !chapitres.some((x) => x.id === c.id)).map((c) => (
                      <button key={c.id} className={"chip" + (sel.includes(c.id) ? " on" : "")}
                        onClick={() => setSel((x) => x.includes(c.id) ? x.filter((y) => y !== c.id) : [...x, c.id])}>
                        {c.court}
                      </button>
                    ))}
                  </div>
                </>
              )}

              {/* QUATRE JOURS AU MOINS. Un contrôle annoncé pour demain ne
                  laisse la place ni à l'épreuve blanche — posée deux jours
                  avant — ni aux révisions. L'élève déclare alors une échéance
                  qui ne change rien à son programme. */}
              {(() => {
                const delai = (semDS - semaine) * 7 + (jourDS ?? 0) - jour;
                if (jourDS === null || delai >= 4) return null;
                return (
                  <p className="small" style={{ marginTop: 10, color: "#7A5A12" }}>
                    Ce contrôle est dans {delai <= 0 ? "moins d'un jour" : delai + " jour" + (delai > 1 ? "s" : "")}.
                    Il en faut au moins quatre pour que ton épreuve blanche et tes
                    révisions tiennent. Choisis une date plus lointaine, ou préviens
                    ton coach en permanence.
                  </p>
                );
              })()}
              <button className="btn btn-gold btn-sm btn-block" style={{ marginTop: 14 }}
                disabled={!sel.length || jourDS === null
                  || ((semDS - semaine) * 7 + (jourDS ?? 0) - jour) < 4}
                onClick={() => { declarerControle(jourDS, semDS, sel, dureeDS); setForm(null); }}>
                Declarer le controle
              </button>
            </div>
          )}
        </div>

      {aRattraper && (
        <div className="card" style={{ borderColor: "#F2E1BC", background: "#FFFDF8" }}>
          <div className="between">
            <span className="eyebrow" style={{ color: "#7A5A12" }}>
              Soirée non faite · {JOURS[aRattraper.jour]}
              {aRattraper.semaine !== semaine ? " de la semaine dernière" : ""}
            </span>
            <span className="tag gold">A rattraper</span>
          </div>
          <p className="small muted" style={{ marginTop: 8 }}>
            Rattrapez-la avant la seance de ce soir. Les feuilles blanches, elles, ne bougent pas :
            elles restent a J+1, J+3 et J+7.
          </p>
          <div style={{ marginTop: 6 }}>
            {aRattraper.taches.map((t) => (
              <div className="tache" key={t.id}>
                <span className={"pst " + (t.cat === "restitution" ? "restitution" : t.cat === "chaud" ? "chaud" : "")}>{t.duree}′</span>
                <div style={{ flex: 1 }}>
                  <h4>{t.libelle}</h4>
                  <p className="small muted">{t.chapNom}</p>
                </div>
                <button className="btn btn-gold btn-sm" onClick={() => lancer(t)}>Rattraper</button>
              </div>
            ))}
          </div>
          <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 12 }}
            onClick={() => passerRattrapage(aRattraper)}>
            Je passe cette soiree
          </button>
        </div>
      )}

      {journal.map((d, k) => (
        <div className="card" key={k} style={{ borderColor: "#D6DEFB",
          opacity: d.fait ? 0.55 : 1 }}>
          <span className="eyebrow">{d.t}{d.fait ? " · fait" : ""}</span>
          {/* Un travail supplémentaire accompli se barre : l'élève voit d'un
              coup d'œil ce qui reste à faire de ce qu'il a déjà réglé. */}
          <p className="small" style={{ marginTop: 6,
            textDecoration: d.fait ? "line-through" : "none" }}>{d.txt}</p>
        </div>
      ))}

      {/* Le BILAN DU TEST, le soir où l'élève vient de le passer : c'est là
          qu'il veut savoir ce qu'il a raté, pas dans un autre écran. Il porte
          le dépliant des gestes, comme dans Progrès. */}
      {(chapitres || []).filter((c) => c.niveau && c.semaineDebut === semaine
        && c.jourDeclare === jour).map((c) => (
        <div className="card" key={"bilan-" + c.id}>
          <span className="eyebrow">Ton test de positionnement</span>
          <h3 style={{ marginTop: 6 }}>{c.nom || CHAPITRES.find((x) => x.id === c.id)?.nom || c.id}</h3>
          <BilanTest c={c} restit={(c.restitutionsFaites || []).length} />
        </div>
      ))}

      {/* la tâche du soir */}
      <div className="card">
        <div className="between">
          <h2>{taches.length ? (total + " min ce soir") : "Rien ce soir"}</h2>
          {controle && <span className="tag red">Contrôle {JOURS[controle.jour]}{controle.semaine > semaine ? " (S+" + (controle.semaine - semaine) + ")" : ""}</span>}
        </div>
        <div style={{ marginTop: 6 }}>
          {taches.map((t) => (
            <div className="tache" key={t.id}>
              <span className={"pst " + (t.cat === "chaud" ? "chaud" : t.cat === "rappel" ? "rappel" : t.cat === "controle" ? "controle" : t.cat === "restitution" ? "restitution" : t.cat === "direct" ? "direct" : "")}>{t.duree}′</span>
              <div style={{ flex: 1 }}>
                <div className="row" style={{ gap: 8 }}>
                  <h4 style={t.statut !== "a_faire" ? { textDecoration: "line-through", opacity: .55 } : {}}>{t.libelle}</h4>
                  {(t.statut === "manquee" || t.statut === "abandonnee") && <span className="tag red">Non fait</span>}
                  {t.serre && <span className="tag gold">Soirée longue</span>}
                  {/* On distingue le sujet de la semaine de celui qu'on traîne
                      depuis la semaine passée : ce ne sont pas les mêmes
                      enjeux, et l'élève doit voir lequel est le plus urgent. */}
                  {t.type === "bac" && (t.reports || 0) > 0 && (
                    <span className="tag gold">Reporté</span>
                  )}
                  {t.type === "bac" && !(t.reports || 0) && !t.enPlus && (
                    <span className="tag">Sujet de la semaine</span>
                  )}
                  {t.type === "bac" && t.enPlus && (
                    <span className="tag grey">Ajouté par toi</span>
                  )}
                </div>
                <p className="small muted">{t.chapNom} · {t.motif}</p>
                {t.serre && <p className="small muted">Prévoyez {t.duree} min : une épreuve blanche ne se raccourcit pas.</p>}

                {/* Un sujet type bac se reporte d'une semaine, une seule fois.
                    Le bouton vit ici, dans la ligne du sujet : un encadré à
                    part faisait douter l'élève sur l'endroit où appuyer. */}
                {/* Le report ne s'offre qu'UNE FOIS par semaine, et jamais sur
                    un sujet déjà reporté. Sans cette règle, l'élève reportait,
                    recevait le sujet suivant, le reportait à son tour — et
                    repoussait indéfiniment le travail du week-end. */}
                {t.type === "bac" && t.statut === "a_faire" && passerSujet && (
                  ((t.reports || 0) > 0
                   || tachesSemaine.some((x) => x.type === "bac" && (x.reports || 0) > 0)) ? (
                    <p className="small" style={{ marginTop: 6, color: "#7A5A12" }}>
                      {(t.reports || 0) > 0
                        ? "Tu l'avais reporté la semaine dernière : c'est ta dernière occasion de le traiter, il ne reviendra plus."
                        : "Tu as déjà reporté un sujet cette semaine : celui-ci ne peut pas l'être."}
                    </p>
                  ) : (
                    aConfirmer === t.id ? (
                      <div style={{ marginTop: 8, padding: 10, borderRadius: 10,
                        background: "#FBF3E4", border: "1px solid #E8DCC0" }}>
                        <p className="small" style={{ margin: 0, color: "#7A5A12" }}>
                          Ce sujet reviendra la semaine prochaine, en plus de celui
                          qui sera prévu. <b>Tu ne pourras pas le reporter une
                          seconde fois</b> : si tu le laisses passer, il sera perdu.
                        </p>
                        <div className="row" style={{ gap: 8, marginTop: 10 }}>
                          <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                            onClick={() => setAConfirmer(null)}>Annuler</button>
                          <button className="btn btn-accent btn-sm" style={{ flex: 1 }}
                            onClick={() => { passerSujet(t.id); setAConfirmer(null); }}>
                            Reporter quand même
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button className="btn btn-ghost btn-sm" style={{ marginTop: 8 }}
                        onClick={() => setAConfirmer(t.id)}>
                        Reporter à la semaine prochaine
                      </button>
                    )
                  )
                )}
              </div>
              {t.type === "direct"
                ? <BoutonRejoindre lien={(directs.find((d) => d.semaine === semaine
                          && d.jour === jour) || directs.find((d) => d.semaine === semaine))?.lien} />
                : t.statut === "a_faire"
                ? (aRattraper
                    ? <span className="tag gold">Après le rattrapage</span>
                    : <button className="btn btn-accent btn-sm" onClick={() => lancer(t)}>Commencer</button>)
                : <span className={"tag " + (t.statut === "manquee" ? "red" : t.statut === "abandonnee" ? "grey" : t.resultat === "acquis" ? "green" : "grey")}>
                    {t.statut === "manquee" || t.statut === "abandonnee" ? "non fait" : t.resultat}
                  </span>}
            </div>
          ))}
          {!taches.length && (
            <>
              <p className="small muted">
                {reglages.joursOff.includes(jour) ? "Jour off : aucune tâche n'est posée." : "Rien ce soir : c'est un soir de repos."}
              </p>
              {/* Un jour de repos reste un jour où l'on PEUT travailler. On ne
                  pose rien d'office — c'est le principe du repos — mais on
                  propose, pour l'élève qui s'y met quand même. */}
              {reglages.joursOff.includes(jour) && (
                <div style={{ marginTop: 12 }}>
                  <p className="small muted">Envie de travailler quand même ?</p>
                  <div className="row" style={{ gap: 8, marginTop: 8 }}>
                    {encore && (
                      <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                        disabled={supplementsDuJour >= MAX_SUPPLEMENTS}
                        onClick={() => encore("exo")}>Un exercice</button>
                    )}
                    {encore && (
                      <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                        onClick={() => encore("flash")}>Des questions flash</button>
                    )}
                  </div>
                  {/* Le week-end, on propose aussi un sujet type bac : c'est le
                      seul moment où l'élève a le temps d'en traiter un. */}
                  {jour >= 5 && ajouterSujet && (chapitres || [])
                    .filter((c) => c.statut === "en_cours" && c.niveau).slice(0, 3).map((c) => (
                    <button key={c.id} className="btn btn-ghost btn-sm btn-block"
                      style={{ marginTop: 8 }}
                      onClick={() => ajouterSujet(c.id, jour)}>
                      Un sujet type bac · {CHAPITRES.find((x) => x.id === c.id)?.nom || c.id}
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Le week-end, une fois le sujet de synthèse rendu, on propose les sujets
          de bac que le coach a sélectionnés sur Labolycée pour ce chapitre.
          C'est le prolongement naturel : même format, mêmes attendus, mais des
          énoncés officiels et variés. */}
      {(() => {
        const bacFait = taches.find((t) => t.type === "bac" && t.statut === "fait");
        if (!bacFait) return null;
        /* On écarte ceux que l'élève a déjà traités : lui proposer « pour aller
           plus loin » un sujet qu'il vient de composer n'aurait aucun sens. */
        const dejaVus = [...vus, ...taches.filter((t) => t.exoId).map((t) => t.exoId)];
        /* TOUS les chapitres en cours, pas seulement celui du sujet rendu : un
           élève qui en mène deux peut vouloir travailler l'autre. Le chapitre
           du sujet passe en tête, les autres suivent. */
        const chapsOuverts = [bacFait.chapId,
          ...(chapitres || []).filter((c) => c.statut === "en_cours" && c.niveau
            && c.id !== bacFait.chapId).map((c) => c.id)];
        const sujets = chapsOuverts.flatMap((cid) =>
          ((ressources[cid] || {}).sujets || [])
            .filter((sj) => !dejaVus.includes(sj.id))
            .slice(0, 4)
            .map((sj) => ({ ...sj, chapId: cid,
              chapNom: CHAPITRES.find((x) => x.id === cid)?.nom || cid })));
        if (!sujets.length) return null;
        return (
          <div className="card" style={{ borderColor: "#D6DEFB" }}>
            <div className="between">
              <span className="eyebrow">Pour aller plus loin</span>
              <span className="tag">{sujets.length} sujet{sujets.length > 1 ? "s" : ""}</span>
            </div>
            <h3 style={{ marginTop: 10 }}>
              {chapsOuverts.length > 1 ? "D'autres sujets, chapitre par chapitre"
                                       : "D'autres sujets sur ce chapitre"}
            </h3>
            <p className="small muted" style={{ marginTop: 4 }}>
              Des sujets de bac officiels, choisis pour toi. Ce n'est pas au
              programme : c'est pour ceux qui en veulent plus.
            </p>
            {/* Un intertitre par chapitre : sans lui les sujets se suivaient
                en une seule liste, et rien ne disait auquel ils appartenaient
                — l'élève croyait travailler un seul chapitre. */}
            {chapsOuverts.map((cid) => {
              const dessus = sujets.filter((sj) => sj.chapId === cid);
              if (!dessus.length) return null;
              const nom = CHAPITRES.find((x) => x.id === cid)?.nom || cid;
              return (
                <div key={cid} style={{ marginTop: 14 }}>
                  {chapsOuverts.length > 1 && (
                    <div className="between" style={{ marginBottom: 6 }}>
                      <span className="eyebrow" style={{ color: "var(--accent)" }}>{nom}</span>
                      <span className="tag grey">{dessus.length}</span>
                    </div>
                  )}
                  {dessus.map((sj, k) => (
                <a key={k} className="tache" href={sj.url} target="_blank" rel="noreferrer"
                   style={{ textDecoration: "none", color: "inherit",
                            alignItems: "flex-start" }}>
                  <span className="pst">{sj.duree ? sj.duree + "′" : "bac"}</span>
                  <div style={{ flex: 1 }}>
                    <h4>{sj.titre}</h4>
                    <p className="small muted">{sj.session || "Labolycée"}</p>
                    {/* La consigne AVANT l'ouverture : un sujet mêle souvent
                        plusieurs chapitres, et l'élève doit savoir ce qu'il a
                        à traiter avant de s'y mettre, pas après. */}
                    {sj.consigne && (
                      <p className="small" style={{ marginTop: 6, color: "#7A5A12" }}>
                        {sj.consigne}
                      </p>
                    )}
                  </div>
                  <span className="tag">ouvrir</span>
                </a>
                  ))}
                </div>
              );
            })}
          </div>
        );
      })()}

      {/* Quand tout est fait, l'élève peut redemander du travail. C'est lui qui
          sait s'il en a encore sous le pied — et le coach doit le savoir aussi. */}
      {taches.length > 0 && taches.every((t) => t.statut !== "a_faire") && (
        <div className="card" style={{ borderColor: "#C9E7D9", background: "#FBFEFC" }}>
          <span className="eyebrow" style={{ color: "#1E6E52" }}>Séance terminée</span>
          <h3 style={{ marginTop: 8 }}>Tu veux continuer à t'exercer ?</h3>
          <p className="small muted" style={{ marginTop: 6 }}>
            Ce n'est pas au programme, et ça ne change rien à demain. Mais si tu as
            encore de l'énergie, autant s'en servir.
          </p>
          <div className="row" style={{ marginTop: 12, gap: 8 }}>
            <button className="btn btn-accent btn-sm"
              disabled={supplementsDuJour >= MAX_SUPPLEMENTS}
              onClick={() => encore("exo")}>
              Un exercice de plus
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => encore("flash")}>
              Des questions flash
            </button>
          </div>
        </div>
      )}

      {conseille && (
        <div className="card" style={{ borderColor: "#D6DEFB" }}>
          <div className="between">
            <span className="eyebrow">En plus, si vous voulez</span>
            <span className="tag">Conseille</span>
          </div>
          <h3 style={{ marginTop: 10 }}>{conseille.titre}</h3>
          <p className="small muted" style={{ marginTop: 4 }}>
            {conseille.chapNom} · {conseille.duree} min · vous l'aviez marque « {conseille.resultat} ».
            Ce n'est pas obligatoire, et ca ne remplace pas la seance de ce soir.
          </p>
          <div className="row" style={{ marginTop: 12 }}>
            <button className="btn btn-accent btn-sm" onClick={lancerConseille}>Le refaire maintenant</button>
            <button className="btn btn-ghost btn-sm" onClick={plusTard}>Plus tard</button>
          </div>
        </div>
      )}

      <div className="card dark">
        <div className="between">
          <span className="eyebrow">Le direct</span>
          {/* La pastille suit l'inscription À UN COURS, non plus à la semaine :
              elle restait grise alors que l'élève venait de s'inscrire. */}
          <span className={"tag " + (prochains.some((d) => estInscrit(d)) ? "green" : "gold")}>
            {inscrits.includes(semaine) ? "Inscrit cette semaine" : "Pas encore inscrit"}
          </span>
        </div>
        <p className="small muted" style={{ marginTop: 8 }}>
          En visio, en petit groupe. Une fois inscrit, la soiree est reservee dans votre planning.
        </p>
        {prochains.length === 0 && (
          <p className="small muted" style={{ marginTop: 10 }}>Aucun direct programme pour l'instant.</p>
        )}
        <div style={{ marginTop: 10 }}>
          {prochains.map((d) => {
            const inscrit = estInscrit(d);
            const qs = questionsDirect.filter((q) => q.semaine === d.semaine);
            return (
              <div key={d.semaine + "-" + d.jour} style={{ padding: "12px 0", borderTop: "1px solid var(--line)" }}>
                <div className="between">
                  <div style={{ flex: 1 }}>
                    <h4>{d.titre}</h4>
                    <p className="small muted">
                      {d.semaine === semaine ? "Cette semaine" : d.semaine === semaine + 1 ? "Semaine prochaine" : "Dans 2 semaines"}
                      {" - "}{JOURS[d.jour]} {d.heure} - {d.duree} min
                    </p>
                  </div>
                  <div className="row" style={{ gap: 8 }}>
                    {inscrit && d.semaine === semaine && d.jour === jour && <BoutonRejoindre lien={d.lien} />}
                    <button className={"btn btn-sm " + (inscrit ? "btn-ghost" : "btn-gold")} onClick={() => inscrire(d)}>
                      {inscrit ? "Annuler" : "Je m'inscris"}
                    </button>
                  </div>
                </div>
                {inscrit && (
                  <div style={{ marginTop: 10 }}>
                    {qs.map((q) => (
                      <p className="small" key={q.id} style={{ color: "#FFF", marginTop: 4 }}>
                        {q.txt} <span className="tag green">transmise</span>
                      </p>
                    ))}
                    {semQuestion === d.semaine ? (
                      <div className="composer">
                        <textarea rows={2} value={question} onChange={(e) => setQuestion(e.target.value)}
                          placeholder="Sur quoi voulez-vous qu'on s'arrete pendant le direct ?" />
                        <button className="btn btn-accent btn-sm"
                          onClick={() => { if (question.trim()) { poserQuestionDirect(d.semaine, question.trim()); setQuestion(""); setSemQuestion(null); } }}>
                          Envoyer
                        </button>
                      </div>
                    ) : (
                      <button className="btn btn-ghost btn-sm" style={{ marginTop: 8 }} onClick={() => { setSemQuestion(d.semaine); setQuestion(""); }}>
                        Poser une question a l'avance
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* LA CARTE « BLOQUÉ ? » EST MASQUÉE : elle ouvrait la permanence, que
          l'élève ne voit plus — les questions passent par Discord.
      <div className="card">
        <div className="between">
          <span className="eyebrow">Permanence</span>
          <span className={"tag " + (enAttente ? "gold" : "green")}>{enAttente ? enAttente + " en attente" : "à jour"}</span>
        </div>
        <h3 style={{ marginTop: 10 }}>Bloqué ?</h3>
        <p className="small muted" style={{ marginTop: 4 }}>Photo de la copie, question posée. Je réponds chaque jour.</p>
        <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 12 }} onClick={() => setOnglet("permanence")}>Ouvrir la permanence</button>
      </div>
      */}

    </div>
  );
}

/* ========================= MA SEMAINE ===================================== */

function MaSemaine({ taches, reglages, jour, semaine, ancreLe, chapitres, principaux, controle, journal, setRun, setDiag, setEval_, directs = [],
  inscrits = [], questionsDirect = [], poserQuestionDirect, aRattraper = null }) {
  /* Le cours DU JOUR s'il y en a un, sinon le premier de la semaine : plusieurs
     cours peuvent désormais être programmés sur une même semaine. */
  const directSemaine = directs.find((d) => d.semaine === semaine && d.jour === jour)
    || directs.find((d) => d.semaine === semaine) || null;
  const inscritDirect = inscrits.includes(semaine);
  const questionsSemaine = questionsDirect.filter((q) => q.semaine === semaine);
  const [ouvertQuestion, setOuvertQuestion] = useState(false);
  const [questionDirect, setQuestionDirect] = useState("");
  const [vue, setVue] = useState("planning");
  const total = taches.filter((t) => t.statut !== "manquee").reduce((a, t) => a + t.duree, 0);
  const principal = principaux[principaux.length - 1];
  const parts = partsSemaine(chapitres, reglages.joursOff);

  return (
    <div>
      <p className="eyebrow">{semaineEnClair(ancreLe, semaine)}</p>
      <h1 style={{ marginTop: 6, marginBottom: 16 }}>Ma semaine</h1>
      <div className="seg">
        <button className={vue === "planning" ? "on" : ""} onClick={() => setVue("planning")}>Planning</button>
        <button className={vue === "logique" ? "on" : ""} onClick={() => setVue("logique")}>Comment ça marche</button>
      </div>

      {vue === "planning" ? (
        <>
          <div className="card dark">
            <div className="between">
              <span className="eyebrow" style={{ color: "#8FA6F7" }}>Charge de la semaine</span>
              <span className="tag">{Math.floor(total / 60)} h {String(total % 60).padStart(2, "0")}</span>
            </div>
            <h2 style={{ marginTop: 10 }}>{principaux.length ? principaux.map((c) => CHAPITRES.find((x) => x.id === c.id).court).join(" · ") : "Aucun chapitre en cours"}</h2>
            <div style={{ marginTop: 10 }}>
              {principaux.map((c) => {
                /* TOUTES les séances de travail, comme côté coach : les
                   restitutions et l'épreuve blanche en font partie. N'en
                   compter que trois types affichait 10 là où le coach en
                   voyait 12, et l'élève ne s'y retrouvait pas. Le direct est
                   exclu des deux côtés : c'est un cours, pas une séance. */
                const seancesChap = taches.filter((t) => t.chapId === c.id
                  && t.type !== "direct");
                const faites = seancesChap.filter((t) => t.statut === "fait").length;

                return (
                  <p className="small" key={c.id} style={{ marginTop: 4 }}>
                    {CHAPITRES.find((x) => x.id === c.id).court} ·{" "}
                    {c.niveau
                      ? faites + "/" + seancesChap.length + " séances faites cette semaine"
                        + ((c.qtRatees || []).length
                            ? " · " + c.qtRatees.length + " geste(s) à reprendre"
                            : " · tous les gestes acquis au test")
                      : "test de positionnement à faire"}
                  </p>
                );
              })}
              {controle && (
                <p className="small" style={{ marginTop: 6 }}>
                  Contrôle {JOURS[controle.jour]}{controle.semaine > semaine ? " de la semaine prochaine" : ""} · épreuve de {controle.duree} min
                </p>
              )}
            </div>
          </div>

          <div className="card">
            {JOURS.map((nom, j) => {
              const tj = taches.filter((t) => t.jour === j && t.semaine === semaine);
              const off = reglages.joursOff.includes(j);
              return (
                <div className={"jour" + (off ? " off" : "")} key={j}>
                  <div className="row">
                    <span className="dl">{nom}</span>
                    {reglages.joursCours.includes(j) && <span className="tag green">Cours</span>}
                    {controle && controle.jour === j && controle.semaine === semaine && <span className="tag red">Contrôle</span>}
                    <span className="small muted">{off ? "Jour off" : tj.length ? tj.reduce((a, t) => a + t.duree, 0) + " min" : "Rien"}</span>
                    {j === jour && <span className="tag grey">Aujourd'hui</span>}
                  </div>
                  {tj.map((t) => (
                    <div className="row sub" key={t.id}>
                      <span className={"pst " + (t.cat === "chaud" ? "chaud" : t.cat === "rappel" ? "rappel" : t.cat === "controle" ? "controle" : t.cat === "restitution" ? "restitution" : t.cat === "direct" ? "direct" : "")}>{t.duree}′</span>
                      <div style={{ flex: 1 }}>
                        <div className="row" style={{ gap: 8 }}>
                          <h4 style={t.statut === "fait" ? { textDecoration: "line-through", opacity: .55 } : {}}>{t.libelle}</h4>
                          {(t.statut === "manquee" || t.statut === "abandonnee") && <span className="tag red">Non fait</span>}
                        </div>
                        {t.type === "direct" && inscritDirect && poserQuestionDirect && (
                          <div style={{ marginTop: 8 }}>
                            {questionsSemaine.map((q) => (
                              <p className="small" key={q.id} style={{ color: "#FFF", marginTop: 4 }}>
                                {q.txt} <span className="tag green">transmise</span>
                              </p>
                            ))}
                            {ouvertQuestion ? (
                              <div className="composer">
                                <textarea rows={2} value={questionDirect} onChange={(e) => setQuestionDirect(e.target.value)}
                                  placeholder="Sur quoi voulez-vous qu'on s'arrête pendant le direct ?" />
                                <button className="btn btn-accent btn-sm"
                                  onClick={() => {
                                    if (questionDirect.trim()) {
                                      poserQuestionDirect(semaine, questionDirect.trim());
                                      setQuestionDirect(""); setOuvertQuestion(false);
                                    }
                                  }}>
                                  Envoyer
                                </button>
                              </div>
                            ) : (
                              <button className="btn btn-ghost btn-sm" style={{ marginTop: 8 }}
                                onClick={() => { setOuvertQuestion(true); setQuestionDirect(""); }}>
                                {questionsSemaine.length ? "Poser une autre question" : "Poser une question à l'avance"}
                              </button>
                            )}
                          </div>
                        )}
                        <p className="small muted">{t.chapNom} · {t.motif}</p>
                      </div>
                      {t.type === "direct"
                        ? <BoutonRejoindre lien={directSemaine?.lien} />
                        : t.statut === "a_faire" && j === jour && (
                          /* Le test diagnostic passe AVANT un rattrapage : il
                             conditionne tout le chapitre, et sans lui le moteur
                             ignore le niveau de l'élève. Le bloquer derrière un
                             rattrapage laissait le chapitre en suspens, avec un
                             chapitre annoncé mais aucun moyen de le commencer. */
                          aRattraper && t.type !== "diagnostic"
                            ? <span className="tag gold">Après le rattrapage</span>
                            : <button className="btn btn-ghost btn-sm"
                                onClick={() => t.type === "diagnostic" ? setDiag(t.chapId) : t.type === "blanche" ? setEval_(t) : setRun(t)}>
                                Commencer
                              </button>
                        )}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </>
      ) : (
        <div className="card">
          <h3>La règle</h3>
          <ul className="small" style={{ marginTop: 12, paddingLeft: 18, display: "grid", gap: 10 }}>
            <li><b style={{ color: "var(--ink)" }}>Un soir, une tâche.</b> Deux seulement quand un contrôle approche.</li>
            <li><b style={{ color: "var(--ink)" }}>Le soir du cours</b>, c'est toujours la restitution à chaud. Nulle part ailleurs.</li>
            <li><b style={{ color: "var(--ink)" }}>Le test diagnostic</b> occupe seul la soirée où vous déclarez un nouveau chapitre. Il fixe le niveau des exercices — le nombre de soirs, lui, vient du temps que vous avez annoncé.</li>
            <li><b style={{ color: "var(--ink)" }}>L'exercice type bac</b> dure 30 min ou 1 h, jamais moins : il se place sur votre soir le plus long.</li>
            <li><b style={{ color: "var(--ink)" }}>Un contrôle</b> ajoute une révision chaque soir, sans supprimer le chapitre en cours. Évaluation blanche l'avant-veille.</li>
            <li><b style={{ color: "var(--ink)" }}>Une soirée sautée</b> est rattrapée une fois, dans les deux jours. Pas deux.</li>
          </ul>
        </div>
      )}
    </div>
  );
}

/* ========================= SESSION ======================================== */

/* ═══════════ LA MASCOTTE ═══════════════════════════════════════════════════
   Elle flotte en bas à droite pendant toute la séance et ouvre une
   conversation par-dessus l'écran. Elle guide, elle ne résout pas : tout passe
   par la fonction relais, qui porte la clé, décompte le crédit et filtre la
   réponse. L'écran n'autorise rien.

   Le solde est relu après chaque échange plutôt que décompté ici : si l'élève
   ouvre l'application sur deux appareils, les deux voient le même chiffre. */
/* LES FORMULES, RENDUES LISIBLES. Le robot écrit ses relations en LaTeX,
   entre $…$ pour une formule dans la phrase et $$…$$ pour une formule seule.
   Sans ce rendu, l'élève lirait « \\frac{\\ln 2}{k} » — illisible. */
function Formules({ texte }) {
  const morceaux = useMemo(() => {
    const out = [];
    const re = /\$\$([^$]+)\$\$|\$([^$\n]+)\$/g;
    let i = 0, m;
    while ((m = re.exec(texte || "")) !== null) {
      if (m.index > i) out.push({ t: texte.slice(i, m.index) });
      out.push({ f: (m[1] || m[2]).trim(), bloc: !!m[1] });
      i = m.index + m[0].length;
    }
    if (i < (texte || "").length) out.push({ t: texte.slice(i) });
    return out;
  }, [texte]);

  return (
    <>
      {morceaux.map((x, k) => {
        if (x.t !== undefined) return <span key={k}>{x.t}</span>;
        let html = "";
        try {
          html = katex.renderToString(x.f, {
            displayMode: x.bloc, throwOnError: false, output: "html",
          });
        } catch { return <span key={k}>{x.f}</span>; }
        return <span key={k} className={x.bloc ? "f-bloc" : "f-ligne"}
          dangerouslySetInnerHTML={{ __html: html }} />;
      })}
    </>
  );
}

function Mascotte({ tache, fiche }) {
  const [ouvert, setOuvert] = useState(false);
  const [appele, setAppele] = useState(false);
  const [echanges, setEchanges] = useState([]);
  const [saisie, setSaisie] = useState("");
  const [attente, setAttente] = useState(false);
  const [credits, setCredits] = useState(null);
  const [fini, setFini] = useState(null);
  const bas = useRef(null);

  useEffect(() => { if (ouvert && !credits) lireCredits().then(setCredits); },
    [ouvert, credits]);
  useEffect(() => {
    if (ouvert) bas.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [echanges, attente, ouvert]);

  /* L'envoi est séparé de la saisie : les puces « Question n » s'en servent
     aussi, sans passer par le champ de texte. */
  const envoyerTexte = async (q) => {
    if (!q || attente) return;
    setEchanges((e) => [...e, { role: "eleve", texte: q }]);
    setAttente(true);
    const r = await demanderAuRobot({
      chapitre: tache?.chapId, qt: tache?.qt,
      exoTitre: fiche?.titre || tache?.exoTitre,
      enonce: fiche?.enonce || "",
      historique: echanges, question: q,
    });
    setAttente(false);
    if (r?.epuise) {
      setFini({ epuise: true });
      setCredits((c) => ({ ...(c || {}), total: 0 }));
      return;
    }
    if (r?.erreur) {
      setEchanges((e) => [...e, { role: "robot", texte: r.erreur, ennui: true }]);
      return;
    }
    setEchanges((e) => [...e, { role: "robot", texte: r.reponse }]);
    if (r.restant != null) setCredits((c) => ({ ...(c || {}), total: r.restant }));
    if (r.fini) setFini({ tropLong: true });
  };

  const envoyer = () => { const q = saisie.trim(); setSaisie(""); envoyerTexte(q); };

  const reste = credits?.total ?? credits?.solde ?? null;

  return (
    <>
      {/* LA BULLE D'APPEL. Elle se montre une fois, puis ne revient plus : un
          élève qui a compris qu'on peut demander n'a pas besoin qu'on le lui
          répète chaque soir. */}
      {!ouvert && !appele && <div className="appel">Besoin d'aide&nbsp;?</div>}

      {/* LA PASTILLE. Toujours au même endroit, toujours à portée de pouce :
          en bas à droite, au-dessus de la barre d'onglets. */}
      <button className="mascotte"
        onClick={() => { setAppele(true); setOuvert((v) => !v); }}
        aria-label={ouvert ? "Fermer l'aide" : "Demander un coup de main"}>
        {ouvert ? <span className="mascotte-x">×</span>
                : <img src="/mascotte.png" alt="" />}

      </button>

      {ouvert && (
        <div className="bulle" role="dialog" aria-label="Un coup de main">
          <div className="bulle-tete">
            <span className="eyebrow">Un coup de main</span>
            {reste != null && (
              <span className={"tag " + (reste > 3 ? "grey" : "gold")}>
                {reste} question{reste > 1 ? "s" : ""}
              </span>
            )}
          </div>

          <div className="bulle-fil">
            {echanges.length === 0 && !fini && (
              <>
                <p className="small muted">
                  Je ne te donnerai pas la réponse — mais je t'emmène jusqu'à
                  elle, une étape à la fois. Sur quelle question veux-tu qu'on
                  commence&nbsp;?
                </p>
                {/* LES QUESTIONS DE L'ÉNONCÉ, à portée de pouce : l'élève
                    désigne la sienne au lieu de la décrire, et le robot part
                    tout de suite sur la bonne. */}
                <div className="chips" style={{ marginTop: 10 }}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button key={n} className="chip"
                      onClick={() => envoyerTexte(
                        "Guide-moi pas à pas sur la question " + n + ".")}>
                      Question {n}
                    </button>
                  ))}
                </div>
              </>
            )}
            {echanges.map((m, k) => (
              <p className={"bulle-m " + (m.role === "eleve" ? "moi" : "lui")}
                key={k} style={m.ennui ? { color: "#C0392B" } : undefined}>
                {m.role === "robot" && !m.ennui
                  ? <Formules texte={m.texte} /> : m.texte}
              </p>
            ))}
            {attente && <p className="small muted">Je réfléchis…</p>}
            {fini?.epuise && (
              <p className="small" style={{ color: "#7A5A12" }}>
                Tu n'as plus de questions pour aujourd'hui — elles reviennent
                demain. En attendant, reprends ta fiche sur ce geste.
              </p>
            )}
            {fini?.tropLong && (
              <p className="small" style={{ color: "#7A5A12" }}>
                On a fait le tour à deux. Envoie ta question à ton professeur.
              </p>
            )}
            <div ref={bas} />
          </div>

          {!fini && (
            <div className="bulle-pied">
              <input className="input" value={saisie}
                placeholder="Ce qui te bloque…"
                onChange={(e) => setSaisie(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") envoyer(); }} />
              <button className="btn btn-accent btn-sm"
                disabled={attente || !saisie.trim()} onClick={envoyer}>
                Envoyer
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
}

function Session({ tache, onFini, onQuit, biblio = {}, vus = [],
                   ressources = RESSOURCES_INIT, avecRobot = false }) {
  const estRestitution = tache.type === "restitution";
  const dureeChrono = estRestitution ? (tache.chrono || 15) : tache.duree;
  /* L'énoncé et le corrigé viennent de la fiche de l'exercice, déposée par le
     coach. Tant qu'ils manquent, les boutons restent inactifs et le disent. */
  const [liseuse, setLiseuse] = useState(null);
  /* L'EXERCICE A PU DISPARAÎTRE : une tâche posée avant un dépôt pointe vers
     un exercice qui n'existe plus, et la séance s'ouvrait sans énoncé. On le
     remplace alors par un autre du même chapitre, de préférence sur le même
     geste — le travail prévu reste le même. */
    const lotChap = (biblio[tache.chapId] || []).filter((e) => e.usage === "entrainement");
  /* LES SUJETS DE BAC ne sont pas dans la bibliothèque : ils viennent du
     fichier des annales, et leur adresse est recopiée dans la tâche au moment
     où elle est posée. Une tâche rejouée après un dépôt perd cette adresse —
     l'élève cliquait alors sur « Le trombone de Koenig » et n'avait pas
     d'énoncé. On retrouve le sujet par son identifiant, à défaut par son
     titre. */
  const sujetBac = tache.type === "bac" && !tache.url
    ? (SUJETS_BAC[tache.chapId] || []).find((s) => s.id === tache.exoId)
      || (SUJETS_BAC[tache.chapId] || []).find((s) => s.titre === tache.exoTitre)
      || null
    : null;
  /* LE RATTACHEMENT PAR TITRE avant tout repêchage. L'identifiant d'un
     exercice est engendré par la base : redéposer le chapitre le change, et la
     tâche posée avant le dépôt ne retrouvait plus rien. Le titre, lui, ne
     bouge pas — c'est le seul lien stable entre une tâche déjà posée et la
     bibliothèque d'aujourd'hui. Sans lui, l'élève ouvrait sa séance et
     tombait sur un exercice pris au hasard dans le chapitre, ou sur rien. */
  const duChap = biblio[tache.chapId] || [];
  const fiche = duChap.find((e) => e.id === tache.exoId)
    || (tache.exoRef ? duChap.find((e) => e.ref && e.ref === tache.exoRef) : null)
    || (tache.exoTitre ? duChap.find((e) => e.titre === tache.exoTitre) : null)
    || (tache.type === "exo" && lotChap.length
        ? (lotChap.find((e) => (e.qt || []).includes(tache.qt))
           || lotChap.find((e) => e.url) || lotChap[0])
        : null)
    || {};
  /* L'EXERCICE RÉELLEMENT SERVI est celui qui compte : la tâche gardait
     l'identifiant d'un exercice disparu, et les gestes ne se cochaient jamais
     — le rapprochement échouait faute de correspondance. */
  const exoServi = fiche.id || tache.exoId;
  /* L'adresse du sujet, reprise des annales quand la tâche l'a perdue. */
  const urlSujet = tache.url || sujetBac?.url || null;
  const consigneSujet = tache.consigne || sujetBac?.consigne || null;
  const sessionSujet = tache.session || sujetBac?.session || null;
  const lienEnonce = fiche.url || urlSujet || null;
  const lienCorrige = fiche.urlCorrige || tache.urlCorrige || null;
  const [etape, setEtape] = useState("chrono");       // chrono -> comparaison (restitution) / corrigé
  const [reste, setReste] = useState(dureeChrono * 60);
  const [actif, setActif] = useState(false);

  useEffect(() => {
    if (!actif || reste <= 0) return;
    const t = setInterval(() => setReste((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [actif, reste]);
  useEffect(() => { if (reste === 0 && estRestitution) setEtape("comparaison"); }, [reste, estRestitution]);

  const fini = reste === 0;
  const entete = (titre) => (
    <div className="between">
      <div>
        <p className="eyebrow">{tache.chapNom} · {tache.motif}</p>
        <h1 style={{ marginTop: 6 }}>{titre}</h1>
      </div>
      <button className="btn btn-ghost btn-sm" onClick={onQuit}>Quitter</button>
    </div>
  );
  /* Après une FEUILLE BLANCHE, on ne demande rien : l'élève vient d'écrire ce
     qu'il savait, il n'a pas à se noter lui-même. Le chrono terminé, le cours
     s'ouvre et un bouton l'y emmène — c'est la comparaison qui l'instruit. */
  const jugement = estRestitution ? (
    <div className="card">
      <h3>Ta feuille est faite</h3>
      <p className="small muted" style={{ marginTop: 6 }}>
        Le cours vient de s'ouvrir : compare ce que tu as écrit avec la fiche et
        les vidéos. C'est là que tu verras ce qui te manque.
      </p>
      <button className="btn btn-accent btn-block" style={{ marginTop: 14 }}
        onClick={() => onFini({ ...tache, exoId: exoServi }, "acquis", { versCours: tache.chapId })}>
        Consulter le cours
      </button>
    </div>
  ) : (
    <div className="card">
      <h3>Comment ça s'est passé ?</h3>
      <div className="row" style={{ marginTop: 12 }}>
        <button className="chip" onClick={() => onFini({ ...tache, exoId: exoServi }, "acquis")}>Acquis</button>
        <button className="chip" onClick={() => onFini({ ...tache, exoId: exoServi }, "hesitant")}>Hésitant</button>
        <button className="chip" onClick={() => onFini({ ...tache, exoId: exoServi }, "rate")}>Raté</button>
      </div>
      {/* Les NIVEAUX SONT ABANDONNÉS : les quinze exercices d'un chapitre sont
          servis à tous. Ce que l'élève déclare ici sert à cocher ses gestes et
          à faire revenir ce qu'il a raté, plus à changer de difficulté. */}
      <p className="small muted" style={{ marginTop: 12 }}>
        Ce que tu déclares coche le geste correspondant. Un exercice raté ou
        hésité revient plus tard, pour que tu le reprennes.
      </p>
    </div>
  );

  /* ---------- restitution feuille blanche ---------- */
  if (estRestitution) {
    /* LA FICHE EXPRESS accompagne la fiche complète : même déverrouillage,
       même écran — l'élève choisit selon le temps dont il dispose. */
    const fichesChap = [...(ressources[tache.chapId]?.fiches || []),
                        ...(ressources[tache.chapId]?.fichesExpress || [])];
    const videosChap = (ressources[tache.chapId]?.videos || []).filter((v) => v.type !== "Question type");

    if (etape === "chrono") {
      return (
        <div className="b"><style>{CSS}</style>
          <div className="wrapc">
            {entete("Feuille blanche")}
            <div className="card" style={{ marginTop: 16, textAlign: "center" }}>
              <span className="tag">{dureeChrono} min · cours fermé</span>
              <div className="timer" style={{ marginTop: 14 }}>{mmss(reste)}</div>
              <div className="bar" style={{ marginTop: 16 }}><i style={{ width: (1 - reste / (dureeChrono * 60)) * 100 + "%" }} /></div>
              <p className="small muted" style={{ maxWidth: "36ch", margin: "14px auto 0" }}>
                Une feuille, un stylo, rien d'autre. Écrivez tout ce dont vous vous souvenez du chapitre :
                définitions, relations, unités, méthode. À la fin du chronomètre, la fiche de révision et les
                vidéos se déverrouillent pour la comparaison.
              </p>
              {!actif
                ? <button className="btn btn-gold btn-block" style={{ marginTop: 18 }} onClick={() => setActif(true)}>Lancer le chronomètre</button>
                : <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 16 }} onClick={() => setReste(0)}>J'ai fini ma feuille</button>}
              <div className="lock" style={{ marginTop: 16 }}>
                <Icon d={I.lock} size={17} />Fiche de révision et vidéos verrouillées jusqu'à la fin.
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="b"><style>{CSS}</style>
        <div className="wrapc">
          {entete("Comparez votre feuille")}
          <div className="card" style={{ marginTop: 16 }}>
            <span className="tag green">Déverrouillé</span>
            <h3 style={{ marginTop: 10 }}>La fiche de révision du chapitre</h3>
            <p className="small muted" style={{ marginTop: 4 }}>
              Relisez-la ligne à ligne et surlignez sur votre feuille ce que vous aviez oublié.
            </p>
            {fichesChap.map((f, k) => (
              <div className="res" key={k}>
                <span className="ico"><Icon d={I.pdf} size={18} /></span>
                <div style={{ flex: 1 }}><h4>{f.titre}</h4><p className="small muted">{f.pages ? f.pages + " pages" : "PDF"}</p></div>
                {f.url
                  ? <a className="btn btn-ghost btn-sm" href={f.url} target="_blank" rel="noreferrer">Ouvrir</a>
                  : <button className="btn btn-ghost btn-sm" disabled>Ouvrir</button>}
              </div>
            ))}
            {!fichesChap.length && <p className="small muted" style={{ marginTop: 10 }}>Aucune fiche déposée pour ce chapitre.</p>}
          </div>

          <div className="card">
            <h3>Les vidéos du chapitre</h3>
            {videosChap.map((v, k) => (
              <div className="res" key={k}>
                <span className="ico"><Icon d={I.play} size={18} /></span>
                <div style={{ flex: 1 }}><h4>{v.titre}</h4><p className="small muted">{v.type}{v.duree ? " · " + v.duree : ""}</p></div>
                {v.url
                  ? <a className="btn btn-ghost btn-sm" href={v.url} target="_blank" rel="noreferrer">Voir</a>
                  : <button className="btn btn-ghost btn-sm" disabled>Voir</button>}
              </div>
            ))}
            {!videosChap.length && <p className="small muted" style={{ marginTop: 10 }}>Aucune vidéo déposée pour ce chapitre.</p>}
          </div>

          {/* La carte « l'exercice d'application vous attend » a été retirée :
              cet exercice n'est plus posé le soir de la déclaration, et
              annoncer une tâche qui n'existe pas égarait l'élève. */}

          {jugement}
        </div>
      </div>
    );
  }

  /* ---------- toutes les autres tâches ---------- */

  return (
    <div className="b"><style>{CSS}</style>
      {/* La liseuse recouvre la séance sans l'interrompre : le chronomètre
          tourne toujours derrière, et l'élève n'a pas quitté l'application. */}
      {liseuse && <Liseuse fichier={liseuse} onFermer={() => setLiseuse(null)} />}
      {/* LA MASCOTTE accompagne toute la séance : l'élève l'appelle pendant
          qu'il cherche, pas seulement au moment du verdict. */}
      {avecRobot && <Mascotte tache={tache} fiche={fiche} />}
      <div className="wrapc">
        {entete(tache.libelle)}
        {(tache.type === "exo" || tache.type === "bac") && (
          <div className="card" style={{ marginTop: 16 }}>
            <span className="eyebrow">
              {tache.conseille ? "Exercice conseille" : tache.type === "bac" ? "Sujet long" : "Exercice d'entrainement"}
            </span>
            {/* On se rabat sur l'exercice RÉELLEMENT SERVI : une tâche posée
                avant l'arrivée de la banque n'a pas de titre, mais « fiche »
                porte l'exercice de remplacement. Le message d'épuisement
                s'affichait alors qu'un exercice était bien là. */}
            {(tache.exoTitre || fiche.titre)
              ? <>
                  <h3 style={{ marginTop: 8 }}>{tache.exoTitre || fiche.titre}</h3>
                  <p className="small muted" style={{ marginTop: 4 }}>
                    {tache.duree} min
                    {sessionSujet ? " · " + sessionSujet : ""}
                    {(tache.points || sujetBac?.points)
                      ? " · " + (tache.points || sujetBac.points) + " points" : ""}
                  </p>
                  {/* La consigne délimite le travail : un sujet de bac mêle
                      souvent plusieurs chapitres, et l'élève doit savoir
                      exactement ce qu'il a à traiter. */}
                  {consigneSujet && (
                    <div className="card" style={{ marginTop: 10, background: "#FBF3E4",
                      borderColor: "#E8DCC0" }}>
                      <span className="eyebrow" style={{ color: "#7A5A12" }}>Ce que tu dois traiter</span>
                      <p className="small" style={{ marginTop: 6, color: "var(--ink)" }}>
                        {consigneSujet}
                      </p>
                    </div>
                  )}
                  {urlSujet && (
                    <>
                      {/* Ouvrir le sujet, c'est commencer à composer : le
                          chronomètre part au même instant, comme pour un
                          énoncé de la bibliothèque. */}
                      <button className="btn btn-accent btn-block" style={{ marginTop: 10 }}
                        onClick={() => { setActif(true); window.open(urlSujet, "_blank", "noopener"); }}>
                        Ouvrir le sujet sur Labolycée
                      </button>
                      <p className="small muted" style={{ marginTop: 8 }}>
                        Les {tache.duree} min annoncées sont le temps de <b>composition</b>.
                        Prends ensuite le temps de te corriger avec le corrigé de
                        Labolycée : cette relecture compte autant que le sujet.
                      </p>
                    </>
                  )}
                </>
              : <p className="small muted" style={{ marginTop: 8 }}>
                  La bibliotheque de ce chapitre est epuisee : tous les exercices disponibles ont deja ete
                  proposes. Signalez-le a votre coach dans la permanence.
                </p>}
          </div>
        )}

        <div className="card" style={{ marginTop: 16, textAlign: "center" }}>
          {/* Le niveau du SUJET, pas celui de l'élève : afficher « facile »
              au-dessus du chronomètre alors que le titre annonce « moyen »
              donnait deux réponses différentes à la même question. */}
          <span className="tag">
            {tache.duree} min
          </span>
          <div className="timer" style={{ marginTop: 14 }}>{mmss(reste)}</div>
          <div className="bar" style={{ marginTop: 16 }}><i style={{ width: (1 - reste / (dureeChrono * 60)) * 100 + "%" }} /></div>
          {/* Un sujet Labolycée n'a ni énoncé ni corrigé dans la bibliothèque :
              tout est sur le site, et le bouton d'ouverture plus haut lance déjà
              le chronomètre. Cet encadré n'aurait que des boutons morts. */}
          {!urlSujet && (
          <div className="row" style={{ marginTop: 16, justifyContent: "center" }}>
            <button className="btn btn-ghost btn-sm" disabled={!lienEnonce}
              onClick={() => {
                /* Lire l'énoncé, c'est avoir commencé : le chronomètre part tout
                   seul, sinon l'élève lit dix minutes hors du temps compté. */
                setActif(true);
                setLiseuse({ lien: lienEnonce, titre: tache.exoTitre || "Énoncé",
                  sous: tache.chapNom, nom: "enonce-" + (tache.exoId || "exercice") });
              }}>
              Ouvrir l'énoncé
            </button>
            <button className="btn btn-ghost btn-sm" disabled={!fini || !lienCorrige}
              onClick={() => setLiseuse({ lien: lienCorrige, titre: "Corrigé · " + (tache.exoTitre || ""),
                sous: tache.chapNom, nom: "corrige-" + (tache.exoId || "exercice") })}>
              {fini ? "Voir le corrigé" : "Corrigé verrouillé"}
            </button>
          </div>
          )}
          {/* Un bouton qui ne fait rien est pire qu'un bouton absent : on dit
              franchement quand le fichier n'a pas encore été déposé. */}
          {!urlSujet && !lienEnonce && (
            <p className="small muted" style={{ marginTop: 10, textAlign: "center" }}>
              L'énoncé de cet exercice n'a pas encore été déposé par le coach.
            </p>
          )}
          {!urlSujet && !fini && (
            <div className="lock"><Icon d={I.lock} size={17} />Le corrigé se débloque à la fin du chronomètre.</div>
          )}
          {!urlSujet && fini && lienEnonce && !lienCorrige && (
            <p className="small muted" style={{ marginTop: 10, textAlign: "center" }}>
              Le corrigé n'a pas encore été déposé.
            </p>
          )}
          {/* Ouvrir l'énoncé démarre déjà le chronomètre. Ce bouton ne sert
              qu'à celui qui n'a PAS d'énoncé à ouvrir — sur papier, ou pas
              encore déposé. Proposer de démarrer sans lire le sujet quand le
              sujet est là n'a aucun sens. */}
          {!actif && !fini && !urlSujet && !lienEnonce && (
            <button className="btn btn-accent btn-block" style={{ marginTop: 14 }}
              onClick={() => setActif(true)}>
              Démarrer
            </button>
          )}
          {actif && !fini && <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 12 }} onClick={() => setReste(0)}>Passer (démo)</button>}
        </div>
        {jugement}
      </div>
    </div>
  );
}
/* Chaque question renvoie à un endroit précis de la fiche : c'est ce qui permet
   à l'élève d'aller revoir, plutôt que de retenir une réponse isolée. */
const libelleSource = (s) => !s ? null
  : /^QT /.test(s) ? "la " + s
  : s === "socle" ? "le socle"
  : "la partie « " + s + " »";

/* Les figures sont servies depuis public/figures. Si l'une manque — en aperçu,
   ou avant dépôt — on la masque plutôt que d'afficher une image cassée. */
function Figure({ nom }) {
  const [absente, setAbsente] = useState(false);
  if (!nom || absente) return null;
  return (
    <img className="figure" src={adresseFigure(nom)} alt="" loading="lazy"
      onError={() => setAbsente(true)} />
  );
}

function Renvoi({ source, chapId, onOuvrir }) {
  if (!source) return null;
  const titre = (TITRES_QT[chapId] || {})[source];
  const Balise = onOuvrir ? "button" : "div";
  return (
    <Balise className={"renvoi" + (onOuvrir ? " cliquable" : "")}
      onClick={onOuvrir} type={onOuvrir ? "button" : undefined}>
      <span className="ico">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="17" height="17" aria-hidden="true">
          <path d="M5 4h10l4 4v12H5z" /><path d="M15 4v4h4" /><path d="M9 12h6M9 16h4" />
        </svg>
      </span>
      <span className="txt">
        <span className="ou">{source}</span>
        {titre && <b>{titre}</b>}
      </span>
      {onOuvrir && <span className="fin">›</span>}
    </Balise>
  );
}

/* La fenêtre de rappel : ce que l'élève doit avoir sur sa copie pour cette
   question type. Elle s'ouvre après la réponse, avant de passer à la suite. */
/* Le changement de niveau s'annonce : une progression invisible ne motive
   personne, et une redescente non expliquée décourage. */
/* La relance : un message pré-rédigé que le coach relit avant d'envoyer. Rien
   ne part sans qu'il l'ait vu — un message automatique sonnerait faux. */
function FenetreRelance({ relance, setRelance, onEnvoyer }) {
  return (
    <div className="voile" onClick={() => setRelance(null)}>
      <div className="feuille" onClick={(e) => e.stopPropagation()}>
        <div className="poignee" />
        <div className="between">
          <span className="eyebrow">Relancer · {relance.eleve}</span>
          <button className="btn btn-ghost btn-sm" onClick={() => setRelance(null)}>Fermer</button>
        </div>
        <p className="small muted" style={{ marginTop: 8 }}>{relance.alerte}</p>
        <textarea className="inp" style={{ width: "100%", minHeight: 150, marginTop: 12, resize: "vertical" }}
          value={relance.texte}
          onChange={(e) => setRelance({ ...relance, texte: e.target.value })} />
        <p className="small muted" style={{ marginTop: 8 }}>
          Le message part dans la permanence de l'élève. Relisez-le : un texte
          adapté à sa situation vaut mieux qu'une formule toute faite.
        </p>
        <button className="btn btn-gold btn-block" style={{ marginTop: 14 }}
          disabled={!relance.texte.trim()} onClick={onEnvoyer}>
          Envoyer la relance
        </button>
      </div>
    </div>
  );
}

/* La fenêtre de changement de niveau a été retirée avec les niveaux. */


/* Le bilan du test de positionnement : le score, puis un dépliant qui liste
   les gestes réussis et ceux à reprendre. C'est le seul rôle du test pour le
   contenu, il doit être lisible d'un coup d'œil. */
/* Les DATES RÉELLES du calendrier. L'application comptait en « semaine 5 · Mar »,
   ce qui ne parle ni à l'élève ni à ses parents : personne ne sait à quel jour
   cela correspond. L'ancre — le lundi de la semaine d'inscription — permet de
   retrouver la vraie date de chaque séance. */
const MOIS = ["janvier", "février", "mars", "avril", "mai", "juin",
              "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
const JOURS_LONGS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi",
                     "samedi", "dimanche"];

function dateDe(ancreLe, semaine, jour) {
  if (!ancreLe) return null;
  const d = new Date(ancreLe);
  if (Number.isNaN(d.getTime())) return null;
  d.setDate(d.getDate() + (semaine - 1) * 7 + jour);
  return d;
}

/* « mardi 6 octobre » — sans l'année, qui alourdit sans rien apprendre. */
function jourEnClair(ancreLe, semaine, jour, avecJour = true) {
  const d = dateDe(ancreLe, semaine, jour);
  if (!d) return null;
  return (avecJour ? JOURS_LONGS[jour] + " " : "") + d.getDate() + " " + MOIS[d.getMonth()];
}

/* « Semaine du 6 au 12 octobre », ou « du 29 septembre au 5 octobre » quand
   la semaine chevauche deux mois. */
function semaineEnClair(ancreLe, semaine) {
  const a = dateDe(ancreLe, semaine, 0), b = dateDe(ancreLe, semaine, 6);
  if (!a || !b) return "Semaine " + semaine;
  return a.getMonth() === b.getMonth()
    ? "Semaine du " + a.getDate() + " au " + b.getDate() + " " + MOIS[b.getMonth()]
    : "Semaine du " + a.getDate() + " " + MOIS[a.getMonth()]
      + " au " + b.getDate() + " " + MOIS[b.getMonth()];
}

function BilanTest({ c, restit }) {
  const [ouvert, setOuvert] = useState(false);
  const titres = TITRES_QT[c.id] || {};
  const tous = Object.keys(titres).filter((k) => k.startsWith("QT"));
  const ratees = c.qtRatees || [];
  const reussis = tous.filter((k) => !ratees.includes(k));
  return (
    <div style={{ marginTop: 6 }}>
      <button className="between" onClick={() => setOuvert((o) => !o)}
        style={{ width: "100%", background: "none", border: "none", padding: 0,
                 cursor: "pointer", font: "inherit", textAlign: "left" }}>
        <span className="small muted">
          Test {c.score}/{c.total}
          {ratees.length ? " · " + ratees.length + " geste" + (ratees.length > 1 ? "s" : "") + " à reprendre"
                         : " · tous les gestes acquis"}
          {" · feuilles blanches " + restit + "/" + RESTITUTIONS.length}
          {/* On dit ce que le dépliant contient : une flèche seule n'invite
              personne à l'ouvrir. */}
          <span style={{ color: "var(--accent)" }}>
            {" · " + (ouvert ? "masquer le détail" : "voir mes gestes ratés")}
          </span>
        </span>
        <span className="small" style={{ color: "var(--accent)", flex: "none",
          transform: ouvert ? "rotate(90deg)" : "none", transition: "transform .15s" }}>›</span>
      </button>
      {ouvert && (
        <div style={{ marginTop: 8, paddingLeft: 4 }}>
          {ratees.length > 0 && (
            <>
              <p className="small" style={{ color: "#7A5A12", marginBottom: 4 }}>À reprendre</p>
              {ratees.map((k) => (
                <div key={k} className="row" style={{ gap: 8, padding: "3px 0", alignItems: "flex-start" }}>
                  <span style={{ flex: "none", width: 16, height: 16, borderRadius: 4, marginTop: 2,
                    background: "#FBF3E4", color: "#7A5A12", fontSize: 10, fontWeight: 700,
                    display: "flex", alignItems: "center", justifyContent: "center" }}>!</span>
                  <span className="small" style={{ flex: 1 }}>{titres[k]}</span>
                </div>
              ))}
            </>
          )}
          {reussis.length > 0 && (
            <>
              <p className="small" style={{ color: "#1E6E52", marginTop: ratees.length ? 10 : 0, marginBottom: 4 }}>Acquis</p>
              {reussis.map((k) => (
                <div key={k} className="row" style={{ gap: 8, padding: "3px 0", alignItems: "flex-start" }}>
                  <span style={{ flex: "none", width: 16, height: 16, borderRadius: 4, marginTop: 2,
                    background: "#E4F5EE", color: "#1E6E52", fontSize: 10, fontWeight: 700,
                    display: "flex", alignItems: "center", justifyContent: "center" }}>✓</span>
                  <span className="small" style={{ flex: 1, color: "var(--ink-soft)" }}>{titres[k]}</span>
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
}

function FenetreFiche({ chapId, source, ressources, onFermer }) {
  const titre = (TITRES_QT[chapId] || {})[source];
  const rappel = (RAPPELS_QT[chapId] || {})[source] || [];
  const chap = CHAPITRES.find((c) => c.id === chapId);
  const fiche = ((ressources[chapId] || {}).fiches || []).find((f) => f.url);
  return (
    <div className="voile" onClick={onFermer}>
      <div className="feuille" onClick={(e) => e.stopPropagation()}>
        <div className="poignee" />
        <div className="between">
          <span className="eyebrow">{chap ? chap.nom : ""} · {source}</span>
          <button className="btn btn-ghost btn-sm" onClick={onFermer}>Fermer</button>
        </div>
        {titre && <h3 style={{ marginTop: 8 }}>{titre}</h3>}
        <p className="small muted" style={{ marginTop: 8 }}>Ce qu'on attend sur ta copie :</p>
        <ul className="rappel">
          {rappel.map((l, i) => <li key={i}>{l}</li>)}
        </ul>
        {fiche
          ? <a className="btn btn-gold btn-block" style={{ marginTop: 16 }}
              href={fiche.url} target="_blank" rel="noopener">Ouvrir la fiche complète</a>
          : <p className="small muted" style={{ marginTop: 14 }}>
              La fiche complète sera consultable ici dès que votre coach l'aura déposée.
            </p>}
      </div>
    </div>
  );
}

/* ========================= QUESTIONS FLASH ================================ */

function Flash({ tache, vus, onFini, onQuit, banques = BANQUES, ressources = {} }) {
  const [fiche, setFiche] = useState(null);
  /* LE NOMBRE DE QUESTIONS SUIT LA DURÉE : il était fixé à cinq, quelle que
     soit la séance — dix minutes pour cinq questions, c'est un temps mort. Le
     moteur calcule « nbQuestions » ; on s'en sert, avec un repli sur la durée
     si la tâche ne le porte pas. */
  const combien = tache.nbQuestions
    || Math.max(4, Math.round((tache.duree || 7) / 1.1));
  const [lot] = useState(() => questionsFlash(tache.chapId, vus, combien, banques));
  const [i, setI] = useState(0);
  const [choix, setChoix] = useState([]);        // indices cochés, ou ordre construit
  const [corr, setCorr] = useState(false);
  const [bons, setBons] = useState(0);
  const chap = CHAPITRES.find((c) => c.id === tache.chapId);

  if (!lot.length) {
    return (
      <div className="b"><style>{CSS}</style>
        <div className="wrapc">
          <div className="between">
            <div><p className="eyebrow">Questions flash</p><h1 style={{ marginTop: 6 }}>{chap.court}</h1></div>
            <button className="btn btn-ghost btn-sm" onClick={onQuit}>Quitter</button>
          </div>
          <div className="card" style={{ marginTop: 18 }}>
            <p className="small muted">
              La banque de questions de ce chapitre n'est pas encore en ligne. Signalez-le à votre coach
              dans la permanence — en attendant, cette séance compte comme faite.
            </p>
            <button className="btn btn-gold btn-block" style={{ marginTop: 14 }} onClick={() => onFini("acquis", [])}>
              J'ai compris
            </button>
          </div>
        </div>
      </div>
    );
  }

  const q = lot[i];
  const multiple = q.type_question === "choix_multiple";
  const ordre = q.type_question === "ordre";

  const juste = () => {
    if (ordre) return choix.length === q.options.length && choix.every((v, k) => v === q.bonne_reponse[k]);
    const a = [...choix].sort((x, y) => x - y), b = [...q.bonne_reponse].sort((x, y) => x - y);
    return a.length === b.length && a.every((v, k) => v === b[k]);
  };

  const basculer = (k) => {
    if (corr) return;
    if (ordre) setChoix(choix.includes(k) ? choix.filter((x) => x !== k) : [...choix, k]);
    else if (multiple) setChoix(choix.includes(k) ? choix.filter((x) => x !== k) : [...choix, k]);
    else setChoix([k]);
  };

  const suivante = () => {
    const n = bons + (juste() ? 1 : 0);
    setBons(n); setChoix([]); setCorr(false);
    if (i + 1 < lot.length) setI(i + 1);
    else onFini(n >= lot.length - 1 ? "acquis" : n >= lot.length / 2 ? "hesitant" : "rate",
                lot.map((x) => x.ref));
  };

  return (
    <div className="b"><style>{CSS}</style>
      <div className="wrapc">
        <div className="between">
          <div>
            <p className="eyebrow">Questions flash · {chap.court} · {q.source_qt}</p>
            <h1 style={{ marginTop: 6, fontSize: "1.3rem" }}>{i + 1} / {lot.length}</h1>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={onQuit}>Plus tard</button>
        </div>
        <div className="bar" style={{ marginTop: 16 }}><i style={{ width: (i / lot.length) * 100 + "%" }} /></div>

        <div className="card" style={{ marginTop: 16 }}>
          <h3 dangerouslySetInnerHTML={{ __html: q.enonce }} />
          <Figure nom={q.image} />
          <Renvoi source={q.source_qt} chapId={tache.chapId}
            onOuvrir={corr ? () => setFiche(q.source_qt) : null} />
          {ordre && <p className="small muted" style={{ marginTop: 8 }}>
            Touchez les étapes dans le bon ordre. Retouchez une étape pour la retirer.</p>}
          {multiple && <p className="small muted" style={{ marginTop: 8 }}>Plusieurs réponses attendues.</p>}

          {q.options.map((o, k) => {
            let cls = "opt" + (multiple || ordre ? " multi" : "");
            const rang = ordre ? choix.indexOf(k) : -1;
            if (corr) {
              const attendu = ordre ? q.bonne_reponse[rang] === k : q.bonne_reponse.includes(k);
              if (attendu) cls += " ok"; else if (choix.includes(k)) cls += " ko";
            } else if (choix.includes(k)) cls += " sel";
            return (
              <button key={k} className={cls} disabled={corr} onClick={() => basculer(k)}>
                <span className="k">{ordre ? (rang >= 0 ? rang + 1 : "·") : String.fromCharCode(65 + k)}</span>
                <span dangerouslySetInnerHTML={{ __html: o }} />
              </button>
            );
          })}

          {!corr ? (
            <button className="btn btn-accent btn-block" style={{ marginTop: 18 }}
              disabled={!choix.length || (ordre && choix.length < q.options.length)}
              onClick={() => setCorr(true)}>Valider</button>
          ) : (
            <>
              <p className="small" style={{ marginTop: 16, color: juste() ? "var(--green)" : "var(--red)" }}>
                {juste() ? "Bonne réponse." : "Ce n'est pas ça."}
              </p>
              <div className="card" style={{ marginTop: 12, background: "var(--surface-alt)" }}>
                <span className="eyebrow">Pourquoi</span>
                <p className="small" style={{ marginTop: 6, color: "var(--ink)" }}
                   dangerouslySetInnerHTML={{ __html: q.explication }} />
                {q.piege && (
                  <>
                    <span className="eyebrow" style={{ display: "block", marginTop: 12, color: "#7A5A12" }}>Le piège</span>
                    <p className="small" style={{ marginTop: 6 }} dangerouslySetInnerHTML={{ __html: q.piege }} />
                  </>
                )}
                {q.source_qt && (
                  <p className="revoir">
                    Pour revoir : {libelleSource(q.source_qt)} de ta fiche {chap.court.toLowerCase()}.
                  </p>
                )}
              </div>
              <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 12 }}
                onClick={() => setFiche(q.source_qt)}>
                Revoir la fiche avant de continuer
              </button>
              <button className="btn btn-gold btn-block" style={{ marginTop: 10 }} onClick={suivante}>
                {i + 1 < lot.length ? "Suivante" : "Terminer"}
              </button>
            </>
          )}
        </div>
      </div>
      {fiche && <FenetreFiche chapId={tache.chapId} source={fiche} ressources={ressources}
        onFermer={() => setFiche(null)} />}
    </div>
  );
}

/* ========================= DIAGNOSTIC ===================================== */

function Diagnostic({ chapId, onFini, onQuit, banques = BANQUES, ressources = {} }) {
  const [fiche, setFiche] = useState(null);
  /* La banque prime ; à défaut, les questions écrites à la main. */
  const questions = (diagnosticDepuisBanque(banques)[chapId] || QUESTIONS[chapId] || [])
    .map(normaliserQuestion);
  const chap = CHAPITRES.find((c) => c.id === chapId);
  const [i, setI] = useState(0);
  const [choix, setChoix] = useState([]);
  const [corr, setCorr] = useState(false);
  const [bons, setBons] = useState(0);

  /* Tant que le coach n'a pas déposé les questions du chapitre, l'élève se situe
     lui-même : c'est moins précis, mais ça vaut mieux que de bloquer sa rentrée. */
  if (!questions.length) {
    const paliers = [
      { t: "Je suis à l'aise sur ce chapitre", d: "J'ai suivi en cours, je vois comment démarrer les exercices", s: 8 },
      { t: "Moyen, j'ai des trous", d: "Je comprends la leçon, mais seul devant un exercice ça coince", s: 6 },
      { t: "Je suis perdu", d: "Même le cours n'est pas clair pour moi", s: 3 },
    ];
    return (
      <div className="b"><style>{CSS}</style>
        <div className="wrapc">
          <div className="between">
            <div>
              <p className="eyebrow">Situez-vous · obligatoire</p>
              <h1 style={{ marginTop: 6 }}>{chap.court}</h1>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={onQuit}>Plus tard</button>
          </div>
          <div className="card" style={{ marginTop: 18 }}>
            <p className="small muted">
              Le test de ce chapitre n'est pas encore en ligne. En attendant, dites-moi où vous en êtes :
              ça règle la difficulté de vos exercices et le nombre de soirs de la semaine.
              Vous pourrez le repasser quand il sera disponible.
            </p>
            {paliers.map((p) => (
              <button key={p.s} className="choix" onClick={() => onFini(p.s, 10)}>
                <span className="ico"><Icon d={I.book} size={18} /></span>
                <span className="lib">{p.t}<span className="small muted" style={{ display: "block", fontFamily: "var(--fb)", fontWeight: 400 }}>{p.d}</span></span>
                <span className="fin">›</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const q = questions[i];
  const ordre = q && q.type_question === "ordre";
  const multiple = q && q.type_question === "choix_multiple";

  const juste = () => {
    if (!q) return false;
    if (ordre) return choix.length === q.options.length && choix.every((v, k) => v === q.bonne_reponse[k]);
    const a = [...choix].sort((x, y) => x - y), b = [...q.bonne_reponse].sort((x, y) => x - y);
    return a.length === b.length && a.every((v, k) => v === b[k]);
  };

  const basculer = (k) => {
    if (corr) return;
    if (ordre || multiple) setChoix(choix.includes(k) ? choix.filter((x) => x !== k) : [...choix, k]);
    else setChoix([k]);
  };

  /* Les gestes RATÉS : c'est désormais le seul usage du test pour le contenu.
     Le moteur servira en priorité les exercices qui les travaillent. */
  const [ratees, setRatees] = useState([]);
  const suivant = (extra = {}) => {
    const ok = juste();
    const n = bons + (ok ? 1 : 0);
    const qt = questions[i]?.source_qt;
    const suite = !ok && qt && /^QT/.test(qt) && !ratees.includes(qt)
      ? [...ratees, qt] : ratees;
    setRatees(suite);
    setBons(n); setChoix([]); setCorr(false);
    if (i + 1 < questions.length) setI(i + 1);
    else onFini(n, questions.length, suite, extra);
  };

  return (
    <div className="b"><style>{CSS}</style>
      <div className="wrapc">
        <div className="between">
          <div>
            <p className="eyebrow">Test diagnostic · obligatoire</p>
            <h1 style={{ marginTop: 6 }}>{chap.court} — {i + 1}/{questions.length}</h1>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={onQuit}>Plus tard</button>
        </div>
        <div className="bar" style={{ marginTop: 16 }}><i style={{ width: (i / questions.length) * 100 + "%" }} /></div>
        <div className="card" style={{ marginTop: 16 }}>
          <h3 dangerouslySetInnerHTML={{ __html: q.enonce }} />
          <Figure nom={q.image} />
          <Renvoi source={q.source_qt} chapId={chapId}
            onOuvrir={corr ? () => setFiche(q.source_qt) : null} />
          {ordre && <p className="small muted" style={{ marginTop: 8 }}>
            Touchez les étapes dans le bon ordre.</p>}
          {multiple && <p className="small muted" style={{ marginTop: 8 }}>Plusieurs réponses attendues.</p>}
          {q.options.map((o, k) => {
            let cls = "opt" + (multiple || ordre ? " multi" : "");
            const rang = ordre ? choix.indexOf(k) : -1;
            if (corr) {
              const attendu = ordre ? q.bonne_reponse[rang] === k : q.bonne_reponse.includes(k);
              if (attendu) cls += " ok"; else if (choix.includes(k)) cls += " ko";
            } else if (choix.includes(k)) cls += " sel";
            return (
              <button key={k} className={cls} disabled={corr} onClick={() => basculer(k)}>
                <span className="k">{ordre ? (rang >= 0 ? rang + 1 : "·") : String.fromCharCode(65 + k)}</span>
                <span dangerouslySetInnerHTML={{ __html: o }} />
              </button>
            );
          })}
          {!corr ? (
            <button className="btn btn-accent btn-block" style={{ marginTop: 18 }}
              disabled={!choix.length || (ordre && choix.length < q.options.length)}
              onClick={() => setCorr(true)}>Valider</button>
          ) : (
            <>
              <p className="small" style={{ marginTop: 16, color: juste() ? "var(--green)" : "var(--red)" }}>
                {juste() ? "Bonne réponse." : "Ce n'est pas ça."}
              </p>
              {q.explication && (
                <p className="small" style={{ marginTop: 8, color: "var(--ink)" }}
                   dangerouslySetInnerHTML={{ __html: q.explication }} />
              )}
              {q.source_qt && (
                <p className="revoir">Pour revoir : {libelleSource(q.source_qt)} de ta fiche {chap.court.toLowerCase()}.</p>
              )}
              <button className="btn btn-gold btn-block" style={{ marginTop: 14 }} onClick={suivant}>
                {i + 1 < questions.length ? "Suivante" : "Voir mon programme"}
              </button>
              {/* Le test vient de déverrouiller le cours : on y emmène l'élève
                  directement, plutôt que de le laisser chercher l'onglet. */}
              {i + 1 === questions.length && (
                <button className="btn btn-ghost btn-block" style={{ marginTop: 8 }}
                  onClick={() => suivant({ versCours: chapId })}>
                  Voir le cours et la fiche
                </button>
              )}
            </>
          )}
        </div>
      </div>
      {fiche && <FenetreFiche chapId={chapId} source={fiche} ressources={ressources}
        onFermer={() => setFiche(null)} />}
    </div>
  );
}

/* ========================= ÉVALUATION BLANCHE ============================= */

function EvalBlanche({ tache, biblio, vus, chapitres, ressources = {}, onEnvoi, onQuit, onEntrainementLibre }) {
  /* La copie ne part pas tant qu'aucune photo n'est jointe : l'ancien bouton
     validait l'envoi sans rien envoyer, et le coach recevait une copie vide. */
  const champPhotos = useRef(null);
  const [photos, setPhotos] = useState([]);
  const ajouterPhotos = async (e) => {
    const fichiers = [...(e.target.files || [])];
    const lues = await Promise.all(fichiers.map(async (f) => ({
      nom: f.name, type: f.type, data: await versDataUrl(f),
    })));
    setPhotos((v) => [...v, ...lues]);
    e.target.value = "";
  };
  const chapEval = tache.chapitresEval || [tache.chapId];
  const diff = chapitres.find((c) => c.id === chapEval[0])?.difficulte || "moyen";
  const exos = useMemo(() => composerEvaluation(biblio, chapEval, tache.duree, diff, vus), [biblio, tache, vus]);

  /* L'ÉPREUVE DÉPOSÉE PAR LE COACH prime sur celle composée depuis les lots :
     ce sont ses propres évaluations, avec sa rédaction et son barème. Le
     corrigé se débloque à la fin du chronomètre, comme pour un exercice. */
  /* TOUS les chapitres évalués, pas seulement le premier : un contrôle porte
     souvent sur deux chapitres, et l'élève qui n'aurait qu'un sujet ne
     préparerait que la moitié de son épreuve. */
  const chapsEval = tache.chapitresEval && tache.chapitresEval.length
    ? tache.chapitresEval : [tache.chapId];
  /* On cherche d'abord une ÉPREUVE COMBINÉE qui couvre les chapitres évalués :
     c'est celle que le coach a préparée pour ce contrôle précis. À défaut, on
     sert les épreuves de chaque chapitre — mais l'élève est prévenu. */
  const toutes = chapsEval.flatMap((cid) =>
    ((ressources[cid] || {}).epreuves || []).map((e) => ({ ...e, chapId: cid,
      chapNom: CHAPITRES.find((x) => x.id === cid)?.nom || cid })));
  const couvre = (e) => (e.chapitres || [e.chapId])
    .filter((x) => chapsEval.includes(x)).length;
  const combinee = chapsEval.length > 1
    ? toutes.filter((e) => (e.chapitres || []).length > 1)
        .sort((a, b) => couvre(b) - couvre(a))[0]
    : null;
  /* Un contrôle sur UN chapitre ne reçoit pas une épreuve combinée : elle
     porterait sur des notions qui ne sont pas évaluées. */
  const epreuvesCoach = combinee ? [combinee]
    : [...new Map(toutes
        .filter((e) => chapsEval.length > 1 || (e.chapitres || [e.chapId]).length === 1)
        .map((e) => [e.id, e])).values()];
  const corrigesCoach = chapsEval.flatMap((cid) =>
    ((ressources[cid] || {}).corriges || []).map((e) => ({ ...e, chapId: cid,
      chapNom: CHAPITRES.find((x) => x.id === cid)?.nom || cid })));
  const epreuveCoach = epreuvesCoach[0] || null;
  const corrigeCoach = corrigesCoach[0] || null;
  const [etape, setEtape] = useState("avant");     // avant | epreuve | apres
  const [reste, setReste] = useState(tache.duree * 60);

  useEffect(() => {
    if (etape !== "epreuve" || reste <= 0) return;
    const t = setInterval(() => setReste((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [etape, reste]);
  useEffect(() => { if (reste === 0 && etape === "epreuve") setEtape("apres"); }, [reste, etape]);

  return (
    <div className="b"><style>{CSS}</style>
      <div className="wrapc">
        <div className="between">
          <div>
            <p className="eyebrow">À deux jours du contrôle</p>
            <h1 style={{ marginTop: 6 }}>Évaluation blanche</h1>
          </div>
          {etape !== "epreuve" && <button className="btn btn-ghost btn-sm" onClick={onQuit}>Quitter</button>}
        </div>

        {etape === "avant" && (
          <div className="card" style={{ marginTop: 16 }}>
            <h3>{tache.duree} minutes, en conditions réelles</h3>
            <p className="small muted" style={{ marginTop: 6 }}>
              Le chronomètre démarre au moment où l'énoncé s'affiche. Le corrigé reste verrouillé jusqu'à la fin.
              À la fin, l'envoi de votre copie est obligatoire.
            </p>
            {/* L'épreuve déposée par le coach prime : cet écran annonçait
                encore une composition depuis la bibliothèque, et le bouton
                restait grisé faute d'exercices — alors qu'un PDF était là. */}
            <div style={{ marginTop: 14 }}>
              {epreuvesCoach.length ? (
                <>
                  <h4>{epreuvesCoach.length > 1
                    ? "Les épreuves de ton coach" : "L'épreuve de ton coach"}</h4>
                  {epreuvesCoach.map((e) => (
                    <div className="res" key={e.id}>
                      <span className="ico"><Icon d={I.pdf} size={18} /></span>
                      <div style={{ flex: 1 }}>
                        <h4>{e.titre}</h4>
                        <p className="small muted">
                          {chapsEval.length > 1 ? e.chapNom + " · " : ""}
                          déposée par ton coach
                        </p>
                      </div>
                    </div>
                  ))}
                  <p className="small muted" style={{ marginTop: 8 }}>
                    {tache.duree} min au total pour {epreuvesCoach.length > 1
                      ? "ces " + epreuvesCoach.length + " sujets" : "ce sujet"}.
                  </p>
                  {/* Sans épreuve combinée, l'élève doit savoir que le sujet ne
                      couvre pas tout son contrôle — sinon il se croira prêt. */}
                  {chapsEval.length > 1 && !combinee && (
                    <p className="small" style={{ marginTop: 8, color: "#7A5A12" }}>
                      Ton contrôle porte sur {chapsEval.length} chapitres.
                      Ton coach n'a pas encore préparé d'épreuve qui les couvre
                      tous — révise les autres avec tes fiches.
                    </p>
                  )}
                </>
              ) : (
                <>
                  <h4>Composée pour vous depuis la bibliothèque</h4>
                  {exos.map((e) => (
                    <div className="res" key={e.id}>
                      <span className="ico"><Icon d={I.pdf} size={18} /></span>
                      <div style={{ flex: 1 }}><h4>{e.titre}</h4><p className="small muted">{e.duree} min</p></div>
                    </div>
                  ))}
                  {!exos.length && <p className="small muted">Bibliothèque insuffisante : ajoutez des exercices dans l'espace coach.</p>}
                </>
              )}
            </div>
            <button className="btn btn-gold btn-block" style={{ marginTop: 16 }}
              disabled={!epreuvesCoach.length && !exos.length}
              onClick={() => {
                setEtape("epreuve");
                /* Ouvrir les énoncés, c'est commencer : ils s'affichent au même
                   instant que le chronomètre démarre. */
                epreuvesCoach.forEach((e) => e.url && window.open(e.url, "_blank", "noopener"));
              }}>
              Découvrir l'énoncé et démarrer
            </button>
          </div>
        )}

        {etape === "epreuve" && (
          <div className="card" style={{ marginTop: 16, textAlign: "center" }}>
            <span className="tag red">Épreuve en cours</span>
            <div className="timer" style={{ marginTop: 14 }}>{mmss(reste)}</div>
            <div className="bar" style={{ marginTop: 16 }}><i style={{ width: (1 - reste / (tache.duree * 60)) * 100 + "%" }} /></div>
            <div style={{ marginTop: 18, textAlign: "left" }}>
              {epreuvesCoach.length ? epreuvesCoach.map((e) => (
                <div className="res" key={e.id}>
                  <span className="ico"><Icon d={I.pdf} size={18} /></span>
                  <div style={{ flex: 1 }}>
                    <h4>{e.titre}</h4>
                    <p className="small muted">
                      {chapsEval.length > 1 ? e.chapNom : "déposée par ton coach"}
                    </p>
                  </div>
                  <button className="btn btn-accent btn-sm"
                    onClick={() => e.url && window.open(e.url, "_blank", "noopener")}>
                    Ouvrir
                  </button>
                </div>
              )) : exos.map((e) => (
                <div className="res" key={e.id}>
                  <span className="ico"><Icon d={I.pdf} size={18} /></span>
                  <div style={{ flex: 1 }}><h4>{e.titre}</h4><p className="small muted">{e.duree} min</p></div>
                  <button className="btn btn-ghost btn-sm">Énoncé</button>
                </div>
              ))}
            </div>
            <div className="lock"><Icon d={I.lock} size={17} />Corrigé verrouillé jusqu'à la fin du chronomètre.</div>
            <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 12 }} onClick={() => setReste(0)}>Terminer maintenant</button>
          </div>
        )}

        {etape === "apres" && (
          <>
            <div className="card" style={{ marginTop: 16 }}>
              <h3>Corrigé déverrouillé</h3>
              {/* Le corrigé du coach, s'il l'a déposé. Sinon ceux des exercices
                  composés depuis la bibliothèque. */}
              {epreuvesCoach.length ? (
                corrigesCoach.length ? corrigesCoach.map((c) => (
                  <div className="res" key={c.id}>
                    <span className="ico"><Icon d={I.pdf} size={18} /></span>
                    <div style={{ flex: 1 }}>
                      <h4>{c.titre}</h4>
                      <p className="small muted">
                        {chapsEval.length > 1 ? c.chapNom : "Corrigé de ton coach"}
                      </p>
                    </div>
                    <button className="btn btn-accent btn-sm"
                      onClick={() => c.url && window.open(c.url, "_blank", "noopener")}>
                      Ouvrir
                    </button>
                  </div>
                )) : (
                  <p className="small muted" style={{ marginTop: 6 }}>
                    Ton coach n'a pas encore déposé le corrigé de cette épreuve.
                  </p>
                )
              ) : exos.map((e) => (
                <div className="res" key={e.id}>
                  <span className="ico"><Icon d={I.pdf} size={18} /></span>
                  <div style={{ flex: 1 }}><h4>{e.titre}</h4><p className="small muted">Corrigé disponible</p></div>
                  <button className="btn btn-ghost btn-sm">Ouvrir</button>
                </div>
              ))}
            </div>
            {/* L'ENTRAÎNEMENT LIBRE : une seconde épreuve, que l'élève fait
                pour lui. Elle ne se rend pas — il posera ses questions en visio
                ou en permanence — mais son coach saura qu'il l'a faite. */}
            {(() => {
              const libre = ((ressources[chapsEval[0]] || {}).libres || [])[0];
              if (!libre) return null;
              return (
                <div className="card" style={{ marginTop: 12 }}>
                  <span className="eyebrow">Pour aller plus loin</span>
                  <h3 style={{ marginTop: 8 }}>Un second sujet, rien que pour toi</h3>
                  <p className="small muted" style={{ marginTop: 4 }}>
                    Celui-ci ne se rend pas : tu le fais seul, dans les mêmes
                    conditions, et tu poses tes questions en direct ou en
                    permanence. Ton coach saura que tu l'as fait.
                  </p>
                  <div className="res" style={{ marginTop: 10 }}>
                    <span className="ico"><Icon d={I.pdf} size={18} /></span>
                    <div style={{ flex: 1 }}>
                      <h4>{libre.titre}</h4>
                      <p className="small muted">2 h · sans rendu</p>
                    </div>
                  </div>
                  <button className="btn btn-ghost btn-block" style={{ marginTop: 10 }}
                    onClick={() => {
                      if (libre.url) window.open(libre.url, "_blank", "noopener");
                      if (onEntrainementLibre) onEntrainementLibre(chapsEval[0], libre.titre);
                    }}>
                    Faire cet entraînement
                  </button>
                </div>
              );
            })()}

            <div className="card" style={{ borderColor: "#E4D3AC", background: "#FDF8EE" }}>
              <h3>Envoyez votre copie</h3>
              <p className="small" style={{ marginTop: 6 }}>
                Obligatoire. Sans copie, l'évaluation reste en attente et le coach est notifié.
                Sa correction et ses conseils deviennent votre tâche de demain.
              </p>

              {/* Une copie fait souvent plusieurs pages : on accepte plusieurs
                  photos, on les montre, et on peut en retirer une avant l'envoi. */}
              <input ref={champPhotos} type="file" accept="image/*,application/pdf" multiple
                style={{ display: "none" }} onChange={ajouterPhotos} />

              {photos.length > 0 && (
                <div style={{ marginTop: 12 }}>
                  {photos.map((ph, k) => (
                    <div className="res" key={k}>
                      <span className="ico"><Icon d={I.pdf} size={18} /></span>
                      <div style={{ flex: 1 }}>
                        <h4>Page {k + 1}</h4>
                        <p className="small muted">{ph.nom}</p>
                      </div>
                      <button className="btn btn-ghost btn-sm"
                        onClick={() => setPhotos((v) => v.filter((_, i) => i !== k))}>Retirer</button>
                    </div>
                  ))}
                </div>
              )}

              <button className="btn btn-ghost btn-block" style={{ marginTop: 12 }}
                onClick={() => champPhotos.current && champPhotos.current.click()}>
                {photos.length ? "Ajouter une page" : "Photographier ma copie"}
              </button>

              <button className="btn btn-gold btn-block" style={{ marginTop: 10 }}
                /* On transmet L'ÉPREUVE RÉELLEMENT COMPOSÉE : celle du coach
                   quand il en a déposé une, les exercices sinon. Envoyer les
                   exercices dans tous les cas donnait à la copie le titre d'un
                   sujet que l'élève n'avait jamais vu. */
                disabled={!photos.length}
                onClick={() => onEnvoi(epreuvesCoach.length
                  ? epreuvesCoach.map((e) => ({ id: e.id, titre: e.titre,
                      chapId: e.chapId, duree: tache.duree }))
                  : exos, photos, { chapitres: chapsEval })}>
                {photos.length
                  ? "Envoyer ma copie · " + photos.length + " page" + (photos.length > 1 ? "s" : "")
                  : "Ajoutez au moins une photo"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ========================= PERMANENCE ===================================== */

/* ---- Enregistreur de messages vocaux ----
   Deux minutes maximum : au-dela, un vocal devient un monologue que personne
   ne reecoute, et la reponse du coach prend dix fois plus de temps.          */
const DUREE_VOCAL_MAX = 120;

function mimeAudioSupporte() {
  if (typeof MediaRecorder === "undefined") return null;
  const candidats = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/aac"];
  return candidats.find((m) => MediaRecorder.isTypeSupported(m)) || "";
}

function Enregistreur({ onEnvoyer, compact = false, max = DUREE_VOCAL_MAX, libelle = "Enregistrer un vocal" }) {
  const [etat, setEtat] = useState("pret");        // pret | enregistrement | pret_a_envoyer
  const [secondes, setSecondes] = useState(0);
  const [apercu, setApercu] = useState(null);       // { url, blob, duree }
  const [erreur, setErreur] = useState("");
  const recorder = useRef(null);
  const morceaux = useRef([]);
  const flux = useRef(null);

  useEffect(() => {
    if (etat !== "enregistrement") return;
    const t = setInterval(() => setSecondes((s) => {
      if (s + 1 >= max) { arreter(); return max; }
      return s + 1;
    }), 1000);
    return () => clearInterval(t);
  }, [etat]);

  const demarrer = async () => {
    setErreur("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      flux.current = stream;
      const mime = mimeAudioSupporte();
      const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      morceaux.current = [];
      mr.ondataavailable = (e) => { if (e.data.size) morceaux.current.push(e.data); };
      mr.onstop = async () => {
        const blob = new Blob(morceaux.current, { type: mr.mimeType || "audio/webm" });
        setApercu({ url: await versDataUrl(blob), blob, duree: secondes });
        setEtat("pret_a_envoyer");
        flux.current?.getTracks().forEach((p) => p.stop());
      };
      recorder.current = mr;
      mr.start();
      setSecondes(0);
      setEtat("enregistrement");
    } catch (e) {
      setErreur("Micro inaccessible. Autorisez le microphone dans les reglages du navigateur.");
    }
  };

  const arreter = () => { try { recorder.current?.stop(); } catch (e) {} };

  const annuler = () => { setApercu(null); setSecondes(0); setEtat("pret"); };

  const envoyer = async () => {
    if (!apercu) return;
    await onEnvoyer(apercu.blob, apercu.duree || secondes);
    annuler();
  };

  const chrono = (s) => Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");

  if (etat === "enregistrement") {
    return (
      <div className="card" style={{ marginTop: 12, borderColor: "#F3D6D3", background: "#FDF6F5" }}>
        <div className="row">
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#E0685F" }} />
          <b style={{ fontFamily: "var(--fm)", color: "var(--ink)" }}>{chrono(secondes)}</b>
          <span className="small muted">enregistrement en cours · {Math.round(max / 60)} min maximum</span>
        </div>
        <button className="btn btn-accent btn-sm btn-block" style={{ marginTop: 12 }} onClick={arreter}>
          Arreter
        </button>
      </div>
    );
  }

  if (etat === "pret_a_envoyer") {
    return (
      <div className="card" style={{ marginTop: 12 }}>
        <span className="eyebrow">Votre vocal · {chrono(apercu?.duree || secondes)}</span>
        <audio controls src={apercu?.url} style={{ width: "100%", marginTop: 10 }} />
        <div className="row" style={{ marginTop: 12 }}>
          {/* Le vocal rejoint le message, il ne part pas seul. */}
          <button className="btn btn-gold btn-sm" onClick={envoyer}>Joindre le vocal</button>
          <button className="btn btn-ghost btn-sm" onClick={annuler}>Recommencer</button>
        </div>
      </div>
    );
  }

  return (
    <>
      <button className={"btn btn-ghost " + (compact ? "btn-sm" : "btn-sm btn-block")} style={{ marginTop: compact ? 8 : 10 }} onClick={demarrer}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" width="17" height="17" aria-hidden="true">
          <rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
        </svg>
        {libelle}
      </button>
      {erreur && <p className="small" style={{ color: "var(--red)", marginTop: 8 }}>{erreur}</p>}
    </>
  );
}

/* ---- Photo de la copie ou PDF ----
   Les photos prises au telephone pesent 3 a 5 Mo : on les redimensionne avant
   l'envoi, sinon le stockage grossit pour rien et le coach attend le chargement. */
const TAILLE_MAX = 10 * 1024 * 1024;

/* Les URL "blob:" sont bloquees par certains cadres d'apercu et par des CSP
   strictes : l'image ne s'affiche alors jamais. Une URL "data:" fonctionne
   partout, au prix d'un peu de memoire — acceptable puisque les photos sont
   deja compressees a ~400 Ko. */
/* ============================================================================
   ASSEMBLER UNE COPIE EN PDF
   Le coach annote bien plus vite dans une application de PDF, sur tablette,
   qu'en regardant les photos une par une à l'écran. On fabrique donc le
   fichier ici, sans aucune bibliothèque : chaque photo est redessinée dans un
   canevas, exportée en JPEG, puis insérée telle quelle dans un PDF minimal.
   Passer par le canevas normalise tous les formats — un PNG deviendrait
   illisible avec le filtre DCTDecode, qui n'accepte que du JPEG.
   ========================================================================== */
function chargerImage(src) {
  return new Promise((ok, ko) => {
    const im = new Image();
    im.onload = () => ok(im);
    im.onerror = () => ko(new Error("image illisible"));
    im.src = src;
  });
}

async function copieEnPdf(photos, nomFichier) {
  const LARGEUR_MAX = 1400;                  // au-delà, le fichier gonfle pour rien
  const pages = [];
  for (const ph of photos) {
    if (!String(ph.type || "").startsWith("image")) continue;
    const im = await chargerImage(ph.data);
    const ech = Math.min(1, LARGEUR_MAX / im.naturalWidth);
    const c = document.createElement("canvas");
    c.width = Math.round(im.naturalWidth * ech);
    c.height = Math.round(im.naturalHeight * ech);
    c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
    const b64 = c.toDataURL("image/jpeg", 0.85).split(",")[1];
    const bin = atob(b64);
    const octets = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) octets[i] = bin.charCodeAt(i);
    pages.push({ octets, l: c.width, h: c.height });
  }
  if (!pages.length) return false;

  /* Construction du fichier. Les décalages doivent être exacts au caractère
     près : on assemble donc des morceaux et l'on compte les octets au fur et
     à mesure, plutôt que de concaténer des chaînes. */
  const enc = new TextEncoder();
  const morceaux = [];
  let taille = 0;
  const ecrire = (x) => {
    const o = typeof x === "string" ? enc.encode(x) : x;
    morceaux.push(o); taille += o.length; return taille;
  };
  const offsets = [];
  const objet = (n, contenu, flux) => {
    offsets[n] = taille;
    ecrire(n + " 0 obj\n" + contenu + "\n");
    if (flux) { ecrire("stream\n"); ecrire(flux); ecrire("\nendstream\n"); }
    ecrire("endobj\n");
  };

  ecrire("%PDF-1.4\n");
  const nPages = pages.length;
  const idsPages = pages.map((_, i) => 3 + i * 3);
  objet(1, "<< /Type /Catalog /Pages 2 0 R >>");
  objet(2, "<< /Type /Pages /Kids [" + idsPages.map((n) => n + " 0 R").join(" ")
    + "] /Count " + nPages + " >>");

  pages.forEach((pg, i) => {
    const idPage = 3 + i * 3, idFlux = idPage + 1, idImage = idPage + 2;
    objet(idPage, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + pg.l + " " + pg.h + "]"
      + " /Resources << /XObject << /Im0 " + idImage + " 0 R >> >>"
      + " /Contents " + idFlux + " 0 R >>");
    const dessin = "q " + pg.l + " 0 0 " + pg.h + " 0 0 cm /Im0 Do Q";
    objet(idFlux, "<< /Length " + dessin.length + " >>", enc.encode(dessin));
    objet(idImage, "<< /Type /XObject /Subtype /Image /Width " + pg.l
      + " /Height " + pg.h + " /ColorSpace /DeviceRGB /BitsPerComponent 8"
      + " /Filter /DCTDecode /Length " + pg.octets.length + " >>", pg.octets);
  });

  const debutXref = taille;
  const dernier = 2 + nPages * 3;
  let xref = "xref\n0 " + (dernier + 1) + "\n0000000000 65535 f \n";
  for (let n = 1; n <= dernier; n++)
    xref += String(offsets[n] || 0).padStart(10, "0") + " 00000 n \n";
  ecrire(xref);
  ecrire("trailer\n<< /Size " + (dernier + 1) + " /Root 1 0 R >>\nstartxref\n"
    + debutXref + "\n%%EOF\n");

  const total = new Uint8Array(taille);
  let pos = 0;
  morceaux.forEach((m) => { total.set(m, pos); pos += m.length; });
  const url = URL.createObjectURL(new Blob([total], { type: "application/pdf" }));
  const a = document.createElement("a");
  a.href = url; a.download = nomFichier;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return true;
}

/* Ouvrir un fichier, qu'il vienne d'un lien ou d'un dépôt.
   Un PDF déposé depuis le téléphone est stocké en « data:…base64 », et les
   navigateurs REFUSENT d'ouvrir une telle adresse dans un nouvel onglet — par
   sécurité. Le bouton semblait alors cassé. On repasse donc par un objet Blob,
   dont l'adresse temporaire, elle, est acceptée. */
/* ============================================================================
   LA LISEUSE
   On lit l'énoncé SANS quitter la séance, chronomètre visible. Les navigateurs
   mobiles — en particulier celui intégré à iOS — refusent d'afficher un PDF
   dans un cadre de page : on dessine donc chaque page nous-mêmes, dans un
   canevas, à l'aide de pdf.js chargé à la demande. C'est le seul moyen d'avoir
   un rendu identique sur tous les appareils.
   ========================================================================== */
/* pdf.js est livré AVEC le site, dans public/pdfjs : pas de dépendance à un
   service extérieur, rien à charger depuis un tiers, et la liseuse fonctionne
   même sur un réseau d'établissement filtré. Le CDN ne sert que de secours,
   notamment pour l'aperçu de démonstration qui n'a pas nos fichiers. */
const PDFJS_SOURCES = [
  "/pdfjs",
  "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174",
];

function chargerScript(url) {
  return new Promise((ok, ko) => {
    const s = document.createElement("script");
    s.src = url;
    s.onload = ok;
    s.onerror = () => ko(new Error(url));
    document.head.appendChild(s);
  });
}

function chargerPdfjs() {
  if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
  if (window.__pdfjsAttente) return window.__pdfjsAttente;
  window.__pdfjsAttente = (async () => {
    for (const base of PDFJS_SOURCES) {
      try {
        await chargerScript(base + "/pdf.min.js");
        if (!window.pdfjsLib) continue;
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = base + "/pdf.worker.min.js";
        return window.pdfjsLib;
      } catch (e) { /* source suivante */ }
    }
    throw new Error("pdf.js indisponible");
  })();
  return window.__pdfjsAttente;
}

/* L'adresse d'une figure : l'espace public de Supabase si la base est branchée,
   le dossier local sinon. */
function adresseFigure(nom) {
  return "/figures/" + nom;
}

function Liseuse({ fichier, onFermer }) {
  const zone = useRef(null);
  const [etat, setEtat] = useState("chargement");   // chargement · pret · erreur
  const [pages, setPages] = useState(0);

  useEffect(() => {
    if (!fichier || !fichier.lien) return;
    let annule = false;

    (async () => {
      try {
        const pdfjs = await chargerPdfjs();
        if (annule) return;
        /* Le document vient soit d'un lien, soit d'un dépôt en base64. */
        const source = /^data:/.test(fichier.lien)
          ? { data: (() => {
              const bin = atob(fichier.lien.split(",")[1]);
              const o = new Uint8Array(bin.length);
              for (let i = 0; i < bin.length; i++) o[i] = bin.charCodeAt(i);
              return o;
            })() }
          : { url: fichier.lien };
        const doc = await pdfjs.getDocument(source).promise;
        if (annule) return;
        setPages(doc.numPages);

        const largeur = Math.min(zone.current?.clientWidth || 900, 1200);
        for (let n = 1; n <= doc.numPages; n++) {
          const page = await doc.getPage(n);
          if (annule) return;
          const brut = page.getViewport({ scale: 1 });
          /* On dessine à deux fois la taille affichée : sur un écran dense,
             un texte manuscrit reste net. */
          const ech = (largeur / brut.width) * 2;
          const vue = page.getViewport({ scale: ech });
          const c = document.createElement("canvas");
          c.width = vue.width; c.height = vue.height;
          c.style.width = "100%"; c.style.display = "block";
          c.style.marginBottom = "10px";
          c.style.borderRadius = "8px";
          c.style.boxShadow = "0 1px 4px rgba(14,17,50,.12)";
          await page.render({ canvasContext: c.getContext("2d"), viewport: vue }).promise;
          if (annule) return;
          zone.current?.appendChild(c);
        }
        setEtat("pret");
      } catch (e) { if (!annule) setEtat("erreur"); }
    })();

    return () => { annule = true; };
  }, [fichier]);

  if (!fichier) return null;
  const estImage = /^data:image/.test(fichier.lien) || /\.(png|jpe?g|webp)$/i.test(fichier.lien);

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 60, background: "var(--bg)",
      display: "flex", flexDirection: "column" }}>
      <div className="between" style={{ padding: "12px 16px", borderBottom: "1px solid var(--line)",
        background: "var(--surface)" }}>
        <div style={{ minWidth: 0 }}>
          <span className="eyebrow">{fichier.titre || "Document"}</span>
          {fichier.sous && <p className="small muted" style={{ marginTop: 2 }}>{fichier.sous}</p>}
        </div>
        <div className="row" style={{ gap: 8 }}>
          <button className="btn btn-ghost btn-sm"
            onClick={() => ouvrirFichier(fichier.lien, fichier.nom || "document")}>
            Ouvrir ailleurs
          </button>
          <button className="btn btn-accent btn-sm" onClick={onFermer}>Fermer</button>
        </div>
      </div>

      <div style={{ flex: 1, minHeight: 0, overflow: "auto", background: "#EDF0FD", padding: 12 }}>
        {estImage ? (
          <img src={fichier.lien} alt={fichier.titre || "document"}
            style={{ width: "100%", display: "block", borderRadius: 8 }} />
        ) : (
          <>
            {etat === "chargement" && (
              <p className="small muted" style={{ padding: 24, textAlign: "center" }}>
                Ouverture du document…
              </p>
            )}
            {etat === "erreur" && (
              <div style={{ padding: 24, textAlign: "center" }}>
                <p className="small muted">Ce document n'a pas pu être affiché ici.</p>
                <button className="btn btn-accent btn-sm" style={{ marginTop: 12 }}
                  onClick={() => ouvrirFichier(fichier.lien, fichier.nom || "document")}>
                  Ouvrir le document
                </button>
              </div>
            )}
            <div ref={zone} />
          </>
        )}
      </div>

      <p className="small muted" style={{ padding: "8px 16px", textAlign: "center",
        borderTop: "1px solid var(--line)", background: "var(--surface)" }}>
        {pages > 1 ? pages + " pages · " : ""}Le chronomètre continue de tourner pendant la lecture.
      </p>
    </div>
  );
}

function ouvrirFichier(lien, nom = "document") {
  if (!lien) return false;
  if (/^https?:/i.test(lien)) { window.open(lien, "_blank", "noopener"); return true; }
  if (!/^data:/.test(lien)) return false;
  try {
    const [entete, donnees] = lien.split(",");
    const type = (entete.match(/data:([^;]+)/) || [])[1] || "application/octet-stream";
    const bin = atob(donnees);
    const octets = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) octets[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([octets], { type }));
    const a = document.createElement("a");
    a.href = url; a.target = "_blank"; a.rel = "noopener";
    /* Sur les navigateurs mobiles qui refusent encore l'onglet, le téléchargement
       prend le relais : dans les deux cas l'élève accède à son énoncé. */
    a.download = nom + (type === "application/pdf" ? ".pdf" : "");
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 8000);
    return true;
  } catch (e) { return false; }
}

/* Déposer un fichier : dans le seau de stockage si la base est branchée, en
   mémoire sinon. L'appelant reçoit dans les deux cas une adresse utilisable —
   il n'a pas à savoir laquelle des deux voies a servi. */
/* Déposer un CHAPITRE ENTIER d'un coup.
   Un chapitre complet représente une centaine de fichiers ; sur vingt-deux
   chapitres, près de deux mille cinq cents. Les déposer un par un depuis un
   téléphone est hors de portée. On lit donc une archive, et l'on rattache
   chaque fichier à son exercice par son nom : « son-f1-enonce.pdf » remplit
   l'énoncé de l'exercice « son-f1 ». */
/* Lire une archive ZIP sans aucune bibliothèque : le navigateur sait décompresser
   depuis « DecompressionStream », et le format ZIP se parcourt en lisant son
   répertoire central. Une dépendance de moins, et surtout un lecteur qui
   fonctionne partout — y compris dans l'aperçu de démonstration, où la
   bibliothèque externe était remplacée par un bouchon vide : le dépôt annonçait
   alors « 0 fichier rattaché » sans rien dire de plus. */
async function lireArchive(octets) {
  const vue = new DataView(octets.buffer, octets.byteOffset, octets.byteLength);
  const u16 = (o) => vue.getUint16(o, true);
  const u32 = (o) => vue.getUint32(o, true);

  /* On cherche la fin du répertoire central, en partant de la queue du fichier. */
  let fin = -1;
  for (let i = octets.length - 22; i >= 0 && i > octets.length - 66000; i--) {
    if (u32(i) === 0x06054b50) { fin = i; break; }
  }
  if (fin < 0) throw new Error("archive illisible : répertoire central introuvable");

  const nombre = u16(fin + 10);
  let p = u32(fin + 16);
  const entrees = [];
  for (let k = 0; k < nombre; k++) {
    if (u32(p) !== 0x02014b50) break;
    const methode = u16(p + 10);
    const taille = u32(p + 20);          // taille compressée
    const nomLg = u16(p + 28), extraLg = u16(p + 30), commLg = u16(p + 32);
    const debut = u32(p + 42);           // position de l'en-tête local
    const nom = new TextDecoder().decode(octets.subarray(p + 46, p + 46 + nomLg));
    entrees.push({ nom, methode, taille, debut });
    p += 46 + nomLg + extraLg + commLg;
  }

  const contenu = {};
  for (const e of entrees) {
    if (e.nom.endsWith("/")) continue;
    /* L'en-tête local redonne les longueurs de nom et d'extra, qui peuvent
       différer de celles du répertoire central. */
    const nomLg = u16(e.debut + 26), extraLg = u16(e.debut + 28);
    const d = e.debut + 30 + nomLg + extraLg;
    const brut = octets.subarray(d, d + e.taille);
    if (e.methode === 0) { contenu[e.nom] = brut; continue; }        // stocké tel quel
    const flux = new Blob([brut]).stream()
      .pipeThrough(new DecompressionStream("deflate-raw"));
    contenu[e.nom] = new Uint8Array(await new Response(flux).arrayBuffer());
  }
  return contenu;
}

/* Une archive qui contient PLUSIEURS chapitres, chacun dans son dossier avec
   son manifeste. Verser vingt-deux chapitres un par un depuis un téléphone
   représente vingt-deux manipulations ; d'un coup, c'est une seule. On repère
   les chapitres par leurs manifestes, puis on traite chaque dossier comme une
   archive à lui seul. */
function chapitresDansArchive(contenu) {
  return Object.keys(contenu)
    .filter((n) => /chapitre\.json$/i.test(n))
    .map((n) => ({ manifeste: n, dossier: n.replace(/chapitre\.json$/i, "") }))
    .sort((a, b) => a.dossier.localeCompare(b.dossier));
}

function sousArchive(contenu, dossier) {
  const out = {};
  Object.entries(contenu).forEach(([nom, octets]) => {
    if (!dossier || nom.startsWith(dossier)) out[nom.slice(dossier.length)] = octets;
  });
  return out;
}

/* Le dépôt en lot des ÉPREUVES BLANCHES. Le coach en produit une par chapitre,
   parfois une combinée sur deux ou trois : les déposer une par une depuis un
   téléphone est long. On lit une archive et l'on range chaque PDF.

   Convention retenue : « evaluation-<chapitre>-2h-enonce.pdf ». Le chapitre
   peut s'écrire sous son identifiant, son nom court, ou plusieurs séparés par
   « + » pour une épreuve combinée. Un PDF rangé dans un dossier au nom du
   chapitre est reconnu aussi, quel que soit son titre. */
function analyserNomEvaluation(chemin) {
  const parts = chemin.split("/");
  const nom = parts[parts.length - 1];
  const dossier = parts.length > 1 ? parts[parts.length - 2] : "";
  if (!/\.pdf$/i.test(nom)) return null;

  const corrige = /corrig/i.test(nom);
  /* « entrainement-son-2h-enonce.pdf » dépose un ENTRAÎNEMENT LIBRE : la
     seconde épreuve, que l'élève fait sans la rendre. */
  const libre = /^entrainement[-_]/i.test(nom);
  if (!/^(?:evaluation|entrainement)[-_]/i.test(nom)) return null;
  const m = nom.match(/^(?:evaluation|entrainement)[-_]([^-_]+)/i);
  let cles = m ? m[1].split("+") : [];
  let parDossier = false;

  /* On rapproche chaque clé d'un chapitre connu : identifiant, nom court, ou
     début du nom affiché. Sans cela, « rad » ou « Radioactivité » créerait un
     chapitre fantôme que l'élève ne verrait jamais. */
  const norm = (x) => String(x).toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
  const trouver = (k) => {
    const n = norm(k);
    return (CHAPITRES.find((c) => norm(c.id) === n)
         || CHAPITRES.find((c) => norm(c.court) === n)
         || CHAPITRES.find((c) => norm(c.nom).startsWith(n) && n.length >= 3)
         || null);
  };
  let chapitres = cles.map(trouver);
  /* Le mot qui suit « evaluation- » n'est pas toujours un chapitre : ce peut
     être le titre, le chapitre venant alors du DOSSIER. On retombe dessus
     plutôt que d'écarter le fichier. */
  if (chapitres.some((c) => !c) && dossier && trouver(dossier)) {
    chapitres = [trouver(dossier)]; cles = []; parDossier = true;
  }
  if (!chapitres.length || chapitres.some((c) => !c)) return null;

  /* Le titre : ce qui reste une fois retirés le préfixe, le chapitre, la durée
     et la mention énoncé ou corrigé. */
  let titre = nom.replace(/\.pdf$/i, "")
    .replace(/^(?:evaluation|entrainement)[-_]/i, "");
  /* On ne retire les noms de chapitres du titre que s'ils s'y trouvaient : pour
     une épreuve rangée dans son dossier, le mot qui suit « evaluation- » EST le
     titre, il faut le garder. */
  if (!parDossier && cles.length) {
    titre = titre.replace(new RegExp("^"
      + cles.join("\\+").replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "[-_]", "i"), "");
  }
  titre = titre
    .replace(/[-_]?\d+\s*h(\d+)?[-_]?/i, " ")
    .replace(/[-_]?(enonce|énoncé|sujet|corrige|corrigé|correction)$/i, "")
    .replace(/[-_]+/g, " ").trim();
  /* Si le titre se réduit aux noms de chapitres, il n'apprend rien : on le
     remplace par un intitulé neutre. */
  if (!titre || norm(titre) === norm(cles.join(""))) titre = libre ? "Entraînement libre" : "Épreuve blanche";

  return { chapitres: chapitres.map((c) => c.id), corrige, libre,
           titre: titre.charAt(0).toUpperCase() + titre.slice(1) };
}

/* Les FICHES DE RÉVISION, déposées en lot. Convention du coach :
   « Fiche_T_titre.pdf », le titre désignant le chapitre — « Fiche_T_cinetique »,
   « Fiche_T_niveau_sonore ». On rapproche ce titre d'un chapitre connu plutôt
   que d'exiger l'identifiant exact : le coach nomme ses fiches comme il pense,
   pas comme l'application les indexe. */
function analyserNomFiche(chemin) {
  const parts = chemin.split("/");
  const nom = parts[parts.length - 1];
  const dossier = parts.length > 1 ? parts[parts.length - 2] : "";
  if (!/\.pdf$/i.test(nom)) return null;

  const norm = (x) => String(x).toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");

  /* « resume-son.pdf » dépose une FICHE EXPRESS : une version brève de la
     fiche de révision, pour réviser vite. Elle s'ajoute à la fiche complète
     sans la remplacer, et se déverrouille en même temps qu'elle. */
  const express = /^resume[-_]/i.test(nom);
  const m = nom.match(/^(?:fiche|resume)[-_](?:t[-_])?(.+)\.pdf$/i);
  const cle = m ? m[1] : (dossier || "");
  if (!cle) return null;
  const n = norm(cle);

  /* Identifiant, nom court, puis nom affiché — dans les deux sens, car le
     fichier peut porter « niveau_sonore » là où le chapitre s'appelle
     « Le niveau sonore ». */
  const chap = CHAPITRES.find((c) => norm(c.id) === n)
            || CHAPITRES.find((c) => norm(c.court) === n)
            || CHAPITRES.find((c) => norm(c.nom) === n)
            || CHAPITRES.find((c) => n.length >= 4 && norm(c.nom).includes(n))
            || CHAPITRES.find((c) => n.length >= 4 && n.includes(norm(c.id)))
            || (dossier ? CHAPITRES.find((c) => norm(c.id) === norm(dossier)) : null);
  if (!chap) return null;
  return { chapId: chap.id, express,
           titre: (express ? "Fiche express · " : "Fiche de révision · ") + chap.nom };
}

/* Les VIDÉOS déposées en masse. Il n'y a pas de fichier à lire — elles sont
   hébergées chez Vimeo — mais une liste de liens à coller, une par ligne :

     son | Leçon | Le niveau sonore | https://vimeo.com/1134530387/ed1ef5d63a

   Le séparateur peut être « | », une tabulation ou un point-virgule. Le type et
   le titre sont facultatifs : sans eux, on prend « Leçon » et le nom du
   chapitre. Une ligne mal formée est signalée, elle n'arrête pas les autres. */
function analyserLigneVideo(ligne) {
  const brut = String(ligne).trim().replace(/^\uFEFF/, "");
  if (!brut || brut.startsWith("#")) return null;
  /* La ligne d'en-tête d'un tableur collé : on l'ignore plutôt que de la
     signaler comme erreur. */
  if (/^chapitre\s*[|;,\t]\s*type\s*[|;,\t]/i.test(brut)) return null;

  /* Séparateurs acceptés : « | », « ; », tabulation et virgule. La virgule
     sert aux fichiers CSV exportés d'un tableur ; on la traite en dernier pour
     ne pas couper un titre qui en contiendrait une, et l'on respecte les
     guillemets que le tableur pose autour de tels titres. */
  const champs = /[|;\t]/.test(brut)
    ? brut.split(/\s*[|;\t]\s*/).filter((x) => x !== "")
    : (brut.match(/("(?:[^"]|"")*"|[^,]+)/g) || [])
        .map((x) => x.trim().replace(/^"|"$/g, "").replace(/""/g, '"'))
        .filter((x) => x !== "");
  if (champs.length < 2) return { erreur: "il manque le chapitre ou le lien", ligne: brut };

  const norm = (x) => String(x).toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");

  const url = champs.find((c) => /^https?:\/\//i.test(c) || /^\d{6,}$/.test(c));
  if (!url) return { erreur: "aucun lien reconnu", ligne: brut };
  if (!lecteurVideo(url)) return { erreur: "lien non reconnu comme vidéo", ligne: brut };

  const reste = champs.filter((c) => c !== url);
  const n = norm(reste[0] || "");
  const chap = CHAPITRES.find((c) => norm(c.id) === n)
            || CHAPITRES.find((c) => norm(c.court) === n)
            || CHAPITRES.find((c) => norm(c.nom) === n)
            || CHAPITRES.find((c) => n.length >= 4 && norm(c.nom).includes(n));
  if (!chap) return { erreur: "chapitre inconnu : " + (reste[0] || "?"), ligne: brut };

  /* Le type, s'il est cité : Leçon, Question type, Résumé. */
  let type = TYPES_VIDEO[0], titre = null;
  const suite = reste.slice(1);
  if (suite.length) {
    const t = TYPES_VIDEO.find((x) => norm(x) === norm(suite[0]));
    if (t) { type = t; titre = suite[1] || null; }
    else titre = suite[0];
  }
  return { chapId: chap.id, type, titre: titre || chap.nom, url };
}

async function deposerArchive(chapId, fichier, biblio, surAvancement, contenuFourni, nomDossier = "") {
  const contenu = contenuFourni || await lireArchive(
    new Uint8Array(await fichier.arrayBuffer()));

  /* L'archive peut porter un manifeste « chapitre.json » : il donne le titre,
     la durée et le niveau de chaque exercice. Sans lui, on ne saurait rattacher
     les fichiers qu'à des exercices déjà connus — et un chapitre entier produit
     ailleurs resterait inutilisable. Avec lui, le dépôt crée les exercices
     manquants et le chapitre entre d'un seul geste. */
  let crees = [];
  const cleManifeste = Object.keys(contenu).find((n) => /chapitre\.json$/i.test(n));
  if (cleManifeste) {
    try {
      const m = JSON.parse(new TextDecoder().decode(contenu[cleManifeste]));
      /* Les manifestes ne sont pas tous écrits avec les mêmes noms de champs :
         selon la conversation qui a produit le chapitre, on trouve « exercices »
         ou « fiches », « id » ou « ident », « duree » ou « duree_min ». On
         accepte les deux plutôt que de rejeter un chapitre entier pour un nom. */
      /* Le manifeste peut annoncer un préfixe court — « rad » — là où
         l'application connaît le chapitre sous un nom complet — « radioactivite ».
         On rapproche les deux plutôt que de créer un chapitre fantôme, invisible
         de l'élève parce qu'absent de la liste officielle. */
      const annonce = m.identifiant || m.prefixe || m.id || "";
      /* LE NOM DU DOSSIER sert de dernier recours : sans lui, un manifeste
         muet ou mal nommé versait ses exercices dans le chapitre affiché à
         l'écran — huit dossiers finissaient dans « Le niveau sonore ». */
      const sansAccent = (x) => String(x || "").toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
      const indice = sansAccent(nomDossier);
      const connu = CHAPITRES.find((c) => c.id === annonce)
        || CHAPITRES.find((c) => annonce && c.id.startsWith(annonce))
        || CHAPITRES.find((c) => (m.chapitre || "").toLowerCase() === c.nom.toLowerCase())
        || CHAPITRES.find((c) => indice && indice.includes(sansAccent(c.id)))
        || CHAPITRES.find((c) => indice && indice.includes(sansAccent(c.court)))
        || CHAPITRES.find((c) => indice && sansAccent(c.nom).includes(indice.slice(0, 8)));
      if (connu) chapId = connu.id;
      const liste = m.exercices || m.fiches || m.liste || [];
      const deja = new Set((biblio[chapId] || []).map((e) => e.id));
      crees = liste
        .map((e) => ({
          id: e.id || e.ident,
          titre: e.titre || e.nom || e.id || e.ident,
          duree: e.duree || e.duree_min || e.minutes || 20,
          niveau: e.niveau || "moyen",
          usage: e.usage || "entrainement",
          /* Les LIBELLÉS d'abord : « questions_types » porte « QT 1 », tandis
             que « qt » ne contient souvent qu'un numéro — « 1 ». Le filtre
             « commence par QT » vidait alors la liste, et aucun geste ne se
             cochait. Un numéro nu est reconstitué en « QT n ». */
          qt: (e.questions_types || e.qt || [])
                .map((q) => String(q).split("·")[0].trim())
                .map((q) => (/^\d+$/.test(q) ? "QT " + q : q))
                .filter((q) => /^QT\s*\d+/.test(q))
                .map((q) => q.replace(/^QT\s*/, "QT ")),
        }))
        .filter((e) => e.id);
      /* Le manifeste fait FOI : redéposer un chapitre remplace son lot, il ne
         s'y ajoute pas. Un exercice retiré du manifeste doit disparaître de
         l'application, sinon la bibliothèque garde des fiches corrigées depuis
         longtemps. Les identifiants déjà connus sont mis à jour, pas dupliqués. */
      const remplace = true;
    } catch (e) { /* manifeste illisible : on retombe sur le rattachement simple */ }
  }

  const connus = new Set([...(biblio[chapId] || []).map((e) => e.id),
                          ...crees.map((e) => e.id)]);
  const majs = {};
  const inconnus = [];
  const noms = Object.keys(contenu).filter((n) => /\.pdf$/i.test(n) && !n.startsWith("__"));

  let fait = 0;
  for (const nom of noms) {
    const court = nom.split("/").pop();
    const m = court.match(/^(.+?)-(enonce|corrige)\.pdf$/i);
    if (!m || !connus.has(m[1])) { inconnus.push(court); fait++; surAvancement?.(fait, noms.length); continue; }
    const [, id, genre] = m;
    const blob = new Blob([contenu[nom]], { type: "application/pdf" });
    blob.name = court;
    const rep = await deposerFichier(
      (genre.toLowerCase() === "enonce" ? "exercices/" : "corriges/") + chapId,
      Object.assign(blob, { name: court }));
    const url = typeof rep === "string" ? rep : rep.url;
    majs[id] = { ...(majs[id] || {}),
      ...(genre.toLowerCase() === "enonce" ? { url, nomEnonce: court }
                                           : { urlCorrige: url, nomCorrige: court }) };
    fait++; surAvancement?.(fait, noms.length);
  }
  return { majs, inconnus, total: noms.length, crees, chapId };
}

/* Le dépôt renvoie l'adresse ET, en cas d'échec, la RAISON. Sans elle,
   l'application se rabattait en silence sur un stockage en mémoire : le coach
   voyait « la base n'est pas branchée » alors qu'elle l'était parfaitement, et
   rien ne disait ce qui bloquait vraiment côté stockage. */
async function deposerFichier(dossier, fichier) {
  try {
    const url = await televerser(dossier, fichier);
    if (url) return url;
    return { url: await versDataUrl(fichier), erreur: "stockage indisponible" };
  } catch (e) {
    return { url: await versDataUrl(fichier),
             erreur: e?.message || String(e) };
  }
}

function versDataUrl(blob) {
  return new Promise((resolve) => {
    try {
      const lecteur = new FileReader();
      lecteur.onload = () => resolve(lecteur.result);
      lecteur.onerror = () => resolve(URL.createObjectURL(blob));
      lecteur.readAsDataURL(blob);
    } catch (e) {
      resolve(URL.createObjectURL(blob));
    }
  });
}

async function compresserImage(fichier, maxCote = 1600, qualite = 0.82) {
  if (!fichier.type.startsWith("image/")) return fichier;
  try {
    const image = await createImageBitmap(fichier);
    const ratio = Math.min(1, maxCote / Math.max(image.width, image.height));
    if (ratio === 1 && fichier.size < 1_500_000) return fichier;
    const toile = document.createElement("canvas");
    toile.width = Math.round(image.width * ratio);
    toile.height = Math.round(image.height * ratio);
    toile.getContext("2d").drawImage(image, 0, 0, toile.width, toile.height);
    const blob = await new Promise((r) => toile.toBlob(r, "image/jpeg", qualite));
    if (!blob) return fichier;
    return new File([blob], (fichier.name || "copie").replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch (e) {
    return fichier;
  }
}

function PieceJointe({ onEnvoyer, compact = false }) {
  const [apercu, setApercu] = useState(null);      // { url, fichier, image }
  const [erreur, setErreur] = useState("");
  const [envoi, setEnvoi] = useState(false);

  const choisir = async (e) => {
    const brut = e.target.files?.[0];
    e.target.value = "";
    if (!brut) return;
    setErreur("");
    const fichier = await compresserImage(brut);
    if (fichier.size > TAILLE_MAX) {
      setErreur("Fichier trop lourd (10 Mo maximum). Prenez la photo d'une seule page.");
      return;
    }
    const image = fichier.type.startsWith("image/");
    setApercu({ url: image ? await versDataUrl(fichier) : null, fichier, image });
  };

  const annuler = () => setApercu(null);

  const envoyer = async () => {
    if (!apercu) return;
    setEnvoi(true);
    await onEnvoyer(apercu.fichier);
    setEnvoi(false);
    annuler();
  };

  const ko = (o) => (o > 1_000_000 ? (o / 1_000_000).toFixed(1) + " Mo" : Math.round(o / 1000) + " Ko");

  if (apercu) {
    return (
      <div className="card" style={{ marginTop: 12 }}>
        <span className="eyebrow">{apercu.image ? "Photo a envoyer" : "Document a envoyer"}</span>
        {apercu.image && apercu.url
          ? <img src={apercu.url} alt="apercu de la copie"
              style={{ width: "100%", borderRadius: 12, marginTop: 10, border: "1px solid var(--line)" }} />
          : <div className="res" style={{ marginTop: 8 }}>
              <span className="ico"><Icon d={I.pdf} size={18} /></span>
              <div style={{ flex: 1 }}><h4>{apercu.fichier.name}</h4><p className="small muted">{ko(apercu.fichier.size)}</p></div>
            </div>}
        <div className="row" style={{ marginTop: 12 }}>
          {/* « Joindre » et non « Envoyer » : la pièce est mise de côté, elle
              part avec le message quand l'élève appuie sur Envoyer. Dire
              « Envoyer » ici laissait croire que c'était déjà parti. */}
          <button className="btn btn-gold btn-sm" onClick={envoyer} disabled={envoi}>
            {envoi ? "Ajout..." : "Joindre au message"}
          </button>
          <button className="btn btn-ghost btn-sm" onClick={annuler}>Annuler</button>
        </div>
        <p className="small muted" style={{ marginTop: 10 }}>{ko(apercu.fichier.size)} · visible par le coach et les eleves du groupe</p>
      </div>
    );
  }

  /* Un <label> qui enveloppe l'input ouvre le selecteur sans appel JavaScript :
     c'est la methode qui fonctionne aussi dans un cadre isole. */
  return (
    <>
      <label className={"btn btn-ghost " + (compact ? "btn-sm" : "btn-sm btn-block")}
        style={{ marginTop: compact ? 8 : 10, cursor: "pointer" }}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="17" height="17" aria-hidden="true">
          <rect x="3" y="5" width="18" height="14" rx="3" /><circle cx="9" cy="10" r="1.6" /><path d="M4 17l5-4 4 3 3-2 4 3" />
        </svg>
        Photo de la copie ou PDF
        <input type="file" accept="image/*,application/pdf" onChange={choisir} style={{ display: "none" }} />
      </label>
      {erreur && <p className="small" style={{ color: "var(--red)", marginTop: 8 }}>{erreur}</p>}
    </>
  );
}

function Permanence({ threads, marquerLu, viderPermanence, lus = [], envoyer, envoyerVocal, envoyerFichier, estCoach, epingler, enRessource, retirerDesRessources, validerMessage, signalerErreur, ajouterAuCarnet, retirerDuCarnetParTexte, carnet = [], envoyerTout = null, elevesPermanence = [] }) {
  /* Un message privé du coach doit se voir immédiatement : c'est le seul fil de
     la permanence qui ne s'adresse qu'à une personne. */

  const [ouvert, setOuvert] = useState(null);
  const [signalement, setSignalement] = useState(null);
  const [commentaire, setCommentaire] = useState("");
  const [confirmeVidage, setConfirmeVidage] = useState(false);
  const [pisteOuverte, setPisteOuverte] = useState(null);   // fil dont on note la piste
  const [notePiste, setNotePiste] = useState("");
  const [txt, setTxt] = useState("");
  const [chap, setChap] = useState(CHAPITRES[0].id);
  const [filtre, setFiltre] = useState("tous");          // tous | mien | chapitre | ressources | attente | eleve
  const [eleveFiltre, setEleveFiltre] = useState(null);  // le nom de l'élève suivi

  /* UN SON quand un message arrive. Le coach garde souvent la permanence
     ouverte en travaillant : sans signal, une question pouvait attendre une
     heure. Deux notes brèves, assez discrètes pour ne pas gêner. */
  /* On ne compte QUE LES MESSAGES REÇUS. L'application marque « moi » les
     messages dont l'utilisateur courant est l'auteur : c'est ce marquage qui
     fait foi. Comparer au rôle — « prof » ou « eleve » — ne marchait que pour
     le coach : côté élève, les réponses du prof portent « prof », donc un rôle
     différent du sien, mais ses propres messages portaient aussi « eleve » et
     le son partait à l'envers. */
  const nbMessages = threads.reduce((n, t) =>
    n + (t.messages || []).filter((m) => m.role !== "moi").length, 0);
  const vuMessages = useRef(null);
  useEffect(() => {
    if (vuMessages.current === null) { vuMessages.current = nbMessages; return; }
    if (nbMessages <= vuMessages.current) { vuMessages.current = nbMessages; return; }
    vuMessages.current = nbMessages;
    try {
      /* Sur iPhone et iPad, le son ne peut être créé qu'à la suite d'un geste
         de l'utilisateur : un contexte créé à la volée reste muet. On garde
         donc UN SEUL contexte, débloqué au premier toucher de l'écran, et on
         le réemploie ensuite. */
      const ctx = contexteSon();
      if (!ctx) return;
      if (ctx.state === "suspended") ctx.resume();
      [880, 1174].forEach((f, k) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = "sine"; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, ctx.currentTime + k * 0.12);
        g.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + k * 0.12 + 0.01);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + k * 0.12 + 0.11);
        o.connect(g); g.connect(ctx.destination);
        o.start(ctx.currentTime + k * 0.12);
        o.stop(ctx.currentTime + k * 0.12 + 0.12);
      });
      /* On ne ferme PAS le contexte : le rouvrir demanderait un nouveau geste
         de l'utilisateur, et le son suivant serait muet sur mobile. */
    } catch (e) { /* le navigateur refuse le son tant qu'on n'a rien cliqué */ }
  }, [nbMessages]);
  const [chapFiltre, setChapFiltre] = useState(null);
  const [formRessource, setFormRessource] = useState(null);
  const [titreRes, setTitreRes] = useState("");
  const [resumeRes, setResumeRes] = useState("");

  const estMien = (t) => t.mien ?? t.messages.some((m) => m.role === "moi");

  /* Une couleur par élève, déduite de son nom : elle ne change donc jamais
     d'une session à l'autre, et deux élèves différents ne se confondent pas
     dans un fil où plusieurs interviennent. Teintes claires et lisibles,
     choisies pour rester distinctes même côte à côte. */
  const auteurDe = (t) => {
    if (!t) return null;
    const premier = (t.messages || []).find((m) => m && m.role !== "prof" && m.role !== "coach");
    return premier?.de || t.pourEleve || null;
  };

  /* La liste part des ÉLÈVES INSCRITS, pas des fils : construite depuis les
     messages, elle restait vide tant que personne n'avait écrit — le coach ne
     voyait aucun prénom, donc aucune pastille. On ajoute ensuite les auteurs
     de fils qui n'y seraient pas. */
  const auteurs = [...new Set([
    ...(elevesPermanence || []).map((e) => e.prenom || e.nom).filter(Boolean),
    ...threads.map(auteurDe).filter(Boolean),
  ])].sort();
  const TEINTES = [
    { fond: "#EEF4FF", trait: "#8AA6E8", texte: "#2A4A8C" },
    { fond: "#F0F7EE", trait: "#93C48D", texte: "#2E6B34" },
    { fond: "#FFF4EC", trait: "#E8AE7E", texte: "#8C5220" },
    { fond: "#F6EFFA", trait: "#B694CE", texte: "#5E3A80" },
    { fond: "#FFF1F3", trait: "#E4949E", texte: "#8C2F3D" },
    { fond: "#EDF7F8", trait: "#84BCC4", texte: "#1F5F68" },
    { fond: "#FBF3E4", trait: "#D3B369", texte: "#7A5A12" },
    { fond: "#F1F1F7", trait: "#A0A2BC", texte: "#43466B" },
  ];
  /* La couleur suit le RANG de l'élève dans la liste alphabétique, pas un
     calcul sur son nom : celui-ci donnait des collisions dès sept élèves —
     trois d'entre eux partageaient la même teinte. Par rang, les huit
     premières sont nécessairement distinctes. */
  const teinteDe = (nom) => {
    if (!nom || !Array.isArray(auteurs)) return null;
    const i = auteurs.indexOf(nom);
    return TEINTES[(i < 0 ? 0 : i) % TEINTES.length];
  };

  /* Les messages arrivés depuis la dernière lecture du fil. On repère le
     dernier message que l'élève avait vu, et tout ce qui suit est nouveau —
     sans quoi il doit relire tout le fil pour trouver ce qui a changé. */
  const nouveauxDe = (t) => {
    const msgs = t.messages || [];
    const e = (lus || []).find((x) => (typeof x === "object" ? x.id : x) === t.id);
    if (!e) return msgs.map((m) => m.id);            // fil jamais ouvert
    if (typeof e !== "object" || !e.msg) return [];  // ancienne marque
    const vu = String(e.msg).split("|")[1];          // l'empreinte porte l'identifiant
    const i = msgs.findIndex((m) => String(m.id) === vu);
    return i < 0 ? [] : msgs.slice(i + 1).map((m) => m.id);
  };
  /* Un message peut porter À LA FOIS un texte, un vocal et un document : ils
     partaient jusqu'ici en trois messages séparés, et le coach devait
     reconstituer l'ensemble. On les garde de côté, puis on les envoie
     ensemble — le texte d'abord, qui porte la question, puis les pièces. */
  /* UN MESSAGE AU COACH SEULEMENT : l'élève ne pouvait écrire qu'au groupe,
     et devait poser en public une question qui ne regardait que lui. */
  const [auCoach, setAuCoach] = useState(false);
  /* LE DESTINATAIRE, côté coach : sa zone de composition envoyait toujours au
     groupe, et il n'avait aucun moyen d'écrire à un seul élève depuis là. */
  const [pourQui, setPourQui] = useState(null);
  const [vocalPret, setVocalPret] = useState(null);
  const [fichierPret, setFichierPret] = useState(null);
  const go = async () => {
    if (!txt.trim() && !vocalPret && !fichierPret) return;
    const cible = ouvert, ch = chap;
    const t = txt.trim(), v = vocalPret, f = fichierPret;
    setTxt(""); setVocalPret(null); setFichierPret(null); setOuvert(null);
    /* UN SEUL message porte le tout : texte, vocal et document. Le coach lit
       une question, pas trois lignes à rapprocher. */
    if (envoyerTout) {
      await envoyerTout({ sujetId: cible, corps: t, blob: v?.blob,
                          duree: v?.duree || 0, fichier: f, chapitre: ch,
                          prive: (auCoach && !cible) || (!!pourQui && !cible),
                          destinataire: !cible ? pourQui : null });
      setAuCoach(false); setPourQui(null);
      return;
    }
    if (t) await envoyer(cible, t, ch);          // repli hors base
  };

  /* L'auteur d'un fil : le nom porté par son premier message. C'est ce qui
     permet au coach de suivre un élève en particulier plutôt que de parcourir
     toute la permanence à sa recherche. */

  const filtres = threads.filter((t) => {
    /* Les copies corrigées ont leur propre place : mêlées aux questions de
       chapitre, elles se perdaient dans le fil — or c'est ce que l'élève
       revient chercher en premier après une évaluation. */
    if (filtre === "copies") return !!t.correction;
    if (filtre !== "tous" && t.correction) return false;
    if (filtre === "eleve") return auteurDe(t) === eleveFiltre;
    if (filtre === "mien") return estMien(t);
    if (filtre === "ressources") return t.ressource;
    if (filtre === "attente") return t.statut !== "resolu";
    if (filtre === "chapitre") return t.chap === chapFiltre;
    return true;
  });
  const listes = [...filtres].sort((a, b) => (b.epingle ? 1 : 0) - (a.epingle ? 1 : 0));
  const mesQuestions = threads.filter(estMien).length;
  const ressources = threads.filter((t) => t.ressource);

  const ouvrirRessource = (t) => {
    setFormRessource(t.id);
    setTitreRes(t.ressourceTitre || t.titre);
    setResumeRes(t.ressourceResume || "");
  };

  return (
    <div className="stack">
      <div>
        <p className="eyebrow">Ouverte 7 j/7 — reponse dans la journee</p>
        <h1 style={{ marginTop: 6 }}>Permanence « Devoirs faits »</h1>
      </div>

      {/* Le coach suit ses élèves un par un : sans ce filtre, retrouver les
          questions d'un élève oblige à parcourir toute la permanence. */}
      {/* Dès le PREMIER élève : avec un seul inscrit, le coach ne voyait pas
          la barre — donc pas la pastille des questions en attente. */}
      {estCoach && auteurs.length > 0 && (
        <div className="chips longue" style={{ marginBottom: 10 }}>
          {auteurs.map((a) => {
            const n = threads.filter((t) => auteurDe(t) === a).length;
            const sansReponse = threads.filter((t) => auteurDe(t) === a
              && t.statut !== "resolu").length;
            return (
              <button key={a}
                className={"chip" + (filtre === "eleve" && eleveFiltre === a ? " on" : "")}
                style={(() => { const c = teinteDe(a);
                  return c && !(filtre === "eleve" && eleveFiltre === a)
                    ? { background: c.fond, borderColor: c.trait, color: c.texte }
                    : undefined; })()}
                onClick={() => {
                  if (filtre === "eleve" && eleveFiltre === a) { setFiltre("tous"); setEleveFiltre(null); }
                  else { setFiltre("eleve"); setEleveFiltre(a); }
                }}>
                {/* Une PASTILLE plutôt qu'un texte : le coach doit voir d'un
                    coup d'œil qui attend une réponse, sans lire chaque chip. */}
                {a}
                {sansReponse > 0
                  ? <span className="tag gold" style={{ marginLeft: 6 }}>{sansReponse}</span>
                  : <span className="small muted" style={{ marginLeft: 6 }}>{n}</span>}
              </button>
            );
          })}
        </div>
      )}

      {/* ---- filtres ---- */}
      <div className="chips">
        <button className={"chip" + (filtre === "tous" ? " on" : "")} onClick={() => setFiltre("tous")}>Tout le groupe</button>

        <button className={"chip" + (filtre === "mien" ? " on" : "")} onClick={() => setFiltre("mien")}>
          Mes questions{mesQuestions ? " (" + mesQuestions + ")" : ""}
        </button>
        <button className={"chip" + (filtre === "attente" ? " on" : "")} onClick={() => setFiltre("attente")}>Sans reponse</button>
        {threads.some((t) => t.correction) && (
          <button className={"chip" + (filtre === "copies" ? " on" : "")}
            onClick={() => setFiltre(filtre === "copies" ? "tous" : "copies")}>
            Mes copies corrigées
          </button>
        )}
        {ressources.length > 0 && (
          <button className={"chip" + (filtre === "ressources" ? " on" : "")} onClick={() => setFiltre("ressources")}>
            Ressources ({ressources.length})
          </button>
        )}
      </div>
      <div className="chips longue">
        {CHAPITRES.map((c) => (
          <button key={c.id}
            className={"chip" + (filtre === "chapitre" && chapFiltre === c.id ? " on" : "")}
            onClick={() => { setFiltre("chapitre"); setChapFiltre(c.id); }}>
            {c.court}
          </button>
        ))}
      </div>

      {/* ---- ressources du chapitre, en tete quand on filtre par chapitre ---- */}
      {filtre === "chapitre" && ressources.some((t) => t.chap === chapFiltre) && (
        <div className="card" style={{ borderColor: "#D6DEFB" }}>
          <span className="eyebrow">Ressources du chapitre</span>
          <p className="small muted" style={{ marginTop: 4 }}>
            Des questions deja traitees, reprises et validees par le coach. A lire avant de poser la votre.
          </p>
          {ressources.filter((t) => t.chap === chapFiltre).map((t) => (
            <div className="res" key={t.id}>
              <span className="ico"><Icon d={I.chat} size={18} /></span>
              <div style={{ flex: 1 }}>
                <h4>{t.ressourceTitre || t.titre}</h4>
                {t.ressourceResume && <p className="small muted">{t.ressourceResume}</p>}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Le ménage du coach : les fils résolus s'accumulent et finissent par
          noyer les questions en cours. On ne touche ni aux fils ouverts, ni aux
          messages privés adressés à un élève. */}
      {estCoach && threads.length > 0 && (
        <div className="card">
          <div className="between">
            <span className="eyebrow">Ménage</span>
            <span className="tag">{threads.length} fil(s)</span>
          </div>

          {!confirmeVidage ? (
            <div className="row" style={{ gap: 8, marginTop: 12 }}>
              <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                disabled={!threads.some((t) => t.statut === "resolu")}
                onClick={() => setConfirmeVidage("resolus")}>
                Supprimer les résolus
              </button>
              <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                onClick={() => setConfirmeVidage("tout")}>
                Tout supprimer
              </button>
            </div>
          ) : (
            <>
              {/* La suppression est définitive et vaut pour TOUT LE MONDE :
                  elle efface les fils de la base, pas seulement de cet écran.
                  Un archivage local les faisait revenir dès qu'un élève
                  reposait une question. */}
              <p className="small" style={{ marginTop: 10, color: "#C0392B" }}>
                {confirmeVidage === "tout"
                  ? "Toute la permanence sera effacée, pour vous comme pour vos élèves. Cette action est définitive."
                  : "Les fils résolus seront effacés pour tout le monde. Les questions en cours sont conservées."}
              </p>
              <div className="row" style={{ gap: 8, marginTop: 10 }}>
                <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                  onClick={() => setConfirmeVidage(false)}>Annuler</button>
                <button className="btn btn-accent btn-sm" style={{ flex: 1 }}
                  onClick={() => {
                    viderPermanence && viderPermanence(confirmeVidage === "tout");
                    setConfirmeVidage(false);
                  }}>
                  Confirmer la suppression
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* ---- poser une question ---- */}
      <div className="card">
        <h3>Poser une question</h3>
        <div className="chips longue" style={{ marginTop: 10 }}>
          {/* « Organisation » d'abord : toutes les questions ne portent pas sur
              un chapitre — un empêchement, un horaire, un doute sur le
              programme. Elles n'avaient nulle part où aller. */}
          <button className={"chip" + (chap === "organisation" ? " on" : "")}
            onClick={() => setChap("organisation")}>Organisation</button>
          {CHAPITRES.map((c) => <button key={c.id} className={"chip" + (chap === c.id ? " on" : "")} onClick={() => setChap(c.id)}>{c.court}</button>)}
        </div>
        <div className="composer">
          <textarea rows={2} value={ouvert ? "" : txt} onChange={(e) => { setOuvert(null); setTxt(e.target.value); }}
            placeholder="Decrivez ou ca bloque — ou expliquez-le a l'oral, c'est souvent plus simple."
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); go(); } }} />
          {/* CÔTÉ ÉLÈVE : « au coach seulement ». CÔTÉ COACH : le choix de
              l'élève destinataire — sa zone de composition envoyait toujours
              au groupe entier. */}
          {!estCoach && (
            <button className={"chip" + (auCoach ? " on" : "")}
              style={{ flex: "none" }}
              onClick={() => setAuCoach(!auCoach)}
              title="Ce message n'ira qu'à ton coach">
              {auCoach ? "au coach seul ✓" : "au coach seul"}
            </button>
          )}
          {estCoach && (elevesPermanence || []).length > 0 && (
            <select className="chip" style={{ flex: "none" }}
              value={pourQui || ""}
              onChange={(ev) => setPourQui(ev.target.value || null)}>
              <option value="">à tout le groupe</option>
              {(elevesPermanence || []).map((el) => (
                <option key={el.id} value={el.id}>
                  à {el.prenom || el.nom || "l'élève"}
                </option>
              ))}
            </select>
          )}
          <button className="btn btn-accent btn-sm" onClick={go}>Envoyer</button>
        </div>
        <Enregistreur onEnvoyer={(blob, duree) => setVocalPret({ blob, duree })} />
        {/* Ce qui partira avec le message : l'élève voit ce qu'il a joint. */}
        {(vocalPret || fichierPret) && (
          <div className="row" style={{ gap: 8, marginTop: 8, flexWrap: "wrap" }}>
            {vocalPret && (
              <span className="tag">
                vocal {vocalPret.duree}s
                <button className="btn btn-ghost btn-sm" style={{ padding: "0 6px" }}
                  onClick={() => setVocalPret(null)}>×</button>
              </span>
            )}
            {fichierPret && (
              <span className="tag">
                {String(fichierPret.name).slice(0, 24)}
                <button className="btn btn-ghost btn-sm" style={{ padding: "0 6px" }}
                  onClick={() => setFichierPret(null)}>×</button>
              </span>
            )}
          </div>
        )}
        <PieceJointe onEnvoyer={(fichier) => setFichierPret(fichier)} />
        <p className="small muted" style={{ marginTop: 8 }}>
          Un vocal vaut souvent mieux qu'un long message : montrez votre copie en photo, expliquez a l'oral ou vous bloquez.
        </p>
      </div>

      {/* ---- fils ---- */}
      {listes.length === 0 && (
        <div className="card">
          <p className="small muted">
            {filtre === "mien" ? "Vous n'avez pas encore pose de question. La premiere est toujours la plus difficile."
              : "Aucune question dans cette selection."}
          </p>
        </div>
      )}

      {/* Les copies corrigées sont annoncées : c'est le retour du coach sur un
          travail rendu, pas une discussion de chapitre. */}
      {filtre === "copies" && (
        <div className="card" style={{ background: "#FBF3E4", borderColor: "#E8DCC0" }}>
          <div className="between">
            <span className="small" style={{ color: "#7A5A12" }}>
              Tes copies corrigées · {listes.length}
            </span>
            <button className="btn btn-ghost btn-sm"
              onClick={() => setFiltre("tous")}>Voir toute la permanence</button>
          </div>
        </div>
      )}

      {filtre === "eleve" && eleveFiltre && (
        <div className="card" style={{ background: "#F8F9FF", borderColor: "#C9D2F8" }}>
          <div className="between">
            <span className="small">Fils de <b>{eleveFiltre}</b> · {listes.length}</span>
            <button className="btn btn-ghost btn-sm"
              onClick={() => { setFiltre("tous"); setEleveFiltre(null); }}>
              Voir tout le groupe
            </button>
          </div>
        </div>
      )}

      {listes.map((t) => (
        <div className="card" key={t.id} style={t.epingle ? { borderColor: "#F2E1BC", background: "#FFFDF8" } : {}}>
          <div className="between">
            <h3>{t.ressourceTitre || t.titre}</h3>
            <div className="row" style={{ gap: 6 }}>
              {/* Un message privé du coach : visible de toi seul. */}
              {/* « pour toi » n'a de sens que pour le DESTINATAIRE : le coach
                  voit tous les fils privés, et croyait se les être envoyés à
                  lui-même. Il voit désormais le nom de l'élève. */}
              {t.prive && (estCoach
                ? <span className="tag gold">pour {t.pourEleve || "l'élève"}</span>
                : <span className="tag gold">pour toi</span>)}
              {t.epingle && <span className="tag gold">Épinglé</span>}
              {t.ressource && <span className="tag">Ressource</span>}
              <span className={"tag " + (t.statut === "resolu" ? "green" : "gold")}>{t.statut === "resolu" ? "Répondu" : "En attente"}</span>
            </div>
          </div>
          <div className="row" style={{ marginTop: 8, gap: 8 }}>
            <span className="tag grey">
              {t.chap === "organisation" ? "Organisation"
                : CHAPITRES.find((c) => c.id === t.chap)?.court || t.chap}
            </span>
            {/* Le nom de l'élève, pour le coach seulement : côté élève la
                permanence est commune, savoir qui a posé quoi n'importe pas. */}
            {estCoach && auteurDe(t) && (
              <span className="tag" style={(() => { const c = teinteDe(auteurDe(t));
                return c ? { background: c.fond, borderColor: c.trait, color: c.texte }
                         : undefined; })()}>
                {auteurDe(t)}
              </span>
            )}
            {t.correction && <span className="tag gold">Copie corrigée</span>}
            {estMien(t) && !t.correction && <span className="tag">Ma question</span>}
          </div>
          {t.ressource && t.ressourceResume && (
            <p className="small" style={{ marginTop: 10, color: "var(--ink)" }}>{t.ressourceResume}</p>
          )}

          {(() => { const neufs = nouveauxDe(t); return t.messages.map((m, k) => (
            <div key={k}
              className={"msg " + (m.role === "prof" ? "msg-prof" : m.role === "moi" ? "msg-me" : "msg-in")}
              style={(() => {
                /* Validation et signalement priment : ce sont les informations
                   les plus utiles. Vient ensuite la nouveauté, puis la couleur
                   de l'élève — seulement pour les messages d'autrui. */
                if (m.valide) return { borderColor: "#2FA97C", boxShadow: "inset 0 0 0 1px #2FA97C" };
                if (m.signale) return { borderColor: "#E0685F", boxShadow: "inset 0 0 0 1px #E0685F" };
                if (neufs.includes(m.id) && m.role !== "moi")
                  return { borderColor: "#6C63FF", boxShadow: "inset 0 0 0 1px #6C63FF" };
                const c = m.role === "prof" || m.role === "moi" ? null : teinteDe(m.de);
                return c ? { background: c.fond, borderColor: c.trait } : undefined;
              })()}>
              <span className="who" style={(() => {
                const c = m.role === "prof" || m.role === "moi" ? null : teinteDe(m.de);
                return c ? { color: c.texte, fontWeight: 600 } : undefined;
              })()}>
                {m.de} · {m.h}
                {/* Nouveau : arrivé depuis la dernière fois que l'élève a
                    ouvert ce fil. Ses propres messages n'en portent pas. */}
                {neufs.includes(m.id) && m.role !== "moi" && (
                  <span className="tag" style={{ marginLeft: 6, fontSize: ".58rem",
                    padding: "1px 6px", background: "#6C63FF", color: "white" }}>
                    nouveau
                  </span>
                )}
              </span>
              {m.txt}
              {m.audio && (
                <>
                  <audio controls src={m.audio} style={{ width: "100%", marginTop: 8 }} />
                  {m.audioDuree ? <span className="small" style={{ opacity: .7 }}>vocal · {m.audioDuree} s</span> : null}
                </>
              )}
              {m.fichier && (m.fichierType || "").startsWith("image/") && (
                <a href={m.fichier} target="_blank" rel="noreferrer">
                  <img src={m.fichier} alt="copie de l'eleve"
                    onError={(e) => { e.currentTarget.style.display = "none"; }}
                    style={{ width: "100%", borderRadius: 10, marginTop: 8, border: "1px solid rgba(0,0,0,.08)", display: "block" }} />
                </a>
              )}
              {m.fichier && !(m.fichierType || "").startsWith("image/") && (
                <a className="btn btn-ghost btn-sm" href={m.fichier} target="_blank" rel="noreferrer" style={{ marginTop: 8 }}>
                  Ouvrir {m.fichierNom || "le document"}
                </a>
              )}

              {m.valide && (
                <span className="badge-msg ok">✓ Reponse validee par le professeur</span>
              )}
              {m.signale && (
                <>
                  <span className="badge-msg ko">Attention : ce message contient une erreur</span>
                  {m.signaleCommentaire && <p className="commentaire">{m.signaleCommentaire}</p>}
                </>
              )}

              {/* actions du coach, sur les messages d'eleves uniquement */}
              {estCoach && m.role !== "prof" && !m.valide && !m.signale && (
                <div className="actions">
                  <button onClick={() => validerMessage(t.id, k, m.id)}>✓ Valider</button>
                  <button onClick={() => { setSignalement({ sujet: t.id, index: k, id: m.id }); setCommentaire(""); }}>
                    Signaler une erreur
                  </button>
                </div>
              )}

              {signalement && signalement.sujet === t.id && signalement.index === k && (
                <div className="card" style={{ marginTop: 10, background: "#FDF6F5", borderColor: "#F3D6D3", padding: 14 }}>
                  <span className="eyebrow" style={{ color: "#8C332C" }}>Signaler une erreur</span>
                  <p className="small muted" style={{ marginTop: 4 }}>
                    Le commentaire est obligatoire : un message signale sans explication ne sert a personne.
                  </p>
                  <textarea className="inp" rows={2} style={{ width: "100%", marginTop: 10 }}
                    placeholder="Quelle est l'erreur ?"
                    value={commentaire} onChange={(e) => setCommentaire(e.target.value)} />
                  <div className="row" style={{ marginTop: 10 }}>
                    <button className="btn btn-accent btn-sm" disabled={!commentaire.trim()}
                      onClick={() => { signalerErreur(t.id, k, m.id, commentaire.trim()); setSignalement(null); }}>
                      Signaler ce message
                    </button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setSignalement(null)}>Annuler</button>
                  </div>
                </div>
              )}
            </div>
          )); })()}

          {ouvert === t.id ? (
            <>
              {estCoach && (
                <>
                  <p className="eyebrow" style={{ marginTop: 12 }}>Reponses types</p>
                  <div className="chips" style={{ marginTop: 8 }}>
                    {REPONSES_TYPES.map((r) => (
                      <button key={r.court} className="chip"
                        onClick={() => setTxt((v) => (v ? v.trim() + " " : "") + r.texte)}>
                        {r.court}
                      </button>
                    ))}
                  </div>
                </>
              )}
              <div className="composer">
                <textarea rows={estCoach ? 4 : 2} value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Votre reponse..." />
                <button className="btn btn-accent btn-sm" onClick={go}>Envoyer</button>
              </div>
              <div className="row" style={{ gap: 8 }}>
                <Enregistreur compact onEnvoyer={(blob, duree) => setVocalPret({ blob, duree })} />
                {/* Ce qui partira avec la réponse. */}
                {vocalPret && <span className="tag">vocal {vocalPret.duree}s</span>}
                {fichierPret && <span className="tag">{String(fichierPret.name).slice(0, 20)}</span>}
                <PieceJointe compact onEnvoyer={(fichier) => setFichierPret(fichier)} />
              </div>
            </>
          ) : (
            <div className="barre-actions">
              {ajouterAuCarnet && (() => {
                const titre = t.ressourceTitre || t.titre;
                const dedans = carnet.find((p) => p.txt === titre);
                return (
                  <button className={dedans ? "principal" : ""}
                    onClick={() => {
                      if (pisteOuverte === t.id) { setPisteOuverte(null); return; }
                      setPisteOuverte(t.id);
                      setNotePiste(dedans?.note || "");
                    }}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" width="15" height="15" aria-hidden="true">
                      <rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
                    </svg>
                    {dedans ? "Dans mes pistes" : "Piste Grand oral"}
                  </button>
                );
              })()}
              <button className="principal"
                onClick={() => { setOuvert(t.id); setTxt(""); marquerLu && marquerLu(t.id); }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" width="15" height="15" aria-hidden="true">
                  <path d="M20 12a7 7 0 0 1-7 7H8l-4 3v-4.5A7 7 0 0 1 8 5h5a7 7 0 0 1 7 7z" />
                </svg>
                Repondre
              </button>
              {estCoach && (
                <>
                  <button onClick={() => epingler(t.id, !t.epingle)}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" width="15" height="15" aria-hidden="true">
                      <path d="M9 4h6l-1 6 4 3v2H6v-2l4-3z" /><path d="M12 15v5" />
                    </svg>
                    {t.epingle ? "Ne plus epingler" : "Epingler"}
                  </button>
                  {t.ressource
                    ? <button onClick={() => retirerDesRessources(t.id)}>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" width="15" height="15" aria-hidden="true">
                          <path d="M6 4h12v16l-6-4-6 4z" /><path d="M9 9h6" />
                        </svg>
                        Retirer des ressources
                      </button>
                    : <button onClick={() => ouvrirRessource(t)}>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" width="15" height="15" aria-hidden="true">
                          <path d="M6 4h12v16l-6-4-6 4z" /><path d="M12 8v5M9.5 10.5h5" />
                        </svg>
                        En faire une ressource
                      </button>}
                </>
              )}
            </div>
          )}

          {pisteOuverte === t.id && (() => {
            const titre = t.ressourceTitre || t.titre;
            const dedans = carnet.find((p) => p.txt === titre);
            return (
              <div className="card" style={{ marginTop: 12, background: "var(--surface-alt)" }}>
                <span className="eyebrow">{dedans ? "Dans votre carnet de pistes" : "Ajouter à votre carnet de pistes"}</span>
                <p className="small" style={{ marginTop: 6, color: "var(--ink)" }}>« {titre} »</p>
                <textarea className="inp" rows={2} style={{ width: "100%", marginTop: 10 }}
                  placeholder="Ce que vous avez en tête maintenant : un angle, un exemple, une intuition..."
                  value={notePiste} onChange={(e) => setNotePiste(e.target.value)} />
                <div className="row" style={{ marginTop: 10, gap: 8 }}>
                  <button className="btn btn-gold btn-sm"
                    onClick={() => {
                      ajouterAuCarnet({ chapId: t.chap, txt: titre, source: "permanence", note: notePiste.trim() });
                      setPisteOuverte(null); setNotePiste("");
                    }}>
                    {dedans ? "Enregistrer la note" : "Ajouter à mon carnet"}
                  </button>
                  {dedans && retirerDuCarnetParTexte && (
                    <button className="btn btn-ghost btn-sm"
                      onClick={() => { retirerDuCarnetParTexte(titre); setPisteOuverte(null); setNotePiste(""); }}>
                      Retirer de mes pistes
                    </button>
                  )}
                  <button className="btn btn-ghost btn-sm" onClick={() => setPisteOuverte(null)}>Fermer</button>
                </div>
              </div>
            );
          })()}

          {formRessource === t.id && (
            <div className="card" style={{ marginTop: 12, background: "var(--surface-alt)" }}>
              <span className="eyebrow">Transformer en ressource</span>
              <p className="small muted" style={{ marginTop: 6 }}>
                Le fil reste consultable, mais il apparait en tete du chapitre avec le titre et le resume que vous ecrivez.
              </p>
              <input className="inp" style={{ width: "100%", marginTop: 10 }} placeholder="Titre de la ressource"
                value={titreRes} onChange={(e) => setTitreRes(e.target.value)} />
              <textarea className="inp" rows={3} style={{ width: "100%", marginTop: 10 }}
                placeholder="Ce qu'il faut retenir, en deux phrases"
                value={resumeRes} onChange={(e) => setResumeRes(e.target.value)} />
              <div className="row" style={{ marginTop: 12 }}>
                <button className="btn btn-gold btn-sm"
                  onClick={() => { enRessource(t.id, titreRes.trim() || t.titre, resumeRes.trim()); setFormRessource(null); }}>
                  Publier la ressource
                </button>
                <button className="btn btn-ghost btn-sm" onClick={() => setFormRessource(null)}>Annuler</button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

/* ========================= RESSOURCES ===================================== */

function Ressources({ ressources, principaux, ajouterAuCarnet, retirerDuCarnetParTexte, carnet = [], chapVoulu = null }) {
  const [chapId, setChapId] = useState(chapVoulu || principaux[0]?.id || CHAPITRES[0].id);
  /* Arrivé depuis une feuille blanche : on ouvre SON chapitre, pas le premier
     de la liste. */
  useEffect(() => { if (chapVoulu) setChapId(chapVoulu); }, [chapVoulu]);
  /* Le chapitre est VERROUILLÉ tant qu'il n'est pas déclaré ET que sa première
     feuille blanche n'est pas rendue. Laisser ouverts les chapitres non
     déclarés vidait le verrou de son sens : il suffisait de lire les fiches
     avant de déclarer, et la feuille blanche ne mesurait plus rien. */
  const chapCourant = principaux.find((x) => x.id === chapId);
  /* Le cours s'ouvre dès que le chapitre est DÉCLARÉ et son test passé. La
     feuille blanche devait servir de clé, mais elle ne se pose pas encore le
     soir de la déclaration : l'élève restait sans accès à ses vidéos. Le test
     joue le même rôle — il mesure ce qu'il sait avant toute relecture. */
  const verrouille = !chapCourant || !chapCourant.niveau;
  const [onglet, setOnglet] = useState(TYPES_VIDEO[0]);
  const [piste, setPiste] = useState("");
  const chap = ressources[chapId] || { videos: [], fiches: [] };
  const videos = chap.videos.filter((v) => v.type === onglet);

  return (
    <div className="stack">
      <div>
        <p className="eyebrow">Cours</p>
        <h1 style={{ marginTop: 6 }}>Videos et fiches de revision</h1>
      </div>

      <div className="chips longue">
        {CHAPITRES.map((c) => (
          <button key={c.id} className={"chip" + (chapId === c.id ? " on" : "")} onClick={() => setChapId(c.id)}>{c.court}</button>
        ))}
      </div>

      {/* LE VERROU. Le cours ne s'ouvre qu'une fois la première feuille blanche
          rendue : elle mesure ce que l'élève a retenu du cours lui-même, avant
          toute relecture. Sans ce verrou, il lui suffisait de passer par le
          menu pour lire les fiches et la restitution ne valait plus rien. */}
      {verrouille && (
          <div className="card" style={{ borderColor: "#E4D3AC", background: "#FDF8EE" }}>
            <div className="row" style={{ gap: 10, alignItems: "flex-start" }}>
              <span className="ico"><Icon d={I.lock} size={18} /></span>
              <div style={{ flex: 1 }}>
                <h4>{chapCourant
                  ? "Passe d'abord ton test de positionnement"
                  : "Déclare d'abord ce chapitre"}</h4>
                <p className="small" style={{ marginTop: 4, color: "#7A5A12" }}>
                  {chapCourant
                    ? "Il mesure ce que tu as retenu du cours, avant de relire "
                      + "quoi que ce soit. Il t'attend dans ton programme du soir "
                      + "— ensuite, vidéos et fiches sont à toi."
                    : "Vidéos et fiches s'ouvrent une fois le chapitre déclaré et "
                      + "ton test passé. C'est lui qui mesure ce que tu as retenu "
                      + "du cours."}
                </p>
              </div>
            </div>
          </div>
      )}

      {!verrouille && (
      <div className="card">
        <p className="eyebrow">{CHAPITRES.find((c) => c.id === chapId)?.nom}</p>
        <div className="seg" style={{ marginTop: 12 }}>
          {TYPES_VIDEO.map((t) => (
            <button key={t} className={onglet === t ? "on" : ""} onClick={() => setOnglet(t)}>
              {t}{chap.videos.filter((v) => v.type === t).length ? " (" + chap.videos.filter((v) => v.type === t).length + ")" : ""}
            </button>
          ))}
        </div>

        {videos.length === 0 && (
          <p className="small muted">Aucune video dans cet onglet pour ce chapitre.</p>
        )}

        {videos.map((v) => (
          <div key={v.id} style={{ marginTop: 14 }}>
            <h4>{v.titre}</h4>
            <p className="small muted" style={{ marginTop: 2 }}>{v.duree || ""}</p>
            {/* Un fichier vidéo déposé directement se lit avec le lecteur du
                navigateur : pas besoin d'un cadre d'intégration. */}
            {/\.(mp4|webm|mov|m4v)(\?|$)/i.test(v.url || "") ? (
              <video controls src={v.url} style={{ width: "100%", marginTop: 10,
                borderRadius: 14, border: "1px solid var(--line)" }} />
            ) : lecteurVimeo(v.url) ? (
              <div style={{ position: "relative", paddingTop: "56.25%", marginTop: 10, borderRadius: 14, overflow: "hidden", border: "1px solid var(--line)" }}>
                <iframe
                  src={lecteurVimeo(v.url)} title={v.titre} loading="lazy"
                  allow="autoplay; fullscreen; picture-in-picture" allowFullScreen
                  style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: 0 }}
                />
              </div>
            ) : (
              <div className="lock" style={{ marginTop: 10 }}>
                <Icon d={I.play} size={17} />
                {v.url ? "Ce lien n'est pas reconnu comme une vidéo. Signale-le à ton coach."
                       : "Vidéo pas encore déposée par le coach."}
              </div>
            )}
          </div>
        ))}
      </div>
      )}

      {/* Le carnet appartient au module Grand oral : il se ferme avec lui. */}
      {ajouterAuCarnet && (
      <div className="card" style={{ borderColor: "#D6DEFB" }}>
        <div className="between">
          <span className="eyebrow">Carnet de pistes · Grand oral</span>
          {carnet.length > 0 && <span className="tag">{carnet.length} piste(s)</span>}
        </div>
        <p className="small muted" style={{ marginTop: 6 }}>
          Une question vous vient en travaillant ce chapitre ? Notez-la maintenant.
          En janvier, vous ne partirez pas d'une page blanche.
        </p>
        <div className="composer">
          <textarea rows={2} value={piste} onChange={(e) => setPiste(e.target.value)}
            placeholder="Ex. pourquoi le sel fait fondre la glace ?" />
          <button className="btn btn-accent btn-sm" disabled={piste.trim().length < 8}
            onClick={() => { ajouterAuCarnet({ chapId, txt: piste.trim(), source: "chapitre", note: "" }); setPiste(""); }}>
            Noter
          </button>
        </div>
        {carnet.filter((p) => p.chapId === chapId).map((p) => (
          <div className="res" key={p.id}>
            <span className="ico"><Icon d={I.micro} size={18} /></span>
            <div style={{ flex: 1 }}>
              <h4>{p.txt}</h4>
              {p.note && <p className="small muted">{p.note}</p>}
            </div>
            {retirerDuCarnetParTexte && (
              <button className="btn btn-ghost btn-sm" onClick={() => retirerDuCarnetParTexte(p.txt)}>Retirer</button>
            )}
          </div>
        ))}
      </div>
      )}

      {/* Les fiches sont VERROUILLÉES comme les vidéos : ce sont elles que
          l'élève relit, et les laisser ouvertes vidait le verrou de son sens. */}
      {!verrouille && (
      <div className="card">
        <h3>Fiches de revision</h3>
        {/* LA FICHE EXPRESS accompagne la fiche complète : même verrou, même
            liste. L'élève choisit selon le temps dont il dispose. */}
        {[...chap.fiches, ...(chap.fichesExpress || [])].length === 0
          && <p className="small muted" style={{ marginTop: 8 }}>Aucune fiche pour ce chapitre.</p>}
        {[...chap.fiches, ...(chap.fichesExpress || [])].map((f) => (
          <div className="res" key={f.id}>
            <span className="ico"><Icon d={I.pdf} size={18} /></span>
            <div style={{ flex: 1 }}>
              <h4>{f.titre}</h4>
              <p className="small muted">{f.pages ? f.pages + " pages" : "PDF"}</p>
            </div>
            {f.url
              ? <a className="btn btn-ghost btn-sm" href={f.url} target="_blank" rel="noreferrer">Ouvrir</a>
              : <span className="tag grey">a deposer</span>}
          </div>
        ))}
      </div>
      )}
    </div>
  );
}

/* Suivi de demonstration : ce que verra le coach quand ses eleves auront
   commence leur preparation. */
const ORAL_DEMO = [
  { nom: "Léa", classe: "Term 3", semainesRestantes: 18, etape: 2, statut: "soumise",
    question: "Pourquoi le sel fait-il fondre la glace sur les routes ?",
    ancrage: "Mon oncle est agent de la voirie, il en répand tous les hivers.",
    chapId: "cin", prises: 0, tirages: 0, sechees: 0, oralBlanc: false, statutPlan: "brouillon", plan: [] },
  { nom: "Malik", classe: "Term 5", semainesRestantes: 18, etape: 4, statut: "validee",
    question: "Comment un casque à réduction de bruit fait-il disparaître le bruit ?",
    ancrage: "Je m'en sers dans le train pour réviser.",
    chapId: "ond", prises: 2, tirages: 3, sechees: 2, oralBlanc: true,
    statutPlan: "soumis", plan: [
      "Ce qu'est un bruit : une onde sonore et ses caractéristiques",
      "Le principe de l'onde en opposition de phase, et les interférences destructives",
      "Pourquoi ça marche mieux sur un moteur que sur une voix : la question des fréquences",
    ] },
  { nom: "Inès", classe: "Term 2", semainesRestantes: 18, etape: 1, statut: "brouillon",
    question: "", ancrage: "", chapId: null, prises: 0, tirages: 0, sechees: 0, oralBlanc: false,
    statutPlan: "brouillon", plan: [] },
];

/* ========================= GRAND ORAL ===================================== */

function GrandOral({ oral, setOral, chapitres, semaine, idees = IDEES_ORAL, retirerDuCarnet, taches = [] }) {
  const [carrousel, setCarrousel] = useState(0);
  const [brouillon, setBrouillon] = useState(oral.question);
  const [ancrage, setAncrage] = useState(oral.ancrage);
  /* Le coach a pu renvoyer la question pendant que l'eleve etait ailleurs :
     on resynchronise les champs plutot que de les laisser vides. */
  useEffect(() => { setBrouillon(oral.question); setAncrage(oral.ancrage); },
    [oral.question, oral.ancrage, oral.statut]);
  const [tirage, setTirage] = useState(null);     // session en cours
  const [planVisible, setPlanVisible] = useState(false);
  const [bilan, setBilan] = useState(null);       // auto-evaluation juste apres la prise de son
  const maj = (champs) => setOral({ ...oral, ...champs });

  const chapsEnCours = chapitres.map((c) => c.id);
  /* Les idees sont classees selon ce que l'eleve maitrise reellement :
     diagnostic, feuilles blanches faites et exercices reussis. */
  const pool = classerIdeesOral(idees, chapitres, taches);
  const semainesRestantes = oral.semaineEpreuve ? oral.semaineEpreuve - semaine : null;

  /* ---------- date de l'epreuve ---------- */
  if (!oral.semaineEpreuve) {
    return (
      <div className="stack">
        <div>
          <p className="eyebrow">Grand oral</p>
          <h1 style={{ marginTop: 6 }}>Vingt minutes, dans combien de temps ?</h1>
        </div>
        <div className="card">
          <p className="small muted">
            L'epreuve dure 20 min : 10 min d'expose debout sans notes, puis 10 min d'echange avec le jury.
            Indiquez dans combien de semaines elle a lieu — le module s'organise a partir de la.
          </p>
          <div className="chips" style={{ marginTop: 14 }}>
            {[24, 20, 16, 12, 8, 4].map((n) => (
              <button key={n} className="chip" onClick={() => maj({ semaineEpreuve: semaine + n })}>
                dans {n} semaines
              </button>
            ))}
          </div>
          <p className="small muted" style={{ marginTop: 14 }}>
            Le bon moment pour commencer : environ cinq mois avant. Vous ne ferez qu'une seule tache
            Grand oral par semaine, en plus de votre travail habituel.
          </p>
        </div>
      </div>
    );
  }

  const idee = idees.find((i) => i.id === oral.ideeId) || null;
  const jury = idee ? idee.jury : [];

  /* ---------- session de tirage ---------- */
  if (tirage) {
    const q = tirage.questions[tirage.index];
    const fini = tirage.index >= tirage.questions.length;
    if (fini) {
      return (
        <div className="stack">
          <div><p className="eyebrow">Session terminee</p><h1 style={{ marginTop: 6 }}>Cinq questions, dix minutes</h1></div>
          <div className="card">
            {tirage.resultats.map((r, k) => (
              <div className="res" key={k}>
                <span className="ico"><Icon d={I.micro} size={18} /></span>
                <div style={{ flex: 1 }}><h4>{r.q}</h4></div>
                <span className={"tag " + (r.res === "repondu" ? "green" : r.res === "hesite" ? "gold" : "red")}>{r.res}</span>
              </div>
            ))}
            <p className="small muted" style={{ marginTop: 12 }}>
              Les questions sechees reviendront a la prochaine session. Vos enregistrements sont envoyes au coach.
            </p>
            <button className="btn btn-gold btn-block" style={{ marginTop: 14 }}
              onClick={() => {
                const sechees = tirage.resultats.filter((r) => r.res !== "repondu").map((r) => r.q);
                maj({
                  tirages: [...oral.tirages, { semaine, resultats: tirage.resultats }],
                  sechees: [...new Set([...oral.sechees, ...sechees])],
                  etape: Math.max(oral.etape, 4),
                });
                setTirage(null);
              }}>
              Enregistrer la session
            </button>
          </div>
        </div>
      );
    }
    return (
      <div className="stack">
        <div className="between">
          <div><p className="eyebrow">Tirage · question {tirage.index + 1} sur {tirage.questions.length}</p>
            <h1 style={{ marginTop: 6, fontSize: "1.35rem" }}>{q}</h1></div>
          <button className="btn btn-ghost btn-sm" onClick={() => setTirage(null)}>Quitter</button>
        </div>
        <div className="card">
          <p className="small muted">
            30 secondes pour reflechir, puis 2 minutes de reponse enregistree. Sans notes, comme le jour J.
          </p>
          <Enregistreur onEnvoyer={() => {}} />
          <p className="eyebrow" style={{ marginTop: 18 }}>Comment ca s'est passe ?</p>
          <div className="row" style={{ marginTop: 10 }}>
            {["repondu", "hesite", "seche"].map((r) => (
              <button key={r} className="chip"
                onClick={() => setTirage({ ...tirage, index: tirage.index + 1,
                  resultats: [...tirage.resultats, { q, res: r }] })}>
                {r === "repondu" ? "Repondu" : r === "hesite" ? "Hesite" : "Seche"}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  /* ---------- ecran principal ---------- */
  return (
    <div className="stack">
      <div className="between">
        <div>
          <p className="eyebrow">Grand oral · dans {semainesRestantes} semaine(s)</p>
          <h1 style={{ marginTop: 6 }}>Ma preparation</h1>
        </div>
        <span className="tag">{oral.etape}/5</span>
      </div>

      {oral.notif && !oral.notif.lu && (
        <div className="card" style={oral.notif.type === "validee"
          ? { borderColor: "#CBE9DD", background: "#F2FBF7" }
          : { borderColor: "#F2E1BC", background: "#FFFDF8" }}>
          <div className="between">
            <span className="eyebrow" style={{ color: oral.notif.type === "validee" ? "#1E6E52" : "#7A5A12" }}>
              Retour du coach
            </span>
            <span className={"tag " + (oral.notif.type === "validee" ? "green" : "gold")}>
              {oral.notif.type === "validee" ? "question validée" : "à reformuler"}
            </span>
          </div>
          <p style={{ marginTop: 10, color: "var(--ink)" }}>{oral.notif.txt}</p>
          <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }}
            onClick={() => maj({ notif: { ...oral.notif, lu: true } })}>
            J'ai lu
          </button>
        </div>
      )}

      {/* retroplanning */}
      <div className="card dark">
        <span className="eyebrow" style={{ color: "#8FA6F7" }}>Retroplanning</span>
        <div style={{ marginTop: 12 }}>
          {JALONS_ORAL.map((j) => {
            const enRetard = semainesRestantes !== null && semainesRestantes < j.semainesAvant && oral.etape < j.etape;
            const fait = oral.etape > j.etape;
            return (
              <div className="row" key={j.etape} style={{ padding: "8px 0", gap: 10 }}>
                <span className={"tag " + (fait ? "green" : enRetard ? "red" : "grey")}>
                  {fait ? "fait" : "S-" + j.semainesAvant}
                </span>
                <span className="small" style={{ flex: 1 }}>{j.libelle}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* etape 1 : la question */}
      <div className="card">
        <div className="between">
          <h3>1 · La question</h3>
          <span className={"tag " + (oral.statut === "validee" ? "green" : oral.statut === "soumise" ? "gold" : "grey")}>
            {oral.statut === "validee" ? "validee" : oral.statut === "soumise" ? "chez le coach" : "a faire"}
          </span>
        </div>

        {oral.statut === "brouillon" && !oral.ideeId && !oral.libre && (
          <>
            <p className="small muted" style={{ marginTop: 8 }}>
              Une seule question en physique-chimie — l'autre porte sur votre seconde specialite.
            </p>

            {/* le carnet de pistes, rempli toute l'annee */}
            {oral.carnet.length > 0 && (
              <div className="card" style={{ marginTop: 12, background: "var(--surface-alt)" }}>
                <div className="between">
                  <span className="eyebrow">Votre carnet de pistes</span>
                  <span className="tag">{oral.carnet.length}</span>
                </div>
                <p className="small muted" style={{ marginTop: 6 }}>
                  Ce que vous avez note pendant l'annee, depuis un chapitre ou la permanence.
                </p>
                {oral.carnet.map((p) => (
                  <div className="res" key={p.id}>
                    <span className="ico"><Icon d={I.micro} size={18} /></span>
                    <div style={{ flex: 1 }}>
                      <h4>{p.txt}</h4>
                      {p.note && <p className="small" style={{ color: "var(--ink)" }}>{p.note}</p>}
                      <p className="small muted">
                        {CHAPITRES.find((c) => c.id === p.chapId)?.court || "—"} · noté en semaine {p.semaine}
                        {p.source === "permanence" ? " · depuis la permanence" : ""}
                      </p>
                      <div className="row" style={{ marginTop: 8, gap: 8 }}>
                        <button className="btn btn-gold btn-sm"
                          onClick={() => { setBrouillon(p.txt); setAncrage(p.note || ""); maj({ libre: true, chapId: p.chapId }); }}>
                          Partir de là
                        </button>
                        {retirerDuCarnet && (
                          <button className="btn btn-ghost btn-sm" onClick={() => retirerDuCarnet(p.id)}>Retirer</button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="row" style={{ marginTop: 14, gap: 8 }}>
              <button className="btn btn-ghost btn-sm" onClick={() => maj({ libre: true })}>
                J'ai deja une idee
              </button>
            </div>

            <p className="small muted" style={{ marginTop: 14 }}>
              Pas d'idee ? Voici trois pistes, tirees des chapitres que vous travaillez.
            </p>
            <p className="small muted" style={{ marginTop: 10 }}>
              Elles sont classees d'apres vos resultats : le jury creuse pendant dix minutes,
              mieux vaut un chapitre que vous tenez.
            </p>
            {pool.slice(carrousel, carrousel + 3).map((i) => (
              <div className="card" key={i.id} style={{ marginTop: 12, background: "var(--surface-alt)" }}>
                <div className="between">
                  <h4 style={{ fontSize: "1rem", lineHeight: 1.3 }}>{i.question}</h4>
                  <span className={"tag " + (i.niveau === "accessible" ? "green" : "gold")}>{i.niveau}</span>
                </div>
                <p className="small muted" style={{ marginTop: 6 }}>
                  {CHAPITRES.find((c) => c.id === i.chapId)?.court} · {i.notions}
                </p>
                <p className="small" style={{ marginTop: 6, color: i.alerte ? "#7A5A12" : "var(--green)" }}>
                  {i.raison}
                </p>
                <button className="btn btn-gold btn-sm btn-block" style={{ marginTop: 12 }}
                  onClick={() => { maj({ ideeId: i.id, chapId: i.chapId }); setBrouillon(i.question); }}>
                  Je choisis cette question
                </button>
              </div>
            ))}

            <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 14 }}
              onClick={() => setCarrousel((c) => (c + 3) % Math.max(1, pool.length))}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" width="16" height="16" aria-hidden="true">
                <path d="M4 12a8 8 0 0 1 13.6-5.7L20 8" /><path d="M20 4v4h-4" />
                <path d="M20 12a8 8 0 0 1-13.6 5.7L4 16" /><path d="M4 20v-4h4" />
              </svg>
              Voir trois autres idées
            </button>
          </>
        )}

        {oral.statut !== "validee" && oral.statut !== "soumise" && (oral.ideeId || oral.libre) && (
          <>
            {oral.commentaire && (
              <div className="card" style={{ marginTop: 10, background: "#FFFDF8", borderColor: "#F2E1BC" }}>
                <span className="eyebrow" style={{ color: "#7A5A12" }}>Ce que le coach demande</span>
                <p className="small" style={{ marginTop: 6, color: "var(--ink)" }}>{oral.commentaire}</p>
              </div>
            )}
            {(() => {
              const choisie = pool.find((i) => i.id === oral.ideeId);
              return choisie && choisie.alerte ? (
                <p className="small" style={{ marginTop: 10, color: "#7A5A12" }}>{choisie.raison}</p>
              ) : null;
            })()}
            <p className="small muted" style={{ marginTop: 10 }}>
              Reecrivez-la avec vos mots : le jury reconnait une question recopiee. Puis dites d'ou elle vous parle.
            </p>
            <textarea className="inp" rows={2} style={{ width: "100%", marginTop: 10 }}
              placeholder="Votre question, formulee par vous"
              value={brouillon} onChange={(e) => setBrouillon(e.target.value)} />
            <textarea className="inp" rows={2} style={{ width: "100%", marginTop: 10 }}
              placeholder="D'ou ca vous parle : un TP, un objet, un sport, un exercice..."
              value={ancrage} onChange={(e) => setAncrage(e.target.value)} />
            <p className="small muted" style={{ marginTop: 10 }}>
              Test des 90 secondes : enregistrez-vous en expliquant pourquoi cette question vous interesse.
              Si vous sechez avant la fin, ce n'est pas la bonne.
            </p>
            <Enregistreur onEnvoyer={() => {}} />
            <button className="btn btn-gold btn-block" style={{ marginTop: 14 }}
              disabled={brouillon.trim().length < 12 || ancrage.trim().length < 10}
              onClick={() => maj({ question: brouillon.trim(), ancrage: ancrage.trim(), statut: "soumise",
                libre: false, commentaire: "", notif: null, etape: Math.max(oral.etape, 2) })}>
              Soumettre au coach
            </button>
            <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 10 }}
              onClick={() => { maj({ ideeId: null, libre: false, chapId: null }); setBrouillon(""); }}>
              Revoir mes pistes et les idees
            </button>
          </>
        )}

        {oral.statut === "soumise" && (
          <>
            <p style={{ marginTop: 12, color: "var(--ink)" }}>{oral.question}</p>
            <p className="small muted" style={{ marginTop: 6 }}>{oral.ancrage}</p>
            <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }}
              onClick={() => maj({ statut: "validee", etape: Math.max(oral.etape, 2) })}>
              (demo) Le coach valide
            </button>
          </>
        )}

        {oral.statut === "validee" && (
          <>
            <p style={{ marginTop: 12, color: "var(--ink)" }}>{oral.question}</p>
            <span className="tag green" style={{ marginTop: 10, display: "inline-block" }}>Validee par le coach</span>
          </>
        )}
      </div>

      {/* etape 2 : le plan */}
      {oral.statut === "validee" && (
        <div className="card">
          <div className="between">
            <h3>2 · La colonne vertebrale</h3>
            <span className={"tag " + (oral.statutPlan === "valide" ? "green" : oral.statutPlan === "soumis" ? "gold" : "grey")}>
              {oral.statutPlan === "valide" ? "validé" : oral.statutPlan === "soumis" ? "chez le coach" : "à faire"}
            </span>
          </div>

          {oral.commentairePlan && oral.statutPlan !== "valide" && (
            <div className="card" style={{ marginTop: 10, background: "#FFFDF8", borderColor: "#F2E1BC" }}>
              <span className="eyebrow" style={{ color: "#7A5A12" }}>Ce que le coach demande</span>
              <p className="small" style={{ marginTop: 6, color: "var(--ink)" }}>{oral.commentairePlan}</p>
            </div>
          )}

          {oral.statutPlan === "soumis" || oral.statutPlan === "valide" ? (
            <>
              {oral.plan.map((t, k) => (
                <p key={k} className="small" style={{ marginTop: 10, color: "var(--ink)" }}>
                  <b>Temps {k + 1}.</b> {t}
                </p>
              ))}
              {oral.statutPlan === "soumis" && (
                <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 12 }}
                  onClick={() => maj({ statutPlan: "brouillon" })}>
                  Le reprendre avant que le coach le lise
                </button>
              )}
            </>
          ) : (
            <>
              <p className="small muted" style={{ marginTop: 6 }}>
                Trois temps, trois idees. {idee ? "Pistes possibles : " + idee.pistes.join(" · ") : ""}
              </p>
              {[0, 1, 2].map((k) => (
                <textarea key={k} className="inp" rows={2} style={{ width: "100%", marginTop: 10 }}
                  placeholder={"Temps " + (k + 1)}
                  value={oral.plan[k]}
                  onChange={(e) => { const plan = [...oral.plan]; plan[k] = e.target.value; maj({ plan }); }} />
              ))}
              <button className="btn btn-gold btn-block" style={{ marginTop: 12 }}
                disabled={oral.plan.some((t) => t.trim().length < 8)}
                onClick={() => maj({ statutPlan: "soumis", commentairePlan: "" })}>
                Envoyer le plan au coach
              </button>
            </>
          )}
        </div>
      )}

      {/* Le plan est parti, on attend le coach : on le dit, plutot que d'ouvrir
          la suite trop tot. */}
      {oral.statutPlan === "soumis" && (
        <div className="card" style={{ borderColor: "#F2E1BC", background: "#FFFDF8" }}>
          <div className="between">
            <h3>3 · La mise en voix</h3>
            <span className="tag gold">en attente</span>
          </div>
          <p className="small muted" style={{ marginTop: 8 }}>
            Elle s'ouvrira des que votre coach aura valide votre plan. Inutile de vous enregistrer
            sur une colonne vertebrale qui va peut-etre changer.
          </p>
        </div>
      )}

      {/* etape 3 : la mise en voix, une fois le plan valide */}
      {oral.statutPlan === "valide" && (
        <div className="card">
          <div className="between">
            <h3>3 · La mise en voix</h3>
            <span className={"tag " + (oral.prises.length >= 3 ? "green" : oral.prises.length ? "gold" : "grey")}>
              {oral.prises.length} prise(s) sur 3
            </span>
          </div>

          <p className="small muted" style={{ marginTop: 6 }}>
            Le jour J, vous parlez <b>dix minutes debout, sans notes</b>. Ici, c'est la meme chose :
            vous vous enregistrez d'une traite, sans vous arreter, meme si vous vous perdez.
            Un blanc de dix secondes vaut mieux qu'un dixieme essai.
          </p>

          <div className="card" style={{ marginTop: 12, background: "var(--surface-alt)" }}>
            <span className="eyebrow">Ce qu'on attend de vous · 10 minutes</span>
            <div style={{ marginTop: 10 }}>
              {[
                ["0:00 – 0:40", "L'accroche", "Une situation concrete, la votre : celle que vous avez ecrite en ancrage."],
                ["0:40 – 1:10", "La question et l'annonce", "Vous posez votre question, puis vous annoncez vos trois temps."],
                ["1:10 – 4:00", "Temps 1", "La mise en place : de quoi parle-t-on, quelles grandeurs, quelles lois."],
                ["4:00 – 7:00", "Temps 2", "Le coeur scientifique : le raisonnement, une relation, un ordre de grandeur."],
                ["7:00 – 9:00", "Temps 3", "La consequence, la limite, ou le cas particulier qui nuance."],
                ["9:00 – 10:00", "La conclusion", "Vous repondez a votre question, et vous ouvrez sur une suite."],
              ].map(([t, titre, quoi]) => (
                <div className="jour-mini" key={t} style={{ display: "flex", gap: 12, padding: "9px 0", borderBottom: "1px solid var(--line)" }}>
                  <span style={{ fontFamily: "var(--fm)", fontSize: ".68rem", color: "var(--accent-2)", width: 84, flex: "none" }}>{t}</span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <b style={{ color: "var(--ink)", fontSize: ".92rem" }}>{titre}</b>
                    <span className="small muted" style={{ display: "block" }}>{quoi}</span>
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* son plan, a relire avant — pas pendant */}
          {oral.plan.some((t) => t.trim()) && (
            <>
              <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 12 }}
                onClick={() => setPlanVisible(!planVisible)}>
                {planVisible ? "Masquer mon plan (on parle sans notes)" : "Relire mon plan une derniere fois"}
              </button>
              {planVisible && (
                <div className="card" style={{ marginTop: 10, background: "#F4F3FF", borderColor: "#DCD9FF" }}>
                  {oral.plan.map((t, k) => (
                    <p className="small" key={k} style={{ marginTop: k ? 8 : 0, color: "var(--ink)" }}>
                      <b>Temps {k + 1}.</b> {t}
                    </p>
                  ))}
                  <p className="small muted" style={{ marginTop: 10 }}>
                    Fermez-le avant de lancer l'enregistrement : lire son plan a l'ecran, c'est deja tricher.
                  </p>
                </div>
              )}
            </>
          )}

          <Enregistreur max={600} libelle="Lancer ma prise de son (10 min)"
            onEnvoyer={(blob, duree) => { setBilan({ duree }); setPlanVisible(false); }} />

          <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 10 }}
            onClick={() => setBilan({ duree: null, horsApp: true })}>
            Je l'ai fait sans l'application
          </button>

          {/* auto-evaluation juste apres */}
          {bilan && (
            <div className="card" style={{ marginTop: 12, borderColor: "#DCD9FF" }}>
              <span className="eyebrow">Juste apres, a chaud</span>
              {bilan.duree != null && (
                <p className="small muted" style={{ marginTop: 6 }}>
                  Vous avez parle {Math.floor(bilan.duree / 60)} min {String(bilan.duree % 60).padStart(2, "0")} s.
                  {bilan.duree < 480 ? " C'est court : le jury attend dix minutes pleines." : " Bonne duree."}
                </p>
              )}
              {[
                ["tenu", "J'ai tenu jusqu'au bout sans m'arreter"],
                ["notes", "Je n'ai regarde aucune note"],
                ["annonce", "J'ai annonce mes trois temps au debut"],
                ["ouverture", "J'ai conclu par une ouverture"],
              ].map(([cle, txt]) => (
                <button key={cle} className={"chip" + (bilan[cle] ? " on" : "")}
                  style={{ display: "block", width: "100%", textAlign: "left", marginTop: 8 }}
                  onClick={() => setBilan({ ...bilan, [cle]: !bilan[cle] })}>
                  {bilan[cle] ? "✓ " : "○ "}{txt}
                </button>
              ))}
              <button className="btn btn-gold btn-block" style={{ marginTop: 12 }}
                onClick={() => {
                  maj({
                    prises: [...oral.prises, { semaine, duree: bilan.duree, horsApp: Boolean(bilan.horsApp),
                      tenu: !!bilan.tenu, notes: !!bilan.notes, annonce: !!bilan.annonce, ouverture: !!bilan.ouverture }],
                    etape: Math.max(oral.etape, 4),
                  });
                  setBilan(null);
                }}>
                Envoyer au coach
              </button>
            </div>
          )}

          {oral.prises.length > 0 && (
            <div style={{ marginTop: 14 }}>
              {oral.prises.map((p, k) => (
                <div className="res" key={k}>
                  <span className="ico"><Icon d={I.micro} size={18} /></span>
                  <div style={{ flex: 1 }}>
                    <h4>Prise {k + 1}{p.duree != null ? " · " + Math.floor(p.duree / 60) + " min " + String(p.duree % 60).padStart(2, "0") : " · hors application"}</h4>
                    <p className="small muted">
                      semaine {p.semaine}
                      {p.tenu ? " · tenu jusqu'au bout" : ""}
                      {p.notes ? " · sans notes" : ""}
                    </p>
                  </div>
                </div>
              ))}
              <p className="small muted" style={{ marginTop: 10 }}>
                Objectif : trois prises d'ici l'epreuve. La premiere sert a decouvrir combien dix minutes,
                c'est long. La troisieme, a ne plus y penser.
              </p>
            </div>
          )}
        </div>
      )}

      {/* etape 4 : le tirage — il ne depend que de la question validee */}
      {oral.statut === "validee" && (
        <div className="card">
          <div className="between">
            <h3>4 · Les 10 minutes d'echange</h3>
            <span className="tag grey">{oral.tirages.length} session(s)</span>
          </div>
          <p className="small muted" style={{ marginTop: 6 }}>
            Cinq questions tirees au hasard, 30 s de reflexion, 2 min de reponse. C'est la moitie de la note,
            et c'est la partie que personne ne travaille.
          </p>
          {oral.sechees.length > 0 && (
            <p className="small" style={{ marginTop: 8, color: "#7A5A12" }}>
              {oral.sechees.length} question(s) sechee(s) reviendront en priorite.
            </p>
          )}
          <button className="btn btn-accent btn-block" style={{ marginTop: 12 }}
            disabled={!jury.length}
            onClick={() => {
              const prioritaires = jury.filter((q) => oral.sechees.includes(q));
              const autres = jury.filter((q) => !oral.sechees.includes(q)).sort(() => Math.random() - 0.5);
              setTirage({ index: 0, resultats: [], questions: [...prioritaires, ...autres].slice(0, 5) });
            }}>
            Lancer une session de tirage
          </button>
        </div>
      )}

      {/* etape 5 : l'oral blanc, une fois le plan valide et l'entrainement commence */}
      {oral.statutPlan === "valide" && (oral.prises.length > 0 || oral.tirages.length > 0) && (
        <div className="card">
          <h3>5 · L'oral blanc</h3>
          <p className="small muted" style={{ marginTop: 6 }}>
            En visio avec le coach : 20 min de preparation chronometrees, 10 min d'expose, 10 min d'echange,
            puis la grille officielle et une note indicative.
          </p>
          <div className="row" style={{ marginTop: 12 }}>
            <button className="btn btn-gold btn-sm" onClick={() => maj({ oralBlanc: { demande: true }, etape: 5 })}>
              Demander un creneau
            </button>
            {oral.oralBlanc?.demande && <span className="tag gold">demande envoyee</span>}
          </div>
        </div>
      )}

      {oral.carnet.length > 0 && oral.statut === "validee" && (
        <div className="card">
          <div className="between">
            <h3>Votre carnet de pistes</h3>
            <span className="tag grey">{oral.carnet.length}</span>
          </div>
          <p className="small muted" style={{ marginTop: 6 }}>
            Gardez-les : elles nourrissent vos exemples pendant les dix minutes d'echange.
          </p>
          {oral.carnet.map((p) => (
            <div className="res" key={p.id}>
              <span className="ico"><Icon d={I.chat} size={18} /></span>
              <div style={{ flex: 1 }}><h4>{p.txt}</h4>
                <p className="small muted">{CHAPITRES.find((c) => c.id === p.chapId)?.court || "—"}</p></div>
              {retirerDuCarnet && (
                <button className="btn btn-ghost btn-sm" onClick={() => retirerDuCarnet(p.id)}>Retirer</button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* la seconde question, pour information */}
      <div className="card">
        <h3>Votre seconde question</h3>
        <p className="small muted" style={{ marginTop: 6 }}>
          Celle de votre autre specialite. On ne la travaille pas ici, mais le jury peut la choisir :
          notez-la pour que le coach sache sur quoi vous serez interroge.
        </p>
        <textarea className="inp" rows={2} style={{ width: "100%", marginTop: 10 }}
          placeholder="Question de votre seconde specialite"
          value={oral.secondeQuestion} onChange={(e) => maj({ secondeQuestion: e.target.value })} />
      </div>
    </div>
  );
}

/* ========================= PROGRÈS ======================================== */

/* L'écran CONTRÔLES : ce que l'élève vise, et ce qu'il a déjà passé.

   Il rassemble ce qui était éparpillé — la date du contrôle, l'épreuve blanche,
   les sujets Labolycée non traités, les gestes non acquis — pour qu'un élève
   voie d'un coup ce qu'il lui reste à faire avant l'échéance.

   Les sujets non traités restent VERROUILLÉS tant que l'épreuve blanche n'est
   pas rendue : elle doit mesurer ce qu'il sait vraiment, pas ce qu'il vient de
   réviser dessus. */
/* LA VEILLE DU CONTRÔLE. L'élève a composé son épreuve blanche l'avant-veille,
   le coach l'a corrigée : ce soir-là sert à relire ses erreurs et les conseils
   reçus, pas à faire un exercice de plus. */
function Reprise({ tache, copies = [], onFini, onQuit }) {
  const [page, setPage] = useState(null);
  const chaps = tache.chapitresEval || [tache.chapId];
  /* Même tolérance : une copie sans chapitres reste consultable. */
  const corrigees = copies.filter((c) => c.corrigee || c.correction);
  const copie = corrigees.find((c) => (c.chapitres || []).some((x) => chaps.includes(x)))
    || corrigees.find((c) => !(c.chapitres || []).length);
  const corr = copie?.correction || null;

  return (
    <div className="b"><style>{CSS}</style>
      {page && (
        <div className="voile" onClick={() => setPage(null)}>
          <img src={page} alt="page corrigée"
            style={{ maxWidth: "94%", maxHeight: "90%", borderRadius: 12 }}
            onClick={(e) => e.stopPropagation()} />
        </div>
      )}
      <div className="wrapc">
        <div className="between">
          <div>
            <p className="eyebrow">Veille du contrôle</p>
            <h1 style={{ marginTop: 6 }}>Reprends tes erreurs</h1>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={onQuit}>Quitter</button>
        </div>

        {corr ? (
          <>
            {corr.texte && (
              <div className="card" style={{ marginTop: 14 }}>
                <span className="eyebrow">Ce que dit ton coach</span>
                <p className="small" style={{ marginTop: 8, lineHeight: 1.55 }}>{corr.texte}</p>
              </div>
            )}
            {corr.vocal && (
              <div className="card" style={{ marginTop: 12 }}>
                <span className="eyebrow">Son message vocal</span>
                <audio controls src={corr.vocal.url || corr.vocal}
                  style={{ width: "100%", marginTop: 8, height: 36 }} />
              </div>
            )}
            {corr.cheminAnnotee && (
              <div className="card" style={{ marginTop: 12 }}>
                <span className="eyebrow">Ta copie annotée</span>
                <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 10 }}
                  onClick={async () => {
                    const url = await lienCopieAnnotee(corr.cheminAnnotee);
                    if (url) window.open(url, "_blank", "noopener");
                  }}>
                  Ouvrir le PDF
                </button>
              </div>
            )}
            {(corr.annotees || []).length > 0 && (
              <div className="card" style={{ marginTop: 12 }}>
                <span className="eyebrow">Ta copie annotée</span>
                <p className="small muted" style={{ marginTop: 4 }}>
                  Appuie sur une page pour la lire en grand.
                </p>
                <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                  {corr.annotees.map((a, k) => (
                    <button key={k} style={{ padding: 0, border: "none", background: "none",
                      cursor: "pointer" }} onClick={() => setPage(a.data || a)}>
                      <img src={a.data || a} alt={"page " + (k + 1)}
                        style={{ width: 88, borderRadius: 8, border: "1px solid var(--line)" }} />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="card" style={{ marginTop: 14, borderColor: "#E4D3AC",
            background: "#FDF8EE" }}>
            <h3>Ta copie n'est pas encore corrigée</h3>
            <p className="small" style={{ marginTop: 6, color: "#7A5A12" }}>
              Reprends ton épreuve blanche avec ta fiche : refais les questions
              sur lesquelles tu as hésité. La correction de ton coach arrivera
              ici dès qu'il l'aura rendue.
            </p>
          </div>
        )}

        <button className="btn btn-accent btn-block" style={{ marginTop: 18 }}
          onClick={() => onFini(tache, "acquis")}>
          J'ai repris mes erreurs
        </button>
      </div>
    </div>
  );
}

function Controles({ controle, controlesPasses = [], chapitres, taches, semaine,
                     vus = [], ressources = {}, copies = [], setRun, setEval_,
                     onEntrainementLibre, travaillerGeste, biblio = {}, ancreLe = null,
                     jour = 0 }) {
  /* La page annotée que l'élève regarde en grand : une vignette de 72 px ne se
     lit pas sur un téléphone. */
  const [pageOuverte, setPageOuverte] = useState(null);

  const nomDe = (id) => (id === METHODE ? NOM_METHODE
    : CHAPITRES.find((c) => c.id === id)?.nom || id);

  const ficheContro = (ctrl, passe) => {
    const chaps = ctrl.chapitres || [];
    const blanche = taches.find((t) => t.type === "blanche"
      && (t.chapitresEval || [t.chapId]).some((x) => chaps.includes(x)));
    const rendue = !!copies.find((c) => (c.chapitres || []).some((x) => chaps.includes(x)))
      || (blanche && blanche.statut === "fait");

    /* Les sujets Labolycée de ces chapitres que l'élève n'a pas traités. */
    const restants = chaps.flatMap((cid) =>
      (SUJETS_BAC[cid] || []).filter((sj) => !vus.includes(sj.id))
        .map((sj) => ({ ...sj, chapId: cid })));
    const faits = chaps.flatMap((cid) =>
      (SUJETS_BAC[cid] || []).filter((sj) => vus.includes(sj.id)));

    /* Les gestes : acquis au test, ou encore à reprendre. */
    const gestes = chaps.flatMap((cid) => {
      const c = chapitres.find((x) => x.id === cid);
      const tous = Object.keys(TITRES_QT[cid] || {}).filter((k) => k.startsWith("QT"));
      const rates = (c && c.qtRatees) || [];
      return tous.map((k) => ({ cid, k, titre: (TITRES_QT[cid] || {})[k],
                                acquis: !rates.includes(k) }));
    });
    const aReprendre = gestes.filter((g) => !g.acquis);

    const libre = chaps.map((cid) => ((ressources[cid] || {}).libres || [])[0])
      .filter(Boolean)[0];

    const j = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"][ctrl.jour] || "";
    const dans = (ctrl.semaine - semaine) * 7 + (ctrl.jour || 0);

    return (
      <div className="card" key={ctrl.semaine + "-" + ctrl.jour} style={{ marginTop: 12 }}>
        <div className="between">
          <span className="eyebrow">{passe ? "Passé" : "À venir"}</span>
          {!passe && (
            <span className={"tag " + (dans <= 3 ? "gold" : "")}>
              {dans <= 0 ? "cette semaine" : "dans " + dans + " jour" + (dans > 1 ? "s" : "")}
            </span>
          )}
        </div>
        <h3 style={{ marginTop: 6 }}>{chaps.map(nomDe).join(" · ")}</h3>
        <p className="small muted" style={{ marginTop: 2 }}>
          {/* La DATE RÉELLE : « mercredi de la semaine 3 » ne dit rien à un
              élève qui a son contrôle noté au 16 septembre sur son cahier. */}
          {(() => {
            const clair = jourEnClair(ancreLe, ctrl.semaine, ctrl.jour);
            if (clair) return passe ? "Passé le " + clair : clair;
            return passe ? "Semaine " + ctrl.semaine
                         : j + " de la semaine " + ctrl.semaine;
          })()}
        </p>

        {/* L'épreuve blanche : l'étape qui commande tout le reste. */}
        <div className="res" style={{ marginTop: 10 }}>
          <span className="ico"><Icon d={I.pdf} size={18} /></span>
          <div style={{ flex: 1 }}>
            <h4>Épreuve blanche</h4>
            <p className="small muted">2 h · deux jours avant le contrôle</p>
          </div>
          <span className={"tag " + (rendue ? "green" : blanche ? "gold" : "grey")}>
            {rendue ? "rendue" : blanche ? "programmée" : "à venir"}
          </span>
        </div>

        {/* LA COPIE CORRIGÉE. Elle arrivait en permanence, noyée dans les
            questions : c'est ici que l'élève la cherche, à côté de l'épreuve
            qu'il a composée. */}
        {(() => {
          /* Une copie SANS CHAPITRES est acceptée : celles rendues avant que
             l'application les enregistre n'en portent pas, et restaient
             introuvables — la correction n'arrivait jamais. */
          const corrigees = copies.filter((c) => c.corrigee || c.correction || c.note != null);
          const copie = corrigees.find((c) => (c.chapitres || []).some((x) => chaps.includes(x)))
            || corrigees.find((c) => !(c.chapitres || []).length);
          if (!copie) return null;
          const corr = copie.correction || null;
          return (
            <div className="res" style={{ marginTop: 10, alignItems: "flex-start",
              background: "#FDF8EE", borderRadius: 12, padding: "10px 12px" }}>
              <span className="ico"><Icon d={I.coche} size={18} /></span>
              <div style={{ flex: 1 }}>
                <h4>Ta copie corrigée</h4>
                <p className="small muted">
                  {copie.note != null ? "Note : " + copie.note : "Corrigée par ton coach"}
                  {copie.semaine ? " · semaine " + copie.semaine : ""}
                </p>
                {/* LE MOT DU COACH, son vocal et les pages annotées : l'élève
                    recevait une copie « corrigée » sans rien à lire. */}
                {corr && corr.texte && (
                  <p className="small" style={{ marginTop: 6, color: "#4A4E6E",
                    background: "#F4F6FE", borderRadius: 8, padding: "8px 10px" }}>
                    {corr.texte}
                  </p>
                )}
                {corr && corr.vocal && (
                  <audio controls src={corr.vocal.url || corr.vocal}
                    style={{ width: "100%", marginTop: 8, height: 34 }} />
                )}
                {/* Les pages annotées ne transitent PAS par l'état de l'élève :
                    deux photos pèsent près d'un méga-octet et l'écriture était
                    refusée. Le coach les envoie par la permanence, où elles
                    s'ouvrent en grand. */}
                {/* Le PDF de la copie annotée : stocké à part, on l'ouvre par
                    un lien signé plutôt que de le charger dans l'état. */}
                {corr && corr.cheminAnnotee && (
                  <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 8 }}
                    onClick={async () => {
                      const url = await lienCopieAnnotee(corr.cheminAnnotee);
                      if (url) window.open(url, "_blank", "noopener");
                    }}>
                    Ouvrir ma copie annotée
                  </button>
                )}
                {corr && (corr.annotees || []).length > 0 && (
                  <>
                    <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: "wrap" }}>
                      {corr.annotees.map((a, k) => (
                        <button key={k} style={{ padding: 0, border: "none", background: "none",
                          cursor: "pointer" }}
                          onClick={() => setPageOuverte(a.data || a)}>
                          <img src={a.data || a} alt={"page " + (k + 1)}
                            style={{ width: 72, borderRadius: 8, border: "1px solid var(--line)" }} />
                        </button>
                      ))}
                    </div>
                    <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 8 }}
                      onClick={async () => {
                        const nom = "copie-corrigee-" + (copie.semaine || "") + ".pdf";
                        const ok = await copieEnPdf(corr.annotees, nom);
                        if (!ok) window.open(corr.annotees[0]?.data || corr.annotees[0], "_blank");
                      }}>
                      Télécharger ma copie corrigée
                    </button>
                  </>
                )}
              </div>
              {copie.url && (
                <button className="btn btn-ghost btn-sm"
                  onClick={() => window.open(copie.url, "_blank", "noopener")}>Ouvrir</button>
              )}
            </div>
          );
        })()}

        {/* Les sujets non traités, verrouillés avant l'épreuve. */}
        {restants.length > 0 && (
          <div style={{ marginTop: 12 }}>
            <div className="between">
              <h4>Sujets de bac non traités</h4>
              <span className="tag grey">{restants.length}</span>
            </div>
            {!rendue && (
              <p className="small" style={{ marginTop: 4, color: "#7A5A12" }}>
                Ils s'ouvriront après ton épreuve blanche : elle doit mesurer ce
                que tu sais déjà, pas ce que tu viens de réviser dessus.
              </p>
            )}
            {/* GROUPÉS PAR CHAPITRE, et tous affichés : la pastille annonçait
                seize sujets là où six seulement apparaissaient, mêlés sans
                distinction de chapitre. */}
            {chaps.map((cid) => {
              const dessus = restants.filter((sj) => sj.chapId === cid);
              if (!dessus.length) return null;
              const nom = CHAPITRES.find((x) => x.id === cid)?.nom || cid;
              return (
                <div key={cid} style={{ marginTop: 10 }}>
                  {chaps.length > 1 && (
                    <div className="between" style={{ marginBottom: 4 }}>
                      <span className="eyebrow" style={{ color: "var(--accent)" }}>{nom}</span>
                      <span className="tag grey">{dessus.length}</span>
                    </div>
                  )}
                  {dessus.map((sj) => (
              <div className="res" key={sj.id} style={{ alignItems: "flex-start",
                opacity: rendue ? 1 : 0.55 }}>
                <span className="ico">
                  <Icon d={rendue ? I.pdf : I.lock} size={18} />
                </span>
                <div style={{ flex: 1 }}>
                  <h4>{sj.titre}</h4>
                  <p className="small muted">{sj.session} · {sj.duree} min</p>
                  {rendue && sj.consigne && (
                    <p className="small" style={{ marginTop: 3, color: "#7A5A12" }}>{sj.consigne}</p>
                  )}
                </div>
                {rendue && sj.url && (
                  <button className="btn btn-ghost btn-sm"
                    onClick={() => window.open(sj.url, "_blank", "noopener")}>Ouvrir</button>
                )}
              </div>
            ))}
                </div>
              );
            })}
          </div>
        )}

        {faits.length > 0 && (
          <p className="small muted" style={{ marginTop: 10 }}>
            <b>{faits.length} sujet(s) déjà traité(s)</b> : {faits.map((x) => x.titre).join(" · ")}
          </p>
        )}

        {/* L'entraînement libre, pour celui qui revient après son épreuve. */}
        {rendue && libre && (
          <div className="res" style={{ marginTop: 10 }}>
            <span className="ico"><Icon d={I.book} size={18} /></span>
            <div style={{ flex: 1 }}>
              <h4>{libre.titre}</h4>
              <p className="small muted">Second sujet · sans rendu</p>
            </div>
            <button className="btn btn-ghost btn-sm"
              onClick={() => {
                if (libre.url) window.open(libre.url, "_blank", "noopener");
                if (onEntrainementLibre) onEntrainementLibre(chaps[0], libre.titre);
              }}>Faire</button>
          </div>
        )}

        {/* Les gestes DISPARAISSENT une fois le contrôle passé : il n'y a plus
            rien à préparer, et les montrer laissait croire à un travail encore
            attendu. Les sujets type bac, eux, restent : l'élève peut vouloir
            s'entraîner sur ce chapitre plus tard. */}
        {!passe && (
        <div style={{ marginTop: 12 }}>
          <div className="between">
            <h4>Les gestes</h4>
            <span className={"tag " + (aReprendre.length ? "gold" : "green")}>
              {gestes.length - aReprendre.length}/{gestes.length}
            </span>
          </div>
          {aReprendre.length > 0 ? (
            <>
              <p className="small" style={{ marginTop: 4, color: "#7A5A12" }}>
                Encore à reprendre avant le contrôle :
              </p>
              {/* Même présentation que dans Progrès : croix rouge, intitulé, et
                  le bouton pour aller chercher l'exercice sans attendre. */}
              {aReprendre.map((g) => {
                const dispo = travaillerGeste && (biblio[g.cid] || []).some((e) =>
                  e.usage === "entrainement" && (e.qt || []).includes(g.k)
                  && !vus.includes(e.id));
                const corps = (
                  <>
                    <span style={{ flex: "none", width: 16, height: 16, borderRadius: 4,
                      marginTop: 2, display: "flex", alignItems: "center",
                      justifyContent: "center", fontSize: 10, fontWeight: 700,
                      background: "#FBE9E7", color: "#C0392B" }}>✕</span>
                    <span className="small" style={{ flex: 1, textAlign: "left" }}>{g.titre}</span>
                    {dispo && <span className="tag" style={{ flex: "none" }}>travailler</span>}
                  </>
                );
                return dispo ? (
                  <button key={g.cid + g.k} className="row"
                    onClick={() => travaillerGeste(g.cid, g.k)}
                    style={{ gap: 8, alignItems: "flex-start", padding: "4px 0",
                      width: "100%", background: "none", border: "none",
                      cursor: "pointer", font: "inherit" }}>{corps}</button>
                ) : (
                  <div key={g.cid + g.k} className="row"
                    style={{ gap: 8, alignItems: "flex-start", padding: "4px 0" }}>{corps}</div>
                );
              })}
            </>
          ) : (
            <p className="small muted" style={{ marginTop: 4 }}>
              Tous les gestes du test sont acquis.
            </p>
          )}
        </div>
        )}
      </div>
    );
  };

  return (
    <div className="wrap">
      {/* La page annotée en grand : sur un téléphone, une vignette de 72 px
          ne se lit pas. */}
      {pageOuverte && (
        <div className="voile" onClick={() => setPageOuverte(null)}>
          <img src={pageOuverte} alt="page corrigée"
            style={{ maxWidth: "94%", maxHeight: "90%", borderRadius: 12 }}
            onClick={(e) => e.stopPropagation()} />
        </div>
      )}
      <span className="eyebrow">Tes échéances</span>
      <h2>Contrôles</h2>
      {!controle && !controlesPasses.length && (
        <div className="card" style={{ marginTop: 12 }}>
          <p className="small muted">
            Aucun contrôle déclaré. Dès que tu en annonces un depuis « Ce soir »,
            tu retrouveras ici ton épreuve blanche, les sujets de bac à traiter
            et les gestes qu'il te reste à revoir.
          </p>
        </div>
      )}
      {/* « Passé » se juge à la DATE, pas à la place dans la liste : le jour du
          contrôle, la fiche affichait encore les gestes à préparer alors que
          l'épreuve avait lieu. */}
      {controle && ficheContro(controle,
        (controle.semaine - 1) * 7 + (controle.jour || 0) <= (semaine - 1) * 7 + jour)}
      {/* LES COPIES CORRIGÉES SANS CONTRÔLE RATTACHÉ. La copie ne s'affichait
          qu'à l'intérieur d'une fiche : sans contrôle en cours ni historique —
          ou si la copie ne porte pas les bons chapitres — elle restait
          invisible alors qu'elle était bien arrivée. */}
      {(() => {
        const orphelines = copies.filter((c) => (c.corrigee || c.correction)
          && ![controle, ...controlesPasses].some((ct) => ct
              && (c.chapitres || []).some((x) => (ct.chapitres || []).includes(x))));
        if (!orphelines.length) return null;
        return orphelines.map((copie) => {
          const corr = copie.correction || null;
          return (
            <div className="card" key={copie.id} style={{ marginTop: 12,
              borderColor: "#E4D3AC", background: "#FDF8EE" }}>
              <span className="eyebrow">Ta copie corrigée</span>
              <h3 style={{ marginTop: 6 }}>
                {copie.semaine ? "Épreuve de la semaine " + copie.semaine : "Épreuve blanche"}
              </h3>
              {corr && corr.texte && (
                <p className="small" style={{ marginTop: 8, lineHeight: 1.55,
                  background: "#FFF", borderRadius: 8, padding: "8px 10px" }}>
                  {corr.texte}
                </p>
              )}
              {corr && corr.vocal && (
                <audio controls src={corr.vocal.url || corr.vocal}
                  style={{ width: "100%", marginTop: 8, height: 34 }} />
              )}
              {corr && corr.cheminAnnotee && (
                <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 10 }}
                  onClick={async () => {
                    const url = await lienCopieAnnotee(corr.cheminAnnotee);
                    if (url) window.open(url, "_blank", "noopener");
                  }}>
                  Ouvrir ma copie annotée
                </button>
              )}
            </div>
          );
        });
      })()}

      {controlesPasses.length > 0 && (
        <>
          <h3 style={{ marginTop: 20 }}>Déjà passés</h3>
          {controlesPasses.map((c) => ficheContro(c, true))}
        </>
      )}
    </div>
  );
}

function Progres({ journalSeances = [], setRun, taches, chapitres, copies, semaine, jour = 0, controle = null, controlesPasses = [], reglages, setReglages, replanifier, travaillerGeste, budgetRetenu, chapitresActifs, ancreLe,
                   biblio = {}, vus = [], supplements = [], demarrage = false }) {
  /* Un chapitre est CLOS dès le jour du contrôle, sans attendre que son statut
     change en base — cela n'a lieu qu'au passage de jour, et les gestes
     restaient affichés toute la journée de l'épreuve. */
  /* Un chapitre est CLOS dès le jour de son contrôle. On regarde le contrôle en
     cours ET l'historique : une fois la date dépassée, le contrôle est écarté
     du programme, et le chapitre paraissait de nouveau actif. */
  /* Un chapitre est CLOS s'il porte une date de fin, ou si l'un des contrôles
     connus le concerne et que sa date est atteinte. On regarde « finSemaine »
     en premier : c'est le champ posé par la clôture, et il ne dépend d'aucun
     historique — celui-ci pouvait être vide, et les gestes restaient affichés. */
  const estClos = (c) => c.statut === "termine"
    || c.finSemaine != null
    || [controle, ...(controlesPasses || [])].some((ct) => ct
        && (ct.chapitres || []).includes(c.id)
        && (ct.semaine - 1) * 7 + (ct.jour || 0) <= (semaine - 1) * 7 + jour);

  /* Ce qui mesure vraiment la préparation d'un élève, ce n'est pas le nombre
     d'exercices faits mais le nombre de GESTES de sa fiche qu'il a travaillés.
     On le lui montre avec les intitulés de sa fiche, jamais avec des numéros :
     « QT 6 » ne dit rien, « Montrer que t½ = ln2/k » dit tout. */
  const couverture = chapitres
    /* Les chapitres CLOS sont écartés : leur carte restait affichée, gestes
       grisés, alors qu'il n'y a plus rien à y travailler. */
    .filter((c) => c.niveau && !estClos(c))
    .map((c) => {
      const lot = (biblio[c.id] || []).filter((e) => e.usage === "entrainement");
      const titres = TITRES_QT[c.id] || {};
      const toutes = Object.keys(titres).filter((k) => k.startsWith("QT"));
      /* Un geste se coche sur un EXERCICE FAIT, pas sur un exercice servi :
         « vus » contenait aussi ce que le moteur avait posé sans que l'élève
         l'ait traité, et le test de positionnement n'y entre pas du tout —
         il désigne ce qu'il faut travailler, il ne valide rien.

         Trois états, selon ce que l'élève a déclaré à la fin de l'exercice :
         acquis, hésitant, ou raté. Le meilleur résultat obtenu l'emporte —
         un geste réussi ne redevient pas raté parce qu'un autre exercice qui
         le porte a moins bien marché. */
      const rang = { rate: 1, hesitant: 2, acquis: 3 };
      const etats = {};
      taches.filter((t) => t.chapId === c.id && t.statut === "fait" && t.exoId)
        .forEach((t) => {
          /* On cherche dans TOUTE la banque du chapitre, pas seulement dans
             les exercices d'entraînement : un sujet type bac travaille des
             gestes lui aussi, et il n'en validait aucun. */
          const e = (biblio[c.id] || []).find((x) => x.id === t.exoId);
          if (!e) return;
          const r = t.resultat === "acquis" ? "acquis"
                  : t.resultat === "hesitant" ? "hesitant" : "rate";
          (e.qt || []).forEach((k) => {
            if (!etats[k] || rang[r] > rang[etats[k]]) etats[k] = r;
          });
        });
      const vues = new Set(Object.keys(etats));
      return { id: c.id, nom: CHAPITRES.find((x) => x.id === c.id)?.nom || c.id,
               toutes, vues, titres, etats };
    })
    .filter((x) => x.toutes.length);

  const faites = taches.filter((t) => t.statut === "fait");
  const minutes = faites.reduce((a, t) => a + t.duree, 0);
  const manquees = taches.filter((t) => t.statut === "manquee");

  /* Les réglages ne peuvent pas rester figés à la mise en route : une classe
     change d'emploi du temps, un élève dégage du temps ou en perd. Toute
     modification replanifie la semaine à partir d'aujourd'hui. */
  const majReglages = (r) => { setReglages(r); if (replanifier) replanifier(undefined, undefined, undefined, undefined, undefined, r); };
  const [avertir, setAvertir] = useState(null);
  const bascule = (cle, v) => {
    const dedans = reglages[cle].includes(v);
    const suite = dedans ? reglages[cle].filter((x) => x !== v) : [...reglages[cle], v].sort();
    if (cle === "joursOff" && !dedans && v >= 5 && [5, 6].every((x) => suite.includes(x))) {
      setAvertir("Garde au moins un jour de week-end : c'est là que se place ton sujet de bac.");
      return;
    }
    setAvertir(null);
    majReglages({ ...reglages, [cle]: suite,
      });
  };

  return (
    <div className="stack">
      <div>
        <p className="eyebrow">Suivi · {semaineEnClair(ancreLe, semaine).toLowerCase()}</p>
        <h1 style={{ marginTop: 6 }}>Ma progression</h1>
      </div>
      <div className="grid2">
        <div className="card">
          <span className="eyebrow">Cette semaine</span>
          <h2 style={{ marginTop: 8 }}>{Math.floor(minutes / 60)} h {String(minutes % 60).padStart(2, "0")}</h2>
          {demarrage && (
            <p className="small" style={{ marginTop: 6, color: "#7A5A12" }}>
              Semaine de démarrage : tu as commencé en cours de semaine, elle ne
              compte pas dans ton bilan.
            </p>
          )}
          <p className="small muted">{faites.length} tâche(s) faite(s){manquees.length ? " · " + manquees.length + " manquée(s)" : ""}</p>
        </div>
        <div className="card">
          <span className="eyebrow">Envoyé à vos parents</span>
          <h3 style={{ marginTop: 8 }}>Le bilan du lundi</h3>

          <p className="small muted" style={{ marginTop: 4 }}>Travail de la semaine précédente, résultat de l'évaluation blanche, objectif de la semaine.</p>
        </div>
      </div>

      {/* ═══════ LES EXERCICES DÉJÀ FAITS ═══════════════════════════════
          L'élève ne voyait nulle part ce qu'il avait traité. La liste est
          repliée par chapitre — sur une année, elle compte des centaines de
          lignes — et chaque exercice se rouvre d'un clic. Les hésités et les
          ratés viennent en premier : ce sont ceux à reprendre. */}
      {(() => {
        const faits = (journalSeances || []).filter((j) => j.chapId && j.type === "exo");
        /* UNE SEULE LIGNE PAR EXERCICE, avec son DERNIER résultat. Un exercice
           repris depuis cet écran s'inscrivait une seconde fois, et l'élève
           voyait « raté » et « acquis » côte à côte pour le même énoncé. La
           reprise est ce qui compte : elle remplace la ligne au lieu de s'y
           ajouter. */
        const dernier = {};
        faits.forEach((j) => { dernier[String(j.exoId || j.id)] = j; });
        const retenus = Object.values(dernier);

        /* Les chapitres montrés : ceux où l'élève a travaillé, et ceux qui sont
           CLOS — pour un chapitre terminé, on liste aussi ce qu'il n'a pas fait,
           afin qu'il puisse y revenir d'ici le bac. */
        const avecTravail = [...new Set(retenus.map((j) => j.chapId))];
        const clos = chapitres.filter(estClos).map((c) => c.id);
        const chaps = [...new Set([...avecTravail, ...clos])]
          .filter((cid) => (biblio[cid] || []).length || retenus.some((j) => j.chapId === cid));
        if (!chaps.length) return null;

        const rang = { rate: 0, hesitant: 1, acquis: 2 };
        const ouvrir = (cid, e, repris) => setRun({
          id: (repris ? "revoir-" : "libre-") + e.id, type: "exo", chapId: cid,
          duree: e.duree, exoId: e.id, exoTitre: e.titre, difficulte: e.niveau,
          chapNom: CHAPITRES.find((c) => c.id === cid)?.nom || "",
          libelle: repris ? "Exercice revu" : "Exercice d'entraînement",
          motif: repris ? "Tu l'avais déjà fait · tu le reprends"
                        : "Chapitre terminé · tu reviens t'entraîner",
          supplement: true });

        return (
          <div className="card" style={{ marginTop: 12 }}>
            <h3>Les exercices, chapitre par chapitre</h3>
            <p className="small muted" style={{ marginTop: 4 }}>
              Ceux que tu as faits, avec ton dernier résultat. Sur un chapitre
              terminé, tu retrouves aussi ceux qu'il te reste à découvrir.
            </p>
            {chaps.map((cid) => {
              const chap = CHAPITRES.find((c) => c.id === cid);
              const lot = (biblio[cid] || []).filter((e) => e.usage === "entrainement");
              const listeFaits = retenus.filter((j) => j.chapId === cid)
                .sort((a, b) => (rang[a.resultat] ?? 3) - (rang[b.resultat] ?? 3));
              const idsFaits = new Set(listeFaits.map((j) => String(j.exoId || j.id)));
              const restants = clos.includes(cid)
                ? lot.filter((e) => !idsFaits.has(String(e.id))) : [];
              if (!listeFaits.length && !restants.length) return null;
              return (
                <details key={cid} style={{ marginTop: 10 }}>
                  <summary className="small" style={{ cursor: "pointer",
                    color: "var(--ink)", fontWeight: 600 }}>
                    {(chap ? chap.nom : cid) + " · " + listeFaits.length
                      + " sur " + (lot.length || 15)
                      + (restants.length ? " · " + restants.length + " à découvrir" : "")}
                  </summary>
                  <div style={{ marginTop: 8 }}>
                    {listeFaits.map((j, k) => {
                      const e = lot.find((x) => String(x.id) === String(j.exoId || j.id));
                      const teinte = j.resultat === "acquis" ? "green"
                        : j.resultat === "hesitant" ? "gold" : "red";
                      return (
                        <div className="row" key={"f" + k}
                          style={{ padding: "6px 0", alignItems: "baseline", gap: 8,
                            borderTop: k ? "1px solid #F0F2FA" : "none" }}>
                          <span className="small" style={{ flex: 1, color: "var(--ink)" }}>
                            {e ? e.titre : (j.exoTitre || "Exercice")}
                          </span>
                          <span className={"tag " + teinte} style={{ flex: "none" }}>
                            {j.resultat === "acquis" ? "acquis"
                              : j.resultat === "hesitant" ? "hésité" : "raté"}
                          </span>
                          {e && setRun && (
                            <button className="btn btn-ghost btn-sm" style={{ flex: "none" }}
                              onClick={() => ouvrir(cid, e, true)}>Rouvrir</button>
                          )}
                        </div>
                      );
                    })}
                    {/* CE QUI RESTE À DÉCOUVRIR, sur un chapitre terminé : les
                        quinze exercices ne sont jamais tous servis avant le
                        contrôle, et ceux-là valent pour les révisions du bac. */}
                    {restants.length > 0 && (
                      <>
                        <p className="small muted" style={{ marginTop: 10,
                          paddingTop: 8, borderTop: "1px solid #F0F2FA" }}>
                          Pas encore faits — le chapitre est terminé, mais ils
                          restent disponibles.
                        </p>
                        {restants.map((e, k) => (
                          <div className="row" key={"r" + k}
                            style={{ padding: "6px 0", alignItems: "baseline", gap: 8 }}>
                            <span className="small" style={{ flex: 1, color: "#8A90AB" }}>
                              {e.titre}
                            </span>
                            {setRun && (
                              <button className="btn btn-ghost btn-sm" style={{ flex: "none" }}
                                onClick={() => ouvrir(cid, e, false)}>Faire</button>
                            )}
                          </div>
                        ))}
                      </>
                    )}
                  </div>
                </details>
              );
            })}
          </div>
        );
      })()}

      {/* La carte « Ton mois » a été RETIRÉE : le bilan des quatre semaines
          est l'affaire du coach, et l'élève n'en tirait rien pour son travail
          du jour. */}

      {/* Les gestes de la fiche : ce que l'élève a déjà travaillé, et ce qui
          l'attend encore. C'est la seule mesure honnête de sa préparation. */}
      {couverture.map((c) => (
        <div className="card" key={c.id}>
          <div className="between">
            <span className="eyebrow">Les gestes de la fiche</span>
            <span className={"tag " + (c.vues.size === c.toutes.length ? "green"
                                     : c.vues.size >= c.toutes.length / 2 ? "gold" : "")}>
              {c.vues.size} / {c.toutes.length}
            </span>
          </div>
          <h3 style={{ marginTop: 8 }}>{c.nom}</h3>
          <div className="bar" style={{ marginTop: 10 }}>
            <i style={{ width: (c.vues.size / c.toutes.length) * 100 + "%" }} />
          </div>
          <div style={{ marginTop: 12 }}>
            {c.toutes.map((k) => {
              const vue = c.vues.has(k);
              /* L'état vient du RÉSULTAT déclaré par l'élève, pas du test. */
              const etat = (c.etats || {})[k];
              /* Un geste non encore vu se travaille d'un geste : l'élève qui
                 s'inquiète va le chercher sans attendre son tour au planning. */
              /* On ne propose le rattrapage que s'il existe VRAIMENT un
                 exercice pour ce geste, et que l'élève ne l'a pas déjà fait :
                 un bouton qui ne mène à rien est pire qu'un bouton absent.
                 Certains chapitres n'ont pas encore de lot produit. */
              /* LE BOUTON RESTE TANT QU'UN EXERCICE TRAVAILLE CE GESTE. Il
                 exigeait un exercice JAMAIS VU et un geste JAMAIS RENCONTRÉ :
                 dès que l'élève avait touché au geste, ou épuisé les exercices
                 qui le portent, le bouton disparaissait — y compris sur un
                 geste hésité ou raté, celui qu'il faut justement reprendre. */
              const dispo = travaillerGeste
                && (biblio[c.id] || []).some((e) => e.usage === "entrainement"
                     && (e.qt || []).includes(k));
              const cliquable = !!dispo;
              const contenu = (
                <>
                  {/* Trois états, trois puces : coche verte pour un geste
                      acquis au test, croix rouge pour un geste raté, puce
                      neutre pour un geste pas encore rencontré. */}
                  {/* Quatre états : acquis (coche verte), hésitant (point
                      d'exclamation ambre), raté (croix rouge), et pas encore
                      travaillé (puce neutre). */}
                  <span style={{ flex: "none", width: 16, height: 16, borderRadius: 4,
                    marginTop: 2, display: "flex", alignItems: "center",
                    justifyContent: "center", fontSize: 10, fontWeight: 700,
                    background: etat === "acquis" ? "#E4F5EE"
                              : etat === "hesitant" ? "#FBF3E4"
                              : etat === "rate" ? "#FBE9E7" : "#EDF0FD",
                    color: etat === "acquis" ? "#1E6E52"
                         : etat === "hesitant" ? "#7A5A12"
                         : etat === "rate" ? "#C0392B" : "#8A93B8" }}>
                    {etat === "acquis" ? "✓" : etat === "hesitant" ? "!"
                      : etat === "rate" ? "✕" : ""}
                  </span>
                  <span className="small" style={{ flex: 1, textAlign: "left",
                    color: vue ? "var(--ink)" : "var(--ink-soft)" }}>{c.titres[k]}</span>
                  {cliquable && (
                    <span className="tag" style={{ flex: "none" }}>travailler</span>
                  )}
                </>
              );
              return cliquable ? (
                <button key={k} className="row"
                  onClick={() => travaillerGeste(c.id, k)}
                  style={{ gap: 8, alignItems: "flex-start", padding: "5px 0",
                    width: "100%", background: "none", border: "none",
                    cursor: "pointer", font: "inherit" }}>
                  {contenu}
                </button>
              ) : (
                <div key={k} className="row" style={{ gap: 8, alignItems: "flex-start",
                  padding: "5px 0", opacity: vue ? 1 : 0.62 }}>
                  {contenu}
                </div>
              );
            })}
          </div>
          <p className="small muted" style={{ marginTop: 10 }}>
            {c.vues.size === c.toutes.length
              ? "Tous les gestes de la fiche ont été travaillés au moins une fois."
              : travaillerGeste
                ? "Chaque geste porte le résultat que tu as déclaré : ✓ acquis, ! hésitant, ✕ raté. Les autres n'ont pas encore été travaillés — appuie sur « travailler » pour en prendre un tout de suite."
                : "Chaque geste porte le résultat que tu as déclaré : ✓ acquis, ! hésitant, ✕ raté."}
          </p>
        </div>
      ))}

      {/* Mes copies : un message dans la permanence finit par descendre dans le
          fil, alors qu'une copie corrigée se relit des semaines plus tard.
          Elle a donc sa place ici, dans le suivi personnel. */}
      {/* Carte RETIRÉE : copies et évaluations blanches vivent dans
          l'historique de l'écran DS, à côté du contrôle qu'elles
          concernent. Les répéter ici dispersait l'information. */}
      {false && (
        <div className="card">
          <h3>Mes copies</h3>
          <p className="small muted" style={{ marginTop: 4 }}>
            Vos évaluations blanches et le retour du coach.
          </p>
          {[...copies].reverse().map((c) => (
            <div key={c.id} style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--line)" }}>
              <div className="between">
                <h4>Semaine {c.semaine}</h4>
                <span className={"tag " + (c.statut === "corrigee" ? "green" : "gold")}>
                  {c.statut === "corrigee" ? "corrigée" : "en attente de correction"}
                </span>
              </div>
              <p className="small muted" style={{ marginTop: 4 }}>
                {(c.exos || []).map((e) => e.titre).join(" · ")}
                {c.photos && c.photos.length ? " · " + c.photos.length + " page(s) envoyée(s)" : ""}
              </p>
              {c.correction && (
                <div style={{ marginTop: 10, padding: "10px 12px", borderRadius: 8,
                  background: "#F7F9FF", border: "1px solid #E3E8F7" }}>
                  <span className="eyebrow">Retour du coach{c.correction.le ? " · " + c.correction.le : ""}</span>
                  {(c.correction.pieges || []).length > 0 && (
                    <ul style={{ margin: "8px 0 0", paddingLeft: 18 }}>
                      {c.correction.pieges.map((pg, k) => (
                        <li key={k} className="small" style={{ color: "var(--ink)", marginBottom: 3 }}>{pg}</li>
                      ))}
                    </ul>
                  )}
                  {c.correction.texte && (
                    <p className="small" style={{ marginTop: 8, color: "var(--ink)", whiteSpace: "pre-wrap" }}>
                      {c.correction.texte}
                    </p>
                  )}
                  {(c.correction.annotees || []).map((ph, k) => (
                    <div key={k} style={{ marginTop: 8 }}>
                      <p className="small muted">Copie annotée · page {k + 1}</p>
                      {String(ph.type || "").startsWith("image")
                        ? <img src={ph.data} alt={"annotée " + (k + 1)}
                            style={{ width: "100%", borderRadius: 8, border: "1px solid var(--line)", marginTop: 4 }} />
                        : <button className="btn btn-ghost btn-sm"
                            onClick={() => ouvrirFichier(ph.data, ph.nom || "page")}>Ouvrir</button>}
                    </div>
                  ))}
                  {c.correction.vocal && (
                    <audio controls src={c.correction.vocal.url}
                      style={{ width: "100%", marginTop: 10 }} />
                  )}
                </div>
              )}
              {c.statut !== "corrigee" && (
                <p className="small muted" style={{ marginTop: 8 }}>
                  Le coach la corrige sous quelques jours. Vous serez prévenu en permanence.
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Les réglages, modifiables toute l'année et pas seulement à la mise en
          route : c'est ici qu'un élève allonge ses soirées quand il ouvre un
          second chapitre. */}
      <div className="card" id="reglages">
        <h3>Mon temps de travail</h3>
        <p className="small muted" style={{ marginTop: 4 }}>
          Chaque séance dure exactement ce que vous indiquez ici. Un changement
          replanifie la semaine à partir d'aujourd'hui.
        </p>

        <p className="eyebrow" style={{ marginTop: 16 }}>En semaine</p>
        <div className="chips" style={{ marginTop: 8 }}>
          {/* Jusqu'à 90 min : avec trois chapitres menés de front, le seuil de
              30 min par chapitre en réclame autant. Plafonner à 60 laissait
              l'élève devant une alerte qu'aucun réglage ne pouvait éteindre. */}
          {/* Le relèvement consenti pour mener plusieurs chapitres s'affiche
              ici : l'élève doit savoir pourquoi ses soirées sont plus longues
              que ce qu'il avait choisi. */}
          {budgetRetenu > reglages.budgetSemaine && (
            <p className="small" style={{ marginBottom: 8, color: "#7A5A12" }}>
              Relevé à {budgetRetenu} min pour mener {chapitresActifs} chapitres.
              Il redescendra dès que tu en auras terminé un.
            </p>
          )}
          {[20, 30].map((b) => (
            <button key={b} className={"chip" + (reglages.budgetSemaine === b ? " on" : "")}
              onClick={() => majReglages({ ...reglages, budgetSemaine: b })}>{b} min</button>
          ))}
        </div>

        <p className="eyebrow" style={{ marginTop: 16 }}>Jours de cours de physique-chimie</p>
        <div className="chips" style={{ marginTop: 8 }}>
          {JOURS.map((j, k) => (
            <button key={j} className={"chip" + (reglages.joursCours.includes(k) ? " on" : "")}
              onClick={() => bascule("joursCours", k)}>{j}</button>
          ))}
        </div>

        <p className="eyebrow" style={{ marginTop: 16 }}>Jours sans travail</p>
        <div className="chips" style={{ marginTop: 8 }}>
          {JOURS.map((j, k) => (
            <button key={j} className={"chip" + (reglages.joursOff.includes(k) ? " on" : "")}
              onClick={() => bascule("joursOff", k)}>{j}</button>
          ))}
        </div>
        {avertir && (
          <p className="small" style={{ marginTop: 8, color: "#7A5A12" }}>{avertir}</p>
        )}
      </div>

      <div className="card">
        <h3>Chapitres</h3>
        <p className="small muted" style={{ marginTop: 4 }}>
          La barre mesure le travail réalisé cette semaine, pas le score du diagnostic :
          celui-ci sert seulement à régler la difficulté des exercices.
        </p>
        <div style={{ marginTop: 14 }}>
          {/* Les chapitres TERMINÉS n'apparaissent plus : leurs gestes ont été
              travaillés, et les revoir ici donnait l'impression d'un programme
              en cours. Ils reviendront d'eux-mêmes avec les rappels espacés. */}
          {chapitres.filter((c) => !estClos(c)).map((c) => {
            /* on exclut le test diagnostic : il fixe le point de depart, il ne mesure rien */
            const tachesChap = taches.filter((t) => t.chapId === c.id && !t.masquee && t.type !== "diagnostic");
            const prevues = tachesChap.length;
            const faitesChap = tachesChap.filter((t) => t.statut === "fait").length;
            const pct = prevues ? Math.round((faitesChap / prevues) * 100) : 0;
            const restit = (c.restitutionsFaites || []).length;
            return (
              <div key={c.id} style={{ marginBottom: 20 }}>
                <div className="between" style={{ marginBottom: 6 }}>
                  <span className="small" style={{ color: "var(--ink)" }}>{CHAPITRES.find((x) => x.id === c.id).nom}</span>
                  <span className="small muted" style={{ fontFamily: "var(--fm)" }}>
                    {c.niveau ? faitesChap + "/" + prevues : "diagnostic a faire"}
                  </span>
                </div>
                <div className="bar"><i style={{ width: pct + "%" }} /></div>
                {/* Le test ne classe plus par niveau : il désigne les GESTES à
                    reprendre. C'est ce bilan que l'élève doit voir, geste par
                    geste — pas une étiquette « facile » qui ne veut plus rien
                    dire depuis que les exercices n'ont plus de niveau. */}
                {c.niveau ? (
                  <BilanTest c={c} restit={restit} />
                ) : (
                  <p className="small muted" style={{ marginTop: 6 }}>
                    Le test de positionnement dira quels gestes travailler en priorité.
                  </p>
                )}
                {c.statut === "termine" && (
                  <p className="small muted">Terminé · en rappel espacé</p>
                )}
              </div>
            );
          })}
          {!chapitres.length && <p className="small muted">Declarez un chapitre un soir de cours pour demarrer.</p>}

          {/* LA TRACE DES CHAPITRES PASSÉS : une ligne par chapitre, sans les
              gestes. L'élève garde une vue de son année, mais on ne lui montre
              plus un suivi qu'il ne peut plus compléter — un rappel espacé ne
              pose qu'une ou deux séances. */}
          {chapitres.some(estClos) && (
            <div style={{ marginTop: 18, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
              <p className="eyebrow">Chapitres terminés</p>
              {chapitres.filter(estClos)
                .sort((a, b) => (b.finSemaine || 0) - (a.finSemaine || 0))
                .map((c) => {
                  const nom = CHAPITRES.find((x) => x.id === c.id)?.nom || c.id;
                  const d = c.finSemaine != null && ancreLe
                    ? jourEnClair(ancreLe, c.finSemaine, c.finJour || 0) : null;
                  return (
                    <div className="row" key={c.id}
                      style={{ padding: "6px 0", alignItems: "baseline", gap: 8 }}>
                      <span className="small" style={{ flex: 1, color: "var(--ink)" }}>{nom}</span>
                      <span className="small muted" style={{ flex: "none" }}>
                        {d ? "terminé le " + d
                           : c.finSemaine ? "semaine " + c.finSemaine : "terminé"}
                      </span>
                      {(c.retours || 0) > 0 && (
                        <span className="tag grey" style={{ flex: "none" }}>
                          {c.retours} rappel{c.retours > 1 ? "s" : ""}
                        </span>
                      )}
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      </div>

      {/* Carte RETIRÉE : copies et évaluations blanches vivent dans
          l'historique de l'écran DS, à côté du contrôle qu'elles
          concernent. Les répéter ici dispersait l'information. */}
      {false && (
        <div className="card">
          <h3>Évaluations blanches</h3>
          {copies.map((c) => (
            <div className="res" key={c.id}>
              <span className="ico"><Icon d={I.clock} size={18} /></span>
              <div style={{ flex: 1 }}><h4>Copie de la semaine {c.semaine}</h4><p className="small muted">{c.exos.length} exercices</p></div>
              <span className={"tag " + (c.statut === "en_attente" ? "gold" : "green")}>{c.statut === "en_attente" ? "Chez le coach" : "Corrigée"}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ========================= ESPACE COACH =================================== */


/* ═══════════════════════════════════════════════════════════════════════════
   L'ESPACE PARENT

   En lecture seule, et volontairement pauvre : un parent doit pouvoir dire
   en trente secondes si son enfant travaille et où il en est. Il ne voit ni
   la permanence ni les échanges avec le coach — ce sont des conversations
   entre l'élève et son professeur.
   ═══════════════════════════════════════════════════════════════════════════ */


/* ═══════════════════════════════════════════════════════════════════════════
   CHOISIR SON MOT DE PASSE

   Affiché une seule fois, juste après la première connexion par lien. Tant
   qu'aucun mot de passe n'est posé, l'élève devrait redemander un courriel
   à chaque fois — ce qui épuise la réserve d'envois et le bloque le soir où
   il travaille.
   ═══════════════════════════════════════════════════════════════════════════ */

function ChoisirMotDePasse({ onFait }) {
  const [mot, setMot] = useState("");
  const [confirme, setConfirme] = useState("");
  const [erreur, setErreur] = useState("");
  const [envoi, setEnvoi] = useState(false);

  const valider = async () => {
    if (mot.length < 8) { setErreur("Huit caractères au minimum."); return; }
    if (mot !== confirme) { setErreur("Les deux saisies ne correspondent pas."); return; }
    setEnvoi(true); setErreur("");
    try { await definirMotDePasse(mot); onFait(); }
    catch (e) { setErreur(String(e.message || e)); }
    finally { setEnvoi(false); }
  };

  return (
    <div className="b"><style>{CSS}</style>
      <div className="wrap" style={{ maxWidth: 460, paddingTop: 40 }}>
        <p className="sur">Bosse ta Physique</p>
        <h1 style={{ margin: "6px 0 0", fontSize: "1.4rem" }}>
          Choisissez votre mot de passe
        </h1>
        <div className="card" style={{ marginTop: 18 }}>
          <p className="small muted">
            Vous n'aurez plus besoin d'attendre un courriel : la prochaine fois,
            vous vous connecterez directement avec votre adresse et ce mot de passe.
          </p>

          <p className="small muted" style={{ marginTop: 14 }}>
            Mot de passe — huit caractères au minimum
          </p>
          <input className="input" type="password" value={mot}
            onChange={(e) => setMot(e.target.value)} />

          <p className="small muted" style={{ marginTop: 10 }}>Confirmez</p>
          <input className="input" type="password" value={confirme}
            onChange={(e) => setConfirme(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") valider(); }} />

          {erreur && (
            <p className="small" style={{ marginTop: 10, color: "#C0392B" }}>{erreur}</p>
          )}

          <button className="btn btn-accent btn-block" style={{ marginTop: 14 }}
            disabled={envoi} onClick={valider}>
            {envoi ? "Enregistrement…" : "Enregistrer et continuer"}
          </button>

          <p className="small muted" style={{ marginTop: 14 }}>
            Notez-le : personne ne peut le retrouver, pas même votre coach.
            En cas d'oubli, vous demanderez un nouveau lien par courriel.
          </p>
        </div>
      </div>
    </div>
  );
}

function EspaceParent() {
  const [enfants, setEnfants] = useState([]);
  const [choisi, setChoisi] = useState(null);
  const [etat, setEtat] = useState(null);
  const [vue, setVue] = useState("semaine");
  const [chargement, setChargement] = useState(true);

  useEffect(() => {
    (async () => {
      const l = await mesEnfants();
      setEnfants(l);
      if (l.length) setChoisi(l[0]);
      setChargement(false);
    })();
  }, []);

  const [points, setPoints] = useState([]);
  useEffect(() => {
    if (!choisi) return;
    (async () => {
      setEtat(await etatDeLEnfant(choisi.id));
      setPoints(await pointsMensuelsDe(choisi.id));
    })();
  }, [choisi]);

  if (chargement) return <div className="card"><p className="small muted">Chargement…</p></div>;
  if (!enfants.length) {
    return (
      <div className="card">
        <span className="eyebrow">Espace parent</span>
        <h3 style={{ marginTop: 8 }}>Aucun enfant rattaché</h3>
        <p className="small muted" style={{ marginTop: 6 }}>
          Votre compte n'est rattaché à aucun élève. Contactez le coach.
        </p>
      </div>
    );
  }

  /* ═══════════ CE QUE LE PARENT DOIT VOIR, DANS CET ORDRE ═══════════════
     À l'ouverture : la semaine EN COURS de son enfant — ce qu'il a fait, ce
     qui lui reste, s'il est inscrit au cours en visioconférence, s'il a un
     contrôle déclaré. Le bilan de la semaine écoulée vient après, et non
     avant : un parent qui se connecte veut savoir où en est son enfant
     aujourd'hui, pas ce qu'il a fait il y a dix jours.
     ═══════════════════════════════════════════════════════════════════════ */
  const taches = etat?.taches || [];
  const chapitres = etat?.chapitres || [];
  const semaine = etat?.semaine || 1;
  const jour = etat?.jour || 0;
  const controle = etat?.controle || null;
  const passes = etat?.controlesPasses || [];
  const inscrits = etat?.inscrits || [];
  const copies = etat?.copies || [];

  const estClos = (c) => c.statut === "termine"
    || c.finSemaine != null
    || [controle, ...passes].some((ct) => ct
        && (ct.chapitres || []).includes(c.id)
        && (ct.semaine - 1) * 7 + (ct.jour || 0) <= (semaine - 1) * 7 + jour);

  const deLaSemaine = (n) => taches.filter((t) => t.semaine === n && !t.masquee);
  const faites = (l) => l.filter((t) => t.statut === "fait");
  /* Dans une semaine RÉVOLUE, toute tâche non faite est manquée : elle ne sera
     plus reprise. S'en tenir au statut « manquee » dépendait du moment où
     l'élève s'était reconnecté. */
  const manquees = (l) => l.filter((t) => t.statut !== "fait");
  const minutes = (l) => l.reduce((a, t) => a + (t.duree || 0), 0);
  const heures = (m) => Math.floor(m / 60) + " h " + String(m % 60).padStart(2, "0");
  const nomDe = (id) => (id === METHODE ? NOM_METHODE
    : CHAPITRES.find((x) => x.id === id)?.nom || id);

  const semCours = deLaSemaine(semaine);
  const semPassee = deLaSemaine(Math.max(1, semaine - 1));
  /* Le programme du jour et celui qui reste d'ici dimanche. */
  const aVenir = semCours.filter((t) => t.jour >= jour && t.statut !== "fait");
  const dejaFaites = faites(semCours);

  /* Les gestes de la fiche, pour les chapitres ENCORE OUVERTS. */
  const couverture = chapitres
    .filter((c) => c.niveau && !estClos(c))
    .map((c) => {
      const lot = (BIBLIO_INIT[c.id] || []).filter((e) => e.usage === "entrainement");
      const titres = TITRES_QT[c.id] || {};
      const toutes = Object.keys(titres).filter((k) => k.startsWith("QT"));
      const faits = [
        ...taches.filter((t) => t.chapId === c.id && t.statut === "fait" && t.exoId)
                 .map((t) => t.exoId),
        ...(etat?.vus || []),
      ];
      const vues = new Set(lot.filter((e) => faits.includes(e.id)).flatMap((e) => e.qt || []));
      return { id: c.id, nom: nomDe(c.id), toutes, vues, titres };
    })
    .filter((x) => x.toutes.length);

  /* Les chapitres TERMINÉS, du plus récent au plus ancien. */
  const termines = chapitres.filter(estClos)
    .map((c) => {
      const ct = [controle, ...passes].find((x) => x
        && (x.chapitres || []).includes(c.id));
      return { id: c.id, nom: nomDe(c.id),
               fin: c.finSemaine ?? (ct ? ct.semaine : null) };
    })
    .sort((a, b) => (b.fin ?? 0) - (a.fin ?? 0));

  /* L'HISTORIQUE DES ÉVALUATIONS : chaque contrôle passé, avec la copie
     rendue quand elle existe. Le parent demande souvent « a-t-il eu son
     devoir ? » — la réponse était nulle part. */
  const evaluations = [...passes]
    .filter((ct) => ct && ct.semaine != null)
    .sort((a, b) => b.semaine - a.semaine)
    .map((ct) => ({
      ct,
      copie: copies.find((cp) => (cp.chapitres || [])
        .some((x) => (ct.chapitres || []).includes(x))),
    }));
  /* Le contrôle en cours, s'il est déclaré et pas encore passé. */
  const controleAVenir = controle
    && (controle.semaine - 1) * 7 + (controle.jour || 0) > (semaine - 1) * 7 + jour
    ? controle : null;

  /* L'HISTORIQUE DES COURS EN VISIOCONFÉRENCE : une ligne par semaine où un
     cours a été programmé, avec l'inscription et la présence. */
  const directs = [...new Set(taches.filter((t) => t.type === "direct")
    .map((t) => t.semaine))]
    .sort((a, b) => b - a)
    .map((sem) => {
      const t = taches.find((x) => x.type === "direct" && x.semaine === sem);
      return { sem,
               /* Le CHAPITRE du cours, pas son libellé générique : « Le direct
                  — cours en visio » ne disait rien au parent. */
               titre: t?.chapNom || nomDe(t?.chapId) || "Cours en visioconférence",
               detail: t?.motif || "",
               inscrit: inscrits.includes(sem), present: t?.statut === "fait" };
    });
  const inscritCetteSemaine = inscrits.includes(semaine);
  const directCetteSemaine = semCours.find((t) => t.type === "direct");

  const JOURS_LONGS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi",
                       "samedi", "dimanche"];

  return (
    <>
      {enfants.length > 1 && (
        <div className="chips longue" style={{ marginBottom: 12 }}>
          {enfants.map((e) => (
            <button key={e.id} className={"chip" + (choisi?.id === e.id ? " on" : "")}
              onClick={() => setChoisi(e)}>{e.prenom}</button>
          ))}
        </div>
      )}

      <div className="chips" style={{ marginBottom: 14 }}>
        {[["semaine", "Cette semaine"],
          ["historique", "L'historique"],
          ["avance", "L'avancement"]].map(([k, l]) => (
          <button key={k} className={"chip" + (vue === k ? " on" : "")}
            onClick={() => setVue(k)}>{l}</button>
        ))}
      </div>

      {/* ═══════════════ CETTE SEMAINE ═══════════════ */}
      {vue === "semaine" && (
        <>
          <div className="card">
            <span className="eyebrow">Cette semaine</span>
            <h2 style={{ marginTop: 8 }}>
              {dejaFaites.length} séance{dejaFaites.length > 1 ? "s" : ""} sur {semCours.length}
            </h2>
            <p className="small muted" style={{ marginTop: 4 }}>
              {minutes(dejaFaites)
                ? heures(minutes(dejaFaites)) + " de travail depuis lundi"
                : "Aucune séance faite pour l'instant"}
              {aVenir.length
                ? " · " + aVenir.length + " encore prévue"
                  + (aVenir.length > 1 ? "s" : "") + " d'ici dimanche"
                : " · rien de prévu d'ici dimanche"}
            </p>
            {semCours.length > 0 && (
              <div className="bar" style={{ marginTop: 12 }}>
                <i style={{ width: (dejaFaites.length / semCours.length) * 100 + "%" }} />
              </div>
            )}
          </div>

          {/* Le programme jour par jour : ce que fait l'enfant, concrètement. */}
          {semCours.length > 0 && (
            <div className="card">
              <h3>Le programme de la semaine</h3>
              {[0, 1, 2, 3, 4, 5, 6].map((j) => {
                const duJour = semCours.filter((t) => t.jour === j);
                if (!duJour.length) return null;
                const toutFait = duJour.every((t) => t.statut === "fait");
                return (
                  <div key={j} className="row" style={{ padding: "7px 0",
                    alignItems: "baseline", gap: 10,
                    borderTop: j ? "1px solid #F0F2FA" : "none",
                    opacity: j < jour && !toutFait ? 0.75 : 1 }}>
                    <span className="small" style={{ width: 74, flex: "none",
                      color: j === jour ? "var(--accent)" : "var(--ink)",
                      fontWeight: j === jour ? 600 : 400 }}>
                      {JOURS_LONGS[j]}
                    </span>
                    <span className="small muted" style={{ flex: 1 }}>
                      {duJour.map((t) => nomDe(t.chapId)).filter((x, k, l) =>
                        l.indexOf(x) === k).join(" · ")}
                      {" — " + minutes(duJour) + " min"}
                    </span>
                    <span className={"tag " + (toutFait ? "green"
                      : j < jour ? "red" : "grey")} style={{ flex: "none" }}>
                      {toutFait ? "fait" : j < jour ? "manqué" : "à faire"}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Le cours en visioconférence de la semaine en cours. */}
          <div className="card">
            <div className="between">
              <span className="eyebrow">Le cours en visioconférence</span>
              {(directCetteSemaine || inscritCetteSemaine) && (
                <span className={"tag " + (inscritCetteSemaine ? "green" : "gold")}>
                  {inscritCetteSemaine ? "inscrit" : "non inscrit"}
                </span>
              )}
            </div>
            {directCetteSemaine || inscritCetteSemaine ? (
              <>
                {/* LE CHAPITRE d'abord : c'est ce qu'un parent veut savoir.
                    Le titre du cours et l'horaire viennent en dessous. */}
                <h3 style={{ marginTop: 8 }}>
                  {directCetteSemaine?.chapNom
                    || nomDe(directCetteSemaine?.chapId)
                    || "Cours de la semaine"}
                </h3>
                {directCetteSemaine?.motif && (
                  <p className="small" style={{ marginTop: 3, color: "#5B6BB5" }}>
                    {directCetteSemaine.motif}
                  </p>
                )}
                <p className="small muted" style={{ marginTop: 4 }}>
                  {inscritCetteSemaine
                    ? (directCetteSemaine?.statut === "fait"
                        ? "Votre enfant y a assisté."
                        : "Votre enfant s'y est inscrit.")
                    : "Un cours est programmé, votre enfant ne s'y est pas "
                      + "inscrit. L'inscription se fait depuis son écran « Ce soir »."}
                </p>
              </>
            ) : (
              <p className="small muted" style={{ marginTop: 8 }}>
                Aucun cours n'est programmé cette semaine.
              </p>
            )}
          </div>

          {/* Le contrôle déclaré, s'il y en a un devant. */}
          <div className="card">
            <span className="eyebrow">Le prochain contrôle</span>
            {controleAVenir ? (
              <>
                <h3 style={{ marginTop: 8 }}>
                  {(controleAVenir.chapitres || []).map(nomDe).join(" et ")}
                </h3>
                <p className="small muted" style={{ marginTop: 4 }}>
                  {(controleAVenir.semaine === semaine
                    ? "Ce " + JOURS_LONGS[controleAVenir.jour || 0]
                    : "Dans " + (controleAVenir.semaine - semaine)
                      + " semaine" + (controleAVenir.semaine - semaine > 1 ? "s" : "")
                      + ", le " + JOURS_LONGS[controleAVenir.jour || 0])
                    + " · " + (controleAVenir.duree || 120) + " min annoncées"}
                </p>
                <p className="small" style={{ marginTop: 8, color: "#7A5A12" }}>
                  Le programme de votre enfant est déjà réorganisé autour de
                  cette date : révisions, épreuve blanche, puis reprise.
                </p>
              </>
            ) : (
              <p className="small muted" style={{ marginTop: 8 }}>
                Aucun contrôle déclaré pour l'instant. C'est votre enfant qui
                l'annonce, dès qu'il connaît la date.
              </p>
            )}
          </div>

          {/* Le bilan de la semaine écoulée, en second : utile, mais ce n'est
              pas ce qu'un parent vient chercher en premier. */}
          <div className="card">
            <span className="eyebrow">La semaine écoulée</span>
            <h3 style={{ marginTop: 8 }}>{heures(minutes(faites(semPassee)))}</h3>
            <p className="small muted" style={{ marginTop: 4 }}>
              {faites(semPassee).length} séance(s) faite(s)
              {manquees(semPassee).length
                ? " · " + manquees(semPassee).length + " manquée(s)"
                : " · aucune manquée"}
            </p>
            {semPassee.length > 0 && (
              <div className="bar" style={{ marginTop: 12 }}>
                <i style={{ width: (faites(semPassee).length / semPassee.length) * 100 + "%" }} />
              </div>
            )}
          </div>
        </>
      )}

      {/* ═══════════════ L'HISTORIQUE ═══════════════ */}
      {vue === "historique" && (
        <>
          <div className="card">
            <div className="between">
              <h3>Les évaluations passées</h3>
              <span className="tag grey">{evaluations.length}</span>
            </div>
            {evaluations.length ? evaluations.map((e, k) => (
              <div key={k} style={{ padding: "10px 0",
                borderTop: k ? "1px solid #F0F2FA" : "none" }}>
                <div className="between">
                  <span className="small" style={{ color: "var(--ink)", fontWeight: 600 }}>
                    {(e.ct.chapitres || []).map(nomDe).join(" et ")}
                  </span>
                  <span className={"tag " + (e.copie ? "green" : "grey")}>
                    {e.copie ? "copie rendue" : "sans copie"}
                  </span>
                </div>
                <p className="small muted" style={{ marginTop: 3 }}>
                  Semaine {e.ct.semaine} · {JOURS_LONGS[e.ct.jour || 0]}
                  {e.ct.duree ? " · " + e.ct.duree + " min" : ""}
                </p>
                {e.copie?.note != null && (
                  <p className="small" style={{ marginTop: 3, color: "#7A5A12" }}>
                    Note : {e.copie.note}{e.copie.bareme ? "/" + e.copie.bareme : ""}
                  </p>
                )}
              </div>
            )) : (
              <p className="small muted" style={{ marginTop: 8 }}>
                Aucune évaluation passée pour l'instant.
              </p>
            )}
          </div>

          <div className="card">
            <div className="between">
              <h3>Les cours en visioconférence</h3>
              <span className="tag grey">{directs.length}</span>
            </div>
            {directs.length ? directs.map((d, k) => (
              <div key={k} className="row" style={{ padding: "9px 0",
                alignItems: "baseline", gap: 10,
                borderTop: k ? "1px solid #F0F2FA" : "none" }}>
                <div style={{ flex: 1 }}>
                  <p className="small" style={{ color: "var(--ink)" }}>{d.titre}</p>
                  <p className="small muted" style={{ fontSize: ".74rem" }}>
                    {"Semaine " + d.sem + (d.detail ? " · " + d.detail : "")}
                  </p>
                </div>
                <span className={"tag " + (d.present ? "green"
                  : d.inscrit ? "gold" : "grey")} style={{ flex: "none" }}>
                  {d.present ? "présent" : d.inscrit ? "inscrit" : "absent"}
                </span>
              </div>
            )) : (
              <p className="small muted" style={{ marginTop: 8 }}>
                Aucun cours en visioconférence n'a encore été programmé.
              </p>
            )}
          </div>
        </>
      )}

      {/* ═══════════════ L'AVANCEMENT ═══════════════ */}
      {vue === "avance" && (
        <>
          <div className="card">
            <div className="between">
              <h3>Les chapitres terminés</h3>
              <span className={"tag " + (termines.length ? "green" : "grey")}>
                {termines.length}
              </span>
            </div>
            {termines.length ? termines.map((c, k) => (
              <div key={c.id} className="row" style={{ padding: "8px 0",
                alignItems: "baseline", gap: 10,
                borderTop: k ? "1px solid #F0F2FA" : "none" }}>
                <span className="small" style={{ flex: 1, color: "var(--ink)" }}>
                  {c.nom}
                </span>
                <span className="small muted" style={{ flex: "none",
                  fontSize: ".76rem" }}>
                  {c.fin != null ? "semaine " + c.fin : ""}
                </span>
              </div>
            )) : (
              <p className="small muted" style={{ marginTop: 8 }}>
                Aucun chapitre terminé pour l'instant.
              </p>
            )}
          </div>

          {/* Les gestes des chapitres EN COURS : c'est là que se joue le
              travail du moment, et le détail intéresse le parent autant que
              le compte. */}
          {couverture.length ? couverture.map((c) => (
            <div className="card" key={c.id}>
              <div className="between">
                <h3>{c.nom}</h3>
                <span className={"tag " + (c.vues.size === c.toutes.length
                  ? "green" : c.vues.size ? "gold" : "grey")}>
                  {c.vues.size}/{c.toutes.length}
                </span>
              </div>
              <div className="bar" style={{ marginTop: 10 }}>
                <i style={{ width: (c.vues.size / c.toutes.length) * 100 + "%" }} />
              </div>
              <p className="small muted" style={{ marginTop: 8 }}>
                Les gestes de la fiche que votre enfant a déjà travaillés.
              </p>
              <details style={{ marginTop: 8 }}>
                <summary className="small" style={{ cursor: "pointer",
                  color: "#5B6BB5" }}>voir le détail</summary>
                <div style={{ marginTop: 6 }}>
                  {c.toutes.map((k) => (
                    <div key={k} className="row" style={{ padding: "4px 0",
                      alignItems: "baseline", gap: 8 }}>
                      <span className={"tag " + (c.vues.has(k) ? "green" : "grey")}
                        style={{ flex: "none", minWidth: 22, textAlign: "center" }}>
                        {c.vues.has(k) ? "✓" : ""}
                      </span>
                      <span className="small" style={{ flex: 1,
                        fontSize: ".78rem",
                        color: c.vues.has(k) ? "var(--ink)" : "#8A90AB" }}>
                        {c.titres[k]}
                      </span>
                    </div>
                  ))}
                </div>
              </details>
            </div>
          )) : (
            <div className="card">
              <p className="small muted">
                Aucun chapitre en cours. Votre enfant en déclarera un dès qu'il
                l'abordera en classe.
              </p>
            </div>
          )}
        </>
      )}
    </>
  );
}

function EspaceCoach({ biblio, setBiblio, copies, setCopies, taches, chapitres, semaine, controle = null, ouvrirRelance, rendreCopie, manquements = [], relances = [], absAujourdhuiCoach = 0, questionsDirect = [], inscrits = [], ressources = {}, ajouterRessource, retirerRessource, viderRessources, libres = [], ancreLe = null, periodes = [], profil = null, oralOuvert = false, setOralOuvert, directs = [], annulerDirect, avisDirect, programmerDirect,
  oral = null, setOral, ideesOral = [], setIdeesOral, banques = BANQUES }) {
  const [vue, setVue] = useState("semaine");
  const [copieOuverte, setCopieOuverte] = useState(null);   // copie affichée en grand
  const [exoOuvert, setExoOuvert] = useState(null);         // exercice dont on gère les fichiers
  const champLot = useRef(null);
  const [lot, setLot] = useState(null);                     // dépôt d'un chapitre entier
  const [invitations, setInvitations] = useState([]);
  const [elevesInscrits, setElevesInscrits] = useState([]);
  const [invit, setInvit] = useState({ courriel: "", role: "eleve", prenom: "", eleveId: "", test: false, groupe: "instagram" });
  const [avis, setAvis] = useState(null);
  const [aAnnuler, setAAnnuler] = useState(null);   // cours en attente de confirmation
  /* La semaine que le coach regarde, pour chaque élève : il peut remonter dans
     les semaines passées sans perdre celle qu'il consultait chez un autre. */
  /* Les cours de la semaine regardée, triés par jour : le coach en programme
     plusieurs, chacun avec ses inscrits et ses questions. */
  /* LE GROUPE REGARDÉ. « Tous » par défaut : le coach retrouve sa liste telle
     qu'elle était, et filtre quand il veut travailler sur un seul groupe. */
  const [groupeVu, setGroupeVu] = useState("tous");

  const directsSemaine = (directs || []).filter((d) => d.semaine === semaine)
    .sort((a, b) => (a.jour ?? 2) - (b.jour ?? 2));
  const [semaineVue, setSemaineVue] = useState({});
  const [aSupprimer, setASupprimer] = useState(null);   // élève en attente de confirmation
  const [aRemettre, setARemettre] = useState(null);     // élève à remettre à zéro
  /* L'HISTORIQUE DE TOUS LES ÉLÈVES : il est chargé par « rafraichirEleves »,
     avec les états et le direct, en une seule salve parallèle. Un second
     chargement séparé doublait les requêtes sans rien apporter. */
  const [histoEleves, setHistoEleves] = useState({});


  /* Les alertes que le coach a écartées cette semaine : elles reviennent au
     changement de semaine, car la situation aura pu évoluer. */
  const [ecartees, setEcartees] = useState([]);
  useEffect(() => { setEcartees([]); }, [semaine]);
  const [purge, setPurge] = useState(null);             // suppression de tous les élèves

  const [parents, setParents] = useState([]);
  const rafraichirAcces = async () => {
    setInvitations(await listerInvitations());
    setElevesInscrits(await listerEleves());
    setParents(await listerParents());
  };
  useEffect(() => { if (vue === "acces") rafraichirAcces(); }, [vue]);
  const champsExo = useRef({});

  /* Attacher un énoncé ou un corrigé à un exercice DÉJÀ dans la bibliothèque :
     sans cela, seuls les exercices créés à la main pouvaient recevoir leurs
     fichiers, et les quinze exercices livrés restaient inaccessibles.

     L'ÉCRITURE EN BASE est la raison d'être de cette fonction : elle ne
     faisait que rafraîchir l'écran. Le PDF montait bien dans le stockage, le
     coach lisait « complet », et le rechargement suivant relisait la base —
     où rien n'avait été écrit. D'où des corrigés déposés la veille et
     introuvables le lendemain. */
  const majExercice = async (chap, id, champs) => {
    const exo = (biblio[chap] || []).find((x) => x.id === id);
    setBiblio((b) => ({ ...b, [chap]: (b[chap] || []).map((x) => (x.id === id ? { ...x, ...champs } : x)) }));
    if (!supabaseActif || !exo) return;
    const r = await majFichiersExerciceDb(chap, exo, champs);
    /* Un refus de la base ne doit pas rester muet : sans ce retour, le coach
       croit son dépôt enregistré et ne s'aperçoit de rien. */
    if (!r?.ok) {
      setAvis({ bon: false,
                txt: "Fichier non enregistré : " + (r?.message || "refus de la base") });
    } else {
      setAvis({ bon: true, txt: "Fichier enregistré." });
    }
  };
  /* ENREGISTRER UN LOT DÉPOSÉ PAR ARCHIVE.

     Deux défauts se logeaient ici. D'abord l'écriture était conditionnée à la
     présence d'exercices CRÉÉS, c'est-à-dire à celle d'un manifeste : une
     archive de PDF seuls montait dans le stockage sans qu'une ligne soit
     écrite. Ensuite « poserExerciceDb » RETOURNE son échec au lieu de le
     lever — le « try » qui l'entourait ne voyait donc jamais un refus de la
     base, et le coach croyait son dépôt enregistré.

     On écrit maintenant les exercices créés ET ceux, déjà en bibliothèque,
     dont l'archive apporte un fichier ; et l'on compte les refus. */
  const enregistrerLot = async (chapitre, r, biblioDuChapitre) => {
    const crees = r.crees || [];
    const dejaLa = (biblioDuChapitre || [])
      .filter((x) => r.majs?.[x.id] && !crees.some((c) => c.id === x.id));
    const aEcrire = [...crees, ...dejaLa];
    const echecs = [];
    for (const ex of aEcrire) {
      /* On FUSIONNE avec « majs » : les exercices sont créés d'abord, leurs
         PDF rattachés ensuite — sans cette fusion, les énoncés étaient perdus
         et la colonne restait vide. */
      const rep = await poserExerciceDb(chapitre,
        { ...ex, ref: ex.ref || ex.id, ...(r.majs?.[ex.id] || {}) });
      if (!rep?.ok) echecs.push((ex.titre || ex.id) + " — " + (rep?.message || "refus"));
    }
    return { ecrits: aEcrire.length - echecs.length, echecs };
  };

  const [retour, setRetour] = useState("");                 // commentaire de correction
  const [pieges, setPieges] = useState([]);                 // erreurs classiques cochées
  const [vocal, setVocal] = useState(null);                 // message vocal joint
  const [annotees, setAnnotees] = useState([]);             // pages annotées
  const champAnnot = useRef(null);

  /* Les pièges des questions types couvertes par les exercices de la copie :
     ils viennent des banques, donc l'élève retrouve les mots de sa fiche. */
  const piegesDeLaCopie = (c) => {
    const chaps = [...new Set((c.exos || []).map((e) => e.chapId).filter(Boolean))];
    const vus = new Set();
    return chaps.flatMap((ch) => (banques[ch] || [])
      .filter((q) => q.piege && q.source_qt)
      .filter((q) => { const k = q.piege; if (vus.has(k)) return false; vus.add(k); return true; })
      .slice(0, 8)
      .map((q) => ({ qt: q.source_qt, texte: q.piege.replace(/<[^>]+>/g, "") })));
  };
  /* Le lien de la salle se retient : le coach le saisit une fois, il se
     reporte ensuite sur chaque nouveau direct. Il reste modifiable, pour une
     séance qui aurait besoin d'une salle à part. */
  const [salle, setSalle] = useState(
    () => (typeof localStorage !== "undefined" && localStorage.getItem("btp.salle"))
          || SALLE_PAR_DEFAUT);
  const [dir, setDir] = useState({ semaine: semaine, jour: DIRECT_JOUR, heure: DIRECT_HEURE,
    duree: 60, titre: "", chapId: CHAPITRES[0].id,
    lien: (typeof localStorage !== "undefined" && localStorage.getItem("btp.salle"))
          || SALLE_PAR_DEFAUT });
  const [edition, setEdition] = useState(null);      // direct en cours de modification
  const formDirect = useRef(null);

  const dirVierge = () => ({ semaine, jour: DIRECT_JOUR, heure: DIRECT_HEURE, duree: 60, titre: "", chapId: CHAPITRES[0].id, lien: "" });

  /* "Modifier" recharge le formulaire ET y ramene l'ecran : sans ce defilement,
     sur telephone, le clic semble ne rien faire. */
  const modifierDirect = (d) => {
    setDir({ ...d });
    setEdition(d.id);
    setVue("directs");
    setTimeout(() => formDirect.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  };
  const [chapId, setChapId] = useState(CHAPITRES[0].id);
  /* Le vidage complet d'un chapitre attend confirmation : c'est irréversible
     pour les élèves, qui perdent l'accès à tout ce qui était déposé. */
  const [videToutes, setVideToutes] = useState(false);
  const champEvals = useRef(null);
  const [lotEvals, setLotEvals] = useState(null);
  const champFiches = useRef(null);
  const [lotFiches, setLotFiches] = useState(null);
  const [collage, setCollage] = useState("");
  const champCsv = useRef(null);
  const [lotVideos, setLotVideos] = useState(null);
  const [form, setForm] = useState({ titre: "", duree: 20, niveau: "moyen", usage: "entrainement", url: "", urlCorrige: "" });
  const champFiche = useRef(null);
  const [depot, setDepot] = useState(null);
  const [res, setRes] = useState({ type: "Leçon", titre: "", url: "", duree: "", pages: "" });
  const formBiblio = useRef(null);

  /* « Ouvrir » sélectionne le chapitre ET ramène l'écran sur le formulaire :
     sans ce défilement, sur téléphone, le clic semble ne rien faire. */
  const ouvrirChapitre = (id) => {
    setChapId(id);
    setTimeout(() => formBiblio.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  };
  /* Les élèves de démonstration n'existent qu'en mode aperçu : le coach ne
     doit voir que ses vrais élèves, et surtout aucune fausse alerte. */
  const [suivi, setSuivi] = useState(supabaseActif ? [] : ORAL_DEMO);
  const [reformuler, setReformuler] = useState(null);
  const [motReform, setMotReform] = useState("");
  const [fiche, setFiche] = useState({ chapId: CHAPITRES[0].id, niveau: "accessible", question: "",
    notions: "", pistes: ["", "", ""], jury: ["", "", "", "", "", ""] });
  const [ouvert, setOuvert] = useState(null);

  /* L'élève de la démo, calculé sur ses vraies tâches de la semaine */
  const faites = taches.filter((t) => t.statut === "fait");
  const principal = chapitres.find((c) => c.statut !== "termine");
  const moi = {
    nom: "Vous (démo)",
    chap: principal ? CHAPITRES.find((c) => c.id === principal.id).nom : "aucun chapitre",
    depuis: principal ? semaine - principal.semaineDebut + 1 : 0,
    diff: principal?.difficulte || "—",
    dernierTravail: faites.length ? 0 : 7,
    /* Une épreuve blanche n'est due que si un contrôle est déclaré ; une
       absence au direct n'a de sens que si un direct était programmé. */
    blanchePrevue: !!controle || taches.some((t) => t.type === "blanche"),
    directPrevu: (directs || []).some((d) => d.semaine === semaine),
    /* Les valeurs sont sans accent : ce sont elles que teste alertesEleve. */
    copie: copies.some((c) => c.statut === "en_attente") ? "a corriger"
         : copies.length ? "corrigee"
         /* Une épreuve blanche sautée est aussi grave qu'une copie non rendue :
            dans les deux cas le coach n'a rien à corriger et ne sait pas où en
            est l'élève. */
         : (manquements.some((x) => x.type === "blanche")
            || taches.some((t) => t.type === "blanche" && ["manquee", "abandonnee"].includes(t.statut)))
           ? "non faite" : "—",
    copiePages: (copies.find((c) => c.statut === "en_attente")?.photos || []).length,
    /* Les restitutions comptées à part : ce sont elles qui font tenir le cours
       dans la durée, et leur retard est le premier signal de décrochage. */
    restitRetard: taches.filter((t) => t.type === "restitution"
      && ["manquee", "abandonnee"].includes(t.statut)).length,
    restitFaites: taches.filter((t) => t.type === "restitution" && t.statut === "fait").length,
    restitPrevues: taches.filter((t) => t.type === "restitution").length,
    histo: [{ minutes: 0, seances: 0, prevues: 0, restit: 0, restitAttendues: 0, direct: false, retards: 0 },
            { minutes: 0, seances: 0, prevues: 0, restit: 0, restitAttendues: 0, direct: false, retards: 0 },
            { minutes: 0, seances: 0, prevues: 0, restit: 0, restitAttendues: 0, direct: false, retards: 0 },
            {
              minutes: faites.reduce((a, t) => a + t.duree, 0),
              seances: faites.filter((t) => ["flash", "exo", "bac"].includes(t.type)).length,
              prevues: taches.filter((t) => ["flash", "exo", "bac"].includes(t.type)).length,
              restit: faites.filter((t) => t.type === "restitution").length,
              restitAttendues: taches.filter((t) => t.type === "restitution" && !t.masquee).length,
              direct: inscrits.includes(semaine),
              retards: taches.filter((t) => t.statut === "manquee" || t.statut === "abandonnee").length,
              /* Une soirée compte pour un jour, quel que soit son nombre de tâches :
                 c'est le nombre de SOIRS sautés qui dit si l'élève décroche. */
              joursManques: new Set(taches.filter((t) => t.statut === "manquee")
                .map((t) => (t.semaine - 1) * 7 + t.jour)).size,
              joursRattrapes: new Set(taches.filter((t) => t.rattrape)
                .map((t) => (t.semaine - 1) * 7 + t.jour)).size,
            }],
  };
  /* Les élèves fictifs ne servent qu'à la démonstration : dès que la base est
     branchée, le coach ne doit voir que ses vrais élèves. Les laisser
     donnerait de fausses alertes à traiter chaque semaine. */
  /* Les vrais élèves, lus depuis la base. Le coach ne voyait jusqu'ici que son
     propre compte : ses élèves travaillaient sans qu'il puisse rien en lire. */
  const [reels, setReels] = useState([]);
  /* Les inscriptions et les questions du direct, tous élèves confondus. Elles
     vivent dans l'état de chaque élève : sans cette lecture, le coach ne voyait
     que les siennes — et le nombre d'inscrits était une valeur écrite en dur. */
  const [classe, setClasse] = useState({ inscrits: 0, noms: [], questions: [], parCours: {} });
  const [envoye, setEnvoye] = useState(null);      // point mensuel qui vient d'être transmis
  const rafraichirEleves = async () => {
    /* LES TROIS REQUÊTES EN PARALLÈLE : enchaînées, elles additionnaient leurs
       délais et le chargement traînait. L'historique part avec les deux
       autres — il doit avancer en même temps, sinon le détail d'une semaine
       se retrouve rattaché à la mauvaise. */
    /* Noms distincts de ceux des états : « classe » masquait la variable du
       même nom et le composant ne se rendait plus. */
    const [lesEtats, laClasse, lHisto] = await Promise.all([
      chargerEtatsEleves().catch(() => []),
      directDeLaClasse(semaine, directs.filter((d) => d.semaine === semaine))
        .catch(() => null),
      chargerHistoriquesEleves().catch(() => ({})),
    ]);
    setReels(lesEtats || []);
    if (laClasse) setClasse(laClasse);
    setHistoEleves(lHisto || {});
  };
  useEffect(() => {
    if (!supabaseActif) return;
    rafraichirEleves();
    /* ET RÉGULIÈREMENT : les états n'étaient relus qu'au changement de semaine
       DU COACH. Quand un élève passait à la semaine suivante, le coach le
       voyait encore sur l'ancienne — d'où une période figée dans l'étiquette
       et une semaine précédente absente du détail. */
    const t = setInterval(rafraichirEleves, 45000);
    return () => clearInterval(t);
  /* « directs » entre dans les dépendances : la date du cours arrive après le
     premier rendu, et sans ce rechargement le coach interrogeait la classe
     sans elle — donc sans jamais retrouver les questions. */
  }, [semaine, vue, directs]);

  /* Le travail des élèves EN DIRECT : dès qu'un élève termine une séance, son
     avancée remonte sur le tableau de bord sans que le coach ait à recharger. */
  useEffect(() => {
    if (!supabaseActif) return;
    /* On ESPACE les rafraîchissements : chaque écriture d'un élève en
       déclenchait un, et une simple séance en produit plusieurs — trente
       requêtes partaient en quelques secondes, chacune écrasant la
       précédente. Une seconde d'attente suffit à les regrouper. */
    let occupe = false, minuteur = null;
    return ecouterEtats(() => {
      clearTimeout(minuteur);
      minuteur = setTimeout(async () => {
        if (occupe) return;
        occupe = true;
        try { await rafraichirEleves(); } finally { occupe = false; }
      }, 3000);
    });
  }, [semaine]);

  /* On traduit l'état brut d'un élève dans la forme qu'attend le tableau de
     bord : chapitre en cours, séances de la semaine, copie, historique. */
  const depuisEtat = (x) => {
    const e = x.etat || {};
    /* L'HISTORIQUE ASSEMBLÉ, calculé une fois AVANT l'objet. « histo » lisait
       « e.journalSeances » — l'état brut, qui ne porte plus rien depuis que
       les séances vivent dans leur propre table. Il ne voyait donc jamais les
       séances chargées, et le bilan restait vide. */
    const journalAssemble = [...(histoEleves[x.id]?.seances || []),
      ...(e.journalSeances || []).filter((j) =>
        !(histoEleves[x.id]?.seances || []).some((h) => String(h.id) === String(j.id)))];
    const totauxAssembles = [...(histoEleves[x.id]?.semaines || []),
      ...(e.totauxSemaine || []).filter((t) =>
        !(histoEleves[x.id]?.semaines || []).some((h) => h.semaine === t.semaine))];
    /* Le DIRECT n'est pas une séance de travail : c'est un cours en visio, que
       l'élève suit ou manque, mais qu'il n'a rien à « faire ». Le compter
       gonflait le total et faisait apparaître un retard le lendemain. */
    const t = (e.taches || []).filter((y) => y.semaine === (e.semaine || 1)
      && !y.masquee && y.type !== "direct");
    const ch = (e.chapitres || []).find((c) => c.statut !== "termine");
    const cop = e.copies || [];
    return {
      id: x.id,
      nom: (x.prenom || "Élève") + (x.nom ? " " + x.nom : ""),
      chap: ch ? (CHAPITRES.find((c) => c.id === ch.id)?.nom || ch.id) : "aucun chapitre",
      depuis: ch ? (e.semaine || 1) - ch.semaineDebut + 1 : 0,
      /* LES JOURS DE L'ÉLÈVE ET SON PROGRAMME. Le coach voyait des séances
         manquées sans savoir si le jour était simplement chômé, et n'avait
         aucun moyen de dire à un élève ce qui l'attendait ce soir. */
      /* Le groupe suit l'élève jusqu'à sa fiche : le coach le voit, et la
         liste se filtre dessus. */
      groupe: x.groupe || "instagram",
      reglages: e.reglages || null,
      jour: e.jour ?? 0,
      semaine: e.semaine || 1,
      tachesSemaine: t,
      /* Ce qui remplace le niveau : le résultat du test et les gestes qu'il
         reste à reprendre. C'est cela qui commande maintenant les exercices. */
      diff: ch?.difficulte || "—",
      /* L'ancre de CET élève : le lundi de sa semaine d'inscription. */
      ancre: x.creeLe ? (() => { const d = new Date(x.creeLe);
        d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
        d.setHours(0, 0, 0, 0); return d.toISOString(); })() : null,
      score: ch?.score ?? null,
      total: ch?.total ?? null,
      qtRatees: ch?.qtRatees || [],
      gestes: ch ? Object.keys(TITRES_QT[ch.id] || {})
        .filter((k) => k.startsWith("QT")).length : 0,
      minutes: t.filter((y) => y.statut === "fait").reduce((a, y) => a + (y.duree || 0), 0),
      seances: t.filter((y) => y.statut === "fait").length,
      prevues: t.length,
      restit: t.filter((y) => y.type === "restitution" && y.statut === "fait").length,
      restitAttendues: t.filter((y) => y.type === "restitution").length,
      direct: false,
      /* Une épreuve blanche n'est attendue que si un contrôle a été déclaré :
         c'est lui qui la fait poser au programme. Sans contrôle, aucune copie
         n'est due, et l'alerte n'a pas lieu d'être. */
      blanchePrevue: !!e.controle
        || t.some((y) => y.type === "blanche" || y.type === "evaluation"),
      directPrevu: (directs || []).some((d) => d.semaine === (e.semaine || 1)),
      copie: cop.some((c) => c.statut === "en_attente") ? "a corriger"
           : cop.length ? "corrigee" : "non envoyee",
      copiePages: cop.find((c) => c.statut === "en_attente")?.pages || 0,
      /* Les COPIES ELLES-MÊMES, avec leurs photos : le coach ne recevait que
         le nombre de pages, et le bouton « Corriger » ouvrait une fenêtre
         vide — il n'avait rien à lire. */
      copies: cop.map((c) => ({ ...c, eleve: x.prenom || x.nom || "Élève",
                                eleveId: x.id })),
      /* Le JOURNAL DES SÉANCES et les TOTAUX FIGÉS : c'est ce qui permet au
         bilan mensuel de survivre aux recalculs de tâches. Sans eux, le coach
         voyait « 0/0 » sur des semaines réellement travaillées. */
      /* L'historique vient des TABLES DÉDIÉES ; on complète avec ce que
         l'état porte encore, le temps que les anciens comptes migrent. */
      journalSeances: journalAssemble,
      totauxSemaine: totauxAssembles,
      /* Les CHAPITRES de l'élève, en cours et terminés : le coach doit voir
         d'un coup d'œil où en est chacun, sans ouvrir son suivi. */
      chapitres: e.chapitres || [],
      /* LE CONTRÔLE DÉCLARÉ et ceux déjà passés. Ils n'étaient lus que pour en
         tirer un booléen d'alerte, et le coach n'avait donc aucune visibilité
         sur les dates : il voyait qu'une copie était attendue, jamais pour
         quel devoir ni pour quand. */
      controle: e.controle || null,
      controlesPasses: e.controlesPasses || [],
      joursManques: new Set(t.filter((y) => y.statut === "manquee").map((y) => y.jour)).size,
      joursRattrapes: new Set(t.filter((y) => y.rattrape).map((y) => y.jour)).size,
      dernierTravail: 0,
      restitRetard: t.filter((y) => y.type === "restitution" && y.statut === "manquee").length,
      restitPrevues: t.filter((y) => y.type === "restitution").length,
      /* L'historique se CALCULE sur les quatre dernières semaines, à partir des
         tâches réelles. Il était fabriqué : trois semaines vides suivies de la
         semaine en cours, ce qui affichait « 0 » sur des semaines réellement
         travaillées et faisait disparaître la semaine courante du graphique. */
      /* Les périodes closes de cet élève : quatre semaines ne disent rien d'un
         trimestre. */
      periodes: (periodes || []).filter((x) => !x.eleve_id
        || x.eleve_id === e.id).sort((a, b) => b.numero - a.numero),
      /* Le bloc EN COURS, et lui seul : les semaines 1 à 4, puis 5 à 8, et
         ainsi de suite. Une fenêtre glissante de quatre semaines affichait
         des colonnes vides pour un élève qui vient de s'inscrire, et faisait
         disparaître les semaines dès la cinquième. Chaque bloc achevé rejoint
         le résumé en dessous. */
      /* Le bloc EN COURS : semaines 1 à 4, puis 5 à 8. Un élève qui vient de
         s'inscrire voit une colonne, pas quatre dont trois vides. */
      histo: (() => {
        const sem = e.semaine || 1;
        const debut = Math.floor((sem - 1) / 4) * 4 + 1;
        return Array.from({ length: Math.max(1, sem - debut + 1) },
          (_, i) => debut + i);
      })().map((n) => {
        /* Le DIRECT est exclu : c'est un cours en visio, pas une séance de
           travail. Le compter ajoutait une tâche fantôme au total de la
           semaine, et son suivi se fait à part, sur la ligne « direct ». */
        /* Le TEST DE POSITIONNEMENT compte dans l'historique : c'est bien du
           travail fait, et une semaine de déclaration n'en porte souvent que
           lui — elle affichait alors « 0/0 », comme si l'élève n'avait rien eu
           à faire. Seul le direct reste exclu : c'est un cours, pas une
           séance. */
        /* Le JOURNAL DES SÉANCES prime : les tâches sont recalculées sans
           cesse et leur historique fondait. Le journal, lui, n'est jamais
           recalculé — une ligne par séance terminée. On complète avec les
           tâches encore présentes pour connaître le total prévu. */
        const faitesJournal = journalAssemble.filter((y) => y.semaine === n);
        /* Les séances HORS PROGRAMME — gestes travaillés à la demande — ne
           comptent pas dans le total prévu : elles gonfleraient « 12/15 » en
           « 12/18 » alors que l'élève a fait plus, pas moins. */
        const l = (e.taches || []).filter((y) => y.semaine === n && !y.masquee
          && y.type !== "direct" && !y.horsProgramme);
        /* Les séances du journal qui ne figurent plus dans les tâches : elles
           ont été effacées par un recalcul, on les rétablit ici. */
        /* On compare les identifiants EN TEXTE : la base les renvoie en
           chaîne, les tâches les portent en nombre, et l'égalité stricte était
           toujours fausse — chaque séance comptait deux fois, ou pas du tout. */
        const perdues = faitesJournal
          .filter((j) => !l.some((y) => String(y.id) === String(j.id)))
          .map((j) => ({ ...j, statut: "fait" }));
        const lot = [...l, ...perdues];
        /* Le TOTAL FIGÉ prime sur ce qui reste : les tâches d'une semaine
           révolue ont pu être effacées par un recalcul, et « lot.length »
           n'aurait compté que les séances retrouvées. */
        const fige = totauxAssembles.find((z) => z.semaine === n);
        const totalPrevu = Math.max(fige ? fige.prevues : 0, lot.length);
        return {
          semaine: n,
          minutes: lot.filter((y) => y.statut === "fait").reduce((a, y) => a + (y.duree || 0), 0),
          /* Toutes les autres tâches comptent : restitutions et épreuves
             blanches en font partie. Ne compter que les exercices affichait
             10 tâches là où l'élève en voyait 15. */
          seances: lot.filter((y) => y.statut === "fait").length,
          prevues: totalPrevu,
          restit: lot.filter((y) => y.type === "restitution" && y.statut === "fait").length,
          restitAttendues: lot.filter((y) => y.type === "restitution").length,
          /* LE DÉTAIL DE LA SEMAINE : savoir qu'un élève a fait 12 séances sur
             15 ne dit pas ce qu'il a sauté. On donne la répartition par nature
             de séance, par chapitre, par jour, et le résultat des exercices. */
          detail: (() => {
            const faites = lot.filter((y) => y.statut === "fait");
            const parType = {};
            faites.forEach((y) => {
              const t = y.type === "restitution" ? "feuille blanche"
                      : y.type === "bac" ? "sujet type bac"
                      : y.type === "flash" ? "questions flash"
                      : y.type === "blanche" ? "épreuve blanche"
                      : y.type === "reprise" ? "reprise"
                      : y.type === "revision" ? "révision"
                      : y.type === "rappel" ? "rappel"
                      : y.type === "diagnostic" ? "test"
                      : "exercice";
              parType[t] = (parType[t] || 0) + 1;
            });
            const parChap = {};
            faites.forEach((y) => {
              if (!y.chapId) return;
              const nom = CHAPITRES.find((c) => c.id === y.chapId)?.court || y.chapId;
              parChap[nom] = (parChap[nom] || 0) + 1;
            });
            /* LES SOIRÉES SANS RIEN. On ne peut pas se fier au seul « lot » :
               les tâches d'une semaine révolue sont souvent effacées, et une
               soirée entièrement manquée n'y laisse aucune trace. On regarde
               donc les jours où l'élève avait des soirées prévues — ses jours
               travaillés — sans aucune séance faite. */
            /* UNE SOIRÉE SANS RIEN est une soirée où l'élève avait du travail
               prévu et n'a rien fait. On se fie aux TÂCHES : signaler tout jour
               travaillé sans séance faite accusait à tort les jours où rien
               n'était programmé. */
            const soirsVides = [];
            for (let j = 0; j < 7; j += 1) {
              const duJour = lot.filter((y) => y.jour === j);
              if (!duJour.length) continue;                   // rien n'était prévu
              if (!duJour.some((y) => y.statut === "fait")) {
                soirsVides.push(["lun", "mar", "mer", "jeu", "ven", "sam", "dim"][j]);
              }
            }
            const exos = faites.filter((y) => y.type === "exo" && y.resultat);
            return {
              parType: Object.entries(parType).sort((a, b) => b[1] - a[1]),
              parChap: Object.entries(parChap).sort((a, b) => b[1] - a[1]),
              soirsVides,
              acquis: exos.filter((y) => y.resultat === "acquis").length,
              hesitant: exos.filter((y) => y.resultat === "hesitant").length,
              rate: exos.filter((y) => y.resultat === "rate").length,
            };
          })(),
          direct: (e.inscrits || []).includes(n),
          /* Dans une semaine révolue, toute tâche non faite est un retard :
             elle ne sera plus reprise. La semaine en cours, elle, ne compte
             que les soirées déjà déclarées manquées. */
          /* « La semaine en cours » se reconnaît à son NUMÉRO : le recul
             n'existe plus depuis que les colonnes suivent le bloc. */
          retards: n === (e.semaine || 1)
            ? l.filter((y) => ["manquee", "abandonnee"].includes(y.statut)).length
            : l.filter((y) => y.statut !== "fait").length,
          joursManques: new Set(l.filter((y) => y.statut === "manquee").map((y) => y.jour)).size,
          joursRattrapes: new Set(l.filter((y) => y.rattrape).map((y) => y.jour)).size,
        };
      }),
    };
  };

  /* La fiche « Vous (démo) » n'a de sens qu'en DÉMONSTRATION : branché à la
     base, le coach n'est pas un élève, et sa propre fiche polluait le suivi
     — jusqu'à fausser les inscriptions au direct qu'il avait saisies pour
     tester. */
  const tousLesEleves = supabaseActif
    ? reels.map(depuisEtat)
    : [moi, ...ELEVES_DEMO];
  /* La liste montrée, filtrée par groupe. Le groupe reste porté par chaque
     élève : le filtre ne change que l'affichage, jamais les données. */
  const auGroupe = (e) => groupeVu === "tous"
    || (e.groupe || "instagram") === groupeVu;
  const eleves = tousLesEleves.filter(auGroupe);

  /* LES PUCES DE GROUPE, posées sur la semaine comme sur le mois : le coach
     doit distinguer ses deux publics partout où il lit une liste d'élèves. */
  const groupesMeles = supabaseActif
    && tousLesEleves.some((e) => (e.groupe || "instagram") !== "instagram");
  const filtreGroupes = groupesMeles ? (
    <div className="chips" style={{ marginBottom: 12 }}>
      {[["tous", "Tous"], ["instagram", "Instagram"], ["lycee", "Lycée"]]
        .map(([g, l]) => (
          <button key={g} className={"chip" + (groupeVu === g ? " on" : "")}
            onClick={() => setGroupeVu(g)}>
            {l + " (" + (g === "tous" ? tousLesEleves.length
              : tousLesEleves.filter((e) => (e.groupe || "instagram") === g).length)
              + ")"}
          </button>
        ))}
    </div>
  ) : null;

  

  /* Toutes les copies rendues par les élèves, à corriger ou déjà corrigées. */
  /* Les copies corrigées pendant cette session : l'état des élèves est relu
     de la base, il ne reflète pas encore la correction qu'on vient de rendre. */
  const [corrigeesLocal, setCorrigeesLocal] = useState([]);
  const toutesLesCopies = (supabaseActif
    ? eleves.flatMap((e) => e.copies || [])
    : copies).map((c) => (corrigeesLocal.includes(c.id)
      ? { ...c, statut: "corrigee", corrigee: true } : c));

  /* LES CONTRÔLES DÉCLARÉS PAR LES ÉLÈVES, à plat et datés.

     Un contrôle ne porte pas de date : il est repéré par une semaine et un
     jour, comptés depuis l'inscription de l'élève. Deux élèves inscrits à
     quinze jours d'écart n'ont donc pas la même « semaine 3 », et le coach ne
     pouvait rien comparer. On rend ici la vraie date, calculée avec l'ancre
     de chacun. */
  const nomDuChapitre = (id) => CHAPITRES.find((c) => c.id === id)?.nom || id;
  const controlesDesEleves = eleves.flatMap((el) => [
    ...(el.controle ? [{ ...el.controle, passe: false }] : []),
    ...(el.controlesPasses || []).map((ct) => ({ ...ct, passe: true })),
  ].map((ct) => ({
    ...ct, eleve: el.nom, eleveId: el.id,
    date: dateDe(el.ancre || ancreLe, ct.semaine, ct.jour),
    enClair: jourEnClair(el.ancre || ancreLe, ct.semaine, ct.jour),
  })));
  const controlesAVenir = controlesDesEleves.filter((c) => !c.passe)
    .sort((a, b) => (a.date?.getTime() || 0) - (b.date?.getTime() || 0));

  /* RATTACHER UNE COPIE À SON CONTRÔLE. Une copie ne garde pas de renvoi vers
     le devoir qu'elle prépare : seuls ses chapitres permettent de la
     rattacher, comme côté élève. Faute de chapitres — les copies anciennes
     n'en portent pas — on prend le contrôle le plus proche de la semaine du
     dépôt, ce qui vaut mieux que rien du tout. */
  const controleDeLaCopie = (c) => {
    const miens = controlesDesEleves.filter((x) => x.eleveId === c.eleveId);
    if (!miens.length) return null;
    const chaps = c.chapitres || [];
    return miens.find((x) => (x.chapitres || []).some((ch) => chaps.includes(ch)))
      || (chaps.length ? null
          : miens.slice().sort((a, b) =>
              Math.abs(a.semaine - c.semaine) - Math.abs(b.semaine - c.semaine))[0])
      || null;
  };

  /* Toutes les alertes, les plus graves d'abord */
  const toutesAlertes = eleves
    .flatMap((e) => alertesEleve(e).map((a) => ({ ...a, eleve: e.nom, eleveId: e.id })))
    .sort((a, b) => (a.niveau === "rouge" ? 0 : a.niveau === "vert" ? 2 : 1)
                  - (b.niveau === "rouge" ? 0 : b.niveau === "vert" ? 2 : 1));
  const rouges = toutesAlertes.filter((a) => a.niveau === "rouge").length;

  const ajouter = async () => {
    if (!form.titre.trim()) return;
    const nouvel = { id: chapId + Date.now(), titre: form.titre, duree: Number(form.duree),
      niveau: form.niveau, usage: form.usage,
      /* La référence voyage avec l'exercice : c'est par elle qu'un dépôt
         d'archive ultérieur retrouvera cette ligne au lieu d'en créer une
         seconde. */
      ref: chapId + "-" + Date.now(),
      url: (form.url || "").trim() || null, urlCorrige: (form.urlCorrige || "").trim() || null };
    setBiblio((b) => ({ ...b, [chapId]: [...(b[chapId] || []), nouvel] }));
    setForm({ titre: "", duree: 20, niveau: "moyen", usage: form.usage, url: "", urlCorrige: "" });
    if (!supabaseActif) return;
    /* ATTENDRE ET LIRE LE RETOUR : lancé sans « await » ni contrôle, l'ajout
       pouvait être refusé par la base sans que rien ne le dise — l'exercice
       s'affichait, puis disparaissait au rechargement. */
    const r = await ajouterExerciceDb(chapId, nouvel);
    if (!r?.ok) {
      setAvis({ bon: false,
                txt: "Exercice non enregistré : " + (r?.message || "refus de la base") });
    } else if (r.id) {
      /* La base a engendré son identifiant : l'adopter tout de suite, sinon
         l'écran garde l'identifiant local et le dépôt des fichiers, juste
         après, ne retrouve pas la ligne. */
      setBiblio((b) => ({ ...b, [chapId]: (b[chapId] || [])
        .map((x) => (x.id === nouvel.id ? { ...x, id: r.id } : x)) }));
    }
  };

  const barre = (v, max, couleur) => (
    <span style={{ display: "inline-block", width: 46, height: 7, borderRadius: 99, background: "#E9EDFB", overflow: "hidden", verticalAlign: "middle" }}>
      <span style={{ display: "block", height: "100%", width: Math.min(100, max ? (v / max) * 100 : 0) + "%", background: couleur, borderRadius: 99 }} />
    </span>
  );
  const hm = (min) => Math.floor(min / 60) + " h " + String(min % 60).padStart(2, "0");

  return (
    <div>
      <p className="eyebrow">Espace coach</p>
      <h1 style={{ marginTop: 6, marginBottom: 16 }}>Suivi des élèves</h1>
      <div className="seg">
        <button className={vue === "semaine" ? "on" : ""} onClick={() => setVue("semaine")}>Semaine</button>
        <button className={vue === "mois" ? "on" : ""} onClick={() => setVue("mois")}>Mois</button>
        <button className={vue === "copies" ? "on" : ""} onClick={() => setVue("copies")}>Copies</button>
        <button className={vue === "biblio" ? "on" : ""} onClick={() => setVue("biblio")}>Bibliothèque</button>
        <button className={vue === "ressources" ? "on" : ""} onClick={() => setVue("ressources")}>Cours</button>
        <button className={vue === "directs" ? "on" : ""} onClick={() => setVue("directs")}>Directs</button>
        <button className={vue === "oral" ? "on" : ""} onClick={() => setVue("oral")}>Grand oral</button>
        <button className={vue === "acces" ? "on" : ""} onClick={() => setVue("acces")}>Accès</button>
      </div>

      {/* ---------------- ACCÈS ---------------- */}
      {vue === "acces" && (
        <>
          {/* L'invitation du coach est la SEULE porte d'entrée : un courriel non
              invité peut demander autant de liens de connexion qu'il veut, la
              base lui refusera tout profil, donc tout accès. */}
          <div className="card">
            <span className="eyebrow">Donner un accès</span>
            <h3 style={{ marginTop: 8 }}>Inviter un élève ou un parent</h3>
            <p className="small muted" style={{ marginTop: 6 }}>
              La personne recevra un lien de connexion à l'adresse indiquée.
              Sans invitation de votre part, personne ne peut entrer.
            </p>

            <div className="chips" style={{ marginTop: 12 }}>
              {[["eleve", "Un élève"], ["parent", "Un parent"]].map(([k, l]) => (
                <button key={k} className={"chip" + (invit.role === k ? " on" : "")}
                  onClick={() => setInvit({ ...invit, role: k, eleveId: "" })}>{l}</button>
              ))}
            </div>

            <p className="small muted" style={{ marginTop: 14 }}>Adresse électronique</p>
            <input className="input" type="email" value={invit.courriel}
              placeholder="prenom.nom@exemple.fr"
              onChange={(e) => setInvit({ ...invit, courriel: e.target.value })} />

            <p className="small muted" style={{ marginTop: 10 }}>Prénom</p>
            <input className="input" value={invit.prenom}
              onChange={(e) => setInvit({ ...invit, prenom: e.target.value })} />

            {invit.role === "eleve" && (
              <>
                {/* LE GROUPE. « Instagram » reste la valeur par défaut : rien
                    ne change pour les comptes déjà ouverts. Un élève du lycée
                    reçoit tout, sauf les cours en visioconférence. */}
                <p className="small muted" style={{ marginTop: 12 }}>Groupe</p>
                <div className="chips" style={{ marginTop: 6 }}>
                  {[["instagram", "Instagram"], ["lycee", "Lycée"]].map(([g, l]) => (
                    <button key={g}
                      className={"chip" + ((invit.groupe || "instagram") === g ? " on" : "")}
                      onClick={() => setInvit({ ...invit, groupe: g })}>{l}</button>
                  ))}
                </div>
                {(invit.groupe || "instagram") === "lycee" && (
                  <p className="small muted" style={{ marginTop: 6 }}>
                    Cet élève n'aura pas les cours en visioconférence. Tout le
                    reste lui est identique.
                  </p>
                )}
                <div className="chips" style={{ marginTop: 12 }}>
                  <button className={"chip" + (invit.test ? " on" : "")}
                    onClick={() => setInvit({ ...invit, test: !invit.test })}>
                    {invit.test ? "✓ Compte de test" : "Compte de test"}
                  </button>
                </div>
                {invit.test && (
                  <p className="small muted" style={{ marginTop: 6 }}>
                    Ce compte gardera le bouton « Jour +1 », pour parcourir
                    plusieurs semaines et vérifier le programme. À ne pas donner
                    à un vrai élève.
                  </p>
                )}
              </>
            )}

            {invit.role === "parent" && (
              <>
                <p className="small muted" style={{ marginTop: 10 }}>
                  Enfant à suivre — le parent ne verra que celui-ci
                </p>
                <div className="chips longue" style={{ marginTop: 6 }}>
                  {elevesInscrits.map((e) => (
                    <button key={e.id} className={"chip" + (invit.eleveId === e.id ? " on" : "")}
                      onClick={() => setInvit({ ...invit, eleveId: e.id })}>
                      {e.prenom} {e.nom || ""}
                    </button>
                  ))}
                </div>
                {!elevesInscrits.length && (
                  <p className="small muted" style={{ marginTop: 6 }}>
                    Aucun élève inscrit pour l'instant : invitez d'abord l'enfant.
                  </p>
                )}
              </>
            )}

            <button className="btn btn-accent btn-block" style={{ marginTop: 14 }}
              disabled={!invit.courriel.includes("@")
                        || (invit.role === "parent" && !invit.eleveId)}
              onClick={async () => {
                try {
                  const r = await inviterPersonne({ courriel: invit.courriel, role: invit.role,
                                          prenom: invit.prenom, eleveId: invit.eleveId,
                                          test: invit.test,
                                          groupe: invit.groupe || "instagram" });
                  /* Un parent déjà inscrit n'a pas besoin d'un nouveau lien :
                     il est simplement rattaché à un enfant de plus. Lui envoyer
                     une invitation consommerait un courriel pour rien. */
                  if (r?.deja) {
                    setAvis({ bon: true, txt: invit.courriel
                      + " suit désormais un enfant de plus. Aucun courriel envoyé : "
                      + "ce compte existe déjà." });
                  } else {
                    await envoyerLienConnexion(invit.courriel.trim().toLowerCase());
                    setAvis({ bon: true, txt: "Invitation envoyée à " + invit.courriel });
                  }
                  setInvit({ courriel: "", role: invit.role, prenom: "", eleveId: "", test: false });
                  rafraichirAcces();
                } catch (e) {
                  setAvis({ bon: false, txt: String(e.message || e) });
                }
              }}>
              Envoyer l'invitation
            </button>
            {avis && (
              <p className="small" style={{ marginTop: 10,
                color: avis.bon ? "#1E6E52" : "#C0392B" }}>{avis.txt}</p>
            )}
          </div>

          <div className="card">
            <div className="between">
              <span className="eyebrow">Invitations</span>
              <span className="tag">{invitations.filter((i) => !i.utilisee_le).length} en attente</span>
            </div>
            {!invitations.length && (
              <p className="small muted" style={{ marginTop: 10 }}>
                Aucune invitation pour le moment.
              </p>
            )}
            {invitations.map((i) => {
              const expiree = !i.utilisee_le && new Date(i.expire_le) < new Date();
              return (
                <div key={i.id} className="row" style={{ gap: 10, padding: "9px 0",
                  borderBottom: "1px solid #EDF0FD", alignItems: "flex-start" }}>
                  <div style={{ flex: 1 }}>
                    <p className="small" style={{ margin: 0, fontWeight: 600 }}>{i.courriel}</p>
                    <p className="small muted" style={{ margin: "3px 0 0" }}>
                      {i.role === "parent"
                        ? "Parent" + (i.eleve ? " de " + i.eleve.prenom : "")
                        : "Élève"}
                      {" · "}
                      {i.utilisee_le ? "compte créé"
                        : expiree ? "expirée" : "en attente"}
                    </p>
                  </div>
                  {!i.utilisee_le && (
                    <button className="btn btn-ghost btn-sm"
                      onClick={async () => { await retirerInvitation(i.id); rafraichirAcces(); }}>
                      Retirer
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <div className="card">
            <div className="between">
              <span className="eyebrow">Mes élèves</span>
              <span className="tag">{elevesInscrits.length}</span>
            </div>
            {!elevesInscrits.length && (
              <p className="small muted" style={{ marginTop: 10 }}>
                Aucun élève inscrit. Invitez-en un ci-dessus.
              </p>
            )}
            {elevesInscrits.map((e) => (
              <div key={e.id} className="row" style={{ gap: 10, padding: "9px 0",
                borderBottom: "1px solid #EDF0FD", alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <p className="small" style={{ margin: 0, fontWeight: 600 }}>
                    {e.prenom} {e.nom || ""}
                  </p>
                  <p className="small muted" style={{ margin: "3px 0 0" }}>
                    {e.courriel} · {e.nb_parents} parent(s) rattaché(s)
                  </p>
                </div>
                {/* Suspendre plutôt qu'effacer : le travail de l'élève reste
                    consultable, mais il ne peut plus entrer. */}
                <div className="row" style={{ gap: 6, flex: "none" }}>
                  <button className="btn btn-ghost btn-sm"
                    onClick={async () => { await changerActivite(e.id, !e.actif); rafraichirAcces(); }}>
                    {e.actif ? "Suspendre" : "Réactiver"}
                  </button>
                  {/* La suppression est DÉFINITIVE : travail, copies, questions,
                      tout disparaît. Pour un simple retrait d'accès, « Suspendre »
                      suffit et conserve les données. */}
                  {/* Remettre à zéro SANS supprimer : l'élève garde son compte,
                      son mot de passe et son rattachement aux parents, mais
                      repart d'un calendrier neuf. Utile pour retester un
                      parcours, ou pour un élève qui recommence l'année. */}
                  {aRemettre === e.id ? (
                    <>
                      <button className="btn btn-accent btn-sm"
                        onClick={async () => {
                          try {
                            await reinitialiserEleve(e.id);
                            /* Si le coach se remet LUI-MÊME à zéro — c'est le
                               cas d'un compte de test qu'il utilise —, sa
                               session garde tout en mémoire : on recharge. */
                            if (e.id === profil?.id) { window.location.reload(); return; }
                            setAvis({ bon: true, txt: (e.nom || "L'élève")
                              + " repart de zéro : à sa prochaine connexion, il "
                              + "retrouvera la page de réglages." });
                          } catch (err) {
                            setAvis({ bon: false, txt: String(err.message || err) });
                          }
                          setARemettre(null); rafraichirAcces();
                        }}>Tout effacer</button>
                      <button className="btn btn-ghost btn-sm"
                        onClick={() => setARemettre(null)}>Annuler</button>
                    </>
                  ) : aSupprimer === e.id ? (
                    <>
                      <button className="btn btn-accent btn-sm"
                        onClick={async () => {
                          await supprimerEleve(e.id); setASupprimer(null); rafraichirAcces();
                        }}>Confirmer</button>
                      <button className="btn btn-ghost btn-sm"
                        onClick={() => setASupprimer(null)}>Annuler</button>
                    </>
                  ) : (
                    <>
                    <button className="btn btn-ghost btn-sm"
                      onClick={() => setARemettre(e.id)}>Remettre à zéro</button>
                    <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                      onClick={() => setASupprimer(e.id)}>Supprimer</button>
                    </>
                  )}
                </div>
              </div>
            ))}

            {/* La purge de fin d'année. Elle demande de recopier un mot : un
                bouton seul, même avec confirmation, finit toujours par être
                pressé par mégarde — et il n'y a aucun retour en arrière. */}
            {elevesInscrits.length > 0 && (
              <div style={{ marginTop: 14, paddingTop: 12, borderTop: "1px solid #EDF0FD" }}>
                {purge === null ? (
                  <button className="btn btn-ghost btn-sm btn-block" style={{ color: "#C0392B" }}
                    onClick={() => setPurge("")}>
                    Supprimer tous les élèves — fin d'année
                  </button>
                ) : (
                  <>
                    <p className="small" style={{ color: "#C0392B" }}>
                      Les {elevesInscrits.length} élèves seront effacés définitivement :
                      leur travail, leurs copies, leurs questions. Les parents qui
                      n'ont plus d'enfant suivi seront retirés eux aussi.
                      <b> Rien ne pourra être récupéré.</b>
                    </p>
                    <p className="small muted" style={{ marginTop: 10 }}>
                      Pour confirmer, recopiez : <b>SUPPRIMER</b>
                    </p>
                    <input className="input" value={purge} style={{ marginTop: 6 }}
                      onChange={(ev) => setPurge(ev.target.value)} />
                    <div className="row" style={{ gap: 8, marginTop: 10 }}>
                      <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                        onClick={() => setPurge(null)}>Annuler</button>
                      <button className="btn btn-accent btn-sm" style={{ flex: 1 }}
                        disabled={purge.trim().toUpperCase() !== "SUPPRIMER"}
                        onClick={async () => {
                          const r = await supprimerTousLesEleves();
                          setPurge(null);
                          setAvis({ bon: true, txt: r.eleves + " élève(s) et "
                            + r.parents + " parent(s) supprimés définitivement." });
                          rafraichirAcces();
                        }}>
                        Supprimer définitivement
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Les parents inscrits. Ils n'apparaissaient nulle part : impossible
              de savoir qui suivait quel enfant, ni de retirer un accès. */}
          {parents.length > 0 && (
            <div className="card">
              <div className="between">
                <span className="eyebrow">Les parents</span>
                <span className="tag">{parents.length}</span>
              </div>
              {parents.map((p) => (
                <div key={p.id} className="row" style={{ gap: 10, padding: "9px 0",
                  borderBottom: "1px solid #EDF0FD", alignItems: "flex-start" }}>
                  <div style={{ flex: 1 }}>
                    <p className="small" style={{ margin: 0, fontWeight: 600 }}>
                      {p.prenom} {p.nom || ""}
                    </p>
                    <p className="small muted" style={{ margin: "3px 0 0" }}>
                      {p.courriel} ·{" "}
                      {p.enfants.length ? "suit " + p.enfants.join(", ")
                                        : "aucun enfant rattaché"}
                    </p>
                  </div>
                  {aSupprimer === p.id ? (
                    <>
                      <button className="btn btn-accent btn-sm"
                        onClick={async () => {
                          await supprimerParent(p.id); setASupprimer(null); rafraichirAcces();
                        }}>Confirmer</button>
                      <button className="btn btn-ghost btn-sm"
                        onClick={() => setASupprimer(null)}>Annuler</button>
                    </>
                  ) : (
                    <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                      onClick={() => setASupprimer(p.id)}>Supprimer</button>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* ---------------- SEMAINE ---------------- */}
      {vue === "semaine" && (
        <>
          <div className="card" style={rouges ? { borderColor: "#F3D6D3", background: "#FDF6F5" } : {}}>
            <div className="between">
              {/* La date plutôt qu'un « cette semaine » sans repère : le coach
                  doit savoir de quelle période il regarde le travail. */}
              <span className="eyebrow">
                À traiter · {ancreLe ? semaineEnClair(ancreLe, semaine).toLowerCase()
                                     : "cette semaine"}
              </span>
              <span className={"tag " + (rouges ? "red" : "green")}>{rouges ? rouges + " urgente(s)" : "rien d'urgent"}</span>
            </div>
            {/* Les relances déjà envoyées, pour ne pas répéter et pour se rappeler
                qui a été sollicité cette semaine. */}
            {(relances || []).length > 0 && (
              <div style={{ marginTop: 12, paddingTop: 10, borderTop: "1px solid var(--line)" }}>
                <span className="eyebrow">Relances envoyées</span>
                {relances.slice(-6).reverse().map((x, k) => (
                  <p className="small muted" key={k} style={{ marginTop: 4 }}>
                    {x.eleve} · {({ copie: "copie non envoyée", inactif: "inactivité",
                      restitution: "restitutions en retard", seances: "séances non faites",
                      soirees: "soirées sautées", direct: "direct manqué" }[x.motif]) || "message"}
                    {" · "}
                    {absAujourdhuiCoach - x.quand === 0 ? "aujourd'hui"
                      : "il y a " + (absAujourdhuiCoach - x.quand) + " jour(s)"}
                  </p>
                ))}
              </div>
            )}
            {toutesAlertes.length ? (
              <div style={{ marginTop: 12 }}>
                {toutesAlertes.filter((a) => !ecartees.includes(a.eleve + "·" + a.txt))
                  .map((a, k) => (
                  <div className="row" key={k} style={{ padding: "8px 0", borderTop: k ? "1px solid var(--line)" : "none" }}>
                    <span className={"tag " + (a.niveau === "rouge" ? "red" : a.niveau === "vert" ? "green" : "gold")}>
                      {a.niveau === "rouge" ? "urgent" : a.niveau === "vert" ? "bonne nouvelle" : "à voir"}
                    </span>
                    <span className="small" style={{ color: "var(--ink)" }}>{a.eleve}</span>
                    <span className="small muted" style={{ flex: 1 }}>{a.txt}</span>
                    {/* Voir un problème sans pouvoir agir n'avance à rien : chaque
                        ligne ouvre un message pré-rédigé pour l'élève. */}
                    {a.niveau !== "vert" && a.motif !== "corriger" && ouvrirRelance && (() => {
                      /* Si l'élève a déjà été relancé sur ce motif, on le dit :
                         relancer deux fois de suite est contre-productif. */
                      const faite = (relances || []).filter((x) => x.eleve === a.eleve
                        && x.motif === (a.motif || "autre")).pop();
                      const jours = faite ? absAujourdhuiCoach - faite.quand : null;
                      return faite ? (
                        <span className="tag green" title={"relancé il y a " + jours + " jour(s)"}>
                          {jours === 0 ? "relancé aujourd'hui" : "relancé il y a " + jours + " j"}
                        </span>
                      ) : (
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => ouvrirRelance(a.eleve, a.motif || "autre", a.txt, a.eleveId)}>
                          Relancer
                        </button>
                      );
                    })()}
                    {/* Écarter une alerte : le coach l'a traitée autrement — un
                        appel, un message en dehors de l'application — et n'a pas
                        à la voir revenir toute la semaine. */}
                    <button className="btn btn-ghost btn-sm"
                      style={{ flex: "none", color: "#8A93B8", padding: "4px 8px" }}
                      title="Retirer de la liste"
                      onClick={() => setEcartees((l) => [...l, a.eleve + "·" + a.txt])}>×</button>
                    {a.motif === "corriger" && (
                      <button className="btn btn-ghost btn-sm" onClick={() => setVue("copies")}>
                        Corriger
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : <p className="small muted" style={{ marginTop: 10 }}>Tous les élèves sont à jour.</p>}
          </div>

          {filtreGroupes}
        {eleves.map((e) => {
            const hh = e.histo || [];
            const s = hh[hh.length - 1]
              || { seances: 0, prevues: 0, minutes: 0, restit: 0,
                   restitAttendues: 0, direct: false,
                   joursManques: 0, joursRattrapes: 0 };
            const al = alertesEleve(e);
            return (
              <div className="card" key={e.nom}>
                <div className="between">
                  {/* LE GROUPE SUR CHAQUE FICHE : le coach distingue d'un coup
                      d'œil un élève de sa classe d'un élève d'Instagram, même
                      quand il regarde la liste entière. */}
                  <h3>{e.nom}
                    {groupesMeles && (
                      <span className="tag" style={{ marginLeft: 8,
                        verticalAlign: "middle", fontWeight: 500,
                        background: (e.groupe || "instagram") === "lycee"
                          ? "#EDE9FE" : "#FBF1DC",
                        color: (e.groupe || "instagram") === "lycee"
                          ? "#5B4BC4" : "#7A5A12" }}>
                        {(e.groupe || "instagram") === "lycee" ? "lycée" : "Instagram"}
                      </span>
                    )}
                  </h3>
                  <span className={"tag " + (al.some((a) => a.niveau === "rouge") ? "red" : al.length ? "gold" : "green")}>
                    {e.dernierTravail === 0 ? "actif aujourd'hui" : "vu il y a " + e.dernierTravail + " j"}
                  </span>
                </div>
                <p className="small muted" style={{ marginTop: 4 }}>
                  {e.chap} · {e.depuis > 0 ? e.depuis + (e.depuis > 1 ? " semaines" : " semaine") : "vient de commencer"}
                  {e.score != null ? " · test " + e.score + "/" + e.total : ""}
                </p>
                {/* Les gestes à reprendre : c'est ce que le test désigne, et ce
                    que les exercices vont chercher en priorité. */}
                {/* Les gestes à reprendre : c'est ce qui remplace l'ancien
                    « niveau », et ce que les exercices vont chercher. */}
                {e.score != null && (() => {
                  const rates = (e.qtRatees || []).length;
                  return (
                    <p className="small" style={{ marginTop: 2,
                      color: rates ? "#7A5A12" : "#1E6E52" }}>
                      {rates
                        ? rates + " geste" + (rates > 1 ? "s" : "")
                          + " à reprendre sur " + (e.gestes || "?")
                        : "tous les gestes acquis au test"}
                    </p>
                  );
                })()}

                {/* LES CRÉDITS DU ROBOT. Le coach en offre à un élève qui a
                    payé, ou à un élève en difficulté. La vente est fermée au
                    lycée : le quota y est fixe, décidé en base. */}
                {(e.groupe || "instagram") !== "lycee" && (
                  <div className="row" style={{ marginTop: 8, gap: 8,
                    alignItems: "center" }}>
                    <span className="small muted" style={{ flex: 1,
                      fontSize: ".78rem" }}>
                      Crédits du robot
                    </span>
                    {[10, 25, 50].map((n) => (
                      <button key={n} className="btn btn-ghost btn-sm"
                        style={{ flex: "none" }}
                        onClick={async () => {
                          const r = await crediterEleve(e.id, n);
                          setAvis(r?.ok
                            ? { bon: true, txt: e.nom + " a reçu " + n + " crédits." }
                            : { bon: false, txt: "Crédits non ajoutés : "
                                + (r?.motif || "erreur") });
                        }}>+{n}</button>
                    ))}
                  </div>
                )}

                {/* SES JOURS ET SON PROGRAMME. Le coach lisait des séances
                    manquées sans savoir si le jour était chômé, et n'avait
                    aucun moyen de dire à un élève ce qui l'attendait ce soir. */}
                {e.reglages && (() => {
                  const J = ["lundi", "mardi", "mercredi", "jeudi", "vendredi",
                             "samedi", "dimanche"];
                  const off = (e.reglages.joursOff || []).map((j) => J[j]);
                  const cours = (e.reglages.joursCours || []).map((j) => J[j]);
                  return (
                    <p className="small muted" style={{ marginTop: 4 }}>
                      {(off.length ? "Repos : " + off.join(" et ")
                                   : "Aucun jour de repos")
                        + (cours.length ? " · cours de physique le "
                            + cours.join(" et le ") : "")
                        + " · " + (e.reglages.budgetSemaine || 30) + " min par soir"}
                    </p>
                  );
                })()}

                {/* CE QUI L'ATTEND CETTE SEMAINE, jour par jour. */}
                {/* LE DÉTAIL DE CHAQUE JOURNÉE, semaine par semaine. Le compte « 2/3 » ne
                    disait pas ce qui avait été fait ni ce qui avait été raté :
                    pour comprendre ce qui se passe chez un élève, il faut voir
                    ses soirées une à une. */}
                {(() => {
                  const J = ["lundi", "mardi", "mercredi", "jeudi", "vendredi",
                             "samedi", "dimanche"];
                  const journal = e.journalSeances || [];
                  const semaines = [...new Set([
                    ...journal.map((j) => j.semaine),
                    ...(e.tachesSemaine || []).map((t) => t.semaine),
                    e.semaine,
                  ])].filter(Boolean).sort((a, b) => b - a).slice(0, 8);
                  if (!semaines.length) return null;
                  const sem = semaineVue[e.id] ?? e.semaine;
                  const duJournal = journal.filter((j) => j.semaine === sem);
                  const prevues = (e.tachesSemaine || []).filter((t) => t.semaine === sem);
                  const nomChap = (id) => CHAPITRES.find((c) => c.id === id)?.court || id;
                  return (
                    <details style={{ marginTop: 10 }}>
                      <summary className="small" style={{ cursor: "pointer", color: "#5B6BB5" }}>
                        voir le détail de ses journées
                      </summary>

                      {semaines.length > 1 && (
                        <div className="chips" style={{ marginTop: 8 }}>
                          {semaines.map((n) => (
                            <button key={n} className={"chip" + (n === sem ? " on" : "")}
                              onClick={() => setSemaineVue((v) => ({ ...v, [e.id]: n }))}>
                              {n === e.semaine ? "cette semaine" : "semaine " + n}
                            </button>
                          ))}
                        </div>
                      )}

                      <div style={{ marginTop: 8 }}>
                        {[0, 1, 2, 3, 4, 5, 6].map((j) => {
                          const chome = (e.reglages?.joursOff || []).includes(j);
                          const cours = (e.reglages?.joursCours || []).includes(j);
                          const faites = duJournal.filter((x) => x.jour === j);
                          const restantes = prevues.filter((t) => t.jour === j
                            && t.statut !== "fait");
                          if (!faites.length && !restantes.length && !chome) return null;
                          const minutes = faites.reduce((a, x) => a + (x.duree || 0), 0);
                          return (
                            <div key={j} style={{ padding: "8px 0",
                              borderTop: "1px solid #F0F2FA" }}>
                              <div className="between">
                                <span className="small" style={{ color: "var(--ink)",
                                  fontWeight: 600 }}>
                                  {J[j] + (cours ? " · cours de physique" : "")}
                                </span>
                                <span className={"tag " + (minutes ? "green" : chome ? "grey" : "red")}>
                                  {chome && !faites.length ? "repos"
                                    : minutes ? minutes + " min" : "rien"}
                                </span>
                              </div>
                              {faites.map((x, k) => (
                                <div className="row" key={"f" + k}
                                  style={{ padding: "3px 0", alignItems: "baseline", gap: 8 }}>
                                  <span className="small" style={{ flex: 1,
                                    fontSize: ".76rem", color: "#5B6BB5" }}>
                                    {(x.reprise ? "Reprise" : (T[x.type]?.libelle || x.type))
                                      + (x.chapId ? " · " + nomChap(x.chapId) : "")
                                      + (x.exoTitre ? " — " + x.exoTitre : "")}
                                  </span>
                                  {x.resultat && x.resultat !== "fait" && (
                                    <span className={"tag " + (x.resultat === "acquis" ? "green"
                                      : x.resultat === "hesitant" ? "gold" : "red")}
                                      style={{ flex: "none" }}>
                                      {x.resultat === "acquis" ? "acquis"
                                        : x.resultat === "hesitant" ? "hésité" : "raté"}
                                    </span>
                                  )}
                                </div>
                              ))}
                              {restantes.map((t, k) => {
                                /* LE STATUT RÉEL, pas seulement « manquée » ou
                                   « à faire ». Une soirée que l'élève a choisi
                                   de ne pas rattraper, un sujet reporté,
                                   tombaient dans « à faire » : le coach lisait
                                   un vendredi encore dû là où l'élève y avait
                                   renoncé la veille. */
                                const statut = {
                                  manquee:    { txt: "manquée",       cls: "red" },
                                  abandonnee: { txt: "non rattrapée", cls: "red" },
                                  reporte:    { txt: "reportée",      cls: "gold" },
                                }[t.statut] || { txt: "à faire", cls: "grey" };
                                return (
                                  <div className="row" key={"r" + k}
                                    style={{ padding: "3px 0", alignItems: "baseline", gap: 8 }}>
                                    <span className="small" style={{ flex: 1,
                                      fontSize: ".76rem", color: "#A8AEC6" }}>
                                      {(T[t.type]?.libelle || t.type)
                                        + (t.chapId ? " · " + nomChap(t.chapId) : "")}
                                    </span>
                                    <span className={"tag " + statut.cls} style={{ flex: "none" }}>
                                      {statut.txt}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          );
                        })}
                      </div>
                    </details>
                  );
                })()}

                {/* LES EXERCICES FAITS, repliés par chapitre. Le coach voit
                    ce que l'élève a traité et surtout ce qu'il a raté. */}
                {(e.journalSeances || []).some((j) => j.type === "exo") && (
                  <details style={{ marginTop: 10 }}>
                    <summary className="small" style={{ cursor: "pointer", color: "#5B6BB5" }}>
                      voir les exercices faits
                    </summary>
                    <div style={{ marginTop: 8 }}>
                      {/* UNE SEULE LIGNE PAR EXERCICE, avec son DERNIER
                          résultat. Un exercice repris apparaissait deux fois —
                          « raté » puis « acquis » — et le coach ne savait plus
                          où en était l'élève. La correction n'avait été posée
                          que sur l'écran de l'élève. */}
                      {Object.entries(Object.values((e.journalSeances || [])
                        .filter((j) => j.chapId && j.type === "exo")
                        .reduce((acc, j) => {
                          acc[String(j.exoId || j.exoTitre || j.id)] = j;
                          return acc;
                        }, {}))
                        .reduce((acc, j) => {
                          (acc[j.chapId] = acc[j.chapId] || []).push(j);
                          return acc;
                        }, {})).map(([cid, liste]) => {
                          const nom = CHAPITRES.find((x) => x.id === cid)?.nom || cid;
                          const n = (r) => liste.filter((j) => j.resultat === r).length;
                          /* LE DÉTAIL, exercice par exercice : le résumé ne
                             disait pas LESQUELS avaient été ratés, et c'est
                             précisément ce que le coach cherche. */
                          const rang = { rate: 0, hesitant: 1, acquis: 2 };
                          const tries = [...liste].sort((a, b) =>
                            (rang[a.resultat] ?? 3) - (rang[b.resultat] ?? 3));
                          return (
                            <div key={cid} style={{ padding: "8px 0",
                              borderTop: "1px solid #F0F2FA" }}>
                              <p className="small" style={{ color: "var(--ink)", fontWeight: 600 }}>
                                {nom + " · " + liste.length + " exercice"
                                  + (liste.length > 1 ? "s" : "")}
                              </p>
                              <p className="small muted" style={{ fontSize: ".72rem" }}>
                                {n("acquis") + " acquis"
                                  + (n("hesitant") ? " · " + n("hesitant") + " hésité" : "")
                                  + (n("rate") ? " · " + n("rate") + " raté" : "")}
                              </p>
                              {tries.map((j, q) => (
                                <div className="row" key={q}
                                  style={{ padding: "3px 0", alignItems: "baseline", gap: 8 }}>
                                  <span className="small" style={{ flex: 1,
                                    fontSize: ".76rem", color: "#5B6BB5" }}>
                                    {j.exoTitre || "Exercice"}
                                  </span>
                                  <span className={"tag " + (j.resultat === "acquis" ? "green"
                                    : j.resultat === "hesitant" ? "gold" : "red")}
                                    style={{ flex: "none" }}>
                                    {j.resultat === "acquis" ? "acquis"
                                      : j.resultat === "hesitant" ? "hésité" : "raté"}
                                  </span>
                                </div>
                              ))}
                            </div>
                          );
                        })}
                    </div>
                  </details>
                )}

                {/* LES CHAPITRES DE L'ÉLÈVE : où il en est, d'un coup d'œil,
                    sans avoir à ouvrir son suivi. */}
                {(e.chapitres || []).length > 0 && (
                  <div style={{ marginTop: 12, paddingTop: 10,
                    borderTop: "1px solid #EDF0FD" }}>
                    <p className="eyebrow">Chapitres</p>
                    {[...(e.chapitres || [])]
                      .sort((a, b) => (a.statut === "termine" ? 1 : 0)
                                    - (b.statut === "termine" ? 1 : 0))
                      .map((c) => {
                        const nom = CHAPITRES.find((x) => x.id === c.id)?.nom || c.id;
                        const clos = c.statut === "termine";
                        const anc = e.ancre || ancreLe;
                        const d = clos && c.finSemaine != null && anc
                          ? jourEnClair(anc, c.finSemaine, c.finJour || 0) : null;
                        return (
                          <div className="row" key={c.id}
                            style={{ padding: "5px 0", alignItems: "baseline", gap: 8 }}>
                            <span className="small" style={{ flex: 1, color: "var(--ink)" }}>
                              {nom}
                            </span>
                            <span className={"tag " + (clos ? "grey" : "green")}
                              style={{ flex: "none" }}>
                              {clos ? (d ? "terminé le " + d
                                        : c.finSemaine ? "terminé · S" + c.finSemaine
                                        : "terminé")
                                    : "en cours"}
                            </span>
                          </div>
                        );
                      })}
                  </div>
                )}

                <div style={{ marginTop: 12, display: "grid", gap: 8 }}>
                  <div className="row">
                    <span className="small muted" style={{ width: 110 }}>Séances</span>
                    {barre(s.seances, s.prevues, s.seances >= s.prevues ? "#2FA97C" : "#E7B24E")}
                    <span className="small" style={{ fontFamily: "var(--fm)" }}>{s.seances}/{s.prevues}</span>
                  </div>
                  <div className="row">
                    <span className="small muted" style={{ width: 110 }}>Restitutions</span>
                    {barre(e.restitFaites ?? s.restit, e.restitPrevues ?? s.restitAttendues,
                      (e.restitRetard || 0) === 0 ? "#2FA97C" : "#E0685F")}
                    <span className="small" style={{ fontFamily: "var(--fm)" }}>
                      {e.restitFaites ?? s.restit}/{e.restitPrevues ?? s.restitAttendues}
                    </span>
                  </div>
                  {(e.restitRetard || 0) > 0 && (
                    <p className="small" style={{ marginTop: 2, color: "#8C332C" }}>
                      {e.restitRetard} non rendue{e.restitRetard > 1 ? "s" : ""}
                    </p>
                  )}
                  {e.copie === "non faite" && (
                    <p className="small" style={{ marginTop: 4, color: "#8C332C" }}>
                      Évaluation blanche non faite — rien à corriger.
                    </p>
                  )}
                  <div className="row">
                    <span className="small muted" style={{ width: 110 }}>Temps</span>
                    <span className="small" style={{ fontFamily: "var(--fm)", color: "var(--ink)" }}>{hm(s.minutes)}</span>
                    <span className="small muted">· direct {s.direct ? "présent" : "absent"} · copie {e.copie}</span>
                  </div>
                </div>

                {al.length > 0 && (
                  <div className="row" style={{ marginTop: 12, gap: 8 }}>
                    {al.map((a, k) => <span key={k} className={"tag " +
                      (a.niveau === "rouge" ? "red" : a.niveau === "vert" ? "green" : "gold")}>{a.txt}</span>)}
                  </div>
                )}
                <div className="row" style={{ marginTop: 12 }}>
                  <button className="btn btn-ghost btn-sm"
                    onClick={() => { setVue("mois"); setOuvert(e.nom); }}>Voir le mois</button>
                  <button className="btn btn-ghost btn-sm"
                    onClick={() => setVue("copies")}>Ses copies</button>
                </div>
              </div>
            );
          })}

          <div className="card">
            <h3>{directsSemaine.length > 1 ? "Les cours de la semaine"
                                           : "Le cours de la semaine"}</h3>
            {/* UN BLOC PAR COURS. Le relevé portait sur la semaine entière :
                avec deux cours, un élève inscrit à l'un était compté dans les
                deux, et leurs questions se mélangeaient. */}
            {directsSemaine.length === 0 && (
              <p className="small muted" style={{ marginTop: 6 }}>
                Aucun cours programmé cette semaine.
              </p>
            )}
            {directsSemaine.map((d, k) => {
              const r = (classe.parCours || {})[d.date]
                || { inscrits: 0, noms: [], questions: [] };
              const JJ = ["lundi", "mardi", "mercredi", "jeudi", "vendredi",
                          "samedi", "dimanche"];
              return (
                <div key={d.id ?? k} style={{ marginTop: k ? 16 : 10,
                  paddingTop: k ? 14 : 0,
                  borderTop: k ? "1px solid #F0F2FA" : "none" }}>
                  <div className="between">
                    <span className="small" style={{ color: "var(--ink)", fontWeight: 600 }}>
                      {d.titre}
                    </span>
                    <span className={"tag " + (r.inscrits ? "green" : "grey")}>
                      {r.inscrits} inscrit{r.inscrits > 1 ? "s" : ""}
                    </span>
                  </div>
                  <p className="small muted" style={{ marginTop: 3 }}>
                    {JJ[d.jour ?? 2] + " · " + (d.heure || "") + " · "
                      + (d.chapId === METHODE ? "Méthode"
                         : CHAPITRES.find((c) => c.id === d.chapId)?.court || "")}
                  </p>
                  {r.noms.length > 0 && (
                    <p className="small" style={{ marginTop: 3, color: "#5B6BB5",
                      fontSize: ".78rem" }}>
                      {r.noms.join(", ")}
                    </p>
                  )}
                  {r.questions.length > 0 ? (
                    <div style={{ marginTop: 8 }}>
                      <p className="small muted" style={{ fontSize: ".76rem" }}>
                        {r.questions.length} question{r.questions.length > 1 ? "s" : ""}
                        {" "}posée{r.questions.length > 1 ? "s" : ""} à l'avance
                      </p>
                      {r.questions.map((q, i) => (
                        <p className="small" key={q.id ?? i}
                          style={{ marginTop: 5, color: "var(--ink)" }}>
                          {(q.de ? q.de + " — " : "") + q.txt}
                        </p>
                      ))}
                    </div>
                  ) : (
                    <p className="small muted" style={{ marginTop: 8, fontSize: ".76rem" }}>
                      Aucune question posée à l'avance.
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* ---------------- MOIS ---------------- */}
      {vue === "mois" && (
        <>
          <div className="card dark">
            <span className="eyebrow" style={{ color: "#8FA6F7" }}>Quatre dernières semaines</span>
            <h2 style={{ marginTop: 8 }}>Point mensuel aux familles</h2>
            <p className="small" style={{ marginTop: 6 }}>
              Chaque élève a son brouillon, écrit à partir de ses données. Relisez, ajustez d'une phrase, envoyez.
            </p>
          </div>

          {filtreGroupes}
        {eleves.map((e) => {
            const max = Math.max(...(e.histo || []).map((x) => x.minutes), 1);
            const ouvertIci = ouvert === e.nom;
            return (
              <div className="card" key={e.nom}>
                <div className="between">
                  {/* LE GROUPE SUR CHAQUE FICHE : le coach distingue d'un coup
                      d'œil un élève de sa classe d'un élève d'Instagram, même
                      quand il regarde la liste entière. */}
                  <h3>{e.nom}
                    {groupesMeles && (
                      <span className="tag" style={{ marginLeft: 8,
                        verticalAlign: "middle", fontWeight: 500,
                        background: (e.groupe || "instagram") === "lycee"
                          ? "#EDE9FE" : "#FBF1DC",
                        color: (e.groupe || "instagram") === "lycee"
                          ? "#5B4BC4" : "#7A5A12" }}>
                        {(e.groupe || "instagram") === "lycee" ? "lycée" : "Instagram"}
                      </span>
                    )}
                  </h3>
                  <span className="tag grey">
                    {hm(totalMois(e, "minutes"))}
                    {(() => { const anc = e.ancre || ancreLe;
                      const deb = Math.floor(((e.semaine || 1) - 1) / 4) * 4 + 1;
                      const a = dateDe(anc, deb, 0),
                            b = dateDe(anc, e.semaine || 1, 6);
                      return a && b ? " · du " + a.getDate() + "/" + (a.getMonth() + 1)
                        + " au " + b.getDate() + "/" + (b.getMonth() + 1) : " sur le mois"; })()}
                  </span>
                </div>

                {/* Les PÉRIODES PASSÉES, dépliables : quatre semaines ne
                    suffisent pas à juger d'un trimestre, et l'ancienne fenêtre
                    glissante effaçait tout au-delà. */}
                {(e.periodes || []).length > 0 && (
                  <details style={{ marginTop: 10 }}>
                    <summary className="small muted" style={{ cursor: "pointer" }}>
                      {(e.periodes || []).length} période(s) précédente(s)
                    </summary>
                    <div style={{ marginTop: 8 }}>
                      {(e.periodes || []).map((p) => (
                        <div className="row" key={p.numero}
                          style={{ gap: 8, padding: "3px 0", alignItems: "baseline" }}>
                          <span className="small muted" style={{ flex: "none",
                            fontFamily: "var(--fm)", fontSize: ".64rem", width: 76 }}>
                            {(() => { const anc = e.ancre || ancreLe;
                              const a = dateDe(anc, p.semaineDebut, 0),
                                    b = dateDe(anc, p.semaineFin, 6);
                              return a && b ? a.getDate() + "/" + (a.getMonth() + 1)
                                + "–" + b.getDate() + "/" + (b.getMonth() + 1)
                                : "S" + p.semaineDebut + "–" + p.semaineFin; })()}
                          </span>
                          <span className="small" style={{ flex: 1 }}>
                            {hm(p.minutes)} · {p.seances}/{p.prevues} séances
                            {p.restitutions ? " · " + p.restitutions + " fb" : ""}
                            {p.copies ? " · " + p.copies + " copie(s)" : ""}
                          </span>
                        </div>
                      ))}
                    </div>
                  </details>
                )}

                {/* quatre semaines, en colonnes */}
                {/* Autant de colonnes que de semaines écoulées dans le bloc :
                    un élève en semaine 2 en voit deux, pas quatre dont deux vides. */}
                <div style={{ display: "grid", gap: 8, marginTop: 14,
                  gridTemplateColumns: "repeat(" + Math.max(1, (e.histo || []).length)
                    + ", minmax(0, 1fr))" }}>
                  {(e.histo || []).map((x, k) => (
                    <div key={k} style={{ border: "1px solid var(--line)", borderRadius: 12, padding: "10px 8px", textAlign: "center" }}>
                      {/* La DATE plutôt que « S-2 » : le coach doit pouvoir
                          rapprocher une semaine creuse de ce qu'il sait de
                          l'élève — vacances, maladie, contrôle ailleurs. */}
                      <p className="small muted" style={{ fontFamily: "var(--fm)", fontSize: ".62rem" }}>
                        {/* La semaine ENTIÈRE, du lundi au dimanche : « du 17/8 »
                            seul ne disait pas jusqu'où allait la colonne. */}
                        {(() => { const anc = e.ancre || ancreLe;
                          /* Les fiches de démonstration n'ont pas de numéro de
                             semaine : sans ce repli, l'espace coach ne
                             s'affichait plus du tout. */
                          /* Une fiche sans historique — un élève tout juste
                             invité — n'a pas de « e.histo » : le lire faisait
                             échouer tout l'espace coach. */
                          const n = (e.histo || []).length;
                          if (!x.semaine) return k === n - 1
                            ? "EN COURS" : "S-" + (n - 1 - k);
                          const a = dateDe(anc, x.semaine, 0),
                                b = dateDe(anc, x.semaine, 6);
                          return a && b
                            ? a.getDate() + "/" + (a.getMonth() + 1)
                              + "–" + b.getDate() + "/" + (b.getMonth() + 1)
                            : "S" + x.semaine; })()}
                      </p>
                      <div style={{ height: 42, display: "flex", alignItems: "flex-end", justifyContent: "center", marginTop: 6 }}>
                        <span style={{
                          display: "block", width: 20, borderRadius: 6,
                          height: Math.max(4, (x.minutes / max) * 42),
                          background: x.seances >= x.prevues ? "#6C63FF" : x.minutes === 0 ? "#E0685F" : "#C9C6FB",
                        }} />
                      </div>
                      <p className="small" style={{ marginTop: 6, fontFamily: "var(--fm)", fontSize: ".64rem", color: "var(--ink)" }}>{x.minutes}′</p>
                      <p className="small muted" style={{ fontSize: ".64rem" }}>{x.seances}/{x.prevues} · {x.restit}/{x.restitAttendues} fb</p>
                      <p className="small muted" style={{ fontSize: ".64rem" }}>{x.direct ? "direct ✓" : "direct —"}</p>
                    </div>
                  ))}
                </div>

                {/* LE DÉTAIL DE CHAQUE SEMAINE, dépliable. Les quatre colonnes
                    donnent la vue d'ensemble ; ici, ce que l'élève a
                    réellement fait — et ce qu'il a sauté. */}
                {(e.histo || []).some((x) => x.detail
                  && (x.detail.parType.length || x.detail.soirsVides.length)) && (
                  <details style={{ marginTop: 10 }}>
                    <summary className="small" style={{ cursor: "pointer", color: "#5B6BB5" }}>
                      voir le détail semaine par semaine
                    </summary>
                    <div style={{ marginTop: 10, display: "grid", gap: 10 }}>
                      {(e.histo || []).map((x, k) => {
                        const d = x.detail;
                        if (!d || (!d.parType.length && !d.soirsVides.length)) return null;
                        const anc = e.ancre || ancreLe;
                        const a = dateDe(anc, x.semaine, 0), b = dateDe(anc, x.semaine, 6);
                        const titre = a && b
                          ? a.getDate() + "/" + (a.getMonth() + 1) + " – "
                            + b.getDate() + "/" + (b.getMonth() + 1)
                          : "Semaine " + x.semaine;
                        return (
                          <div key={k} style={{ borderLeft: "3px solid #D6DEFB",
                            paddingLeft: 10 }}>
                            <p className="small" style={{ color: "var(--ink)", fontWeight: 600 }}>
                              {titre}
                            </p>
                            {d.parType.length > 0 && (
                              <p className="small muted" style={{ marginTop: 2 }}>
                                {d.parType.map(([t, n]) => n + " " + t).join(" · ")}
                              </p>
                            )}
                            {d.parChap.length > 1 && (
                              <p className="small muted" style={{ marginTop: 2 }}>
                                par chapitre : {d.parChap.map(([c, n]) => c + " (" + n + ")").join(" · ")}
                              </p>
                            )}
                            {(d.acquis + d.hesitant + d.rate) > 0 && (
                              <p className="small" style={{ marginTop: 2, color: "#5B6BB5" }}>
                                exercices : {d.acquis} acquis
                                {d.hesitant ? " · " + d.hesitant + " hésitant" : ""}
                                {d.rate ? " · " + d.rate + " raté" : ""}
                              </p>
                            )}
                            {d.soirsVides.length > 0 && (
                              <p className="small" style={{ marginTop: 2, color: "#8C5220" }}>
                                soirées sans rien : {d.soirsVides.join(", ")}
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </details>
                )}

                <div className="row" style={{ marginTop: 14, gap: 8 }}>
                  <span className="tag grey">{totalMois(e, "seances")}/{totalMois(e, "prevues")} séances</span>
                  <span className={"tag " + (totalMois(e, "restit") >= totalMois(e, "restitAttendues") ? "green" : "red")}>
                    {totalMois(e, "restit")}/{totalMois(e, "restitAttendues")} feuilles blanches
                  </span>
                  <span className="tag grey">{e.histo.filter((x) => x.direct).length}/4 directs</span>
                </div>

                {ouvertIci ? (
                  <div className="card" style={{ marginTop: 14, background: "var(--surface-alt)" }}>
                    <span className="eyebrow">Brouillon du point mensuel</span>
                    <p className="small" style={{ marginTop: 8, color: "var(--ink)" }}>{pointMensuel(e)}</p>
                    <div className="row" style={{ marginTop: 12 }}>
                      {/* Le bouton ne faisait rien. Le point est désormais rangé
                          dans le profil de l'élève, où son parent le lit dans son
                          espace — sans aucun courriel à envoyer. */}
                      {/* Un bloc de quatre semaines vient de s'achever : c'est
                          le moment du point aux familles. Sans ce rappel, le
                          coach devait y penser lui-même. */}
                      {(e.semaine || 1) % 4 === 0 && (
                        <span className="tag gold" style={{ marginRight: 6 }}>
                          fin de période · point à envoyer
                        </span>
                      )}
                      <button className="btn btn-gold btn-sm"
                        onClick={async () => {
                          if (e.id) await envoyerPointMensuel(e.id, pointMensuel(e));
                          setEnvoye(e.nom);
                          setOuvert(null);
                        }}>
                        {e.id ? "Envoyer à la famille" : "Compte de démonstration"}
                      </button>
                      <button className="btn btn-ghost btn-sm" onClick={() => setOuvert(null)}>Fermer</button>
                    </div>
                  </div>
                ) : envoye === e.nom ? (
                  <p className="small" style={{ marginTop: 14, color: "#1E6E52" }}>
                    Point envoyé · visible dans l'espace des parents
                  </p>
                ) : (
                  <button className="btn btn-accent btn-sm" style={{ marginTop: 14 }} onClick={() => setOuvert(e.nom)}>
                    Rédiger le point mensuel
                  </button>
                )}
              </div>
            );
          })}
        </>
      )}

      {/* ---------------- COPIES ---------------- */}
      {vue === "copies" && (
        <div className="card">
          {/* Les ENTRAÎNEMENTS LIBRES : pas de copie à corriger, mais la trace
              de qui s'est donné la peine d'en faire un second. C'est un signal
              d'implication, et il compte dans le suivi. */}
          {libres.length > 0 && (
            <div className="card" style={{ marginBottom: 12 }}>
              <div className="between">
                <h3>Entraînements libres</h3>
                <span className="tag green">{libres.length}</span>
              </div>
              <p className="small muted" style={{ marginTop: 4 }}>
                Seconds sujets faits sans rendu. Aucune copie à corriger : les
                questions arrivent en direct ou en permanence.
              </p>
              <div style={{ marginTop: 10 }}>
                {libres.slice(0, 12).map((e) => {
                  const el = inscrits.find((x) => x.id === e.eleve_id);
                  const ch = CHAPITRES.find((c) => c.id === e.chapitre);
                  const d = new Date(e.commence_le);
                  return (
                    <div className="res" key={e.id}>
                      <span className="ico"><Icon d={I.book} size={18} /></span>
                      <div style={{ flex: 1 }}>
                        <h4>{el?.nom || e.nom || "Élève"}</h4>
                        <p className="small muted">
                          {ch?.nom || e.chapitre}
                          {e.titre ? " · " + e.titre : ""}
                          {" · " + d.toLocaleDateString("fr-FR",
                            { day: "numeric", month: "short" })}
                        </p>
                      </div>
                      <span className={"tag " + (e.termine_le ? "green" : "grey")}>
                        {e.termine_le ? "terminé" : "lancé"}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* LES CONTRÔLES ANNONCÉS, avant les copies : c'est ce qui dit au
              coach qui compose quoi et quand. La date est calculée avec
              l'ancre de chaque élève, jamais avec celle du coach. */}
          <h3>Contrôles annoncés</h3>
          {controlesAVenir.length ? (
            <div style={{ marginTop: 10 }}>
              {controlesAVenir.map((ct) => {
                const jours = ct.date
                  ? Math.round((ct.date - new Date()) / 86400000) : null;
                const proche = jours != null && jours <= 3;
                return (
                  <div key={ct.eleveId + "-" + ct.semaine + "-" + ct.jour}
                    className="res" style={{ alignItems: "flex-start" }}>
                    <span className="ico"><Icon d={I.cal} size={18} /></span>
                    <div style={{ flex: 1 }}>
                      <h4>{ct.eleve} · {ct.enClair || "date inconnue"}</h4>
                      <p className="small muted">
                        {(ct.chapitres || []).map(nomDuChapitre).join(" · ")
                          || "chapitre non précisé"}
                      </p>
                    </div>
                    {jours != null && (
                      <span className={"tag " + (proche ? "gold" : "grey")}>
                        {jours < 0 ? "passé"
                          : jours === 0 ? "aujourd'hui"
                          : jours === 1 ? "demain"
                          : "dans " + jours + " j"}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="small muted" style={{ marginTop: 8 }}>
              Aucun contrôle annoncé pour l'instant. Les élèves les déclarent
              depuis leur écran du soir, au moins quatre jours à l'avance.
            </p>
          )}

          <h3 style={{ marginTop: 24 }}>Copies d'évaluation blanche</h3>
          {/* Les copies DES ÉLÈVES : « copies » désigne l'état de l'utilisateur
              courant, qui n'en produit aucune. Le coach voyait une liste vide,
              et « Corriger » ouvrait une fenêtre sans copie à lire. */}
          {toutesLesCopies.length ? toutesLesCopies.map((c) => (
            <div key={c.id} style={{ borderTop: "1px solid var(--line)", paddingTop: 12, marginTop: 12 }}>
              <div className="res" style={{ borderTop: "none", paddingTop: 0 }}>
                <span className="ico"><Icon d={I.pdf} size={18} /></span>
                <div style={{ flex: 1 }}>
                  {/* LA DATE plutôt que « semaine 3 » : le coach corrige des
                      copies de plusieurs élèves, inscrits à des dates
                      différentes — leurs semaines ne coïncident pas. */}
                  <h4>{c.eleve || "Élève"} · {(() => {
                    const el = eleves.find((x) => x.id === c.eleveId);
                    const anc = el?.ancre || ancreLe;
                    const d = anc ? dateDe(anc, c.semaine, 6) : null;
                    return d ? "semaine du " + dateDe(anc, c.semaine, 0).getDate()
                             + "/" + (dateDe(anc, c.semaine, 0).getMonth() + 1)
                             + " au " + d.getDate() + "/" + (d.getMonth() + 1)
                             : "semaine " + c.semaine;
                  })()}</h4>
                  {/* LE CONTRÔLE QU'ELLE PRÉPARE : sans lui, le coach lit des
                      titres d'exercices et doit deviner pour quel devoir la
                      copie a été composée, et s'il lui reste du temps pour la
                      rendre. */}
                  {(() => {
                    const ct = controleDeLaCopie(c);
                    if (!ct) return null;
                    const jours = ct.date
                      ? Math.round((ct.date - new Date()) / 86400000) : null;
                    return (
                      <p className="small" style={{ marginTop: 2,
                        color: jours != null && jours >= 0 && jours <= 3
                          ? "#7A5A12" : "var(--ink-soft)" }}>
                        Contrôle {ct.passe ? "passé " : ""}le {ct.enClair}
                        {(ct.chapitres || []).length
                          ? " · " + ct.chapitres.map(nomDuChapitre).join(", ") : ""}
                        {jours != null && jours >= 0 && jours <= 3 && !ct.passe
                          ? " — à rendre vite" : ""}
                      </p>
                    );
                  })()}
                  <p className="small muted">
                    {c.exos.map((e) => e.titre).join(" · ")}
                    {c.photos && c.photos.length
                      ? " · " + c.photos.length + " page" + (c.photos.length > 1 ? "s" : "")
                      : " · aucune page jointe"}
                  </p>
                </div>
                {c.statut === "en_attente"
                  ? <button className="btn btn-accent btn-sm"
                      onClick={() => setCopieOuverte(copieOuverte === c.id ? null : c.id)}>
                      {copieOuverte === c.id ? "Fermer" : "Corriger"}
                    </button>
                  : <span className="tag green">Corrigée</span>}
              </div>

              {/* Corriger sans voir la copie n'a aucun sens : les pages
                  s'affichent ici, en pleine largeur. */}
              {copieOuverte === c.id && (
                <div style={{ marginTop: 12 }}>
                  {/* Annoter dans une application de PDF, sur tablette, va bien
                      plus vite que de commenter à l'écran. */}
                  {(c.photos || []).some((ph) => String(ph.type || "").startsWith("image")) && (
                    <button className="btn btn-ghost btn-block" style={{ marginBottom: 12 }}
                      onClick={async () => {
                        const nom = "copie-" + (c.eleve || "eleve").replace(/[^a-zA-Z0-9]+/g, "-")
                          + "-s" + c.semaine + ".pdf";
                        const ok = await copieEnPdf(c.photos || [], nom);
                        if (!ok) alert("Aucune photo à assembler dans cette copie.");
                      }}>
                      Télécharger la copie en PDF
                    </button>
                  )}
                  {/* Les pages viennent du STOCKAGE quand elles n'y sont plus
                      en clair : l'état de l'élève ne les porte plus. */}
                  {!(c.photos || []).length && (c.cheminsPages || []).length > 0 && (
                    <div className="row" style={{ gap: 8, flexWrap: "wrap", marginTop: 8 }}>
                      {c.cheminsPages.map((ch, k) => (
                        <button key={k} className="btn btn-ghost btn-sm"
                          onClick={async () => {
                            const url = await lienCopieAnnotee(ch);
                            if (url) window.open(url, "_blank", "noopener");
                          }}>
                          Page {k + 1}
                        </button>
                      ))}
                    </div>
                  )}
                  {(c.photos || []).length ? (c.photos || []).map((ph, k) => (
                    <div key={k} style={{ marginBottom: 12 }}>
                      <p className="small muted" style={{ marginBottom: 4 }}>Page {k + 1}</p>
                      {String(ph.type || "").startsWith("image")
                        ? <img src={ph.data} alt={"page " + (k + 1)}
                            style={{ width: "100%", borderRadius: 8, border: "1px solid var(--line)" }} />
                        : <button className="btn btn-ghost btn-sm"
                            onClick={() => ouvrirFichier(ph.data, ph.nom || "page")}>Ouvrir {ph.nom}</button>}
                    </div>
                  )) : (
                    <p className="small muted">
                      Cette copie a été envoyée sans page jointe. Relancez l'élève.
                    </p>
                  )}
                  {/* --- La correction rendue à l'élève ---------------------
                      Trois formes complémentaires : les pièges cochés, un mot
                      écrit, et un vocal — le plus rapide pour expliquer un
                      raisonnement. Plus, si besoin, la copie annotée en photo. */}

                  {/* ① Les pièges classiques des exercices de cette évaluation,
                      tirés des banques de questions. Cocher va dix fois plus
                      vite qu'écrire, et le vocabulaire est celui des fiches. */}
                  {/* Les pièges à cocher ont été RETIRÉS : corriger une copie, c'est la
                      lire et écrire à l'élève, pas remplir une grille. */}

                  {/* ② Le mot du coach */}
                  <p className="eyebrow" style={{ marginTop: 16 }}>Votre mot</p>
                  <textarea className="inp" rows={4} style={{ width: "100%", marginTop: 8, resize: "vertical" }}
                    placeholder="Ce qui va, ce qui coince, et quoi reprendre en priorité."
                    value={retour} onChange={(e) => setRetour(e.target.value)} />

                  {/* ③ La copie annotée */}
                  <input ref={champAnnot} type="file" accept="image/*,application/pdf" multiple
                    style={{ display: "none" }}
                    onChange={async (e) => {
                      const fs = [...(e.target.files || [])];
                      const lues = await Promise.all(fs.map(async (f) => ({
                        nom: f.name, type: f.type, data: await versDataUrl(f) })));
                      /* On garde le FICHIER lui-même : il partira dans le
                         stockage, pas encodé dans l'état de l'élève. On le
                         prend dans « fs », capturé avant que le champ soit
                         vidé — « e.target.files » est alors déjà nul. */
                      setAnnotees((v) => [...v, ...lues.map((l, i) => ({
                        ...l, fichier: fs[i] }))]);
                      e.target.value = "";
                    }} />
                  {annotees.length > 0 && (
                    <p className="small muted" style={{ marginTop: 8 }}>
                      {annotees.length} page(s) annotée(s) jointe(s)
                    </p>
                  )}
                  <button className="btn btn-ghost btn-block" style={{ marginTop: 10 }}
                    onClick={() => champAnnot.current && champAnnot.current.click()}>
                    Joindre la copie annotée
                  </button>

                  {/* ④ Le vocal : souvent le plus clair et le plus rapide */}
                  <p className="eyebrow" style={{ marginTop: 16 }}>Un mot de vive voix</p>
                  <Enregistreur compact onEnvoyer={(blob, duree) =>
                    versDataUrl(blob).then((url) => setVocal({ url, duree }))} />
                  {vocal && (
                    <p className="small muted" style={{ marginTop: 6 }}>
                      Vocal de {vocal.duree} s prêt à partir ·{" "}
                      <button className="btn btn-ghost btn-sm" onClick={() => setVocal(null)}>retirer</button>
                    </p>
                  )}

                  <p className="small muted" style={{ marginTop: 12 }}>
                    Tout arrive dans la permanence de l'élève, visible de lui seul, et se
                    retrouve ensuite dans ses copies. Sa reprise devient sa tâche du lendemain.
                  </p>
                  <button className="btn btn-gold btn-block" style={{ marginTop: 10 }}
                    disabled={!retour.trim() && !pieges.length && !vocal && !annotees.length}
                    onClick={() => {
                      const corr = { texte: retour.trim(), pieges, vocal, annotees,
                        le: new Date().toLocaleDateString("fr-FR") };
                      /* On marque la copie CORRIGÉE dans les deux listes : la
                         sienne — pour la démonstration — et celle des élèves,
                         qui est ce que le coach voit réellement. Sans la
                         seconde, le bouton restait « Corriger » après coup. */
                      setCopies((cs) => cs.map((x) => x.id === c.id
                        ? { ...x, statut: "corrigee", correction: corr } : x));
                      setCorrigeesLocal((l) => [...new Set([...l, c.id])]);
                      rendreCopie && rendreCopie(c, corr);
                      setRetour(""); setPieges([]); setVocal(null); setAnnotees([]);
                      setCopieOuverte(null);
                    }}>
                    Rendre la copie corrigée
                  </button>
                </div>
              )}
            </div>
          )) : <p className="small muted" style={{ marginTop: 8 }}>Aucune copie en attente.</p>}
          {/* Cette carte est une DÉMONSTRATION : « Tom B. » n'existe pas, et
              elle apparaissait dans l'espace d'un coach branché à sa base, au
              milieu de ses vraies copies. */}
          {!supabaseActif && (
            <div className="res">
              <span className="ico"><Icon d={I.clock} size={18} /></span>
              <div style={{ flex: 1 }}><h4>Tom B. · évaluation blanche</h4><p className="small muted">Faite il y a 3 jours, copie jamais envoyée</p></div>
              <button className="btn btn-ghost btn-sm"
                onClick={() => ouvrirRelance && ouvrirRelance("Tom B.", "copie", "copie jamais envoyée")}>
                Relancer
              </button>
            </div>
          )}
        </div>
      )}

      {/* ---------------- GRAND ORAL ---------------- */}
      {vue === "oral" && (() => {
        /* L'utilisateur figure dans le suivi comme un élève — en DÉMONSTRATION
           seulement : branché à la base, le coach n'a pas d'oral à préparer. */
        const moi = !supabaseActif && oral && oral.semaineEpreuve ? [{
          nom: "Vous (démo)", classe: "Term", moi: true,
          semainesRestantes: oral.semaineEpreuve - semaine, etape: oral.etape, statut: oral.statut,
          question: oral.question, ancrage: oral.ancrage, chapId: oral.chapId,
          prises: oral.prises.length, tirages: oral.tirages.length, sechees: oral.sechees.length,
          oralBlanc: Boolean(oral.oralBlanc?.demande),
          statutPlan: oral.statutPlan, plan: oral.plan,
        }] : [];
        const eleves = [...moi, ...suivi];
        const enAttente = eleves.filter((e) => e.statut === "soumise");
        const plansAlire = eleves.filter((e) => e.statutPlan === "soumis");
        const creneaux = eleves.filter((e) => e.oralBlanc);
        const enRetard = eleves.filter((e) => {
          const jalon = JALONS_ORAL.find((j) => j.etape === e.etape);
          return jalon && e.semainesRestantes < jalon.semainesAvant;
        });

        const trancherPlan = (e, decision) => {
          if (e.moi && setOral) {
            setOral({
              ...oral,
              statutPlan: decision === "valide" ? "valide" : "brouillon",
              commentairePlan: decision === "valide" ? "" : motReform,
              etape: decision === "valide" ? Math.max(oral.etape, 3) : oral.etape,
              notif: decision === "valide"
                ? { type: "validee", txt: "Votre plan est validé. Place à la mise en voix.", lu: false }
                : { type: "reformuler", txt: "Sur votre plan : " + motReform, lu: false },
            });
          } else {
            setSuivi((l) => l.map((x) => (x.nom === e.nom
              ? { ...x, statutPlan: decision === "valide" ? "valide" : "brouillon" } : x)));
          }
          setReformuler(null); setMotReform("");
        };

        const trancher = (e, decision) => {
          if (e.moi && setOral) {
            /* En cas de reformulation, on renvoie l'eleve DANS son texte, pas au
               depart : sa question et son ancrage restent, il n'a qu'a corriger. */
            setOral({
              ...oral,
              statut: decision === "validee" ? "validee" : "brouillon",
              libre: decision === "validee" ? false : true,
              commentaire: decision === "validee" ? "" : motReform,
              etape: decision === "validee" ? Math.max(oral.etape, 2) : 1,
              notif: decision === "validee"
                ? { type: "validee", txt: "Votre question est validée. Vous pouvez passer au plan.", lu: false }
                : { type: "reformuler", txt: motReform, lu: false },
            });
          } else {
            setSuivi((l) => l.map((x) => (x.nom === e.nom
              ? { ...x, statut: decision === "validee" ? "validee" : "brouillon", commentaire: motReform } : x)));
          }
          setReformuler(null); setMotReform("");
        };

        return (
          <>
            {(enAttente.length > 0 || creneaux.length > 0 || enRetard.length > 0) && (
              <div className="card" style={{ borderColor: "#F2E1BC", background: "#FFFDF8" }}>
                <span className="eyebrow" style={{ color: "#7A5A12" }}>À traiter</span>
                {enAttente.map((e) => (
                  <p className="small" key={"a" + e.nom} style={{ marginTop: 8, color: "var(--ink)" }}>
                    <b>{e.nom}</b> attend la validation de sa question.
                  </p>
                ))}
                {plansAlire.map((e) => (
                  <p className="small" key={"p" + e.nom} style={{ marginTop: 8, color: "var(--ink)" }}>
                    <b>{e.nom}</b> a envoyé son plan.
                  </p>
                ))}
                {creneaux.map((e) => (
                  <p className="small" key={"c" + e.nom} style={{ marginTop: 8, color: "var(--ink)" }}>
                    <b>{e.nom}</b> demande un créneau d'oral blanc.
                  </p>
                ))}
                {enRetard.map((e) => (
                  <p className="small" key={"r" + e.nom} style={{ marginTop: 8, color: "var(--red)" }}>
                    <b>{e.nom}</b> est en retard sur le rétroplanning (étape {e.etape} à {e.semainesRestantes} semaines de l'épreuve).
                  </p>
                ))}
              </div>
            )}

            {/* file 1 : les questions */}
            {enAttente.length > 0 && (
              <div className="card">
                <div className="between">
                  <h3>Questions à valider</h3>
                  <span className="tag gold">{enAttente.length}</span>
                </div>
                {enAttente.map((e) => (
                  <div key={"q" + e.nom} style={{ padding: "14px 0", borderTop: "1px solid var(--line)" }}>
                    <h4>{e.nom} · {e.classe}</h4>
                    <p className="small" style={{ marginTop: 8, color: "var(--ink)" }}>« {e.question} »</p>
                    {e.ancrage && <p className="small muted" style={{ marginTop: 4 }}>Son ancrage : {e.ancrage}</p>}
                    <div className="row" style={{ marginTop: 12, gap: 8 }}>
                      <button className="btn btn-gold btn-sm" onClick={() => trancher(e, "validee")}>Valider la question</button>
                      <button className="btn btn-ghost btn-sm"
                        onClick={() => { setReformuler("q-" + e.nom); setMotReform(""); }}>À reformuler</button>
                    </div>
                    {reformuler === "q-" + e.nom && (
                      <div className="card" style={{ marginTop: 10, background: "var(--surface-alt)" }}>
                        <textarea className="inp" rows={2} style={{ width: "100%" }}
                          placeholder="Ce qui ne va pas, et dans quelle direction reprendre"
                          value={motReform} onChange={(ev) => setMotReform(ev.target.value)} />
                        <div className="row" style={{ marginTop: 10 }}>
                          <button className="btn btn-accent btn-sm" disabled={!motReform.trim()}
                            onClick={() => trancher(e, "reformuler")}>Renvoyer à l'élève</button>
                          <button className="btn btn-ghost btn-sm" onClick={() => setReformuler(null)}>Annuler</button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* file 2 : les plans */}
            {plansAlire.length > 0 && (
              <div className="card">
                <div className="between">
                  <h3>Plans à relire</h3>
                  <span className="tag gold">{plansAlire.length}</span>
                </div>
                {plansAlire.map((e) => (
                  <div key={"pl" + e.nom} style={{ padding: "14px 0", borderTop: "1px solid var(--line)" }}>
                    <h4>{e.nom} · {e.classe}</h4>
                    <p className="small muted" style={{ marginTop: 4 }}>« {e.question} »</p>
                    {(e.plan || []).map((t, k) => (
                      <p key={k} className="small" style={{ marginTop: 8, color: "var(--ink)" }}>
                        <b>Temps {k + 1}.</b> {t}
                      </p>
                    ))}
                    <div className="row" style={{ marginTop: 12, gap: 8 }}>
                      <button className="btn btn-gold btn-sm" onClick={() => trancherPlan(e, "valide")}>Valider le plan</button>
                      <button className="btn btn-ghost btn-sm"
                        onClick={() => { setReformuler("p-" + e.nom); setMotReform(""); }}>À retravailler</button>
                    </div>
                    {reformuler === "p-" + e.nom && (
                      <div className="card" style={{ marginTop: 10, background: "var(--surface-alt)" }}>
                        <textarea className="inp" rows={2} style={{ width: "100%" }}
                          placeholder="Ce qui manque : un temps trop faible, un enchaînement, une notion absente..."
                          value={motReform} onChange={(ev) => setMotReform(ev.target.value)} />
                        <div className="row" style={{ marginTop: 10 }}>
                          <button className="btn btn-accent btn-sm" disabled={!motReform.trim()}
                            onClick={() => trancherPlan(e, "retravailler")}>Renvoyer le plan</button>
                          <button className="btn btn-ghost btn-sm" onClick={() => setReformuler(null)}>Annuler</button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            <div className="card">
              <h3>Suivi des élèves</h3>
              <p className="small muted" style={{ marginTop: 4 }}>
                Cinq étapes : question · plan · mise en voix · tirage · oral blanc.
              </p>
              {eleves.map((e) => (
                <div key={e.nom} style={{ padding: "16px 0", borderTop: "1px solid var(--line)" }}>
                  <div className="between">
                    <div style={{ flex: 1 }}>
                      <h4>{e.nom} · {e.classe}</h4>
                      <p className="small muted">
                        étape {e.etape}/5 · {e.prises} prise(s) de son · {e.tirages} session(s) de tirage
                        {e.sechees ? " · " + e.sechees + " question(s) séchée(s)" : ""}
                      </p>
                    </div>
                    <span className={"tag " + (e.statut === "validee" ? "green" : e.statut === "soumise" ? "gold" : "grey")}>
                      {e.statut === "validee" ? "question validée" : e.statut === "soumise" ? "à valider" : "sans question"}
                    </span>
                  </div>

                  {e.question && (
                    <>
                      <p className="small" style={{ marginTop: 10, color: "var(--ink)" }}>« {e.question} »</p>
                      {e.ancrage && <p className="small muted" style={{ marginTop: 4 }}>Son ancrage : {e.ancrage}</p>}
                    </>
                  )}

                  <div className="row" style={{ marginTop: 8, gap: 6 }}>
                    <span className={"tag " + (e.statutPlan === "valide" ? "green" : e.statutPlan === "soumis" ? "gold" : "grey")}>
                      plan {e.statutPlan === "valide" ? "validé" : e.statutPlan === "soumis" ? "à relire" : "en cours"}
                    </span>
                  </div>

                  {e.oralBlanc && (
                    <div className="row" style={{ marginTop: 10 }}>
                      <span className="tag gold">oral blanc demandé</span>
                      <button className="btn btn-ghost btn-sm">Proposer un créneau</button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* banque d'idees */}
            <div className="card">
              <h3>Proposer une question</h3>
              <p className="small muted" style={{ marginTop: 4 }}>
                Une fiche alimente deux choses : le carrousel d'idées des élèves sans piste,
                et les questions tirées au sort pendant l'entraînement à l'échange.
              </p>

              <div className="chips" style={{ marginTop: 12 }}>
                {CHAPITRES.map((c) => (
                  <button key={c.id} className={"chip" + (fiche.chapId === c.id ? " on" : "")}
                    onClick={() => setFiche({ ...fiche, chapId: c.id })}>{c.court}</button>
                ))}
              </div>
              <div className="row" style={{ marginTop: 10 }}>
                {["accessible", "ambitieux"].map((n) => (
                  <button key={n} className={"chip" + (fiche.niveau === n ? " on" : "")}
                    onClick={() => setFiche({ ...fiche, niveau: n })}>{n}</button>
                ))}
              </div>

              <input className="inp" style={{ width: "100%", marginTop: 12 }}
                placeholder="La question mère, ex. Pourquoi entend-on mieux la nuit ?"
                value={fiche.question} onChange={(e) => setFiche({ ...fiche, question: e.target.value })} />
              <input className="inp" style={{ width: "100%", marginTop: 10 }}
                placeholder="Notions de spé mobilisées"
                value={fiche.notions} onChange={(e) => setFiche({ ...fiche, notions: e.target.value })} />

              <p className="eyebrow" style={{ marginTop: 14 }}>Trois pistes de plan</p>
              {[0, 1, 2].map((k) => (
                <input key={k} className="inp" style={{ width: "100%", marginTop: 8 }} placeholder={"Piste " + (k + 1)}
                  value={fiche.pistes[k]}
                  onChange={(e) => { const p = [...fiche.pistes]; p[k] = e.target.value; setFiche({ ...fiche, pistes: p }); }} />
              ))}

              <p className="eyebrow" style={{ marginTop: 14 }}>Six questions de jury</p>
              <p className="small muted">Une definition, un mecanisme, un ordre de grandeur, une limite du modele, un « et si… », un lien avec une autre notion.</p>
              {[0, 1, 2, 3, 4, 5].map((k) => (
                <input key={k} className="inp" style={{ width: "100%", marginTop: 8 }} placeholder={"Question " + (k + 1)}
                  value={fiche.jury[k]}
                  onChange={(e) => { const j = [...fiche.jury]; j[k] = e.target.value; setFiche({ ...fiche, jury: j }); }} />
              ))}

              <button className="btn btn-gold btn-block" style={{ marginTop: 14 }}
                disabled={!fiche.question.trim() || fiche.jury.filter((q) => q.trim()).length < 3}
                onClick={() => {
                  const fresh = {
                    id: "o-" + fiche.chapId + "-" + Date.now(), chapId: fiche.chapId, niveau: fiche.niveau,
                    question: fiche.question.trim(), notions: fiche.notions.trim(),
                    pistes: fiche.pistes.filter((p) => p.trim()),
                    jury: fiche.jury.filter((q) => q.trim()),
                  };
                  setIdeesOral([...ideesOral, fresh]);
                  if (supabaseActif) ajouterIdeeOral(fresh);
                  setFiche({ chapId: fiche.chapId, niveau: fiche.niveau, question: "", notions: "",
                    pistes: ["", "", ""], jury: ["", "", "", "", "", ""] });
                }}>
                Ajouter à la banque
              </button>
              <p className="small muted" style={{ marginTop: 10 }}>
                Trois questions de jury minimum pour enregistrer une fiche.
              </p>
            </div>

            <div className="card">
              <h3>Banque de questions</h3>
              {CHAPITRES.map((c) => {
                const liste = ideesOral.filter((i) => i.chapId === c.id);
                return (
                  <div key={c.id} style={{ marginTop: 12 }}>
                    <div className="between">
                      <h4>{c.nom}</h4>
                      <span className={"tag " + (liste.length >= 3 ? "green" : liste.length ? "gold" : "red")}>
                        {liste.length} fiche(s)
                      </span>
                    </div>
                    {liste.map((i) => (
                      <div className="res" key={i.id}>
                        <span className="ico"><Icon d={I.micro} size={18} /></span>
                        <div style={{ flex: 1 }}>
                          <h4>{i.question}</h4>
                          <p className="small muted">{i.jury.length} question(s) de jury · {i.niveau}</p>
                        </div>
                      </div>
                    ))}
                    {!liste.length && <p className="small muted" style={{ marginTop: 6 }}>Aucune fiche pour ce chapitre.</p>}
                  </div>
                );
              })}
            </div>
          </>
        );
      })()}

      {/* ---------------- DIRECTS ---------------- */}
      {vue === "directs" && (
        <>
          {/* La salle permanente : saisie une fois, reportée sur chaque direct. */}
          <div className="card">
            <div className="between">
              <span className="eyebrow">Ma salle de visioconférence</span>
              {salle && <span className="tag green">enregistrée</span>}
            </div>
            <p className="small muted" style={{ marginTop: 6 }}>
              Ce lien se reporte automatiquement sur chaque nouveau direct. Une
              salle permanente vaut mieux qu'un lien différent chaque semaine :
              vos élèves finissent par la connaître par cœur.
            </p>
            <input className="input" style={{ marginTop: 10 }} value={salle}
              placeholder="https://us06web.zoom.us/j/…"
              onChange={(e) => setSalle(e.target.value)} />
            <div className="row" style={{ gap: 8, marginTop: 10 }}>
              <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                onClick={() => {
                  try { localStorage.setItem("btp.salle", salle); } catch (e) {}
                  setDir((d) => ({ ...d, lien: salle }));
                }}>
                Enregistrer
              </button>
              <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                onClick={() => setDir((d) => ({ ...d, lien: salle }))}>
                Utiliser pour ce direct
              </button>
            </div>
            <p className="small muted" style={{ marginTop: 10 }}>
              Pensez à activer la <b>salle d'attente</b> dans Zoom, et à
              désactiver <b>rejoindre avant l'hôte</b> : sans cela, un élève
              pourrait entrer en votre absence.
            </p>
          </div>

          {/* Ce que les élèves travaillent en ce moment. Programmer un direct
              sur un chapitre que personne n'a en cours ne remplit pas la salle :
              autant partir de ce qui occupe réellement la classe. */}
          {(() => {
            const compte = {};
            eleves.forEach((el) => {
              const c = CHAPITRES.find((x) => x.nom === el.chap);
              if (c) compte[c.id] = (compte[c.id] || 0) + 1;
            });
            const classement = Object.entries(compte)
              .sort((a, b) => b[1] - a[1]);
            if (!classement.length) return null;
            return (
              <div className="card">
                <div className="between">
                  <span className="eyebrow">Ce que la classe travaille</span>
                  <span className="tag">{eleves.length} élève(s)</span>
                </div>
                <div style={{ marginTop: 12 }}>
                  {classement.map(([id, n]) => {
                    const nom = CHAPITRES.find((c) => c.id === id)?.nom || id;
                    const part = n / eleves.length;
                    return (
                      <div key={id} style={{ marginBottom: 11 }}>
                        <div className="between">
                          <span className="small">{nom}</span>
                          <span className="small muted">{n} élève(s)</span>
                        </div>
                        <div className="bar" style={{ marginTop: 5 }}>
                          <i style={{ width: part * 100 + "%" }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
                <p className="small muted" style={{ marginTop: 6 }}>
                  {classement.length === 1
                    ? "Toute la classe est sur le même chapitre : un seul direct suffit."
                    : classement[0][1] === classement[1][1]
                      ? "Deux groupes de taille égale : prévoyez deux directs, ou un sujet transversal."
                      : "Le premier chapitre rassemble le plus d'élèves — c'est celui qui remplira la séance."}
                </p>
                <button className="btn btn-accent btn-block" style={{ marginTop: 12 }}
                  onClick={() => {
                    const id = classement[0][0];
                    setDir((d) => ({ ...d, chapId: id,
                      titre: d.titre || (CHAPITRES.find((c) => c.id === id)?.nom || "") }));
                    formDirect.current?.scrollIntoView({ behavior: "smooth" });
                  }}>
                  Programmer un direct sur {CHAPITRES.find((c) => c.id === classement[0][0])?.court}
                </button>
              </div>
            );
          })()}

          <div className="card" ref={formDirect} style={edition ? { borderColor: "#C9D2F8", background: "#F8F9FF" } : {}}>
            <div className="between">
              <h3>{edition ? "Modifier le direct" : "Programmer un direct"}</h3>
              {edition && <span className="tag">en modification</span>}
            </div>
            <p className="small muted" style={{ marginTop: 4 }}>
              {edition
                ? "Vous modifiez une seance deja programmee. Changez ce que vous voulez, puis enregistrez."
                : "Un direct par semaine. Programmer une semaine deja pourvue remplace la seance existante, et le planning des eleves inscrits se met a jour immediatement."}
            </p>

            <p className="small muted" style={{ marginTop: 14 }}>Semaine</p>
            <div className="chips" style={{ marginTop: 8 }}>
              {[0, 1, 2, 3].map((k) => (
                <button key={k} className={"chip" + (dir.semaine === semaine + k ? " on" : "")}
                  onClick={() => setDir({ ...dir, semaine: semaine + k })}>
                  {k === 0 ? "Cette semaine" : "S+" + k}
                </button>
              ))}
            </div>

            <p className="small muted" style={{ marginTop: 14 }}>Jour et heure</p>
            <div className="chips" style={{ marginTop: 8 }}>
              {JOURS.map((j, k) => (
                <button key={j} className={"chip" + (dir.jour === k ? " on" : "")} onClick={() => setDir({ ...dir, jour: k })}>{j}</button>
              ))}
            </div>
            {/* Quatre horaires de soirée ne suffisaient pas : un direct peut
                tomber un mercredi après-midi, un samedi matin, ou pendant les
                vacances. On propose les créneaux usuels et on laisse la saisie
                libre pour tout le reste. */}
            <div className="chips" style={{ marginTop: 10 }}>
              {["12:00", "14:00", "15:00", "16:00", "17:00",
                "18:00", "18:30", "19:00", "20:00", "21:00"].map((h) => (
                <button key={h} className={"chip" + (dir.heure === h ? " on" : "")}
                  onClick={() => setDir({ ...dir, heure: h })}>{h}</button>
              ))}
            </div>
            <div className="row" style={{ marginTop: 10, alignItems: "center", gap: 10 }}>
              <span className="small muted" style={{ flex: "none" }}>Autre heure</span>
              <input className="input" type="time" value={dir.heure} style={{ flex: 1 }}
                onChange={(e) => setDir({ ...dir, heure: e.target.value })} />
            </div>
            <p className="small muted" style={{ marginTop: 14 }}>Durée</p>
            <div className="chips" style={{ marginTop: 8 }}>
              {[30, 45, 60, 90, 120].map((d) => (
                <button key={d} className={"chip" + (dir.duree === d ? " on" : "")}
                  onClick={() => setDir({ ...dir, duree: d })}>{d} min</button>
              ))}
            </div>

            {avisDirect && (
              <div className="card" style={{ marginTop: 12, borderColor: "#E8C6C2",
                background: "#FCF3F2" }}>
                <p className="small" style={{ color: "#C0392B", margin: 0 }}>
                  {avisDirect}
                </p>
              </div>
            )}

            <p className="small muted" style={{ marginTop: 14 }}>Chapitre traité</p>
            <div className="chips longue" style={{ marginTop: 8 }}>
              {/* LA MÉTHODE vient en premier : un cours de méthode ne porte sur
                  aucun chapitre en particulier — rédaction, gestion du temps,
                  lecture d'un énoncé — et concerne tout le monde, quel que soit
                  le chapitre que chacun travaille. */}
              <button className={"chip" + (dir.chapId === METHODE ? " on" : "")}
                onClick={() => setDir({ ...dir, chapId: METHODE })}>Méthode</button>
              {CHAPITRES.map((c) => (
                <button key={c.id} className={"chip" + (dir.chapId === c.id ? " on" : "")} onClick={() => setDir({ ...dir, chapId: c.id })}>{c.court}</button>
              ))}
            </div>
            {dir.chapId === METHODE && (
              <p className="small muted" style={{ marginTop: 6 }}>
                Ce cours sera proposé à tous, quel que soit le chapitre en cours.
              </p>
            )}

            <input className="inp" style={{ width: "100%", marginTop: 12 }}
              placeholder="Theme de la seance, ex. Diffraction : un exercice type bac de A a Z"
              value={dir.titre} onChange={(e) => setDir({ ...dir, titre: e.target.value })} />
            <input className="inp" style={{ width: "100%", marginTop: 10 }}
              placeholder="Lien de la visio (Zoom, Meet, Whereby...)"
              value={dir.lien} onChange={(e) => setDir({ ...dir, lien: e.target.value })} />

            <button className="btn btn-gold btn-block" style={{ marginTop: 14 }}
              disabled={!dir.titre.trim()}
              onClick={() => {
                programmerDirect({
                  ...dir,
                  id: edition || "d" + Date.now(),
                  titre: dir.titre.trim(),
                  lien: (dir.lien || "").trim(),
                  replayUrl: dir.replayUrl || "",
                });
                setEdition(null);
                setDir(dirVierge());
              }}>
              {edition ? "Enregistrer les modifications" : "Programmer ce direct"}
            </button>
            {edition && (
              <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 10 }}
                onClick={() => { setEdition(null); setDir(dirVierge()); }}>
                Annuler la modification
              </button>
            )}
          </div>

          <div className="card">
            <h3>Directs programmes</h3>
            {directs.filter((d) => d.semaine >= semaine - 1).sort((a, b) => a.semaine - b.semaine).map((d) => {
              /* Les questions de TOUS les élèves, pas seulement celles du
                 compte connecté : c'est sur elles que le coach prépare sa séance. */
              const qs = supabaseActif
                ? classe.questions.filter((q) => q.semaine === d.semaine || q.semaine == null)
                : questionsDirect.filter((q) => q.semaine === d.semaine);
              return (
                <div key={d.id} style={{ padding: "14px 0", borderTop: "1px solid var(--line)" }}>
                  <div className="between">
                    <div style={{ flex: 1 }}>
                      <h4>{d.titre}</h4>
                      <p className="small muted">
                        {d.semaine === semaine ? "Cette semaine" : "S+" + (d.semaine - semaine)} - {JOURS[d.jour]} {d.heure} - {d.duree} min
                        {" - "}{d.chapId === METHODE ? "Méthode"
                          : CHAPITRES.find((c) => c.id === d.chapId)?.court}
                      </p>
                      {supabaseActif && d.semaine === semaine && classe.noms.length > 0 && (
                        <p className="small muted" style={{ marginTop: 3 }}>
                          Inscrits : {classe.noms.join(", ")}
                        </p>
                      )}
                    </div>
                    <span className={"tag " + (d.lien ? "green" : "gold")}>{d.lien ? "lien pret" : "sans lien"}</span>
                  </div>
                  <div className="row" style={{ marginTop: 8, gap: 8 }}>
                    <span className="tag grey" title={classe.noms.join(", ")}>
                      {supabaseActif
                        ? classe.inscrits + (inscrits.includes(d.semaine) ? 1 : 0)
                        : (inscrits.includes(d.semaine) ? 1 : 0) + 7} inscrit(s)
                    </span>
                    <span className={"tag " + (qs.length ? "gold" : "grey")}>{qs.length} question(s) a l'avance</span>
                    <button className={"btn btn-sm " + (edition === d.id ? "btn-accent" : "btn-ghost")}
                      onClick={() => modifierDirect(d)}>
                      {edition === d.id ? "En cours de modification" : "Modifier"}
                    </button>
                    {/* L'annulation demande confirmation : elle retire le cours
                        du programme de tous les élèves inscrits. */}
                    {aAnnuler === d.id ? (
                      <>
                        <button className="btn btn-sm" style={{ background: "#C0392B", color: "#FFF" }}
                          onClick={() => { annulerDirect(d); setAAnnuler(null); }}>
                          Confirmer l'annulation
                        </button>
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => setAAnnuler(null)}>Garder</button>
                      </>
                    ) : (
                      <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                        onClick={() => setAAnnuler(d.id)}>Annuler ce cours</button>
                    )}
                  </div>
                  {qs.map((q) => (
                    /* Le prénom devant la question : sans lui, le coach ne sait
                       pas à qui répondre ni si un élève en a posé plusieurs. */
                    <p className="small" key={q.id} style={{ marginTop: 6, color: "var(--ink)" }}>
                      {q.de && (
                        <b style={{ color: "var(--accent, #4E4BC4)" }}>{q.de} — </b>
                      )}
                      {q.txt}
                    </p>
                  ))}
                  {d.semaine < semaine && (
                    <div className="row" style={{ marginTop: 10 }}>
                      <input className="inp" style={{ flex: 1 }} placeholder="Lien du replay Vimeo"
                        defaultValue={d.replayUrl}
                        onBlur={(e) => programmerDirect({ ...d, replayUrl: e.target.value.trim() })} />
                      <span className={"tag " + (d.replayUrl ? "green" : "grey")}>{d.replayUrl ? "replay en ligne" : "replay a deposer"}</span>
                    </div>
                  )}
                </div>
              );
            })}
            {!directs.filter((d) => d.semaine >= semaine - 1).length && (
              <p className="small muted" style={{ marginTop: 10 }}>Aucun direct programme.</p>
            )}
          </div>
        </>
      )}

      {/* ---------------- RESSOURCES ---------------- */}
      {vue === "ressources" && (
        <>
          <div className="card">
            <h3>Deposer une video ou une fiche</h3>
            <p className="small muted" style={{ marginTop: 4 }}>
              Les videos sont hebergees sur Vimeo : collez simplement le lien de la video.
              Les fiches sont des PDF : collez le lien de partage du fichier.
            </p>
            <div className="chips longue" style={{ marginTop: 12 }}>
              {CHAPITRES.map((c) => <button key={c.id} className={"chip" + (chapId === c.id ? " on" : "")} onClick={() => setChapId(c.id)}>{c.court}</button>)}
            </div>

            <p className="small muted" style={{ marginTop: 14 }}>Type</p>
            <div className="chips" style={{ marginTop: 8 }}>
              {/* L'épreuve blanche et son corrigé sont des PDF déposés par le
                  coach : ce sont SES évaluations, pas celles des lots. Le
                  moteur les sert deux jours avant un contrôle déclaré. */}
              {[...TYPES_VIDEO, "Fiche", "Fiche express", "Épreuve blanche", "Corrigé épreuve",
                "Entraînement libre", "Sujet Labolycée"].map((t) => (
                <button key={t} className={"chip" + (res.type === t ? " on" : "")} onClick={() => setRes({ ...res, type: t })}>
                  {t === "Fiche" ? "Fiche de revision (PDF)" : t}
                </button>
              ))}
            </div>

            <input className="inp" style={{ width: "100%", marginTop: 12 }}
              placeholder={res.type === "Fiche" ? "Titre de la fiche"
                : res.type === "Épreuve blanche" ? "Titre de l'épreuve, ex. Contrôle blanc n° 1"
                : res.type === "Corrigé épreuve" ? "Titre du corrigé"
                : res.type === "Sujet Labolycée" ? "Titre du sujet, ex. Le sonar du dauphin"
                : "Titre de la video"}
              value={res.titre} onChange={(e) => setRes({ ...res, titre: e.target.value })} />

            {/* Une fiche se dépose depuis le téléphone, sans passer par un
                hébergeur tiers : c'est le geste le plus courant de l'année. */}
            {["Fiche", "Fiche express", "Épreuve blanche", "Corrigé épreuve",
              "Entraînement libre"].includes(res.type) && (
              <>
                <input ref={champFiche} type="file" accept="application/pdf"
                  style={{ display: "none" }}
                  onChange={async (e) => {
                    const f = (e.target.files || [])[0]; if (!f) return;
                    setDepot("en cours");
                    const dossier = res.type === "Épreuve blanche" ? "epreuves"
                      : res.type === "Corrigé épreuve" ? "corriges" : "fiches";
                    const rep = await deposerFichier(dossier + "/" + chapId, f);
                    const url = typeof rep === "string" ? rep : rep.url;
                    setRes((r) => ({ ...r, url, titre: r.titre || f.name.replace(/\.pdf$/i, "") }));
                    setDepot(String(url).startsWith("http") ? "stocké"
                      : (typeof rep === "object" && rep.erreur) || "en mémoire");
                    e.target.value = "";
                  }} />
                <button className="btn btn-ghost btn-block" style={{ marginTop: 10 }}
                  onClick={() => champFiche.current && champFiche.current.click()}>
                  {res.url ? "Remplacer le PDF"
                    : res.type === "Épreuve blanche" ? "Déposer le PDF de l'épreuve"
                    : res.type === "Corrigé épreuve" ? "Déposer le PDF du corrigé"
                    : res.type === "Entraînement libre" ? "Déposer le PDF de l'entraînement"
                    : "Déposer le PDF de la fiche"}
                </button>
                {depot && (
                  <p className="small muted" style={{ marginTop: 6 }}>
                    {depot === "en cours" ? "Dépôt en cours…"
                      : depot === "stocké" ? "Déposé et conservé."
                      : "Le fichier n'a pas pu être stocké : " + depot
                        + ". Il tient en mémoire, mais disparaîtra au rechargement."}
                  </p>
                )}
              </>
            )}
            <input className="inp" style={{ width: "100%", marginTop: 10 }}
              placeholder={["Fiche", "Épreuve blanche", "Corrigé épreuve", "Entraînement libre"].includes(res.type)
                  ? "…ou lien du PDF (https://...)"
                : res.type === "Sujet Labolycée" ? "Lien Labolycée (https://labolycee.org/...)"
                : "Lien de la vidéo (Vimeo, YouTube, Dailymotion)"}
              value={res.url} onChange={(e) => setRes({ ...res, url: e.target.value })} />

            {res.type === "Sujet Labolycée" ? (
              <>
                <input className="inp" style={{ width: "100%", marginTop: 10 }}
                  placeholder="Session, ex. Métropole 2023 · sujet 1"
                  value={res.session || ""} onChange={(e) => setRes({ ...res, session: e.target.value })} />
                <input className="inp" style={{ width: "100%", marginTop: 10 }} placeholder="Durée en minutes, ex. 40"
                  value={res.duree} onChange={(e) => setRes({ ...res, duree: e.target.value })} />
              </>
            ) : res.type === "Épreuve blanche" ? (
              <>
                <p className="small muted" style={{ marginTop: 10 }}>
                  Durée fixée à 2 h, pour toutes les épreuves blanches.
                </p>
                {/* Un contrôle porte souvent sur PLUSIEURS chapitres. Une
                    épreuve combinée les couvre d'un coup : coller deux sujets
                    bout à bout donnerait quatre heures, ce qu'aucun élève ne
                    fera. Le chapitre choisi plus haut est coché d'office. */}
                <p className="small muted" style={{ marginTop: 12 }}>
                  Chapitres couverts par cette épreuve
                </p>
                <div className="chips longue" style={{ marginTop: 6 }}>
                  {CHAPITRES.map((c) => {
                    const dedans = (res.chapitres || [chapId]).includes(c.id);
                    return (
                      <button key={c.id} className={"chip" + (dedans ? " on" : "")}
                        onClick={() => {
                          const act = res.chapitres || [chapId];
                          const suite = dedans ? act.filter((x) => x !== c.id) : [...act, c.id];
                          setRes({ ...res, chapitres: suite.length ? suite : [chapId] });
                        }}>{c.court}</button>
                    );
                  })}
                </div>
                {(res.chapitres || [chapId]).length > 1 && (
                  <p className="small" style={{ marginTop: 8, color: "#7A5A12" }}>
                    Épreuve combinée : elle sera servie quand le contrôle portera
                    sur ces {(res.chapitres || []).length} chapitres.
                  </p>
                )}
              </>
            ) : !["Fiche", "Corrigé épreuve", "Entraînement libre"].includes(res.type) ? (
              <input className="inp" style={{ width: "100%", marginTop: 10 }} placeholder="Duree, ex. 12 min"
                value={res.duree} onChange={(e) => setRes({ ...res, duree: e.target.value })} />
            ) : (
              <input className="inp" style={{ width: "100%", marginTop: 10 }} placeholder="Nombre de pages"
                value={res.pages} onChange={(e) => setRes({ ...res, pages: e.target.value })} />
            )}

            {TYPES_VIDEO.includes(res.type) && res.url && !lecteurVideo(res.url) && (
              <p className="small" style={{ color: "var(--red)", marginTop: 10 }}>
                Ce lien ne ressemble pas a un lien Vimeo. Attendu : https://vimeo.com/123456789
              </p>
            )}
            {res.type !== "Fiche" && res.type !== "Sujet Labolycée" && lecteurVideo(res.url) && (
              <div style={{ position: "relative", paddingTop: "56.25%", marginTop: 12, borderRadius: 14, overflow: "hidden", border: "1px solid var(--line)" }}>
                <iframe src={lecteurVimeo(res.url)} title="apercu" allow="fullscreen"
                  style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: 0 }} />
              </div>
            )}

            <button className="btn btn-gold btn-block" style={{ marginTop: 14 }}
              /* Seules les VIDÉOS exigent un lien de lecture valide. L'épreuve
                 blanche et son corrigé sont des PDF : la condition les bloquait,
                 le bouton restait grisé après un dépôt pourtant réussi. */
              disabled={!res.titre.trim() || !res.url.trim()
                || (TYPES_VIDEO.includes(res.type) && !lecteurVideo(res.url))}
              onClick={() => {
                ajouterRessource(chapId, {
                  id: chapId + "-" + Date.now(),
                  type: res.type,
                  titre: res.titre.trim(),
                  url: res.url.trim(),
                  ...(res.type === "Fiche" ? { pages: Number(res.pages) || null }
                    : res.type === "Épreuve blanche"
                    ? { duree: 120, chapitres: res.chapitres || [chapId] }
                    : res.type === "Corrigé épreuve" ? {}
                    : res.type === "Sujet Labolycée"
                    ? { duree: Number(res.duree) || null, session: (res.session || "").trim() }
                    : { duree: (res.duree || "").trim() }),
                });
                setRes({ type: res.type, titre: "", url: "", duree: "", pages: "", session: "" });
              }}>
              Ajouter au chapitre
            </button>
          </div>

          <div className="card">
            <h3>{CHAPITRES.find((c) => c.id === chapId)?.nom}</h3>
            {TYPES_VIDEO.map((t) => {
              const liste = (ressources[chapId]?.videos || []).filter((v) => v.type === t);
              return (
                <div key={t} style={{ marginTop: 14 }}>
                  <div className="between">
                    <h4>{t}</h4>
                    <div className="row" style={{ gap: 6, flex: "none" }}>
                      <span className={"tag " + (liste.length ? "green" : "grey")}>{liste.length}</span>
                      {/* Retirer d'un coup toutes les vidéos de ce type pour ce
                          chapitre : refaire une série de leçons ne doit pas
                          obliger à les supprimer une par une. */}
                      {liste.length > 0 && viderRessources && (
                        <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                          onClick={() => viderRessources(chapId, t)}>Tout retirer</button>
                      )}
                    </div>
                  </div>
                  {liste.map((v) => (
                    <div className="res" key={v.id}>
                      <span className="ico"><Icon d={I.play} size={18} /></span>
                      <div style={{ flex: 1 }}><h4>{v.titre}</h4><p className="small muted">{v.duree || ""}</p></div>
                      {v.url && (
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => window.open(v.url, "_blank", "noopener")}>Voir</button>
                      )}
                      <span className={"tag " + (lecteurVideo(v.url) ? "green" : "red")}>{lecteurVideo(v.url) ? "en ligne" : "sans lien"}</span>
                      {retirerRessource && (
                        <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                          onClick={() => retirerRessource(chapId, v.id)}>Retirer</button>
                      )}
                    </div>
                  ))}
                  {!liste.length && <p className="small muted" style={{ marginTop: 6 }}>Rien pour l'instant.</p>}
                </div>
              );
            })}
            <div style={{ marginTop: 16 }}>
              <div className="between">
                <h4>Fiches de revision</h4>
                {(ressources[chapId]?.fiches || []).length > 0 && viderRessources && (
                  <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                    onClick={() => viderRessources(chapId, "fiches")}>Tout retirer</button>
                )}
              </div>
              {(ressources[chapId]?.fiches || []).map((f) => (
                <div className="res" key={f.id}>
                  <span className="ico"><Icon d={I.pdf} size={18} /></span>
                  <div style={{ flex: 1 }}><h4>{f.titre}</h4><p className="small muted">{f.pages ? f.pages + " pages" : "PDF"}</p></div>
                  {/* Ouvrir ce qui a été déposé : sans ce bouton, rien ne
                      permet de vérifier qu'on a bien versé le bon PDF — et un
                      dépôt en lot rend l'erreur facile. */}
                  {f.url && (
                    <button className="btn btn-ghost btn-sm"
                      onClick={() => window.open(f.url, "_blank", "noopener")}>Ouvrir</button>
                  )}
                  <span className={"tag " + (f.url ? "green" : "red")}>{f.url ? "en ligne" : "sans lien"}</span>
                  {retirerRessource && (
                    <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                      onClick={() => retirerRessource(chapId, f.id)}>Retirer</button>
                  )}
                </div>
              ))}
              {!(ressources[chapId]?.fiches || []).length && <p className="small muted" style={{ marginTop: 6 }}>Aucune fiche.</p>}
            </div>

            {/* Les épreuves blanches du coach : ses propres PDF, qui remplacent
                celles composées depuis les lots. */}
            <div style={{ marginTop: 16 }}>
              <div className="between">
                <h4>Épreuve blanche</h4>
                <span className={"tag " + ((ressources[chapId]?.epreuves || []).length ? "green" : "grey")}>
                  {(ressources[chapId]?.epreuves || []).length ? "déposée" : "aucune"}
                </span>
              </div>
              {[...(ressources[chapId]?.epreuves || []),
                ...(ressources[chapId]?.corriges || [])].map((f) => (
                <div className="res" key={f.id}>
                  <span className="ico"><Icon d={I.pdf} size={18} /></span>
                  <div style={{ flex: 1 }}>
                    <h4>{f.titre}</h4>
                    <p className="small muted">
                      {f.type === "Corrigé épreuve" ? "corrigé" : "2 h"}
                      {(f.chapitres || []).length > 1
                        ? " · " + f.chapitres.map((x) =>
                            CHAPITRES.find((c) => c.id === x)?.court || x).join(", ")
                        : ""}
                      {/* Le nom du fichier stocké : c'est lui qui dit sans
                          ambiguïté quel PDF a été versé. */}
                      {f.url ? " · " + decodeURIComponent(String(f.url).split("/").pop()
                        .replace(/^\d+-/, "")).slice(0, 40) : ""}
                    </p>
                  </div>
                  {/* Une épreuve combinée se distingue d'un coup d'œil : elle
                      ne sert que pour une combinaison précise de chapitres. */}
                  {(f.chapitres || []).length > 1 && (
                    <span className="tag gold">combinée</span>
                  )}
                  {/* Ouvrir ce qui a été déposé : sans ce bouton, rien ne
                      permet de vérifier qu'on a bien versé le bon PDF — et un
                      dépôt en lot rend l'erreur facile. */}
                  {f.url && (
                    <button className="btn btn-ghost btn-sm"
                      onClick={() => window.open(f.url, "_blank", "noopener")}>Ouvrir</button>
                  )}
                  <span className={"tag " + (f.url ? "green" : "red")}>{f.url ? "en ligne" : "sans lien"}</span>
                  {retirerRessource && (
                    <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                      onClick={() => retirerRessource(chapId, f.id)}>Retirer</button>
                  )}
                </div>
              ))}
              {!(ressources[chapId]?.epreuves || []).length && (
                <p className="small muted" style={{ marginTop: 6 }}>
                  Aucune épreuve déposée : l'application en composera une depuis
                  les exercices du chapitre.
                </p>
              )}
            </div>

            {/* L'entraînement libre du chapitre : le second sujet, sans rendu. */}
            <div style={{ marginTop: 16 }}>
              <div className="between">
                <h4>Entraînement libre</h4>
                <span className={"tag " + ((ressources[chapId]?.libres || []).length ? "green" : "grey")}>
                  {(ressources[chapId]?.libres || []).length ? "déposé" : "aucun"}
                </span>
              </div>
              {(ressources[chapId]?.libres || []).map((f) => (
                <div className="res" key={f.id}>
                  <span className="ico"><Icon d={I.pdf} size={18} /></span>
                  <div style={{ flex: 1 }}>
                    <h4>{f.titre}</h4>
                    <p className="small muted">
                      sans rendu
                      {f.url ? " · " + decodeURIComponent(String(f.url).split("/").pop()
                        .replace(/^\d+-/, "")).slice(0, 36) : ""}
                    </p>
                  </div>
                  {f.url && (
                    <button className="btn btn-ghost btn-sm"
                      onClick={() => window.open(f.url, "_blank", "noopener")}>Ouvrir</button>
                  )}
                  {retirerRessource && (
                    <button className="btn btn-ghost btn-sm" style={{ color: "#C0392B" }}
                      onClick={() => retirerRessource(chapId, f.id)}>Retirer</button>
                  )}
                </div>
              ))}
              {!(ressources[chapId]?.libres || []).length && (
                <p className="small muted" style={{ marginTop: 6 }}>
                  Aucun second sujet déposé : l'élève n'aura rien à faire après
                  son épreuve blanche.
                </p>
              )}
            </div>

            {/* Les vidéos en masse. Pas de fichier à déposer : elles sont chez
                Vimeo. On colle une liste de liens, une par ligne. */}
            <div style={{ marginTop: 16, paddingTop: 12, borderTop: "1px solid #EDF0FD" }}>
              <h4>Toutes les vidéos d'un coup</h4>
              <p className="small muted" style={{ marginTop: 4 }}>
                Une ligne par vidéo : <b>chapitre, type, titre, lien</b>. Déposez
                le fichier CSV, ou collez les lignes. Le type et le titre sont
                facultatifs ; le séparateur peut être une virgule, « | », « ; »
                ou une tabulation.
              </p>
              <textarea className="inp" rows={6} value={collage}
                onChange={(e) => setCollage(e.target.value)}
                placeholder={"son | Leçon | Le niveau sonore | https://vimeo.com/1134530387/ed1ef5d63a\n"
                  + "doppler | Question type | Les questions types | https://vimeo.com/…"}
                style={{ width: "100%", marginTop: 10, fontFamily: "var(--fm, monospace)",
                         fontSize: 12, lineHeight: 1.5 }} />
              {/* Le CSV se dépose comme un fichier : plus simple que de coller
                  soixante lignes sur un téléphone. Son contenu remplit la zone
                  de texte, que le coach peut relire avant de valider. */}
              <input ref={champCsv} type="file" accept=".csv,text/csv,text/plain"
                style={{ display: "none" }}
                onChange={async (ev) => {
                  const f = (ev.target.files || [])[0]; if (!f) return;
                  ev.target.value = "";
                  const txt = await f.text();
                  setCollage(txt.replace(/^\uFEFF/, ""));
                }} />
              <button className="btn btn-ghost btn-block" style={{ marginTop: 10 }}
                onClick={() => champCsv.current && champCsv.current.click()}>
                Choisir un fichier CSV
              </button>
              <button className="btn btn-accent btn-block" style={{ marginTop: 8 }}
                disabled={!collage.trim() || lotVideos?.etat === "en cours"}
                onClick={async () => {
                  const lignes = collage.split(/\r?\n/);
                  setLotVideos({ etat: "en cours", fait: 0, total: lignes.length });
                  const bilan = []; let fait = 0;
                  for (const ligne of lignes) {
                    setLotVideos({ etat: "en cours", fait: fait++, total: lignes.length });
                    const a = analyserLigneVideo(ligne);
                    if (!a) continue;                       // ligne vide ou commentaire
                    if (a.erreur) { bilan.push(a); continue; }
                    try {
                      await ajouterRessource(a.chapId, {
                        id: "vi-" + Date.now() + "-" + fait, type: a.type,
                        titre: a.titre, url: a.url, duree: null });
                      bilan.push(a);
                    } catch (e) {
                      bilan.push({ erreur: String(e.message || e), ligne: ligne.trim() });
                    }
                  }
                  setLotVideos({ etat: "fini", bilan });
                  if (!bilan.some((x) => x.erreur)) setCollage("");
                }}>
                {lotVideos?.etat === "en cours"
                  ? "Dépôt " + (lotVideos.fait + 1) + " sur " + lotVideos.total + "…"
                  : "Déposer toutes les vidéos"}
              </button>
              {lotVideos?.etat === "fini" && (
                <div style={{ marginTop: 10 }}>
                  <p className="small" style={{ marginBottom: 6 }}>
                    <b>{lotVideos.bilan.filter((x) => !x.erreur).length} vidéo(s) rattachées</b>
                    {lotVideos.bilan.some((x) => x.erreur)
                      ? " · " + lotVideos.bilan.filter((x) => x.erreur).length + " ligne(s) en erreur" : ""}
                  </p>
                  {lotVideos.bilan.map((x, k) => (
                    <div className="row" key={k} style={{ gap: 8, padding: "2px 0" }}>
                      <span className={"tag " + (x.erreur ? "red" : "green")}>
                        {x.erreur ? "erreur" : CHAPITRES.find((c) => c.id === x.chapId)?.court}
                      </span>
                      <span className="small" style={{ flex: 1 }}>
                        {x.erreur ? x.erreur + " — " + x.ligne.slice(0, 46)
                          : x.type + " · " + x.titre}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* L'OUVERTURE DU GRAND ORAL. Le module reste fermé tant que le
                coach ne l'a pas éprouvé : ni onglet, ni carnet de pistes chez
                l'élève. */}
            <div style={{ marginTop: 16, paddingTop: 12, borderTop: "1px solid #EDF0FD" }}>
              <div className="between">
                <h4>Module Grand oral</h4>
                <span className={"tag " + (oralOuvert ? "green" : "grey")}>
                  {oralOuvert ? "ouvert aux élèves" : "fermé"}
                </span>
              </div>
              <p className="small muted" style={{ marginTop: 4 }}>
                Tant qu'il est fermé, les élèves n'ont ni l'onglet Oral ni le
                carnet de pistes. Vous y accédez quand même, pour le vérifier.
              </p>
              <button className="btn btn-ghost btn-block" style={{ marginTop: 10 }}
                onClick={async () => {
                  try { await ecrireOralOuvert(!oralOuvert); setOralOuvert(!oralOuvert); }
                  catch (e) { setAvis({ bon: false, txt: String(e.message || e) }); }
                }}>
                {oralOuvert ? "Fermer le module" : "Ouvrir aux élèves"}
              </button>
            </div>

            {/* Les fiches de révision, toutes d'un coup. Même principe que les
                évaluations : le nom du fichier désigne le chapitre. */}
            <div style={{ marginTop: 16, paddingTop: 12, borderTop: "1px solid #EDF0FD" }}>
              <h4>Toutes les fiches de révision d'un coup</h4>
              <p className="small muted" style={{ marginTop: 4 }}>
                Une archive de PDF nommés <b>Fiche_T_cinetique.pdf</b>,
                <b> Fiche_T_niveau_sonore.pdf</b>… Un fichier <b>resume-son.pdf</b>
                dépose une <b>fiche express</b>, version brève qui s'ajoute à la
                fiche complète. Le titre du fichier suffit à
                retrouver le chapitre.
              </p>
              <input ref={champFiches} type="file" accept=".zip,application/zip"
                style={{ display: "none" }}
                onChange={async (ev) => {
                  const f = (ev.target.files || [])[0]; if (!f) return;
                  ev.target.value = "";
                  setLotFiches({ etat: "en cours", fait: 0, total: 0 });
                  try {
                    const contenu = await lireArchive(new Uint8Array(await f.arrayBuffer()));
                    const noms = Object.keys(contenu).filter((n) => /\.pdf$/i.test(n));
                    const bilan = []; let fait = 0;
                    for (const nom of noms) {
                      setLotFiches({ etat: "en cours", fait: fait++, total: noms.length });
                      const a = analyserNomFiche(nom);
                      if (!a) { bilan.push({ nom, erreur: "chapitre non reconnu" }); continue; }
                      try {
                        const blob = new Blob([contenu[nom]], { type: "application/pdf" });
                        const court = nom.split("/").pop();
                        const rep = await deposerFichier("fiches/" + a.chapId,
                          Object.assign(blob, { name: court }));
                        const url = typeof rep === "string" ? rep : rep.url;
                        await ajouterRessource(a.chapId, {
                          id: "fi-" + Date.now() + "-" + fait,
                          /* Une FICHE EXPRESS a son propre type : elle
                             s'ajoute à la fiche complète au lieu de la
                             remplacer, et se déverrouille avec elle. */
                          type: a.express ? "Fiche express" : "Fiche",
                          titre: a.titre, url, pages: null });
                        bilan.push({ nom: court, chapId: a.chapId });
                      } catch (e) {
                        bilan.push({ nom, erreur: String(e.message || e) });
                      }
                    }
                    setLotFiches({ etat: "fini", bilan });
                  } catch (e) {
                    setLotFiches({ etat: "erreur", message: String(e.message || e) });
                  }
                }} />
              <button className="btn btn-accent btn-block" style={{ marginTop: 10 }}
                disabled={lotFiches?.etat === "en cours"}
                onClick={() => champFiches.current && champFiches.current.click()}>
                {lotFiches?.etat === "en cours"
                  ? "Dépôt " + (lotFiches.fait + 1) + " sur " + lotFiches.total + "…"
                  : "Déposer toutes les fiches"}
              </button>
              {lotFiches?.etat === "erreur" && (
                <p className="small" style={{ marginTop: 8, color: "#C0392B" }}>{lotFiches.message}</p>
              )}
              {lotFiches?.etat === "fini" && (
                <div style={{ marginTop: 10 }}>
                  <p className="small" style={{ marginBottom: 6 }}>
                    <b>{lotFiches.bilan.filter((x) => !x.erreur).length} fiche(s) rangées</b>
                    {lotFiches.bilan.some((x) => x.erreur)
                      ? " · " + lotFiches.bilan.filter((x) => x.erreur).length + " non reconnue(s)" : ""}
                  </p>
                  {lotFiches.bilan.map((x, k) => (
                    <div className="row" key={k} style={{ gap: 8, padding: "2px 0" }}>
                      <span className={"tag " + (x.erreur ? "red" : "green")}>
                        {x.erreur ? "échec" : CHAPITRES.find((c) => c.id === x.chapId)?.court}
                      </span>
                      <span className="small" style={{ flex: 1 }}>
                        {x.erreur ? x.nom + " — " + x.erreur
                          : CHAPITRES.find((c) => c.id === x.chapId)?.nom}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Le dépôt en lot des épreuves : une par chapitre, parfois une
                combinée. Les déposer une par une depuis un téléphone prend
                vingt-deux manipulations ; par archive, une seule. */}
            <div style={{ marginTop: 16, paddingTop: 12, borderTop: "1px solid #EDF0FD" }}>
              <h4>Toutes les évaluations d'un coup</h4>
              <p className="small muted" style={{ marginTop: 4 }}>
                Une archive de PDF nommés <b>evaluation-son-2h-enonce.pdf</b> et
                <b> evaluation-son-2h-corrige.pdf</b>. Un fichier commençant par
                <b> entrainement-</b> devient un entraînement libre. Pour une épreuve combinée,
                séparez les chapitres par « + ». Un PDF rangé dans un dossier au
                nom du chapitre est reconnu aussi.
              </p>
              <input ref={champEvals} type="file" accept=".zip,application/zip"
                style={{ display: "none" }}
                onChange={async (ev) => {
                  const f = (ev.target.files || [])[0]; if (!f) return;
                  ev.target.value = "";
                  setLotEvals({ etat: "en cours", fait: 0, total: 0 });
                  try {
                    const contenu = await lireArchive(new Uint8Array(await f.arrayBuffer()));
                    const noms = Object.keys(contenu).filter((n) => /\.pdf$/i.test(n));
                    const bilan = []; let fait = 0;
                    for (const nom of noms) {
                      setLotEvals({ etat: "en cours", fait: fait++, total: noms.length });
                      const a = analyserNomEvaluation(nom);
                      if (!a) { bilan.push({ nom, erreur: "nom non reconnu" }); continue; }
                      try {
                        const blob = new Blob([contenu[nom]], { type: "application/pdf" });
                        const court = nom.split("/").pop();
                        const dossier = a.libre ? "libres/" : a.corrige ? "corriges/" : "epreuves/";
                        const rep = await deposerFichier(dossier + a.chapitres[0],
                          Object.assign(blob, { name: court }));
                        const url = typeof rep === "string" ? rep : rep.url;
                        const item = { id: "ev-" + Date.now() + "-" + fait,
                          type: a.libre ? "Entraînement libre"
                              : a.corrige ? "Corrigé épreuve" : "Épreuve blanche",
                          titre: a.titre, url, duree: a.corrige ? null : 120,
                          chapitres: a.chapitres };
                        await ajouterRessource(a.chapitres[0], item);
                        bilan.push({ nom: court, chapitres: a.chapitres,
                                     corrige: a.corrige, libre: a.libre, titre: a.titre });
                      } catch (e) {
                        bilan.push({ nom, erreur: String(e.message || e) });
                      }
                    }
                    setLotEvals({ etat: "fini", bilan });
                  } catch (e) {
                    setLotEvals({ etat: "erreur", message: String(e.message || e) });
                  }
                }} />
              <button className="btn btn-accent btn-block" style={{ marginTop: 10 }}
                disabled={lotEvals?.etat === "en cours"}
                onClick={() => champEvals.current && champEvals.current.click()}>
                {lotEvals?.etat === "en cours"
                  ? "Dépôt " + (lotEvals.fait + 1) + " sur " + lotEvals.total + "…"
                  : "Déposer toutes les évaluations"}
              </button>
              {lotEvals?.etat === "erreur" && (
                <p className="small" style={{ marginTop: 8, color: "#C0392B" }}>
                  {lotEvals.message}
                </p>
              )}
              {lotEvals?.etat === "fini" && (
                <div style={{ marginTop: 10 }}>
                  <p className="small" style={{ marginBottom: 6 }}>
                    <b>{lotEvals.bilan.filter((x) => !x.erreur).length} fichier(s) rangés</b>
                    {lotEvals.bilan.some((x) => x.erreur)
                      ? " · " + lotEvals.bilan.filter((x) => x.erreur).length + " non reconnu(s)" : ""}
                  </p>
                  {lotEvals.bilan.map((x, k) => (
                    <div className="row" key={k} style={{ gap: 8, padding: "2px 0" }}>
                      <span className={"tag " + (x.erreur ? "red" : "green")}>
                        {x.erreur ? "échec" : x.libre ? "libre" : x.corrige ? "corrigé" : "épreuve"}
                      </span>
                      <span className="small" style={{ flex: 1 }}>
                        {x.erreur ? x.nom + " — " + x.erreur
                          : x.chapitres.map((c) => CHAPITRES.find((y) => y.id === c)?.court || c).join(" + ")
                            + " · " + x.titre}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Tout le chapitre d'un coup, avec confirmation : c'est le geste
                de fin d'année, ou celui d'une série à refaire entièrement. */}
            {((ressources[chapId]?.videos || []).length
              + (ressources[chapId]?.fiches || []).length) > 0 && viderRessources && (
              <div style={{ marginTop: 16, paddingTop: 12, borderTop: "1px solid #EDF0FD" }}>
                {videToutes ? (
                  <>
                    <p className="small" style={{ color: "#C0392B" }}>
                      Toutes les vidéos et fiches de ce chapitre seront retirées.
                      Les élèves ne les verront plus.
                    </p>
                    <div className="row" style={{ gap: 8, marginTop: 10 }}>
                      <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}
                        onClick={() => setVideToutes(false)}>Annuler</button>
                      <button className="btn btn-accent btn-sm" style={{ flex: 1 }}
                        onClick={async () => { await viderRessources(chapId); setVideToutes(false); }}>
                        Tout retirer
                      </button>
                    </div>
                  </>
                ) : (
                  <button className="btn btn-ghost btn-sm btn-block" style={{ color: "#C0392B" }}
                    onClick={() => setVideToutes(true)}>
                    Retirer toutes les ressources de ce chapitre
                  </button>
                )}
              </div>
            )}

            <div style={{ marginTop: 16 }}>
              <div className="between">
                <h4>Sujets Labolycée</h4>
                <span className={"tag " + ((ressources[chapId]?.sujets || []).length ? "green" : "grey")}>
                  {(ressources[chapId]?.sujets || []).length}
                </span>
              </div>
              <p className="small muted" style={{ marginTop: 4 }}>
                Un par week-end, en rotation entre les chapitres en cours. La ligne
                ambre est la consigne que lit l'élève : ouvrez le sujet pour vérifier
                qu'elle désigne bien la bonne partie.
              </p>
              {(ressources[chapId]?.sujets || []).map((sj) => (
                <div className="res" key={sj.id} style={{ alignItems: "flex-start" }}>
                  <span className="ico"><Icon d={I.pdf} size={18} /></span>
                  <div style={{ flex: 1 }}>
                    <h4>{sj.titre}</h4>
                    <p className="small muted">{sj.session || "Labolycée"}{sj.duree ? " · " + sj.duree + " min" : ""}{sj.points ? " · " + sj.points + " pts" : ""}</p>
                    {/* La CONSIGNE, celle que l'élève lira : c'est elle qui dit
                        quelle partie traiter. Sans elle, impossible de vérifier
                        depuis l'espace coach que le sujet est bien découpé. */}
                    {sj.consigne && (
                      <p className="small" style={{ marginTop: 4, color: "#7A5A12" }}>
                        {sj.consigne}
                      </p>
                    )}
                  </div>
                  {sj.url && (
                    <button className="btn btn-ghost btn-sm"
                      onClick={() => window.open(sj.url, "_blank", "noopener")}>Ouvrir</button>
                  )}
                  <span className={"tag " + (sj.url ? "green" : "red")}>{sj.url ? "en ligne" : "sans lien"}</span>
                </div>
              ))}
              {!(ressources[chapId]?.sujets || []).length &&
                <p className="small muted" style={{ marginTop: 6 }}>Aucun sujet pour l'instant.</p>}
            </div>
          </div>
        </>
      )}

      {/* ---------------- BIBLIOTHÈQUE ---------------- */}
      {vue === "biblio" && (
        <>
          {/* Avec quatorze chapitres, la vraie question n'est plus « que contient
              la bibliothèque » mais « qu'est-ce qu'il me reste à produire ». */}
          <div className="card">
            <h3>Où en est le contenu</h3>
            <p className="small muted" style={{ marginTop: 4 }}>
              Un chapitre est prêt quand il a son test diagnostic, quinze exercices
              d'entraînement, sa fiche de révision et sa vidéo. Les sujets du week-end
              viennent de Labolycée : ils n'ont rien à déposer.
            </p>
            {(() => {
              const etat = CHAPITRES.map((c) => {
                const ex = biblio[c.id] || [];
                const res = ressources[c.id] || { videos: [], fiches: [] };
                const manques = [];
                /* Un test complet, c'est UNE QUESTION PAR GESTE — pas dix.
                   Le seuil fixe signalait comme manquants les quatorze
                   chapitres qui comptent moins de dix gestes, alors que leur
                   test les couvrait tous. */
                {
                  const d = (banques[c.id] || []).filter((q) => q.diagnostic);
                  const gestes = Object.keys(TITRES_QT[c.id] || {})
                    .filter((k) => k.startsWith("QT"));
                  const vus = new Set(d.map((q) => q.source_qt));
                  if (!d.length) manques.push("diagnostic");
                  else if (gestes.some((k) => !vus.has(k)))
                    manques.push("diagnostic incomplet");
                }
                /* Quinze exercices d'entraînement par chapitre, sans niveau.
                   Le sujet long ne se dépose plus : il vient de Labolycée. */
                if (ex.filter((e) => e.usage === "entrainement").length < 15) manques.push("entraînement");
                /* La réserve d'évaluation ne compte que si le coach n'a pas
                   déposé sa propre épreuve blanche en PDF : dans ce cas
                   l'application en compose une depuis ces exercices. */
                if (!(res.epreuves || []).length
                    && ex.filter((e) => e.usage === "evaluation").reduce((a, e) => a + e.duree, 0) < 120)
                  manques.push("épreuve blanche");
                if (!res.videos.filter((v) => v.url).length) manques.push("vidéo");
                if (!res.fiches.filter((f) => f.url).length) manques.push("fiche");
                return { c, manques };
              });
              const prets = etat.filter((e) => !e.manques.length).length;
              return (
                <>
                  <div className="row" style={{ marginTop: 12, gap: 8 }}>
                    <span className={"tag " + (prets ? "green" : "red")}>{prets} chapitre(s) prêt(s)</span>
                    <span className="tag gold">{CHAPITRES.length - prets} à compléter</span>
                  </div>
                  {etat.map(({ c, manques }) => (
                    <div className="res" key={c.id}>
                      <span className="ico"><Icon d={manques.length ? I.book : I.coche} size={18} /></span>
                      <div style={{ flex: 1 }}>
                        <h4>{c.nom}</h4>
                        <p className="small muted">
                          {manques.length ? "Il manque : " + manques.join(", ") : "Prêt pour la rentrée"}
                        </p>
                      </div>
                      <button className={"btn btn-sm " + (chapId === c.id ? "btn-accent" : "btn-ghost")}
                        onClick={() => ouvrirChapitre(c.id)}>
                        {chapId === c.id ? "Ouvert" : "Ouvrir"}
                      </button>
                    </div>
                  ))}
                </>
              );
            })()}
          </div>

          {/* Le dépôt en lot : une centaine de fichiers par chapitre, deux mille
              cinq cents au total. Un par un, c'est hors de portée depuis un
              téléphone ; par archive, c'est l'affaire d'une minute. */}
          <div className="card">
            <div className="between">
              <h3>Déposer tout un chapitre</h3>
              <span className="tag">{CHAPITRES.find((c) => c.id === chapId)?.court}</span>
            </div>
            <p className="small muted" style={{ marginTop: 8 }}>
              Choisissez l'archive du chapitre. Chaque fichier rejoint son exercice
              d'après son nom : <b>son-f1-enonce.pdf</b> remplit l'énoncé de l'exercice
              <b> son-f1</b>, et <b>son-f1-corrige.pdf</b> son corrigé.
              Si l'archive contient un fichier <b>chapitre.json</b>, les exercices
              qui n'existent pas encore sont <b>créés automatiquement</b> — un
              chapitre entier s'ajoute alors d'un seul geste. Une archive qui
              contient <b>plusieurs dossiers</b>, chacun avec son manifeste, verse
              <b> tous les chapitres à la suite</b>.
            </p>
            <input ref={champLot} type="file" accept=".zip,application/zip"
              style={{ display: "none" }}
              onChange={async (ev) => {
                const f = (ev.target.files || [])[0]; if (!f) return;
                ev.target.value = "";
                setLot({ etat: "en cours", fait: 0, total: 0 });
                try {
                  const contenu = await lireArchive(new Uint8Array(await f.arrayBuffer()));
                  /* UNE archive peut porter PLUSIEURS chapitres, chacun dans son
                     dossier avec son manifeste. On les verse tous : vingt-deux
                     dépôts depuis un téléphone, c'est vingt-deux manipulations. */
                  const lots = chapitresDansArchive(contenu);
                  if (lots.length > 1) {
                    const bilan = [];
                    let biblioCourante = biblio;
                    for (let k = 0; k < lots.length; k++) {
                      setLot({ etat: "en cours", fait: k, total: lots.length,
                               chapitres: lots.length, enCours: lots[k].dossier });
                      try {
                        const r = await deposerArchive(chapId, null, biblioCourante,
                          null, sousArchive(contenu, lots[k].dossier), lots[k].dossier);
                        biblioCourante = { ...biblioCourante,
                          [r.chapId]: (r.crees.length
                            ? r.crees
                            : (biblioCourante[r.chapId] || []))
                            .map((x) => r.majs[x.id] ? { ...x, ...r.majs[x.id] } : x) };
                        /* LES EXERCICES SONT ENREGISTRÉS EN BASE. Le dépôt ne
                           mettait à jour que l'affichage : ils disparaissaient
                           au prochain chargement, et l'élève ne les voyait
                           jamais. On remplace la banque du chapitre, puisqu'un
                           lot est une version complète. */
                        if (supabaseActif) {
                          try {
                            /* ON NE VIDE PLUS. Chaque exercice est rapproché
                               par sa référence : ce qui existe est mis à jour,
                               ce qui est nouveau s'ajoute, rien ne disparaît.
                               Le travail des élèves reste rattaché. */
                            const bil = await enregistrerLot(r.chapId, r,
                              biblioCourante[r.chapId]);
                            if (bil.echecs.length) {
                              bilan.push({ chapId: r.chapId,
                                erreur: "enregistrement refusé : "
                                  + bil.echecs.slice(0, 3).join(" ; ") });
                            }
                          } catch (e) {
                            bilan.push({ chapId: r.chapId,
                              erreur: "enregistrement refusé : " + (e.message || e) });
                          }
                        }
                        bilan.push({ chapId: r.chapId, crees: r.crees.length,
                                     fichiers: r.fait || 0 });
                      } catch (e) {
                        bilan.push({ chapId: lots[k].dossier, erreur: String(e.message || e) });
                      }
                    }
                    setBiblio(biblioCourante);
                    setLot({ etat: "fini", bilan, chapitres: lots.length });
                    return;
                  }
                  const r = await deposerArchive(chapId, null, biblio,
                    (fait, total) => setLot({ etat: "en cours", fait, total }), contenu);
                  setBiblio((b) => ({ ...b,
                    /* Le manifeste REMPLACE le lot du chapitre : les exercices
                       qu'il ne cite plus disparaissent, et ceux qu'il cite sont
                       mis à jour. Fusionner laissait s'accumuler des versions
                       anciennes que le coach croyait avoir corrigées. */
                    [r.chapId]: (r.crees.length
                      ? r.crees
                      : (b[r.chapId] || [])).map((x) =>
                        r.majs[x.id] ? { ...x, ...r.majs[x.id] } : x) }));
                  /* EN BASE AUSSI : sans cela, les exercices ne vivaient que
                     dans le navigateur du coach et l'élève ne les voyait
                     jamais. */
                  if (supabaseActif) {
                    try {
                      /* Mise à jour par référence, sans vider le chapitre. */
                      const bil = await enregistrerLot(r.chapId, r, biblio[r.chapId]);
                      if (bil.echecs.length) {
                        setAvis({ bon: false, txt: bil.echecs.length
                          + " exercice(s) non enregistré(s) : "
                          + bil.echecs.slice(0, 3).join(" ; ") });
                      } else if (bil.ecrits) {
                        setAvis({ bon: true, txt: bil.ecrits
                          + " exercice(s) enregistré(s) en base." });
                      }
                    } catch (e) {
                      /* « setJournal » est le carnet du soir de l'ÉLÈVE : il
                         n'existe pas ici. L'espace coach a son propre bandeau
                         d'avis, et l'appel jetait une exception qui laissait
                         la page blanche au moindre échec d'enregistrement. */
                      setAvis({ bon: false, txt: "Exercices non enregistrés. "
                        + "Ils s'affichent chez vous mais l'élève ne les verra "
                        + "pas : " + (e.message || e) });
                    }
                  }
                  if (r.chapId !== chapId) setChapId(r.chapId);
                  setLot({ etat: "fini", ...r });
                } catch (e) { setLot({ etat: "erreur", message: String(e.message || e) }); }
              }} />
            <button className="btn btn-accent btn-block" style={{ marginTop: 12 }}
              disabled={lot?.etat === "en cours"}
              onClick={() => champLot.current && champLot.current.click()}>
              {lot?.etat === "en cours"
                ? (lot.chapitres ? "Chapitre " + (lot.fait + 1) + " sur " + lot.chapitres + "…"
                                 : "Dépôt en cours…")
                : "Choisir une archive"}
            </button>
            {lot?.etat === "en cours" && lot.total > 0 && (
              <>
                <div className="bar" style={{ marginTop: 10 }}>
                  <i style={{ width: (lot.fait / lot.total) * 100 + "%" }} />
                </div>
                <p className="small muted" style={{ marginTop: 6 }}>
                  {lot.fait} fichier(s) sur {lot.total}
                </p>
              </>
            )}
            {/* Le bilan d'une archive multi-chapitres : une ligne par chapitre,
                pour voir d'un coup ce qui est passé et ce qui a échoué. */}
            {lot?.etat === "fini" && lot.bilan && (
              <div style={{ marginTop: 10 }}>
                <p className="small" style={{ marginBottom: 6 }}>
                  <b>{lot.bilan.filter((x) => !x.erreur).length} chapitre(s) versés</b>
                  {lot.bilan.some((x) => x.erreur)
                    ? " · " + lot.bilan.filter((x) => x.erreur).length + " en échec" : ""}
                </p>
                {lot.bilan.map((x, k) => (
                  <div className="row" key={k} style={{ gap: 8, padding: "2px 0" }}>
                    <span className={"tag " + (x.erreur ? "red" : "green")}>
                      {x.erreur ? "échec" : x.crees + " exos"}
                    </span>
                    <span className="small" style={{ flex: 1 }}>
                      {CHAPITRES.find((c) => c.id === x.chapId)?.nom || x.chapId}
                      {x.erreur ? " — " + x.erreur : ""}
                    </span>
                  </div>
                ))}
              </div>
            )}
            {lot?.etat === "fini" && !lot.bilan && (
              <p className="small" style={{ marginTop: 10 }}>
                {lot.crees && lot.crees.length > 0 && (
                  <><b>{lot.crees.length} exercice(s) créés</b> depuis le manifeste
                    de l'archive. </>
                )}
                <b>{lot.total - lot.inconnus.length} fichier(s) rattachés.</b>
                {lot.inconnus.length > 0 && (
                  <> {lot.inconnus.length} non reconnu(s) :{" "}
                    <span className="muted">{lot.inconnus.slice(0, 4).join(", ")}
                    {lot.inconnus.length > 4 ? "…" : ""}</span></>
                )}
                {!supabaseActif && (
                  <><br /><span className="muted">La base n'est pas branchée : ces fichiers
                  disparaîtront au rechargement.</span></>
                )}
              </p>
            )}
            {lot?.etat === "erreur" && (
              <p className="small" style={{ marginTop: 10, color: "var(--red, #C0392B)" }}>
                L'archive n'a pas pu être lue. {lot.message}
              </p>
            )}
          </div>

          <div className="card" ref={formBiblio}>
            <div className="between">
              <h3>Ajouter un exercice</h3>
              <span className="tag">{CHAPITRES.find((c) => c.id === chapId)?.court}</span>
            </div>
            <div className="chips longue" style={{ marginTop: 12 }}>
              {CHAPITRES.map((c) => <button key={c.id} className={"chip" + (chapId === c.id ? " on" : "")} onClick={() => setChapId(c.id)}>{c.court}</button>)}
            </div>
            <p className="small muted" style={{ marginTop: 14 }}>Catégorie</p>
            <div className="chips" style={{ marginTop: 8 }}>
              {USAGES.map((u) => (
                <button key={u.id} className={"chip" + (form.usage === u.id ? " on" : "")} onClick={() => setForm({ ...form, usage: u.id })}>{u.nom}</button>
              ))}
            </div>
            <p className="small muted" style={{ marginTop: 6 }}>{USAGES.find((u) => u.id === form.usage).desc}</p>
            <input className="inp" style={{ width: "100%", marginTop: 12 }} placeholder="Titre de l'exercice"
              value={form.titre} onChange={(e) => setForm({ ...form, titre: e.target.value })} />
            <input className="inp" style={{ width: "100%", marginTop: 10 }}
              placeholder="Lien de l'énoncé (PDF)"
              value={form.url || ""} onChange={(e) => setForm({ ...form, url: e.target.value })} />
            <input className="inp" style={{ width: "100%", marginTop: 10 }}
              placeholder="Lien du corrigé (PDF) — débloqué en fin de chronomètre"
              value={form.urlCorrige || ""} onChange={(e) => setForm({ ...form, urlCorrige: e.target.value })} />
            {/* Une évaluation blanche dure deux heures : rien à choisir. Un
                exercice d'entraînement se dépose en 15, 20 ou 30 min. */}
            {form.usage === "evaluation" ? (
              <p className="small muted" style={{ marginTop: 12 }}>
                Durée fixée à 2 h, pour toutes les épreuves blanches.
              </p>
            ) : (
              <div className="row" style={{ marginTop: 12 }}>
                <span className="small muted">Durée</span>
                {[15, 20, 30].map((d) =>
                  <button key={d} className={"chip" + (form.duree === d ? " on" : "")} onClick={() => setForm({ ...form, duree: d })}>{d} min</button>)}
              </div>
            )}
            <p className="small muted" style={{ marginTop: 12 }}>
              Sans lien d'énoncé, l'exercice apparaît dans le planning mais l'élève ne
              peut pas l'ouvrir. Le corrigé, lui, reste verrouillé jusqu'à la fin du
              chronomètre.
            </p>
            <button className="btn btn-gold btn-block" style={{ marginTop: 14 }} onClick={ajouter}>Ajouter à la bibliothèque</button>
          </div>

          {USAGES.map((u) => {
            const liste = (biblio[chapId] || []).filter((e) => e.usage === u.id);
            const total = liste.reduce((a, e) => a + e.duree, 0);
            const manque = u.id === "evaluation" && total < 120;
            return (
              <div className="card" key={u.id}>
                <div className="between">
                  <h3>{u.nom}</h3>
                  <span className={"tag " + (liste.length ? (manque ? "gold" : "green") : "red")}>
                    {liste.length} exercice(s) · {total} min
                  </span>
                </div>
                <p className="small muted" style={{ marginTop: 4 }}>{u.desc}</p>
                {liste.map((e) => (
                  <div key={e.id}>
                  <div className="res">
                    <span className="ico"><Icon d={I.pdf} size={18} /></span>
                    <div style={{ flex: 1 }}>
                      <h4>{e.titre}</h4>
                      {/* Le niveau a disparu : ce qui compte est le geste que
                          l'exercice travaille, pas une difficulté déclarée. */}
                      <p className="small muted">
                        {e.duree} min{(e.qt || []).length ? " · " + e.qt.join(", ") : ""}
                      </p>
                    </div>
                    {/* Un exercice sans énoncé déposé ne peut pas être travaillé :
                        il faut que ça se voie d'un coup d'œil, et se corriger sur place. */}
                    <span className={"tag " + (e.url ? (e.urlCorrige ? "green" : "gold") : "red")}>
                      {e.url ? (e.urlCorrige ? "complet" : "sans corrigé") : "sans énoncé"}
                    </span>
                    <button className="btn btn-ghost btn-sm"
                      onClick={() => setExoOuvert(exoOuvert === e.id ? null : e.id)}>
                      {exoOuvert === e.id ? "Fermer" : "Fichiers"}
                    </button>
                  </div>

                  {exoOuvert === e.id && (
                    <div style={{ padding: "10px 0 14px", borderBottom: "1px solid var(--line)" }}>
                      <p className="small muted">
                        Déposez les deux PDF depuis votre téléphone, ou collez un lien.
                      </p>

                      <input type="file" accept="application/pdf,image/*" style={{ display: "none" }}
                        ref={(el) => { champsExo.current[e.id + "-e"] = el; }}
                        onChange={async (ev) => {
                          const f = (ev.target.files || [])[0]; if (!f) return;
                          /* DÉBALLER LA RÉPONSE : en cas d'échec du stockage,
                             « deposerFichier » rend un objet, pas une adresse.
                             Posé tel quel, il passait pour un fichier déposé —
                             l'étiquette affichait « complet » sans rien
                             derrière. */
                          const rep = await deposerFichier("exercices/" + chapId, f);
                          const url = typeof rep === "string" ? rep : rep?.url;
                          if (typeof rep === "object" && rep?.erreur) {
                            setAvis({ bon: false, txt: "Stockage : " + rep.erreur });
                          }
                          await majExercice(chapId, e.id, { url, nomEnonce: f.name });
                          ev.target.value = "";
                        }} />
                      <input type="file" accept="application/pdf,image/*" style={{ display: "none" }}
                        ref={(el) => { champsExo.current[e.id + "-c"] = el; }}
                        onChange={async (ev) => {
                          const f = (ev.target.files || [])[0]; if (!f) return;
                          const rep = await deposerFichier("corriges/" + chapId, f);
                          const url = typeof rep === "string" ? rep : rep?.url;
                          if (typeof rep === "object" && rep?.erreur) {
                            setAvis({ bon: false, txt: "Stockage : " + rep.erreur });
                          }
                          await majExercice(chapId, e.id, { urlCorrige: url, nomCorrige: f.name });
                          ev.target.value = "";
                        }} />

                      <div className="row" style={{ marginTop: 10, gap: 8 }}>
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => champsExo.current[e.id + "-e"]?.click()}>
                          {e.url ? "Remplacer l'énoncé" : "Déposer l'énoncé"}
                        </button>
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => champsExo.current[e.id + "-c"]?.click()}>
                          {e.urlCorrige ? "Remplacer le corrigé" : "Déposer le corrigé"}
                        </button>
                      </div>
                      {(e.nomEnonce || e.nomCorrige) && (
                        <p className="small muted" style={{ marginTop: 8 }}>
                          {e.nomEnonce ? "Énoncé : " + e.nomEnonce : ""}
                          {e.nomEnonce && e.nomCorrige ? " · " : ""}
                          {e.nomCorrige ? "Corrigé : " + e.nomCorrige : ""}
                        </p>
                      )}

                      <input className="inp" style={{ width: "100%", marginTop: 10 }}
                        placeholder="…ou lien de l'énoncé (https://)"
                        defaultValue={String(e.url || "").startsWith("http") ? e.url : ""}
                        onBlur={(ev) => majExercice(chapId, e.id, { url: ev.target.value.trim() || null })} />
                      <input className="inp" style={{ width: "100%", marginTop: 8 }}
                        placeholder="…ou lien du corrigé (https://)"
                        defaultValue={String(e.urlCorrige || "").startsWith("http") ? e.urlCorrige : ""}
                        onBlur={(ev) => majExercice(chapId, e.id, { urlCorrige: ev.target.value.trim() || null })} />
                    </div>
                  )}
                  </div>
                ))}
                {!liste.length && <p className="small muted" style={{ marginTop: 10 }}>Aucun exercice dans cette catégorie pour ce chapitre.</p>}
                {manque && (
                  <p className="small" style={{ marginTop: 10, color: "#7A5A12" }}>
                    Réserve courte : {total} min disponibles. Pour composer une épreuve blanche d'une heure sans réutiliser
                    un exercice déjà vu, comptez au moins 2 h d'exercices réservés par chapitre.
                  </p>
                )}
              </div>
            );
          })}
        </>
      )}
    </div>
  );
}
